#!/usr/bin/expect


set THISHOST [string toupper [info hostname]]
set myindex [expr [string first . $THISHOST] -1 ]
set THISHOST_CAPS [string range $THISHOST 0 $myindex ]
set SERVICENAME [lindex $argv 0]
set ACTION [lindex $argv 1]
set USERNAME [lindex $argv 2]

set SCRIPTNAME "shutdown.sh"
if { "$ACTION" == "start" } {
     set SCRIPTNAME "start.sh"
}

puts "Commencing $SCRIPTNAME on $SERVICENAME on  $THISHOST_CAPS  as $USERNAME "

set command "/x/web/$THISHOST_CAPS/$SERVICENAME/$SCRIPTNAME"
spawn bash
match_max 100000
send -- "export PS1='done_prompt '\r"
expect "\ndone_prompt" { }
send -- "sudo -u $USERNAME -S $command\r"
while 1 {
        expect "done_prompt" { break } \
        "Please enter a share password: " { send -- "aardvark\r" }\
        "Enter Share password: " { send -- "aardvark\r" } \
}
send -- "exit\r"
