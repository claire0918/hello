package com.paypal.test.riskgators.linking.lionv2.requestbuilder;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.w3c.dom.Document;

import com.paypal.asf.service.RequestVO;
import com.paypal.riskpayment.FundingRiskAnalyzeRequest;
import com.paypal.test.jaws.file.FileHelper;
import com.paypal.test.riskgators.Common.XMLDocumentUtils;
import com.paypal.test.riskgators.linking.lionv2.dataobject.RPSData;
import com.paypal.vo.serialization.UniversalDeserializer;

public class RPSBuilder {
	private final String Rps_TEMPLATE = "src/test/resources/request/linking/riskpaymentservtemp.xml";
	private final String Rps_OUTPUT= "src/test/resources/request/linking/outgen/riskpaymentserv.xml";
	
	public FundingRiskAnalyzeRequest buildRequest(RPSData dataRow) throws IOException, Exception {
		Properties properties = new Properties();
		properties.put("$sacctnum", dataRow.getSAccountNum());
		properties.put("$cacctnum", dataRow.getCAccountNum());
		properties.put("$semail", dataRow.getSEmail());
		properties.put("$cemail", dataRow.getCEmail());
		properties.put("$session_id", dataRow.getSessionId());
		properties.put("$vid", dataRow.getVID());
		properties.put("$sfname", dataRow.getSFName());
		properties.put("$slname", dataRow.getSLName());
		properties.put("$cfname", dataRow.getCFName());
		properties.put("$clname", dataRow.getCLName());
		properties.put("$sname", dataRow.getSName());
		

		Document reqDoc = 
			XMLDocumentUtils.convertStrAsDocument(FileUtils.readFileToString(new File(Rps_TEMPLATE)), true);
				
		String new_req = XMLDocumentUtils.populateWithData(reqDoc, properties);
		
		try{
		FileOutputStream fileo = new FileOutputStream(new File(Rps_OUTPUT));
		fileo.write(new_req.getBytes());
		fileo.close();
		} catch(IOException e){System.out.println("Error: "+e.getMessage()+"\n");}

		UniversalDeserializer uDeserializer = new UniversalDeserializer();			
		InputStream is = FileHelper.loadFile(new File(Rps_OUTPUT));	

		
		RequestVO requestvo = new RequestVO();
		uDeserializer.deserialize(is, requestvo);
		return (FundingRiskAnalyzeRequest) requestvo.getParams();
		
		
	}

}
