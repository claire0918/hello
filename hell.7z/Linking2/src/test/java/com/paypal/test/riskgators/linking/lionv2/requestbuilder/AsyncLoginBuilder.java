package com.paypal.test.riskgators.linking.lionv2.requestbuilder;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.w3c.dom.Document;

import com.paypal.asf.service.RequestVO;
import com.paypal.risk.AsyncPostLoginRequest;
import com.paypal.test.jaws.file.FileHelper;
import com.paypal.test.riskgators.Common.XMLDocumentUtils;
import com.paypal.test.riskgators.linking.lionv2.dataobject.AsyncLoginData;
import com.paypal.vo.serialization.UniversalDeserializer;

public class AsyncLoginBuilder {
	private final String Async_TEMPLATE = "src/test/resources/request/linking/riskloginasynctemp.xml";
	private final String Async_OUTPUT= "src/test/resources/request/linking/outgen/asyncloginserv.xml";
	
	public AsyncPostLoginRequest buildRequest(AsyncLoginData dataRow) throws IOException, Exception {
		Properties properties = new Properties();
		properties.put("$accountnum", dataRow.getAccountNum());
		properties.put("$serializedata", dataRow.getSerialized_data());
		properties.put("$eventid", dataRow.getEventId());
		properties.put("$sesson_id", dataRow.getSessionId());
		
		Document reqDoc = 
			XMLDocumentUtils.convertStrAsDocument(FileUtils.readFileToString(new File(Async_TEMPLATE)), true);
				
		String new_req = XMLDocumentUtils.populateWithData(reqDoc, properties);
		
		try{
		FileOutputStream fileo = new FileOutputStream(new File(Async_OUTPUT));
		fileo.write(new_req.getBytes());
		fileo.close();
		} catch(IOException e){System.out.println("Error: "+e.getMessage()+"\n");}

		UniversalDeserializer uDeserializer = new UniversalDeserializer();			
		InputStream is = FileHelper.loadFile(new File(Async_OUTPUT));	

		
		RequestVO requestvo = new RequestVO();
		uDeserializer.deserialize(is, requestvo);
		return (AsyncPostLoginRequest) requestvo.getParams();
	}

}
