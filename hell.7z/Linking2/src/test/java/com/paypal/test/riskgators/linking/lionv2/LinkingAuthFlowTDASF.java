package com.paypal.test.riskgators.linking.lionv2;

import static org.testng.Assert.assertEquals;

import com.paypal.infra.asf.core.ASFRequest;
import java.io.IOException;
import java.sql.ResultSet;
import org.testng.annotations.Test;


import com.paypal.test.bluefin.platform.config.BluefinConfig;
import com.paypal.test.bluefin.platform.config.BluefinConfig.BluefinConfigProperty;
import com.paypal.test.bluefin.platform.utilities.ExcelDataProvider;

import com.paypal.riskverification.CPAuthFlowRequest;
import com.paypal.riskverification.RiskVerificationClientImpl;


import java.util.logging.Level;

import org.testng.annotations.DataProvider;

import com.paypal.test.jaws.db.DatabaseName;
import com.paypal.test.jaws.db.JDBCUtils;

import com.paypal.test.jaws.logging.JawsLogger;
import com.paypal.test.jaws.logging.SimpleLogger;

import com.paypal.test.jaws.utilities.asf.ASFClientAssistant;
import com.paypal.test.jaws.utilities.asf.ASFServiceInfo;
import com.paypal.test.riskgators.linking.lionv2.dataobject.AuthFlowData;
import com.paypal.test.riskgators.linking.lionv2.requestbuilder.AuthFlowBuilder;

import org.testng.annotations.BeforeClass;


public class LinkingAuthFlowTDASF {
	private final String EXL_DATA_FILE = "src/test/resources/testdata/linking/stage2p2370/AuthFlowData.xls";
	private ExcelDataProvider dataProvider = null;

	
	@BeforeClass
	public void initialize() throws IOException {
		dataProvider = new ExcelDataProvider(EXL_DATA_FILE);
	}

	@DataProvider(name = "AuthFlowData")
	public Object[][] myExcelsheetReader() {
		Object[][] data = null;
		AuthFlowData dataRow = new AuthFlowData();
		try {
			data = dataProvider.getAllExcelRows(dataRow);
		} catch (Exception e) {
			JawsLogger.getLogger().severe("Error reading Excel rows.");	
			throw new RuntimeException(
					"Error reading Excel rows. Root cause: ", e);
		}

		return data;
	}


	@Test(dataProvider = "AuthFlowData", groups = "RiskGatorsRQA")
	public void LinkingSignUPTDASFTest(AuthFlowData data) throws IOException,
			Exception {
		String hostname = BluefinConfig.getConfigProperty(BluefinConfigProperty.HOSTNAME);		
		SimpleLogger logger = (SimpleLogger) JawsLogger.getLogger();
		logger.log(Level.INFO,"Stage is: "+hostname+"\n");

		
		if (data.getFLAG().equals("POSITIVE")) {
			
			//prepare

			System.out.println("\n//////////////////////////////////////////////////////////////////////"
								+ "\n Start testing \""
								+ data.getTCName()
								+ "\"..."
								+ "\n//////////////////////////////////////////////////////////////////////");
			
			// build request
			AuthFlowBuilder reqBuilder = new AuthFlowBuilder();
			CPAuthFlowRequest cpAuthFlowReq = reqBuilder.buildRequest(data);
		

			// build SSL handshake ASFService
			ASFServiceInfo info = new ASFServiceInfo("riskverificationserv",RiskVerificationClientImpl.class.getCanonicalName()); // what's
			RiskVerificationClientImpl client = (RiskVerificationClientImpl) ASFClientAssistant.createClient(info);	
			
		
			ASFRequest<CPAuthFlowRequest> request = new ASFRequest<CPAuthFlowRequest>(cpAuthFlowReq);

			System.out.println("Request Email: " + request.getRequestVO().getAccountVo().getPrimaryEmailName()+"\n");
		
			//CPAuthFlowResponse cpAuthFlowRep = new CPAuthFlowResponse();
			//ASFResponse<CPAuthFlowResponse> response = new ASFResponse<CPAuthFlowResponse>(cpAuthFlowRep, null, null, null);

			client.CPAuthFlow(request);

			
			//Check Database //do db verify String
			 String query="select * from wrule_checkpoint_log where id in (select checkpoint_log_id from wrule_log where rule_id="+data.getRuleID()+" and account_number="+data.getAccountNum()+" and server='RVS')and rownum<2 order by time_created desc";
		  	 JDBCUtils jdbc = null;
		  	 ResultSet rs = null;
		     jdbc = new JDBCUtils(DatabaseName.RISK);
		  	 jdbc.createConnection();
		  	 rs=jdbc.executeQuery(query);
		  	 rs.next();
		  	 System.out.println("Rule ID: "+data.getRuleID()+"\n");
		  	 assertEquals(rs.getString("CHECKPOINT"),"AuthFlow","The rule is not triggered\n");
		  	 rs.close();
		  	 jdbc.closeConnection();	 

				
		}
	}
}


