package com.paypal.test.riskgators.linking.lionv2;

import static org.testng.Assert.assertEquals;
import com.paypal.infra.asf.core.ASFRequest;
import java.io.IOException;
import java.sql.ResultSet;
import org.testng.annotations.Test;
import com.paypal.test.bluefin.platform.config.BluefinConfig;
import com.paypal.test.bluefin.platform.config.BluefinConfig.BluefinConfigProperty;
import com.paypal.test.bluefin.platform.utilities.ExcelDataProvider;
import com.paypal.riskpayment.FundingRiskAnalyzeRequest;
import com.paypal.riskpayment.RiskPaymentClientImpl;
import java.util.logging.Level;
import org.testng.annotations.DataProvider;
import com.paypal.test.jaws.db.DatabaseName;
import com.paypal.test.jaws.db.JDBCUtils;
import com.paypal.test.jaws.execution.Execution;
import com.paypal.test.jaws.file.StageFileHelper;
import com.paypal.test.jaws.logging.JawsLogger;
import com.paypal.test.jaws.logging.SimpleLogger;
import com.paypal.test.jaws.utilities.asf.ASFClientAssistant;
import com.paypal.test.jaws.utilities.asf.ASFServiceInfo;
import com.paypal.test.riskgators.linking.lionv2.dataobject.RPSData;
import com.paypal.test.riskgators.linking.lionv2.requestbuilder.RPSBuilder;
import org.testng.annotations.BeforeClass;


public class LinkingRPSFlowTDASF {

	private final String EXL_DATA_FILE = "src/test/resources/testdata/linking/stage2p2370/RiskPaymentData.xls";
	private ExcelDataProvider dataProvider = null;

	
	@BeforeClass
	public void initialize() throws IOException {
		dataProvider = new ExcelDataProvider(EXL_DATA_FILE);
	}

	@DataProvider(name = "RPSData")
	public Object[][] myExcelsheetReader() {
		Object[][] data = null;
		RPSData dataRow = new RPSData();
		try {
			data = dataProvider.getAllExcelRows(dataRow);
		} catch (Exception e) {
			JawsLogger.getLogger().severe("Error reading Excel rows.");	
			throw new RuntimeException(
					"Error reading Excel rows. Root cause: ", e);
		}

		return data;
	}

	@Test(dataProvider = "RPSData", groups = "RiskGatorsRQA")
	public void LinkingSignUPTDASFTest(RPSData data) throws IOException,
			Exception {
		
		String hostname = BluefinConfig.getConfigProperty(BluefinConfigProperty.HOSTNAME);		
		SimpleLogger logger = (SimpleLogger) JawsLogger.getLogger();
		logger.log(Level.INFO,"Stage is: "+hostname+"\n");

		
		if (data.getFLAG().equals("POSITIVE")) {
			
			//prepare

			System.out.println("\n//////////////////////////////////////////////////////////////////////"
								+ "\n Start testing \""
								+ data.getTCName()
								+ "\"..."
								+ "\n//////////////////////////////////////////////////////////////////////");
			
			// build request
			RPSBuilder reqBuilder = new RPSBuilder();
			
			FundingRiskAnalyzeRequest fundingRiskAlyReq = reqBuilder.buildRequest(data);
			
			

			// build SSL handshake ASFService
			ASFServiceInfo info = new ASFServiceInfo("riskpaymentserv",RiskPaymentClientImpl.class.getCanonicalName());
			
		    String fileName = "/x/web/" + BluefinConfig.getConfigProperty(BluefinConfigProperty.STAGE_NAME) + "/riskpaymentserv/protected/riskpaymentserv_trusted_clients.pem";

		    if (! StageFileHelper.exists(fileName)){
		    	Execution.executeCommandOnStage("touch " + fileName);
		    	Execution.executeCommandOnStage("chmod 777" + fileName);
		    	}


	
			RiskPaymentClientImpl client = (RiskPaymentClientImpl) ASFClientAssistant.createClient(info);
			
			ASFRequest<FundingRiskAnalyzeRequest> request = new ASFRequest<FundingRiskAnalyzeRequest>(fundingRiskAlyReq);
			
			System.out.println("Request Actor AccountNumber: " + request.getRequestVO().getActorInfo().getActorAccountNumber()+"\n");
			
			
			//FundingRiskAnalyzeResponse fundingRiskAlyRep = new FundingRiskAnalyzeResponse();
					
			//ASFResponse<FundingRiskAnalyzeResponse> response = new ASFResponse<FundingRiskAnalyzeResponse>(fundingRiskAlyRep, null, null, null);

			client.funding_risk_analyze(request);
			
		
			
			
			//Check Database //do db verify String
		 	String query="select * from wrule_checkpoint_log where id in (select checkpoint_log_id from wrule_log where rule_id="+data.getRuleID()+" and account_number="+data.getAccountNum()+" and server='RPS') and rownum<2 order by time_created desc"; 
			JDBCUtils jdbc = null;
		  	ResultSet rs = null;
		    jdbc = new JDBCUtils(DatabaseName.RISK);
		  	jdbc.createConnection();
		  	rs=jdbc.executeQuery(query);
		  	rs.next();
			System.out.println("Rule ID: "+data.getRuleID()+"\n");
			assertEquals(rs.getString("CHECKPOINT"),"ConsolidatedFunding","The rule is not triggered\n");
			rs.close();
			jdbc.closeConnection();
			
		}
	}
}


