package com.paypal.test.riskgators.linking.lionv2.dataobject;

public class AuthFlowData {
	private String FLAG;
	private String TCName;
	private String Email;
	private String FName;
	private String LName;
	private String VID;
	private String FSO;
	private String AccountNum;
	private String SessionID;
	private String HashValue;
	private String Serialized_data;
	private String Action;
	private String RuleID;
	
	
	public String getFLAG(){
		return FLAG;
	}
	
	public String getTCName(){
		return TCName;
	}
	
	public String getEmail(){
		return Email;
	}
	
	public String getFName(){
		return FName;
	}
	
	public String getLName(){
		return LName;
	}
	
	public String getVID(){
		return VID;
	}
	
	public String getFSO(){
		return FSO;
	}
	
	public String getAccountNum(){
		return AccountNum;
	}
	
	public String getSessionID(){
		return SessionID;
	}
	
	public String getHashValue(){
		return HashValue;
	}
	
	public String getSerialized_data(){
		return Serialized_data;
	}
	
	public String getAction(){
		return Action;
	}
	
	public String getRuleID(){
		return RuleID;
	}
	
	public void setFLAG(String flag){
		FLAG = flag;
	}
	
	public void setTCName(String tcname){
		TCName = tcname;
	}
	
	public void setEmail(String email){
		Email = email;
	}
	
	public void setFName(String fname){
		FName = fname;
	}
	
	public void setLName(String lname){
		LName = lname;
	}
	
	public void setVID(String vid){
		VID = vid;
	}
	
	public void setFSO(String fso){
		FSO = fso;
	}
	
	public void setAccountNum(String accountnum){
		AccountNum = accountnum;
	}
	
	public void setSessionID(String sessionid){
		SessionID = sessionid;
	}
	
	public void setHashValue(String hashvalue){
		HashValue = hashvalue;
	}
	
	public void setSerialized_data(String serialized_data){
		Serialized_data = serialized_data;
	}
	
	public void setAction(String action){
		Action = action;
	}
	
	public void setRuleID(String ruleid){
		RuleID = ruleid;
	}

}
