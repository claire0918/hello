package com.paypal.test.riskgators.linking.lionv2.dataobject;

public class RPSData {
	private String FLAG;
	private String TCName;
	private String S_Email;
	private String S_Name;
	private String S_FName;
	private String S_LName;
	private String C_Email;
	private String C_FName;
	private String C_LName;
	private String VID;
	private String FSO;
	private String SessionId;
	private String S_AccountNum;
	private String C_AccountNum;
	private String AccountNum;
	private String Action;
	private String RuleID;

	
	

	public String getFLAG(){
		return FLAG;
	}
	
	public String getTCName(){
		return TCName;
	}
	
	
	
	public String getSEmail(){
		return S_Email;
	}
	
	public String getSName(){
		return S_Name;
	}
	
	public String getSFName(){
		return S_FName;
	}
	
	public String getSLName(){
		return S_LName;
	}
	
	public String getCEmail(){
		return C_Email;
	}
	
	public String getCFName(){
		return C_FName;
	}
	
	public String getCLName(){
		return C_LName;
	}
	
	public String getVID(){
		return VID;
	}
	
	public String getFSO(){
		return FSO;
	}


	public String getSessionId(){
		return SessionId;
	}

	
	public String getSAccountNum(){
		return S_AccountNum;
	}
	
	public String getCAccountNum(){
		return C_AccountNum;
	}
	
	public String getAccountNum(){
		return AccountNum;
	}
	
	public String getAction(){
		return Action;
	}
	
	public String getRuleID(){
		return RuleID;
	}
	

	
	public void setFLAG(String flag){
		FLAG = flag;
	}
	
	public void setTCName(String tcname){
		TCName = tcname;
	}
	
	public void setSEmail(String s_email){
		S_Email = s_email;
	}
	
	public void setSName(String s_name){
		S_Name = s_name;
	}
		
	public void setSFName(String s_fname){
		S_FName = s_fname;
	}
	
	public void setSLName(String s_lname){
		S_LName = s_lname;
	}
	
	
	public void setCEmail(String c_email){
		C_Email = c_email;
	}
	
	public void setCFName(String c_fname){
		C_FName = c_fname;
	}
	
	public void setCLName(String c_lname){
		C_LName = c_lname;
	}
	
	public void setVID(String vid){
		VID = vid;
	}
	
	public void setFSO(String fso){
		FSO = fso;
	}
	
	public void setSessionId(String sessionid){
		SessionId = sessionid;
	}
	
	
	public void setSAccountNum(String s_accountnum){
		S_AccountNum = s_accountnum;
	}
	
	public void setCAccountNum(String c_accountnum){
		C_AccountNum = c_accountnum;
	}

	public void setAccountNum(String accountnum){
		AccountNum = accountnum;
	}
	
	public void setAction(String action){
		Action = action;
	}
	
	public void setRuleID(String ruleid){
		RuleID = ruleid;
	}

}
