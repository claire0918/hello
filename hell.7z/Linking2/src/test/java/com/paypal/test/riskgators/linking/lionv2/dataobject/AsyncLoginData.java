package com.paypal.test.riskgators.linking.lionv2.dataobject;

public class AsyncLoginData {
	private String FLAG;
	private String TCName;
	private String Email;
	private String FName;
	private String LName;
	private String VID;
	private String FSO;
	private String SessionId;
	private String EventId;
	private String AccountNum;
	private String HashValue;
	private String Serialized_data;
	private String Action;
	private String RuleID;
	
	
	public String getFLAG(){
		return FLAG;
	}
	
	public String getTCName(){
		return TCName;
	}
	
	public String getEmail(){
		return Email;
	}
	
	public String getFName(){
		return FName;
	}
	
	public String getLName(){
		return LName;
	}
	
	public String getVID(){
		return VID;
	}
	
	public String getFSO(){
		return FSO;
	}
	public String getSessionId(){
		return SessionId;
	}
	
	public String getEventId(){
		return EventId;
	}
	
	public String getAccountNum(){
		return AccountNum;
	}
	
	public String getHashValue(){
		return HashValue;
	}
	
	public String getSerialized_data(){
		return Serialized_data;
	}
	
	public String getAction(){
		return Action;
	}
	
	public String getRuleID(){
		return RuleID;
	}
	
	public void setFLAG(String flag){
		FLAG = flag;
	}
	
	public void setTCName(String tcname){
		TCName = tcname;
	}
	
	public void setEmail(String email){
		Email = email;
	}
	
	public void setFName(String fname){
		FName = fname;
	}
	
	public void setLName(String lname){
		LName = lname;
	}
	
	public void setVID(String vid){
		VID = vid;
	}
	
	public void setFSO(String fso){
		FSO = fso;
	}
	
	public void setSessionId(String sessionid){
		SessionId = sessionid;
	}
	
	public void setEventId(String eventid){
		EventId = eventid;
	}
	
	public void setAccountNum(String accountnum){
		AccountNum = accountnum;
	}
	
	public void setHashValue(String hashvalue){
		HashValue = hashvalue;
	}
	
	public void setSerialized_data(String serialized_data){
		Serialized_data = serialized_data;
	}
	
	public void setAction(String action){
		Action = action;
	}
	
	public void setRuleID(String ruleid){
		RuleID = ruleid;
	}

}
