package com.paypal.test.riskgators.linking.lionv2.setup;

import java.io.IOException;

import org.testng.annotations.Test;

import com.paypal.test.riskgators.Common.LinkingUtil;

public class LinkingEnvSetup {
	@Test
	public void StageSetup() throws IOException{
		
		LinkingUtil.LinkingModelPrepare();
		
		
	}

}
