package com.paypal.test.riskgators.linking.lionv2.requestbuilder;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.w3c.dom.Document;

import com.paypal.asf.service.RequestVO;
import com.paypal.riskverification.CPAuthFlowRequest;
import com.paypal.test.jaws.file.FileHelper;
import com.paypal.test.riskgators.Common.XMLDocumentUtils;
import com.paypal.test.riskgators.linking.lionv2.dataobject.AuthFlowData;
import com.paypal.vo.serialization.UniversalDeserializer;

public class AuthFlowBuilder {
	private final String SignUp_OUTPUT= "src/test/resources/request/linking/outgen/riskverificationserv.xml";
	private final String SignUp_TEMPLATE= "src/test/resources/request/linking/riskverificationservtemp.xml";

	public CPAuthFlowRequest buildRequest(AuthFlowData dataRow)throws IOException,Exception {
		String semail="tingzhang"+System.currentTimeMillis()+"@paypal.com";
			
		Properties properties = new Properties();
		properties.put("$accountnum", dataRow.getAccountNum());
		properties.put("$vid",dataRow.getVID());
		properties.put("$fname",dataRow.getFName());
		properties.put("$lname",dataRow.getLName());
		properties.put("$serializedata", dataRow.getSerialized_data());
		properties.put("$session_id",dataRow.getSessionID());
		properties.put("$acctemail",semail);

		
		Document reqDoc = 
			XMLDocumentUtils.convertStrAsDocument(FileUtils.readFileToString(new File(SignUp_TEMPLATE)), true);		
		

		
		String new_req = XMLDocumentUtils.populateWithData(reqDoc, properties);
		
		try{
		FileOutputStream fileo = new FileOutputStream(new File(SignUp_OUTPUT));
		fileo.write(new_req.getBytes());
		fileo.close();
		} catch(IOException e){System.out.println("Error: "+e.getMessage()+"\n");}

		UniversalDeserializer uDeserializer = new UniversalDeserializer();			
		InputStream is = FileHelper.loadFile(new File(SignUp_OUTPUT));	

		RequestVO requestvo = new RequestVO();
		uDeserializer.deserialize(is, requestvo);
		return (CPAuthFlowRequest) requestvo.getParams();
		
	}
}
