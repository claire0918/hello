package com.paypal.test.riskgators.linking.lionv2.setup;

import java.io.IOException;

import org.testng.annotations.Test;

import com.paypal.test.riskgators.Common.LinkingUtil;

public class DBPrepare {
	@Test
	public void StageDBPrepare() throws IOException{
		
		//LinkingUtil.CleanUpDB();
		LinkingUtil.InsertDB();
	
	}

}
