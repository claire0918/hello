package com.paypal.test.riskgators.linking.lionv2;

import static org.testng.Assert.assertEquals;

import java.io.IOException;
import java.sql.ResultSet;
import java.util.logging.Level;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.paypal.infra.asf.core.ASFRequest;
import com.paypal.risk.AsyncPostLoginRequest;
import com.paypal.risk.RiskLoginAsyncClientImpl;
import com.paypal.test.bluefin.platform.config.BluefinConfig;
import com.paypal.test.bluefin.platform.config.BluefinConfig.BluefinConfigProperty;
import com.paypal.test.bluefin.platform.utilities.ExcelDataProvider;
import com.paypal.test.jaws.db.DatabaseName;
import com.paypal.test.jaws.db.JDBCUtils;
import com.paypal.test.jaws.logging.JawsLogger;
import com.paypal.test.jaws.logging.SimpleLogger;
import com.paypal.test.jaws.utilities.asf.ASFClientAssistant;
import com.paypal.test.jaws.utilities.asf.ASFServiceInfo;
import com.paypal.test.riskgators.linking.lionv2.dataobject.AsyncLoginData;
import com.paypal.test.riskgators.linking.lionv2.requestbuilder.AsyncLoginBuilder;


public class LinkingAsyncLoginTDASF {
	
	
	
	private final String EXL_DATA_FILE="src/test/resources/testdata/linking/stage2p2370/AsyncLoginData.xls";
	private ExcelDataProvider dataProvider = null;
	
	@BeforeClass
	public void initialize() throws IOException {
		dataProvider = new ExcelDataProvider(EXL_DATA_FILE);
	}

	@DataProvider(name = "AsyncLoginData")
	public Object[][] myExcelsheetReader() {
		Object[][] data = null;
		AsyncLoginData dataRow = new AsyncLoginData();
		try {
			data = dataProvider.getAllExcelRows(dataRow);
		} catch (Exception e) {
			JawsLogger.getLogger().severe("Error reading Excel rows.");
			throw new RuntimeException(
					"Error reading Excel rows. Root cause: ", e);
		}

		return data;
	}



	@Test(dataProvider = "AsyncLoginData", testName = "RGRI1394102F", groups = "RiskGatorsRQA" )
	public void LinkingAsyncLoginTDASFTest(AsyncLoginData data) throws IOException,
			Exception {
		String hostname = BluefinConfig.getConfigProperty(BluefinConfigProperty.HOSTNAME);		
		SimpleLogger logger = (SimpleLogger) JawsLogger.getLogger();
		logger.log(Level.INFO,"Stage is: "+hostname+"\n");

		
		if (data.getFLAG().equals("POSITIVE")) {
			
			//prepare

			System.out.println("\n//////////////////////////////////////////////////////////////////////"
								+ "\n Start testing \""
								+ data.getTCName()
								+ "\"..."
								+ "\n//////////////////////////////////////////////////////////////////////");
			

			// build request
			AsyncLoginBuilder reqBuilder = new AsyncLoginBuilder();
			
			AsyncPostLoginRequest cpAsyncLoginReq = reqBuilder.buildRequest(data);

			

			// build SSL handshake ASFService
			ASFServiceInfo info = new ASFServiceInfo("riskloginasyncserv",RiskLoginAsyncClientImpl.class.getCanonicalName()); // what's
			RiskLoginAsyncClientImpl client = (RiskLoginAsyncClientImpl) ASFClientAssistant.createClient(info);	
			
		
			ASFRequest<AsyncPostLoginRequest> request = new ASFRequest<AsyncPostLoginRequest>(cpAsyncLoginReq);

			System.out.println("Request AccountNumber: " + request.getRequestVO().getActorInfo().getActorAccountNumber()+"\n");

			client.async_post_login(request);
	
			
			
			//Check Database //do db verify String
			 String query="select * from wrule_checkpoint_log where id in (select checkpoint_log_id from wrule_log where rule_id="+data.getRuleID()+" and account_number="+data.getAccountNum()+") and rownum<2 order by time_created desc";
		  	 JDBCUtils jdbc = null;
		  	 ResultSet rs = null;
		     jdbc = new JDBCUtils(DatabaseName.RISK);
		  	 jdbc.createConnection();
		  	 rs=jdbc.executeQuery(query);
		  	 rs.next();
		  	 System.out.println("Rule ID: "+data.getRuleID()+"\n");
		   	 assertEquals(rs.getString("CHECKPOINT"),"AsyncLogin","The rule is not triggered\n");
		  	 rs.close();
		  	 jdbc.closeConnection();	 

				
		}
	}
}
