/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/SellerPropertyInfoVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:41 2012 */

package com.paypal.money;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
  * 
   */

public class SellerPropertyInfoVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((6041*6041)<<32)/*<-SellerPropertyInfoVO*/+
         		26071/*<-business_type*/*38894/*<-int*/+
         		20001/*<-business_name*/*18443/*<-String*/+
         		43047/*<-seller_ebay_id*/*18443/*<-String*/+
         		21250/*<-risk_auction_rating_info*/*com.paypal.risk.AuctionRatingInfoVO.TYPE_SIGNATURE/*<-Risk::AuctionRatingInfoVO*/;
 
	public SellerPropertyInfoVO() {
		super("Money::SellerPropertyInfoVO", TYPE_SIGNATURE);

 		addFieldQualifier("business_type","required","false");
 
		set("business_type", null, "int");
 		addFieldQualifier("business_name","required","false");
 
		set("business_name", null, "String");
 		addFieldQualifier("seller_ebay_id","required","false");
 
		set("seller_ebay_id", null, "String");
 		addFieldQualifier("risk_auction_rating_info","required","false");
 
		set("risk_auction_rating_info", null, "Risk::AuctionRatingInfoVO");
	}

	// {{{
	public void setBusinessType(Integer value) { this.set("business_type", (Object)value); }
 	public Integer getBusinessType() { return (Integer)this.get("business_type"); }
	// }}}
	// {{{
	public void setBusinessName(String value) { this.set("business_name", (Object)value); }
 	public String getBusinessName() { return (String)this.get("business_name"); }
	// }}}
	// {{{
	public void setSellerEbayId(String value) { this.set("seller_ebay_id", (Object)value); }
 	public String getSellerEbayId() { return (String)this.get("seller_ebay_id"); }
	// }}}
	// {{{
	public void setRiskAuctionRatingInfo(com.paypal.risk.AuctionRatingInfoVO value) { this.set("risk_auction_rating_info", (Object)value); }
 	public com.paypal.risk.AuctionRatingInfoVO getRiskAuctionRatingInfo() { return (com.paypal.risk.AuctionRatingInfoVO)this.get("risk_auction_rating_info"); }
	// }}}
}