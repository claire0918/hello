/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/ProductFamilyType.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:40 2012 */

package com.paypal.money;

import java.math.BigInteger;

  
public enum ProductFamilyType {
/**
           Types of high level groups of payment product flows
       */
   	EBAY_CHECKOUT(new String("EBAXO"), ""),
   	CLASSIFIEDS(new String("CLASS"), ""),
   	EXPRESS_CHECKOUT(new String("EXPXO"), ""),
   	WEBSITE_PAYMENT_STANDARD(new String("WEBPS"), ""),
   	EMAIL_SEND_MONEY(new String("EMSMO"), ""),
   	EXTERNAL_SEND_MONEY(new String("EXSMO"), ""),
   	EMAIL_REQUEST_MONEY(new String("EMRMO"), ""),
   	DIRECT_CREDIT_CARD(new String("DCC"), ""),
   	VIRTUAL_TERMINAL(new String("VIRT"), ""),
   	MOBILE(new String("MOBIL"), ""),
   	ADAPTIVE_PAYMENTS(new String("ADAPT"), ""),
   	MASS_PAY(new String("MSPAY"), ""),
   	POSTAGE_PAYMENTS(new String("POSTP"), ""),
   	DEBIT_CARD(new String("DEBCR"), ""),
   	MASS_PAY_V2(new String("MassPayV2"), ""),
   	MASS_PAY_V2_EXT(new String("MSPY2"), "");

	private final String value;
	private final String desc;

	private ProductFamilyType(String value, String desc) {
		this.value = value;
		this.desc  = desc;
	}

	public String getValue() {
		return value;
	}

	public String getDesc() {
		return desc;
	}
}
