/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/ProductType.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:40 2012 */

package com.paypal.money;

import java.math.BigInteger;

  
public enum ProductType {
/**
             Types of payment flows
        */
   	EBAY_CLASSIC_CHECKOUT(new String("EBCXO"), ""),
   	EBAY_CLASSIC_CHECKOUT_MULTI_SELLER(new String("CXOMS"), ""),
   	EBAY_CLASSIC_CHECKOUT_IMMEDIATE_PAY(new String("CXOIP"), ""),
   	EBAY_CLASSIC_CHECKOUT_IMMEDIATE_PAY_MULTI_SELLER(new String("XIPMS"), ""),
   	EBAY_CLASSIC_CHECKOUT_PAY_FOR_EBAY_ITEM(new String("CXOEB"), ""),
   	EBAY_NEXGEN_CHECKOUT(new String("NGXO"), ""),
   	EBAY_NEXT_GEN_CHECKOUT_MULTI_SELLER(new String("NXOMS"), ""),
   	EBAY_NEXT_GEN_CHECKOUT_IMMEDIATE_PAY(new String("NXOIP"), ""),
   	EBAY_NEXT_GEN_CHECKOUT_IMMEDIATE_PAY_MULTI_SELLER(new String("NIPMS"), ""),
   	EBAY_EXPRESS(new String("EXPRE"), ""),
   	MARKETPLAATS(new String("MPLAT"), ""),
   	EXPRESS_CHECKOUT_SHORTCUT(new String("XXOSC"), ""),
   	EXPRESS_CHECKOUT_MARK(new String("XXOMA"), ""),
   	EXPRESS_CHECKOUT_UNIFIED_SHORTCUT(new String("XXOUS"), ""),
   	EXPRESS_CHECKOUT_UNIFIED_MARK(new String("XXOUM"), ""),
   	EXPRESS_CHECKOUT_REFERENCE(new String("XXORF"), ""),
   	EXPRESS_CHECKOUT_RECURRING(new String("XXORE"), ""),
   	EXPRESS_CHECKOUT_PREAPPROVED(new String("XXOPA"), ""),
   	EXPRESS_CHECKOUT_INCONTEXT_FLEXIBLE(new String("XXOIF"), ""),
   	WEBSITE_PAYMENTS_STANDARD(new String("WPSTD"), ""),
   	WEBSITE_PAYMENTS_STANDARD_UNIFIED(new String("WPSTU"), ""),
   	EMAIL_SEND_MONEY(new String("EMSMO"), ""),
   	EMAIL_SEND_MONEY_P2P(new String("SMP2P"), ""),
   	EMAIL_REQUEST_MONEY(new String("EMRMO"), ""),
   	EMAIL_REQUEST_MONEY_P2P(new String("RMP2P"), ""),
   	EMAIL_REQUEST_MONEY_INVOICE(new String("ERMIN"), ""),
   	DIRECT_CREDIT_CARD(new String("DCC"), ""),
   	DIRECT_CREDIT_CARD_RECURRING(new String("DCCR"), ""),
   	VIRTUAL_TERMINAL(new String("VITER"), ""),
   	VIRTUAL_TERMINAL_RECURRING(new String("VTREC"), ""),
   	VIRTUAL_TERMINAL_SWIPE(new String("VTSWI"), ""),
   	MOBILE_CHECKOUT(new String("MOBXO"), ""),
   	MOBILE_EXPRESS_CHECKOUT(new String("MOXXO"), ""),
   	MOBILE_WAP_SEND_MONEY(new String("MOWSM"), ""),
   	MOBILE_WAP_SEND_MONEY_P2P(new String("MWP2P"), ""),
   	MOBILE_WAP_REQUEST_MONEY(new String("MWRM"), ""),
   	MOBILE_WAP_REQUEST_MONEY_P2P(new String("MWRP2"), ""),
   	MOBILE_EMBEDDED(new String("MOEMB"), ""),
   	MOBILE_P2P(new String("MOP2P"), ""),
   	MOBILE_TEXT_TO_BUY(new String("MOT2B"), ""),
   	MOBILE_TEXT_TO_GIVE(new String("MOT2G"), ""),
   	MOBILE_TOPUP(new String("M2PUP"), ""),
   	ADAPTIVE_IMPLICIT(new String("ADIMP"), ""),
   	ADAPTIVE_PREAPPROVED(new String("ADPAP"), ""),
   	ADAPTIVE_SEND_MONEY(new String("ADSMO"), ""),
   	ADAPTIVE_IMPLICIT_PARALLEL(new String("ADIPP"), ""),
   	ADAPTIVE_PREAPPROVED_PARALLEL(new String("APAPP"), ""),
   	ADAPTIVE_IMPLICIT_CHAIN(new String("ADIMC"), ""),
   	ADAPTIVE_PREAPPROVED_CHAIN(new String("ADPAC"), ""),
   	ADAPTIVE_SEND_MONEY_CHAIN(new String("ADSMC"), ""),
   	ADAPTIVE_SEND_MONEY_DIRECT_CREDIT_CARD(new String("SMCC"), ""),
   	ADAPTIVE_SEND_MONEY_DIRECT_CREDIT_CARD_PARALLEL(new String("ASDCP"), ""),
   	ADAPTIVE_SEND_MONEY_DIRECT_CREDIT_CARD_CHAIN(new String("SMCCC"), ""),
   	MASS_PAY(new String("MAPAY"), ""),
   	POSTAGE_PAYMENTS(new String("POPAY"), ""),
   	MERCHANT_POS_SIGNATURE(new String("MPSIG"), ""),
   	MERCHANT_POS_PIN(new String("MPOPI"), ""),
   	MERCHANT_ATM(new String("MEATM"), ""),
   	CONSUMER_POS_SIGNATURE(new String("CPOSI"), ""),
   	COMSUMER_POS_PIN(new String("CPOSP"), ""),
   	CONSUMER_ATM(new String("CATM"), ""),
   	STUDENT_POS_SIGNATURE(new String("SPOSS"), ""),
   	STUDENT_POS_PIN(new String("SPOSP"), ""),
   	STUDENT_ATM(new String("SATM"), ""),
   	VIRTUAL(new String("VIRTU"), ""),
   	VIRTUAL_HIDDEN(new String("VIRTH"), ""),
   	PAYMENT_INTERMEDIATION(new String("PAYIN"), ""),
   	FAMILY_TRANSFER(new String("FMTXFR"), "");

	private final String value;
	private final String desc;

	private ProductType(String value, String desc) {
		this.value = value;
		this.desc  = desc;
	}

	public String getValue() {
		return value;
	}

	public String getDesc() {
		return desc;
	}
}
