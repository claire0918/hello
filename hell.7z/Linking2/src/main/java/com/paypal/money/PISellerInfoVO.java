/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/PISellerInfoVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:40 2012 */

package com.paypal.money;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
  * 
   */

public class PISellerInfoVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((35417*35417)<<32)/*<-PISellerInfoVO*/+
         		4613/*<-paypal_account_info*/*com.paypal.user.AccountVO.TYPE_SIGNATURE/*<-User::AccountVO*/+
         		12785/*<-seller_property_info*/*SellerPropertyInfoVO.TYPE_SIGNATURE/*<-SellerPropertyInfoVO*/;
 
	public PISellerInfoVO() {
		super("Money::PISellerInfoVO", TYPE_SIGNATURE);

 		addFieldQualifier("paypal_account_info","required","false");
 
		set("paypal_account_info", null, "User::AccountVO");
 		addFieldQualifier("seller_property_info","required","false");
 
		set("seller_property_info", null, "Money::SellerPropertyInfoVO");
	}

	// {{{
	public void setPaypalAccountInfo(com.paypal.user.AccountVO value) { this.set("paypal_account_info", (Object)value); }
 	public com.paypal.user.AccountVO getPaypalAccountInfo() { return (com.paypal.user.AccountVO)this.get("paypal_account_info"); }
	// }}}
	// {{{
	public void setSellerPropertyInfo(SellerPropertyInfoVO value) { this.set("seller_property_info", (Object)value); }
 	public SellerPropertyInfoVO getSellerPropertyInfo() { return (SellerPropertyInfoVO)this.get("seller_property_info"); }
	// }}}
}