/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/IntegrationType.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:40 2012 */

package com.paypal.money;

import java.math.BigInteger;

  
public enum IntegrationType {
/**
             Types of integration that merchants can have with PayPal
     */
   	MOBILE(new String("MOBIL"), "Indicates Mobile integration"),
   	ONLINE(new String("ONLIN"), "Indicates integration using online techniques"),
   	POS(new String("POS"), "Indicates integration using POS terminals");

	private final String value;
	private final String desc;

	private IntegrationType(String value, String desc) {
		this.value = value;
		this.desc  = desc;
	}

	public String getValue() {
		return value;
	}

	public String getDesc() {
		return desc;
	}
}
