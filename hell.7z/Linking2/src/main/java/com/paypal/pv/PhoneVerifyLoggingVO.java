/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/PhoneVerifyLoggingVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:40 2012 */

package com.paypal.pv;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
  * 
   */

public class PhoneVerifyLoggingVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((60059*60059)<<32)/*<-PhoneVerifyLoggingVO*/+
         		3355/*<-id*/*46168/*<-ullong*/+
         		61412/*<-time_sent*/*46168/*<-ullong*/+
         		39381/*<-time_received*/*46168/*<-ullong*/+
         		24631/*<-vendor_id*/*33490/*<-ulong*/+
         		7343/*<-vendor_desc*/*18443/*<-String*/+
         		60232/*<-flags*/*33490/*<-ulong*/+
         		56246/*<-caller_id*/*33490/*<-ulong*/+
         		62145/*<-account_number*/*46168/*<-ullong*/+
         		59048/*<-address_id*/*46168/*<-ullong*/+
         		5695/*<-phone_id*/*46168/*<-ullong*/+
         		65283/*<-verified_status*/*37752/*<-char*/+
         		31875/*<-verified_message*/*18443/*<-String*/+
         		39098/*<-error_code*/*33490/*<-ulong*/+
         		1739/*<-part_key*/*33490/*<-ulong*/+
         		29011/*<-PYPL_TIME_TOUCHED*/*46168/*<-ullong*/;
 
	public PhoneVerifyLoggingVO() {
		super("PV::PhoneVerifyLoggingVO", TYPE_SIGNATURE);

 
		set("id", null, "ullong");
 
		set("time_sent", null, "ullong");
 
		set("time_received", null, "ullong");
 
		set("vendor_id", null, "ulong");
 
		set("vendor_desc", null, "String");
 
		set("flags", null, "ulong");
 
		set("caller_id", null, "ulong");
 
		set("account_number", null, "ullong");
 
		set("address_id", null, "ullong");
 
		set("phone_id", null, "ullong");
 
		set("verified_status", null, "char");
 
		set("verified_message", null, "String");
 
		set("error_code", null, "ulong");
 
		set("part_key", null, "ulong");
 
		set("PYPL_TIME_TOUCHED", null, "ullong");
	}

	// {{{
	public void setId(BigInteger value) { this.set("id", (Object)value); }
 	public BigInteger getId() { return (BigInteger)this.get("id"); }
	// }}}
	// {{{
	public void setTimeSent(BigInteger value) { this.set("time_sent", (Object)value); }
 	public BigInteger getTimeSent() { return (BigInteger)this.get("time_sent"); }
	// }}}
	// {{{
	public void setTimeReceived(BigInteger value) { this.set("time_received", (Object)value); }
 	public BigInteger getTimeReceived() { return (BigInteger)this.get("time_received"); }
	// }}}
	// {{{
	public void setVendorId(Long value) { this.set("vendor_id", (Object)value); }
 	public Long getVendorId() { return (Long)this.get("vendor_id"); }
	// }}}
	// {{{
	public void setVendorDesc(String value) { this.set("vendor_desc", (Object)value); }
 	public String getVendorDesc() { return (String)this.get("vendor_desc"); }
	// }}}
	// {{{
	public void setFlags(Long value) { this.set("flags", (Object)value); }
 	public Long getFlags() { return (Long)this.get("flags"); }
	// }}}
	// {{{
	public void setCallerId(Long value) { this.set("caller_id", (Object)value); }
 	public Long getCallerId() { return (Long)this.get("caller_id"); }
	// }}}
	// {{{
	public void setAccountNumber(BigInteger value) { this.set("account_number", (Object)value); }
 	public BigInteger getAccountNumber() { return (BigInteger)this.get("account_number"); }
	// }}}
	// {{{
	public void setAddressId(BigInteger value) { this.set("address_id", (Object)value); }
 	public BigInteger getAddressId() { return (BigInteger)this.get("address_id"); }
	// }}}
	// {{{
	public void setPhoneId(BigInteger value) { this.set("phone_id", (Object)value); }
 	public BigInteger getPhoneId() { return (BigInteger)this.get("phone_id"); }
	// }}}
	// {{{
	public void setVerifiedStatus(Byte value) { this.set("verified_status", (Object)value); }
 	public Byte getVerifiedStatus() { return (Byte)this.get("verified_status"); }
	// }}}
	// {{{
	public void setVerifiedMessage(String value) { this.set("verified_message", (Object)value); }
 	public String getVerifiedMessage() { return (String)this.get("verified_message"); }
	// }}}
	// {{{
	public void setErrorCode(Long value) { this.set("error_code", (Object)value); }
 	public Long getErrorCode() { return (Long)this.get("error_code"); }
	// }}}
	// {{{
	public void setPartKey(Long value) { this.set("part_key", (Object)value); }
 	public Long getPartKey() { return (Long)this.get("part_key"); }
	// }}}
	// {{{
	public void setPYPLTIMETOUCHED(BigInteger value) { this.set("PYPL_TIME_TOUCHED", (Object)value); }
 	public BigInteger getPYPLTIMETOUCHED() { return (BigInteger)this.get("PYPL_TIME_TOUCHED"); }
	// }}}
}