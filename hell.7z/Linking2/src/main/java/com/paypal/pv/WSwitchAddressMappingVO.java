/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/WSwitchAddressMapping.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:41 2012 */

package com.paypal.pv;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
  * 
   */

public class WSwitchAddressMappingVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((45414*45414)<<32)/*<-WSwitchAddressMappingVO*/+
         		3355/*<-id*/*46168/*<-ullong*/+
         		16570/*<-phone_number*/*18443/*<-String*/+
         		56224/*<-thunsand_block*/*33490/*<-ulong*/+
         		60232/*<-flags*/*33490/*<-ulong*/+
         		52543/*<-status*/*37752/*<-char*/+
         		39237/*<-city*/*18443/*<-String*/+
         		49691/*<-state*/*18443/*<-String*/+
         		55072/*<-zip*/*18443/*<-String*/+
         		59909/*<-iso_country_code*/*18443/*<-String*/+
         		25816/*<-prefix_type*/*18443/*<-String*/+
         		14259/*<-phone_provider*/*18443/*<-String*/+
         		2463/*<-longitude*/*18443/*<-String*/+
         		44615/*<-latitude*/*18443/*<-String*/+
         		29011/*<-PYPL_TIME_TOUCHED*/*46168/*<-ullong*/;
 
	public WSwitchAddressMappingVO() {
		super("PV::WSwitchAddressMappingVO", TYPE_SIGNATURE);

 
		set("id", null, "ullong");
 
		set("phone_number", null, "String");
 
		set("thunsand_block", null, "ulong");
 
		set("flags", null, "ulong");
 
		set("status", null, "char");
 
		set("city", null, "String");
 
		set("state", null, "String");
 
		set("zip", null, "String");
 
		set("iso_country_code", null, "String");
 
		set("prefix_type", null, "String");
 
		set("phone_provider", null, "String");
 
		set("longitude", null, "String");
 
		set("latitude", null, "String");
 
		set("PYPL_TIME_TOUCHED", null, "ullong");
	}

	// {{{
	public void setId(BigInteger value) { this.set("id", (Object)value); }
 	public BigInteger getId() { return (BigInteger)this.get("id"); }
	// }}}
	// {{{
	public void setPhoneNumber(String value) { this.set("phone_number", (Object)value); }
 	public String getPhoneNumber() { return (String)this.get("phone_number"); }
	// }}}
	// {{{
	public void setThunsandBlock(Long value) { this.set("thunsand_block", (Object)value); }
 	public Long getThunsandBlock() { return (Long)this.get("thunsand_block"); }
	// }}}
	// {{{
	public void setFlags(Long value) { this.set("flags", (Object)value); }
 	public Long getFlags() { return (Long)this.get("flags"); }
	// }}}
	// {{{
	public void setStatus(Byte value) { this.set("status", (Object)value); }
 	public Byte getStatus() { return (Byte)this.get("status"); }
	// }}}
	// {{{
	public void setCity(String value) { this.set("city", (Object)value); }
 	public String getCity() { return (String)this.get("city"); }
	// }}}
	// {{{
	public void setState(String value) { this.set("state", (Object)value); }
 	public String getState() { return (String)this.get("state"); }
	// }}}
	// {{{
	public void setZip(String value) { this.set("zip", (Object)value); }
 	public String getZip() { return (String)this.get("zip"); }
	// }}}
	// {{{
	public void setIsoCountryCode(String value) { this.set("iso_country_code", (Object)value); }
 	public String getIsoCountryCode() { return (String)this.get("iso_country_code"); }
	// }}}
	// {{{
	public void setPrefixType(String value) { this.set("prefix_type", (Object)value); }
 	public String getPrefixType() { return (String)this.get("prefix_type"); }
	// }}}
	// {{{
	public void setPhoneProvider(String value) { this.set("phone_provider", (Object)value); }
 	public String getPhoneProvider() { return (String)this.get("phone_provider"); }
	// }}}
	// {{{
	public void setLongitude(String value) { this.set("longitude", (Object)value); }
 	public String getLongitude() { return (String)this.get("longitude"); }
	// }}}
	// {{{
	public void setLatitude(String value) { this.set("latitude", (Object)value); }
 	public String getLatitude() { return (String)this.get("latitude"); }
	// }}}
	// {{{
	public void setPYPLTIMETOUCHED(BigInteger value) { this.set("PYPL_TIME_TOUCHED", (Object)value); }
 	public BigInteger getPYPLTIMETOUCHED() { return (BigInteger)this.get("PYPL_TIME_TOUCHED"); }
	// }}}
}