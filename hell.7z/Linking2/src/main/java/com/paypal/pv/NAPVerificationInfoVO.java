/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/NAPVerificationInfoVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:40 2012 */

package com.paypal.pv;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
  * 
   */

public class NAPVerificationInfoVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((1957*1957)<<32)/*<-NAPVerificationInfoVO*/+
         		32018/*<-acct_id*/*46168/*<-ullong*/+
         		34750/*<-addr_id*/*46168/*<-ullong*/+
         		60232/*<-flags*/*33490/*<-ulong*/+
         		56246/*<-caller_id*/*33490/*<-ulong*/+
         		44309/*<-nap_verification_req*/*com.paypal.pv.NAPVerificationReqVO.TYPE_SIGNATURE/*<-PV::NAPVerificationReqVO*/;
 
	public NAPVerificationInfoVO() {
		super("PV::NAPVerificationInfoVO", TYPE_SIGNATURE);

 
		set("acct_id", null, "ullong");
 
		set("addr_id", null, "ullong");
 
		set("flags", null, "ulong");
 
		set("caller_id", null, "ulong");
 
		set("nap_verification_req", null, "PV::NAPVerificationReqVO");
	}

	// {{{
	public void setAcctId(BigInteger value) { this.set("acct_id", (Object)value); }
 	public BigInteger getAcctId() { return (BigInteger)this.get("acct_id"); }
	// }}}
	// {{{
	public void setAddrId(BigInteger value) { this.set("addr_id", (Object)value); }
 	public BigInteger getAddrId() { return (BigInteger)this.get("addr_id"); }
	// }}}
	// {{{
	public void setFlags(Long value) { this.set("flags", (Object)value); }
 	public Long getFlags() { return (Long)this.get("flags"); }
	// }}}
	// {{{
	public void setCallerId(Long value) { this.set("caller_id", (Object)value); }
 	public Long getCallerId() { return (Long)this.get("caller_id"); }
	// }}}
	// {{{
	public void setNapVerificationReq(com.paypal.pv.NAPVerificationReqVO value) { this.set("nap_verification_req", (Object)value); }
 	public com.paypal.pv.NAPVerificationReqVO getNapVerificationReq() { return (com.paypal.pv.NAPVerificationReqVO)this.get("nap_verification_req"); }
	// }}}
}