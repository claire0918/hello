/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/NAPVerificationRespVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:40 2012 */

package com.paypal.pv;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
  * 
   */

public class NAPVerificationRespVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((48285*48285)<<32)/*<-NAPVerificationRespVO*/+
         		65283/*<-verified_status*/*37752/*<-char*/+
         		31875/*<-verified_message*/*18443/*<-String*/+
         		53209/*<-verification_error_code*/*33490/*<-ulong*/+
         		16823/*<-transaction_error_code*/*33490/*<-ulong*/+
         		57997/*<-soap_error_code*/*33490/*<-ulong*/;
 
	public NAPVerificationRespVO() {
		super("PV::NAPVerificationRespVO", TYPE_SIGNATURE);

 
		set("verified_status", null, "char");
 
		set("verified_message", null, "String");
 
		set("verification_error_code", null, "ulong");
 
		set("transaction_error_code", null, "ulong");
 
		set("soap_error_code", null, "ulong");
	}

	// {{{
	public void setVerifiedStatus(Byte value) { this.set("verified_status", (Object)value); }
 	public Byte getVerifiedStatus() { return (Byte)this.get("verified_status"); }
	// }}}
	// {{{
	public void setVerifiedMessage(String value) { this.set("verified_message", (Object)value); }
 	public String getVerifiedMessage() { return (String)this.get("verified_message"); }
	// }}}
	// {{{
	public void setVerificationErrorCode(Long value) { this.set("verification_error_code", (Object)value); }
 	public Long getVerificationErrorCode() { return (Long)this.get("verification_error_code"); }
	// }}}
	// {{{
	public void setTransactionErrorCode(Long value) { this.set("transaction_error_code", (Object)value); }
 	public Long getTransactionErrorCode() { return (Long)this.get("transaction_error_code"); }
	// }}}
	// {{{
	public void setSoapErrorCode(Long value) { this.set("soap_error_code", (Object)value); }
 	public Long getSoapErrorCode() { return (Long)this.get("soap_error_code"); }
	// }}}
}