/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/NAPVerificationReqVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:40 2012 */

package com.paypal.pv;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
  * 
   */

public class NAPVerificationReqVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((62877*62877)<<32)/*<-NAPVerificationReqVO*/+
         		24631/*<-vendor_id*/*33490/*<-ulong*/+
         		5695/*<-phone_id*/*46168/*<-ullong*/+
         		15157/*<-phone*/*18443/*<-String*/+
         		35037/*<-first_name*/*18443/*<-String*/+
         		51561/*<-last_name*/*18443/*<-String*/+
         		32390/*<-address_1*/*18443/*<-String*/+
         		32391/*<-address_2*/*18443/*<-String*/+
         		39237/*<-city*/*18443/*<-String*/+
         		49691/*<-state*/*18443/*<-String*/+
         		55072/*<-zip*/*18443/*<-String*/+
         		59909/*<-iso_country_code*/*18443/*<-String*/;
 
	public NAPVerificationReqVO() {
		super("PV::NAPVerificationReqVO", TYPE_SIGNATURE);

 
		set("vendor_id", null, "ulong");
 
		set("phone_id", null, "ullong");
 
		set("phone", null, "String");
 
		set("first_name", null, "String");
 
		set("last_name", null, "String");
 
		set("address_1", null, "String");
 
		set("address_2", null, "String");
 
		set("city", null, "String");
 
		set("state", null, "String");
 
		set("zip", null, "String");
 
		set("iso_country_code", null, "String");
	}

	// {{{
	public void setVendorId(Long value) { this.set("vendor_id", (Object)value); }
 	public Long getVendorId() { return (Long)this.get("vendor_id"); }
	// }}}
	// {{{
	public void setPhoneId(BigInteger value) { this.set("phone_id", (Object)value); }
 	public BigInteger getPhoneId() { return (BigInteger)this.get("phone_id"); }
	// }}}
	// {{{
	public void setPhone(String value) { this.set("phone", (Object)value); }
 	public String getPhone() { return (String)this.get("phone"); }
	// }}}
	// {{{
	public void setFirstName(String value) { this.set("first_name", (Object)value); }
 	public String getFirstName() { return (String)this.get("first_name"); }
	// }}}
	// {{{
	public void setLastName(String value) { this.set("last_name", (Object)value); }
 	public String getLastName() { return (String)this.get("last_name"); }
	// }}}
	// {{{
	public void setAddress1(String value) { this.set("address_1", (Object)value); }
 	public String getAddress1() { return (String)this.get("address_1"); }
	// }}}
	// {{{
	public void setAddress2(String value) { this.set("address_2", (Object)value); }
 	public String getAddress2() { return (String)this.get("address_2"); }
	// }}}
	// {{{
	public void setCity(String value) { this.set("city", (Object)value); }
 	public String getCity() { return (String)this.get("city"); }
	// }}}
	// {{{
	public void setState(String value) { this.set("state", (Object)value); }
 	public String getState() { return (String)this.get("state"); }
	// }}}
	// {{{
	public void setZip(String value) { this.set("zip", (Object)value); }
 	public String getZip() { return (String)this.get("zip"); }
	// }}}
	// {{{
	public void setIsoCountryCode(String value) { this.set("iso_country_code", (Object)value); }
 	public String getIsoCountryCode() { return (String)this.get("iso_country_code"); }
	// }}}
}