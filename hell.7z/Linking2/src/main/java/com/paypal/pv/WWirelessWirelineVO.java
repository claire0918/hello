/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/WWirelessWirelineVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:41 2012 */

package com.paypal.pv;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
  * 
   */

public class WWirelessWirelineVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((62598*62598)<<32)/*<-WWirelessWirelineVO*/+
         		35074/*<-source_phone_number*/*18443/*<-String*/+
         		59909/*<-iso_country_code*/*18443/*<-String*/+
         		60232/*<-flags*/*33490/*<-ulong*/+
         		29011/*<-PYPL_TIME_TOUCHED*/*46168/*<-ullong*/;
 
	public WWirelessWirelineVO() {
		super("PV::WWirelessWirelineVO", TYPE_SIGNATURE);

 
		set("source_phone_number", null, "String");
 
		set("iso_country_code", null, "String");
 
		set("flags", null, "ulong");
 
		set("PYPL_TIME_TOUCHED", null, "ullong");
	}

	// {{{
	public void setSourcePhoneNumber(String value) { this.set("source_phone_number", (Object)value); }
 	public String getSourcePhoneNumber() { return (String)this.get("source_phone_number"); }
	// }}}
	// {{{
	public void setIsoCountryCode(String value) { this.set("iso_country_code", (Object)value); }
 	public String getIsoCountryCode() { return (String)this.get("iso_country_code"); }
	// }}}
	// {{{
	public void setFlags(Long value) { this.set("flags", (Object)value); }
 	public Long getFlags() { return (Long)this.get("flags"); }
	// }}}
	// {{{
	public void setPYPLTIMETOUCHED(BigInteger value) { this.set("PYPL_TIME_TOUCHED", (Object)value); }
 	public BigInteger getPYPLTIMETOUCHED() { return (BigInteger)this.get("PYPL_TIME_TOUCHED"); }
	// }}}
}