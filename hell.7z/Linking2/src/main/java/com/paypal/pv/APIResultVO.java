/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/APIResultVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.pv;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
  * 
   */

public class APIResultVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((1007*1007)<<32)/*<-APIResultVO*/+
         		3633/*<-rc*/*50766/*<-long*/+
         		236/*<-message*/*18443/*<-String*/;
 
	public APIResultVO() {
		super("PV::APIResultVO", TYPE_SIGNATURE);

 
		set("rc", null, "long");
 
		set("message", null, "String");
	}

	// {{{
	public void setRc(Integer value) { this.set("rc", (Object)value); }
 	public Integer getRc() { return (Integer)this.get("rc"); }
	// }}}
	// {{{
	public void setMessage(String value) { this.set("message", (Object)value); }
 	public String getMessage() { return (String)this.get("message"); }
	// }}}
}