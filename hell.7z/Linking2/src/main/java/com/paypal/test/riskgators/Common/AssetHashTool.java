package com.paypal.test.riskgators.Common;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;

public class AssetHashTool {

    /**
     * @param args
     * @throws NoSuchAlgorithmException 
     */
    public static void main(String[] args) throws NoSuchAlgorithmException {
        if (args.length == 0) {
            System.out.println("Usage: java -jar assethashtool.jar assetValue1, assetValue2...");
            System.exit(1);
        }
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < args.length; i++) {
            sb.append(args[i].trim());
        }
        String hashValue = generateHash(sb.toString());
        System.out.println(hashValue);
    }

    private static String generateHash(String input) throws NoSuchAlgorithmException {
        MessageDigest md = MessageDigest.getInstance("MD5");
        md.update(input.getBytes(), 0, input.length());
        String value = new BigInteger(1, md.digest()).toString(16);
//        char[] chars = new char[32 - value.length()];
//        Arrays.fill(chars, 0, chars.length, '0');
//        value = String.valueOf(chars) + value;
        return value;
    }

}
