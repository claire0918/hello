package com.paypal.test.riskgators.Common;



import static org.testng.Assert.fail;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.paypal.test.bluefin.platform.config.BluefinConfig;
import com.paypal.test.bluefin.platform.config.BluefinConfig.BluefinConfigProperty;
import com.paypal.test.jaws.db.DatabaseName;
import com.paypal.test.jaws.db.JDBCUtils;
import com.paypal.test.jaws.file.CDBHelper;
import com.paypal.test.jaws.file.FileHelper;


import java.util.Calendar;
import java.util.Properties;

public class LinkingUtil {
	
	
	
	public static void LinkingModelPrepare() throws IOException {

	
		//define cdb files
		
		final String sRPS_Model = "/x/web/" + BluefinConfig.getConfigProperty(BluefinConfigProperty.STAGE_NAME) + "/riskpaymentserv/riskpaymentserv.cdb";
		final String sRVS_Model = "/x/web/" + BluefinConfig.getConfigProperty(BluefinConfigProperty.STAGE_NAME) + "/riskverificationserv/riskverificationserv.cdb";
		final String sRALS_Model = "/x/web/" + BluefinConfig.getConfigProperty(BluefinConfigProperty.STAGE_NAME) + "/riskloginasyncserv/riskloginasyncserv.cdb";
		final String sRPS_atlasserv = "/x/web/" + BluefinConfig.getConfigProperty(BluefinConfigProperty.STAGE_NAME) + "/riskpaymentserv/atlasserv.cdb";
		final String sWEB = "/x/web/" + BluefinConfig.getConfigProperty(BluefinConfigProperty.STAGE_NAME) + "-webscr-1/web/paypal.com/cgi-bin/web.cdb";
		final String sRPS_CAL = "/x/web/" + BluefinConfig.getConfigProperty(BluefinConfigProperty.STAGE_NAME) + "/riskpaymentserv/cal_client.cdb";
		final String sRVS_CAL = "/x/web/" + BluefinConfig.getConfigProperty(BluefinConfigProperty.STAGE_NAME) + "/riskverificationserv/cal_client.cdb"; 
		final String sRALS_CAL = "/x/web/" + BluefinConfig.getConfigProperty(BluefinConfigProperty.STAGE_NAME) + "/riskloginasyncserv/cal_client.cdb"; 
		
		
		//final String sRDRS_DSImport = "/x/web/" + BluefinConfig.getConfigProperty(BluefinConfigProperty.STAGE_NAME) + "riskdatareadserv/config/config/kerneldal/dsimport.xml";
		//final String sRDRS_linkingproperties="x/web/" + BluefinConfig.getConfigProperty(BluefinConfigProperty.STAGE_NAME) +"riskdatareadserv/container/webapps/riskdataread.war/WEB-INF/classes/linkingservices.properties";

		
		//Calendar currentDate = Calendar.getInstance();
		
		
		CDBHelper set_RPS = new CDBHelper(sRPS_Model);
		CDBHelper set_RVS = new CDBHelper(sRVS_Model);
		CDBHelper set_RALS = new CDBHelper(sRALS_Model);
		CDBHelper set_RPS_ATLASSERV = new CDBHelper(sRPS_atlasserv);
		CDBHelper set_WEB = new CDBHelper(sWEB);
		CDBHelper set_RPSCAL = new CDBHelper(sRPS_CAL);
		CDBHelper set_RVSCAL = new CDBHelper(sRVS_CAL);
		CDBHelper set_RALSCAL = new CDBHelper(sRALS_CAL);
		
		/*
		//enable ASF xml format request for rps
		set_WEB.setCDBProperty("asf.service.RiskPayment.rpc.format", "xml");//or binary
		*/
		
		// Set rampup value in riskpaymentserv for lionv1		
		
		set_RPS.setCDBProperty("get_person_entity_map_by_asset_tuple_ramp_up","1000");
		set_RPS.setCDBProperty("get_person_entity_map_by_account_ramp_up","1000");
		set_RPS.setCDBProperty("get_person_entity_map_by_counterparty_ramp_up","1000");
		set_RPS.setCDBProperty("get_business_entity_map_by_account_ramp_up","1000");
		set_RPS.setCDBProperty("get_business_entity_map_by_counterparty_ramp_up","1000");
		
		// Set rampup value in riskpaymentserv for lionv2
		
		set_RPS.setCDBProperty("linking2_person_sender_asset_ramp_up","1000");
		set_RPS.setCDBProperty("linking2_person_sender_account_ramp_up","1000");
		set_RPS.setCDBProperty("linking2_person_counterparty_account_ramp_up","1000");
		set_RPS.setCDBProperty("linking2_business_sender_account_ramp_up","1000");
		set_RPS.setCDBProperty("linking2_business_counterparty_account_ramp_up","1000");
		
		
		//set qa rules value in riskpaymentserv		
		set_RPS.setCDBProperty("test_qa_rules","true");
		set_RPS.setCDBProperty("test_fqa_rules","false");
		set_RPS.setCDBProperty("update_qa_rules","true");
		
		//enable xom dump value in riskpaymentserv	
		set_RPS.setCDBProperty("test_xom_output","rps_xom.txt");
		
		//set log level value in riskpaymentserv
		set_RPS.setCDBProperty("asf.logger.default.level","verbose");//info or debug
		set_RPS.setCDBProperty("asf.logger.riskpaymentserv.level","verbose");//info or debug
		
		//enable ASF request access to riskpaymentserv
		set_RPS_ATLASSERV.setCDBProperty("asf.service.default.custom_auth.enable","false");//true is webflow	
		
		
		/*
		//enable CAL for riskpaymentserv
		set_RPSCAL.setCDBProperty("enable_cal", "true");
		set_RPSCAL.setCDBProperty("cal_handler", "file");
		set_RPSCAL.setCDBProperty("cal_log_level", "5");
		set_RPSCAL.setCDBProperty("cal_enable_mlog", "false");
		set_RPSCAL.setCDBProperty("cal_log_file", "logCal.txt");
		*/
		
		
		System.out.println(BluefinConfig.getConfigProperty(BluefinConfigProperty.STAGE_NAME)+": riskpaymentserv setup completed"+"\n");
		
		
		
		// Enable LionV1 in riskloginasyncserv
		set_RALS.setCDBProperty("linking_get_business_entity_map_by_account_enabled","true");
		set_RALS.setCDBProperty("linking_get_person_entity_map_by_asset_tuple_enabled","true");
		
		// Enable LionV2 in riskloginasyncserv
		set_RALS.setCDBProperty("linking2_person_sender_asset_enabled","true");
		set_RALS.setCDBProperty("linking2_person_sender_account_enabled","true");
		set_RALS.setCDBProperty("linking2_business_sender_account_enabled","true");

		
		//set qa rules value in riskloginasyncserv		
		set_RALS.setCDBProperty("test_qa_rules","true");
		set_RALS.setCDBProperty("test_fqa_rules","false");
		set_RALS.setCDBProperty("update_qa_rules","true");
		
		//enable xom dump value in riskloginasyncserv	
		set_RALS.setCDBProperty("test_xom_output","riskloginasync_xom.txt");
		
		//set log level value in riskloginasyncserv
		set_RALS.setCDBProperty("asf.logger.riskloginasyncserv.level","verbose");//info or debug
		set_RALS.setCDBProperty("asf.logger.default.level","6");// 0=Disabled, 1=Alert, 2=Perf, 3=Error, 4=Warn, 5=Info, 6=Debug
		
		
		/*
		//enable CAL for riskloginasyncserv
		set_RALSCAL.setCDBProperty("enable_cal", "true");
		set_RALSCAL.setCDBProperty("cal_handler", "file");
		set_RALSCAL.setCDBProperty("cal_log_level", "5");
		set_RALSCAL.setCDBProperty("cal_enable_mlog", "false");
		set_RALSCAL.setCDBProperty("cal_log_file", "logCal.txt");		
		*/
		
		
		System.out.println(BluefinConfig.getConfigProperty(BluefinConfigProperty.STAGE_NAME)+": riskloginasyncserv setup completed"+"\n");
	
		
		
		
		
		// Enable LionV1 in riskverificationserv
		set_RVS.setCDBProperty("linking_get_business_entity_map_by_account_enabled","true");
		set_RVS.setCDBProperty("linking_get_person_entity_map_by_asset_tuple_enabled","true");
		
		// Enable LionV1 in riskverificationserv
		set_RVS.setCDBProperty("linking2_person_sender_asset_enabled","true");

		
		//set qa rules value in riskverificationserv		
		set_RVS.setCDBProperty("test_qa_rules","true");
		set_RVS.setCDBProperty("test_fqa_rules","false");
		set_RVS.setCDBProperty("update_qa_rules","true");
		
		//enable xom dump value in riskverificationserv	
		set_RVS.setCDBProperty("test_xom_output","rvs_xom.txt");
		
		//set log level value in riskverificationserv
		set_RVS.setCDBProperty("asf.logger.riskverificationserv.level","verbose");//info or debug
		set_RVS.setCDBProperty("asf.logger.default.level","6");// 0=Disabled, 1=Alert, 2=Perf, 3=Error, 4=Warn, 5=Info, 6=Debug
		
		/*
		//enable CAL for riskloginasyncserv
		set_RVSCAL.setCDBProperty("enable_cal", "true");
		set_RVSCAL.setCDBProperty("cal_handler", "file");
		set_RVSCAL.setCDBProperty("cal_log_level", "5");
		set_RVSCAL.setCDBProperty("cal_enable_mlog", "false");
		set_RVSCAL.setCDBProperty("cal_log_file", "logCal.txt");	
		*/
		
		
		System.out.println(BluefinConfig.getConfigProperty(BluefinConfigProperty.STAGE_NAME)+": riskverificationserv setup completed"+"\n");
	
	}
	
	
	
	public static void CleanUpDB() throws IOException {
	/*DB prepare
	LION 8 Tables
	linked_accounts
	link_entity
	link_entity_attr_metadata
	link_entity_attr_values
	link_entity_instance
	link_instance_definition
	link_entity_type
	link_asset_definition
	*/
	
	//Clean up Linking related 8 tables
	JDBCUtils dbConnect = null;
	ResultSet results = null;
	String sSQL = null;
	int iCounter;
	
	
	String[] s_LION_TABLE = { 
			"linked_accounts",
			"link_entity", 
			"link_entity_attr_metadata", 
			"link_entity_attr_values",
			"link_entity_instance",			
			"link_instance_definition",
			"link_entity_type",
			"link_asset_definition"
			
			};

	
	//final String sdbDriver="oracle.jdbc.OracleDriver";
	//final String sdbURL="jdbc:oracle:thin:@lvsvmdb22.qa.paypal.com:2126:QADBA9EC";
	//final String sdbUser="liondba";
	//final String sdbPasswd="liondbastg";
	
	
	try {
		for (iCounter = 0; iCounter < s_LION_TABLE.length; iCounter++) {

			sSQL = "DELETE FROM " + s_LION_TABLE[iCounter];
			try {
				//dbConnect = new JDBCUtils(sdbDriver,sdbURL,sdbUser,sdbPasswd);
				dbConnect = new JDBCUtils(DatabaseName.LION);
				dbConnect.createConnection();
				results = dbConnect.executeQuery(sSQL);
				Thread.sleep(3000);

			} catch (SQLException e) {
				e.printStackTrace();
				fail("Error in performing LION tables");
			} catch (Exception e) {
				e.printStackTrace();
			}
			System.out.println(BluefinConfig.getConfigProperty(BluefinConfigProperty.STAGE_NAME)+": "+s_LION_TABLE[iCounter] + " is successfully cleaned"+"\n");
		}
	} catch (Exception e) {
		e.printStackTrace();
	} finally {
		try {
			dbConnect.closeConnection();
			results = null;
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	}
	
	public static void InsertDB() throws IOException{
		JDBCUtils dbConnect = null;
		ResultSet results = null;
		String sSQL = null;
		File dbfile;
		int iCounter;
		String dataLoc = "src/test/resources/dbdata/stage2p2370/";
		String[] s_LION_TABLE = { 
				"linked_accounts",
				"link_entity", 
				"link_entity_attr_metadata", 
				"link_entity_attr_values",
				"link_entity_instance",
				"link_instance_definition",
				"link_entity_type",
				"link_asset_definition"
				
				};

		String[][] s_LION_COLUMN = {
				{"ENTITY_ID", "ACCOUNT_NUM", "LINK_ENTITY_TYPE_ID", "TIME_CREATED", "TIME_UPDATED"},//5
				{"ENTITY_ID", "SCORE", "IS_DELETED", "LINK_ENTITY_TYPE_ID","TIME_CREATED", "TIME_UPDATED"},//6
				{"ID", "LINK_ENTITY_ATTR_NAME", "LINK_ENTITY_ATTR_DATA_TYPE", "TIME_CREATED", "TIME_UPDATED"},//5				
				{"ENTITY_ID", "LINK_ENTITY_TYPE_ID", "LINK_ENTITY_ATTR_VALUES_1","LINK_ENTITY_ATTR_VALUES_2","LINK_ENTITY_ATTR_VALUES_3", "TIME_CREATED", "TIME_UPDATED"},//7
				{"ID", "ENTITY_ID", "LINK_ENTITY_TYPE_ID", "LINK_INSTANCE_DEFINITION_ID", "ASSET_VALUE1", "ASSET_VALUE2", "ASSET_VALUE3", "ASSET_VALUE4", "ASSET_VALUE5", "ASSET_VALUE6", "ASSET_VALUE_HASH", "FIRST_CREATED", "TIME_CREATED", "TIME_UPDATED"},//14
				{"ID","LINK_ENTITY_TYPE_ID", "ENTITY_DEFINITION_NAME", "ASSET_ID1","ASSET_ID2","ASSET_ID3", "ASSET_ID4","ASSET_ID5","ASSET_ID6", "TIME_CREATED","TIME_UPDATED"},//11
				{"ID","ENTITY_TYPE_NAME","TIME_CREATED","TIME_UPDATED"},//4
				{"ID","ASSET_NAME","TIME_CREATED","TIME_UPDATED"}//4
				};
		
		String[] s_LION_FILE = {
				"SQL_LOADER-LINKED_ACCOUNTS.txt",
				"SQL_LOADER-LINK_ENTITY.txt",
				"SQL_LOADER-LINK_ENTITY_ATTR_METADATA.txt",
				"SQL_LOADER-LINK_ENTITY_ATTR_VALUE.txt",
				"SQL_LOADER-LINK_ENTITY_INSTANCE.txt",
				"SQL_LOADER-LINK_INSTANCE_DEFINITION.txt",
				"SQL_LOADER-LINK_ENTITY_TYPE.txt",
				"SQL_LOADER-LINK_ASSET_DEFINITION.txt"
				
				};
		
		//final String sdbDriver="oracle.jdbc.OracleDriver";
		//final String sdbURL="jdbc:oracle:thin:@lvsvmdb22.qa.paypal.com:2126:QADBA9EC";
		//final String sdbUser="liondba";
		//final String sdbPasswd="liondbastg";
		
		
			for (iCounter = 0; iCounter < s_LION_FILE.length; iCounter++) {
				//System.out.println("iCounter-"+s_LION_TABLE[iCounter].toString()+"\n");
				//System.out.println("s_LION_COLUMN["+iCounter+"] and jCounter: "+s_LION_COLUMN[iCounter].length+"\n");
				try {
					dbfile= new File(dataLoc+s_LION_FILE[iCounter]);
					FileInputStream fis = new FileInputStream(dbfile);
		            BufferedReader br = new BufferedReader(new InputStreamReader(fis));
		            String dataline = br.readLine();
		            while(dataline != null){
						String[] column_values=dataline.split("\\|"); 
						StringBuilder sValue=new StringBuilder();
						for (int n=0;n<column_values.length - 1;n++){
							if(column_values[n].contains("TO_DATE")){
								sValue.append(column_values[n]+",");
							}
							else sValue.append("'"+column_values[n]+"'" +",");					
							}
						sValue.append("'"+column_values[column_values.length - 1]+"'");
						sSQL = "INSERT INTO " + s_LION_TABLE[iCounter] + " VALUES (" + sValue.toString()+ ")";
						System.out.println("sSQL: "+sSQL+"\n");
						//dbinsert
						try {
							dbConnect = new JDBCUtils(DatabaseName.LION);
							dbConnect.createConnection();
							//dbConnect = new JDBCUtils(sdbDriver,sdbURL,sdbUser,sdbPasswd);
							results = dbConnect.executeQuery(sSQL);
							Thread.sleep(3000);
							System.out.println(BluefinConfig.getConfigProperty(BluefinConfigProperty.STAGE_NAME)+": "+s_LION_TABLE[iCounter] + " is successfully insert"+"\n");
						} catch (SQLException e) {
							e.printStackTrace();
							fail("Error in performing LION tables");
						} catch (Exception e) {
							e.printStackTrace();
						}
						finally {
								try {
									dbConnect.closeConnection();
									results = null;
								} catch (SQLException e) {
									e.printStackTrace();
								} catch (ClassNotFoundException e) {
									e.printStackTrace();
								}
						}					
						dataline = br.readLine();
					}
					fis.close();
					br.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
	}

		
					
/*	
	public static void LoadProperties() throws IOException{
		Properties prop = new Properties();
		final String PropFile = "src/test/resources/dbconfig.properties";
		
		try{
			//load db properties file
			prop.load(new FileInputStream(PropFile));
			
			System.out.println(prop.getProperty("ID"));
			System.out.println(prop.getProperty("ENTITY_TYPE_NAME"));
			System.out.println(prop.getProperty("TIME_CREATED"));
			System.out.println(prop.getProperty("TIME_UPDATED"));
				
			
		} catch (Exception e){
			e.printStackTrace();
		}
		
		
		
		
	}
*/
	
}
