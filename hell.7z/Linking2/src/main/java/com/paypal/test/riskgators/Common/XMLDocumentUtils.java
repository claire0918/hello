package com.paypal.test.riskgators.Common;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.Properties;

import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.xerces.parsers.DOMParser;
import org.apache.xml.serialize.OutputFormat;
import org.apache.xml.serialize.XMLSerializer;
import org.apache.xpath.XPathAPI;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.traversal.NodeIterator;
import org.xml.sax.InputSource;


/**
 * 
 * @author pviswanathan
 * 
 */
public abstract class XMLDocumentUtils {
	
	/**
	 * Convert the XML Document as String
	 * 
	 * @param doc
	 * @param lineSeparator
	 * @return
	 * @throws IOException
	 */
	public static String convertDocumentAsFormatStr(Document doc) throws IOException {
		String lineSeparator = System.getProperty("line.separator");
		OutputFormat format = new OutputFormat(doc);
		format.setPreserveSpace(false);
		format.setIndent(2);
		format.setLineSeparator(lineSeparator);
		StringWriter stringOut = new StringWriter();
		XMLSerializer serializer = new XMLSerializer(stringOut, format);
		serializer.serialize(doc);
		return stringOut.toString();
	}
	
	/**
	 * Convert String as XML Document
	 * 
	 * @param input
	 * @param nameSpaceSupport
	 * @return
	 * @throws Exception
	 */
	public static Document convertStrAsDocument(String input, boolean nameSpaceSupport) throws Exception {
		StringReader stringStream = new StringReader(input);
		InputSource source = new InputSource(stringStream);
		DOMParser parser = new DOMParser();
		parser.setFeature("http://xml.org/sax/features/namespaces", nameSpaceSupport);
		parser.parse(source);
		Document doc = parser.getDocument();
		stringStream.close();
		return doc;
	}


	/**
	 * 
	 * This method makes a clone/copy of a given node in the XML document and
	 * returns it
	 * 
	 * @param document
	 * @param nodeName
	 *            - name of the node to be cloned
	 * @return
	 * @throws Exception
	 */
	public static Node getCloneOfNode(Document document, String nodeName)
			throws Exception {
		Node oldNode = document.getElementsByTagName(nodeName).item(0);
		if (oldNode != null) {
			Node newNode = oldNode.cloneNode(true);
			return newNode;
		} else {
			throw new Exception("\"" + nodeName
					+ "\" node not found in the given document.");
		}
	}

	/**
	 * 
	 * This method is used to clone more nodes based on the request list and
	 * populate the $variables defined in the XML template with request data.
	 * 
	 * <ol>
	 * <li>Makes a copy/clone of the node specified</li>
	 * <li>Loops through the reqList size which is equal to the number of
	 * request</li>
	 * <li>For the first request, the data is directly replaced as it already
	 * defined in the template</li>
	 * <li>for the subsequent requests, first the node copied in step 1 is
	 * appended(just below the previous request node) and then the data is
	 * replaced for the $variables</li>
	 * <li>Finally, the document is returned as string.</li>
	 * </ol>
	 * 
	 * <p>
	 * <b>Example:</b><br>
	 * if there need to be three requests(<ser:changeMediaBlockingStateRequest>)
	 * referring to the input document shown below and if the following values
	 * are to be passed for the $variables: 1) $invID :
	 * invoaction1,invocation2,invocation3 2) $locID : locale1,locale2,locale3
	 * (These request datas are passed as Properties list). Then,
	 * </p>
	 * 
	 * <b>Input</b><br>
	 * <code><pre>
	 * <xmp>
	 * <soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ser="http://www.ebay.com/marketplace/catalog/v1/services">
	 * <soapenv:Header/>
	 * <soapenv:Body>
	 * <ser:changeMediaBlockingStateBatchRequest>
	 * <ser:changeMediaBlockingStateRequest>
	 * <ser:invocationId>$invID</ser:invocationId>
	 * <ser:localeId>$locID</ser:localeId>
	 * </ser:changeMediaBlockingStateRequest>
	 * </ser:changeMediaBlockingStateBatchRequest>
	 * </soapenv:Body>
	 * </soapenv:Envelope>
	 * </xmp>
	 * </pre></code>
	 * 
	 * <b>Output</b><br>
	 * <code><pre>
	 * <xmp>
	 * <soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ser="http://www.ebay.com/marketplace/catalog/v1/services">
	 * <soapenv:Header/>
	 * <soapenv:Body>
	 * <ser:changeMediaBlockingStateBatchRequest>
	 * <ser:changeMediaBlockingStateRequest>
	 * <ser:invocationId>invocation1</ser:invocationId>
	 * <ser:localeId>locale1</ser:localeId>
	 * </ser:changeMediaBlockingStateRequest>
	 * <ser:changeMediaBlockingStateRequest>
	 * <ser:invocationId>invocation2</ser:invocationId>
	 * <ser:localeId>locale2</ser:localeId>
	 * </ser:changeMediaBlockingStateRequest>
	 * <ser:changeMediaBlockingStateRequest>
	 * <ser:invocationId>invocation3</ser:invocationId>
	 * <ser:localeId>locale3</ser:localeId>
	 * </ser:changeMediaBlockingStateRequest>
	 * </ser:changeMediaBlockingStateBatchRequest>
	 * </soapenv:Body>
	 * </soapenv:Envelope>
	 * </xmp>
	 * </pre></code>
	 * 
	 * @param doc
	 *            - the xml template
	 * @param reqList
	 *            - the list of request data as key-value Properties
	 * @param nodeNameToClone
	 *            - name of the node to be cloned
	 * @param parentNodeNameOfNodeToBeCloned
	 *            - name of the parent node of the node to be cloned
	 * @return - the updated xml document as string
	 * @throws Exception
	 */
	public static String cloneNodeAndPopulateWithData(Document doc,
			List<Properties> reqList, String nodeNameToClone,
			String parentNodeNameOfNodeToBeCloned) throws Exception {
		Node cloned = getCloneOfNode(doc, nodeNameToClone);
		int reqnum = 0;
		for (int i = 0; i < reqList.size(); i++) {
			if (i != 0) {
				Node parent = doc.getElementsByTagName(
						parentNodeNameOfNodeToBeCloned).item(0);
				if (parent != null) {
					parent.appendChild(doc.importNode(cloned, true));
				} else {
					throw new Exception("ParentNode \""
							+ parentNodeNameOfNodeToBeCloned
							+ "\" is not found" + " in the document provided.");
				}
			}
			String xmlContent = convertDocumentAsFormatStr(doc);
			Enumeration<Object> e = reqList.get(i).keys();
			while (e.hasMoreElements()) {
				String key = e.nextElement().toString();
				xmlContent = xmlContent.replace(key, reqList.get(reqnum)
						.getProperty(key));
			}
			reqnum++;
			doc = convertStrAsDocument(xmlContent, true);
		}
		return convertDocumentAsFormatStr(doc);
	}

	/**
	 * This method is used to set the values for $varibles in the XML template.
	 * This method could be used under scenarios where there is no need to clone
	 * the request but simply populate the $variables with actual data.
	 * 
	 * @param doc
	 *            - the xml template
	 * @param reqProperties
	 *            - request data as key-value Properties
	 * @return - the updated xml document as string
	 * @throws Exception
	 */
	public static String populateWithData(Document doc, Properties reqProperties)
			throws Exception {
		int reqnum = 0;
		for (int i = 0; i < reqProperties.size(); i++) {
			String xmlContent = convertDocumentAsFormatStr(doc);
			Enumeration<Object> e = reqProperties.keys();
			while (e.hasMoreElements()) {
				String key = e.nextElement().toString();
				xmlContent = xmlContent.replace(key,
						reqProperties.getProperty(key));
			}
			reqnum++;
			doc = convertStrAsDocument(xmlContent, true);
		}
		return convertDocumentAsFormatStr(doc);
	}

	/**
	 * This method is used to clone a copy of a given node and append it below
	 * at the same level and return the entire xml document as string
	 * 
	 * @param xmlContent
	 *            - given XML document as string
	 * @param nodeName
	 *            - name of the node to be cloned
	 * @return
	 * @throws Exception
	 */
	public static String cloneAndAppendNodeToDocument(String xmlContent,
			String nodeName) throws Exception {
		Document document = convertStrAsDocument(xmlContent, true);
		Node oldNode = document.getElementsByTagName(nodeName).item(0);
		Node parentNode = oldNode.getParentNode();
		Node newNode = oldNode.cloneNode(true);
		parentNode.appendChild(newNode);
		String newXmlContent = convertDocumentAsFormatStr(document);
		return newXmlContent;
	}

	/**
	 * This method is used to clone a given node in a XML, given number of times
	 * and attach it below at the same level
	 * 
	 * @param xmlContent
	 *            - XML as string
	 * @param requiredNodeCount
	 *            - count of number of times the node need to be cloned
	 * @param nodeName
	 *            - name of the node to be cloned
	 * @return XML as string after cloning a given node, the given number of
	 *         times
	 * @throws Exception
	 */
	public static String cloneMoreNodes(String xmlContent,
			int requiredNodeCount, String nodeName) throws Exception {
		String newXml = xmlContent;
		if (requiredNodeCount > 1) {
			for (int i = 2; i <= requiredNodeCount; i++) {
				newXml = cloneAndAppendNodeToDocument(newXml, nodeName);
			}
		}
		return newXml;
	}

	/**
	 * Extracts all the $variables from XML file into a List
	 * 
	 * @param xmlContent
	 * @return
	 * @throws Exception
	 */
	public static List<String> extractVariablesFromXML(String xmlContent)
			throws Exception {
		List<String> variablesList = new ArrayList<String>();
		int fromIndex = xmlContent.indexOf("$", 0);
		if (fromIndex < 0) {
			throw new Exception("No $variables in the xml document.");
		}
		while ((fromIndex + 1) > 0) {
			int endIndex = xmlContent.indexOf("<", fromIndex);
			String variable = xmlContent.substring(fromIndex, endIndex);
			fromIndex = xmlContent.indexOf("$", fromIndex + 1);
			variablesList.add(variable.trim());
		}
		return variablesList;
	}

	/**
	 * This method is used to delete the extra number of the given node than the
	 * required number in a XML document given as String.
	 * 
	 * @param xmlContent
	 *            - XML document as String
	 * @param nodeName
	 *            - name of the node to be deleted
	 * @param requiredNodeCount
	 *            - number of the given node to be retained
	 * @return
	 * @throws Exception
	 */
	public static String deleteExtraNodes(String xmlContent, String nodeName,
			int numberOfNodesToDelete) throws Exception {
		Document document = convertStrAsDocument(xmlContent, true);
		int totalNodeCount = document.getElementsByTagName(nodeName)
				.getLength();
		if (totalNodeCount == 0) {
			if (nodeName.startsWith("<")) {
				throw new Exception("Give Node Name Without the symbols < >.");
			}
			throw new Exception("Node \"" + nodeName
					+ "\" not found in xmlContent.");
		}
		if (numberOfNodesToDelete > totalNodeCount) {
			throw new Exception("Number of nodes to be deleted ("
					+ numberOfNodesToDelete + ") exceeds the total node count "
					+ totalNodeCount + ".");
		} else if (numberOfNodesToDelete < 0) {
			throw new Exception("The value for number of nodes to be deleted ("
					+ numberOfNodesToDelete + ") is INVALID.");
		}
		int index = totalNodeCount - 1;
		for (int i = 0; i < numberOfNodesToDelete; i++) {
			NodeList nl = document.getElementsByTagName(nodeName);
			Node parent = nl.item(index).getParentNode();
			parent.removeChild(nl.item(index));
			index--;
		}
		String newXmlContent = convertDocumentAsFormatStr(document);
		return newXmlContent;
	}

	/**
	 * This method is used to write a text value to the 'itemnum'th child of the
	 * given node
	 * 
	 * @param document
	 *            xml document
	 * @param nodeName
	 *            name of the node/tag for which the value is to be written
	 * @param nodeValue
	 *            value to be written to the given node
	 * @throws Exception
	 */
	public static void writeValueToNode(Document document, String nodeName,
			int itemnum, String nodeValue) throws Exception {
		int count = document.getElementsByTagName(nodeName).getLength();
		if (count == 0) {
			if (nodeName.startsWith("<")) {
				throw new Exception("Give Node Name without the symbols < >.");
			}
			throw new Exception("Node \"" + nodeName
					+ "\" not found in xmlContent.");
		}
		Node node = document.getElementsByTagName(nodeName).item(itemnum);
		if (node == null) {
			throw new Exception("There is no item with index " + itemnum
					+ " found in xml document.");
		}
		node.getChildNodes().item(0).setNodeValue(nodeValue);
	}

	/**
	 * This method is used to write value to a Node using xpath
	 * 
	 * @param document
	 *            xml document
	 * @param xpath
	 *            xpath of the node/tag for which the value is to be written
	 * @param nodeValue
	 *            value to be written to the given node
	 * @throws Exception
	 */
	public static void writeValueUsingXpath(Document document, String xpath,
			String nodeValue) throws Exception {
		NodeIterator ni = XPathAPI.selectNodeIterator(document, xpath);
		Node node = ni.nextNode();
		if (node != null) {
			node.setTextContent(nodeValue);
		} else {
			throw new Exception("XPATH is NOT correct.");
		}
	}

	/**
	 * This method converts a node to String object
	 * 
	 * @param node
	 * @return
	 */
	public static String convertNodeToString(Node node) {
		StringWriter sw = new StringWriter();
		try {
			Transformer t = TransformerFactory.newInstance().newTransformer();
			t.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "no");
			t.transform(new DOMSource(node), new StreamResult(sw));
		} catch (TransformerException te) {
			te.printStackTrace();
		}
		return sw.toString();
	}

	/**
	 * This method returns as a List the content of all given node present in
	 * the document
	 * 
	 * @param document
	 *            - xml document
	 * @param nodeName
	 *            - name of the tag in the xml file whose text value is desired
	 * @return List<String> - list of all the text values of the given tag in
	 *         the document
	 * @throws Exception
	 */
	public static List<String> getTextContentOfNode(Document document,
			String nodeName) throws Exception {
		List<String> textValueList = new ArrayList<String>();
		Element element = document.getDocumentElement();
		NodeList nodeList = element.getElementsByTagName(nodeName);
		if (nodeList != null && nodeList.getLength() > 0) {
			for (int i = 0; i < nodeList.getLength(); i++) {
				textValueList.add(nodeList.item(i).getTextContent());
			}
		} else {
			throw new Exception("No Node named " + nodeName
					+ " is found in the document.");
		}
		return textValueList;
	}

	/**
	 * This method is used store a given document in a physical location
	 * specified
	 * 
	 * @param document
	 * @param fileLocation
	 * @throws FileNotFoundException
	 * @throws TransformerException
	 */
	public static void storeXmlDocumentInGivenLocation(Document document,
			String fileLocation) throws FileNotFoundException,
			TransformerException {
		FileOutputStream outputStream = null;
		outputStream = new FileOutputStream(fileLocation);
		DOMSource source = new DOMSource(document);
		StreamResult result = new StreamResult(outputStream);
		TransformerFactory transFactory = TransformerFactory.newInstance();
		Transformer transformer = null;
		transformer = transFactory.newTransformer();
		transformer.transform(source, result);
	}
}
