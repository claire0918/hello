/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AccountToAccountRelationshipVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.user;

import java.math.BigInteger;

  
public enum AccountRelPosition {
/***/
   	SUBJECT_ACCOUNT(new Integer("1"), ""),
   	ACTING_ACCOUNT(new Integer("2"), ""),
   	EITHER(new Integer("3"), "");

	private final Integer value;
	private final String desc;

	private AccountRelPosition(Integer value, String desc) {
		this.value = value;
		this.desc  = desc;
	}

	public Integer getValue() {
		return value;
	}

	public String getDesc() {
		return desc;
	}
}
