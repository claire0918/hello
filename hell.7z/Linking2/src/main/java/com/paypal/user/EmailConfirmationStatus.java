/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/EmailVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:40 2012 */

package com.paypal.user;

import java.math.BigInteger;

  
public enum EmailConfirmationStatus {
/***/
   	NONE(new String("NONE"), ""),
   	VALID(new String("VALID"), ""),
   	POTENTIALLY_INVALID(new String("POT_INV"), "We have received a bounce in sending an email to this email address and that might mean that the email is invalid. Setting this to true also causes the current time to be recorded for use by the batch that marks these things invalid."),
   	INVALID(new String("INVALID"), "We've gotten another bounce at this email and decided to write it off as invalid. This status being set means that we regard this email address as not really existing.");

	private final String value;
	private final String desc;

	private EmailConfirmationStatus(String value, String desc) {
		this.value = value;
		this.desc  = desc;
	}

	public String getValue() {
		return value;
	}

	public String getDesc() {
		return desc;
	}
}
