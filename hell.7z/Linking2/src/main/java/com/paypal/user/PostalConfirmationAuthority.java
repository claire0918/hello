/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AddressVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.user;

import java.math.BigInteger;

  
public enum PostalConfirmationAuthority {
/***/
   	NONE(new String("NONE"), ""),
   	INSPECTION(new String("INSPECT"), "The status was determined by our own internal logic analyzing the inputs"),
   	NORMALIZATION(new String("NORMAL"), "The status was assumed because we were given normalized data."),
   	LOC_CONF(new String("LOC_CONF"), "The status is known because the address went through the location confirmation flow with one of its parties."),
   	PITNEY_BOWES(new String("PTNY_BWS"), "");

	private final String value;
	private final String desc;

	private PostalConfirmationAuthority(String value, String desc) {
		this.value = value;
		this.desc  = desc;
	}

	public String getValue() {
		return value;
	}

	public String getDesc() {
		return desc;
	}
}
