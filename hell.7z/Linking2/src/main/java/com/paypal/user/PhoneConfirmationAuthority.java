/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/PhoneVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:40 2012 */

package com.paypal.user;

import java.math.BigInteger;

  
public enum PhoneConfirmationAuthority {
/***/
   	NONE(new String("NONE"), "Should always be paired with Confirmation status none."),
   	UNKNOWN(new String("UNKNOWN"), "We have a Confirmation status, but we don't know the source."),
   	PARTY_RELATIONSHIP(new String("PRTY_REL"), "The Confirmation status is inferred from the Confirmation status of one of the Party-Phone relationships.");

	private final String value;
	private final String desc;

	private PhoneConfirmationAuthority(String value, String desc) {
		this.value = value;
		this.desc  = desc;
	}

	public String getValue() {
		return value;
	}

	public String getDesc() {
		return desc;
	}
}
