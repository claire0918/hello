/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/UserPropertyVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:41 2012 */

package com.paypal.user;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
  * 
   */

public class UserPropertyVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((23444*23444)<<32)/*<-UserPropertyVO*/+
         		36620/*<-type*/*18443/*<-String*/+
         		59701/*<-user_id*/*46168/*<-ullong*/+
         		54327/*<-domain*/*18443/*<-String*/+
         		45455/*<-property_name*/*18443/*<-String*/+
         		23051/*<-property_value*/*47/*<-repeating*/*18443/*<-String*/+
         		18222/*<-property_id*/*46168/*<-ullong*/;
 
	public UserPropertyVO() {
		super("User::UserPropertyVO", TYPE_SIGNATURE);

 		addFieldQualifier("type","default","ACCOUNT");
 
		set("type", null, "String");
 
		set("user_id", null, "ullong");
 
		set("domain", null, "String");
 
		set("property_name", null, "String");
 
		set("property_value", null, "List<String>");
 
		set("property_id", null, "ullong");
	}

	// {{{
	public void setType(String value) { this.set("type", (Object)value); }
 	public String getType() { return (String)this.get("type"); }
	// }}}
	// {{{
	public void setUserId(BigInteger value) { this.set("user_id", (Object)value); }
 	public BigInteger getUserId() { return (BigInteger)this.get("user_id"); }
	// }}}
	// {{{
	public void setDomain(String value) { this.set("domain", (Object)value); }
 	public String getDomain() { return (String)this.get("domain"); }
	// }}}
	// {{{
	public void setPropertyName(String value) { this.set("property_name", (Object)value); }
 	public String getPropertyName() { return (String)this.get("property_name"); }
	// }}}
	// {{{
	public void setPropertyValue(List<String> value) { this.set("property_value", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<String> getPropertyValue() { return (List<String>)this.get("property_value"); }
	// }}}
	// {{{
	public void setPropertyId(BigInteger value) { this.set("property_id", (Object)value); }
 	public BigInteger getPropertyId() { return (BigInteger)this.get("property_id"); }
	// }}}
}