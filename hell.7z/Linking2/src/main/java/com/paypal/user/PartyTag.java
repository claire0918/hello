/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/PartyVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:40 2012 */

package com.paypal.user;

import java.math.BigInteger;

  
public enum PartyTag {
/***/
   	COMMERCIAL_ENTITY(new String("COM_ENT"), ""),
   	ACCEPTS_HTML_EMAIL(new String("HTML_EML"), ""),
   	HAS_BUYER_CREDIT_ACCOUNT(new String("BUY_CRED"), "This tag is a hint, intended to reduce load on fpaccountserv. Tag is set when the user signs up for PayPal Credit products such as ebay MasterCard, PayPal Plus Card or PayPal Buyer Credit. The flag is unset if the credit account is closed. The plan is for this tag to be deprecated and usage moved to the HAS_EVER_HAD_FINANCIAL_PRODUCT tag."),
   	HAS_TRANSACTIONAL_BUYER_CREDIT_ACCOUNT(new String("TBC_ACCT"), "This tag is a hint, intended to reduce load on fpaccountserv. Tag is set when the user signs up for transactional buyer credit products such as BML or PayPal Pay Later (sunsetted). It is unest when the user closes the transactional credit account. The plan is for this tag to be deprecated and usage moved to the HAS_EVER_HAD_FINANCIAL_PRODUCT tag."),
   	HAS_EVER_HAD_FINANCIAL_PRODUCT(new String("FIN_PROD"), "This tag is a hint, intended to reduce load on fpaccountserv. Tag is set when a financial product account is created, and will never be unset. \"financial product account\" could include such things as \"Buyer Credit\", branded credit cards, or transactional credit programs like \"Bill Me Later\".");

	private final String value;
	private final String desc;

	private PartyTag(String value, String desc) {
		this.value = value;
		this.desc  = desc;
	}

	public String getValue() {
		return value;
	}

	public String getDesc() {
		return desc;
	}
}
