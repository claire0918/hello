/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AddressVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.user;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
  * 
   */

public class AddressCriteriaVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((57677*57677)<<32)/*<-AddressCriteriaVO*/+
         		53486/*<-load_addresses*/*15044/*<-bool*/+
         		58785/*<-filter_out_hidden*/*15044/*<-bool*/+
         		33376/*<-load_primary_only*/*15044/*<-bool*/+
         		31109/*<-filter_by_tags*/*47/*<-repeating*/*18443/*<-String*/;
 
	public AddressCriteriaVO() {
		super("User::AddressCriteriaVO", TYPE_SIGNATURE);

 
		set("load_addresses", null, "bool");
 
		set("filter_out_hidden", null, "bool");
 
		set("load_primary_only", null, "bool");
 
		set("filter_by_tags", null, "List<String>");
	}

	// {{{
	public void setLoadAddresses(Boolean value) { this.set("load_addresses", (Object)value); }
 	public Boolean getLoadAddresses() { return (Boolean)this.get("load_addresses"); }
	// }}}
	// {{{
	public void setFilterOutHidden(Boolean value) { this.set("filter_out_hidden", (Object)value); }
 	public Boolean getFilterOutHidden() { return (Boolean)this.get("filter_out_hidden"); }
	// }}}
	// {{{
	public void setLoadPrimaryOnly(Boolean value) { this.set("load_primary_only", (Object)value); }
 	public Boolean getLoadPrimaryOnly() { return (Boolean)this.get("load_primary_only"); }
	// }}}
	// {{{
	public void setFilterByTags(List<String> value) { this.set("filter_by_tags", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<String> getFilterByTags() { return (List<String>)this.get("filter_by_tags"); }
	// }}}
}