/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AccountToAccountRelationshipVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.user;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
  * 
   */

public class AccountRelCriteriaVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((34301*34301)<<32)/*<-AccountRelCriteriaVO*/+
         		35800/*<-load_account_rel*/*15044/*<-bool*/+
         		30640/*<-this_account_is*/*38894/*<-int*/+
         		40435/*<-other_account*/*46168/*<-ullong*/+
         		504/*<-rel_type*/*62361/*<-sint8*/;
 
	public AccountRelCriteriaVO() {
		super("User::AccountRelCriteriaVO", TYPE_SIGNATURE);

 
		set("load_account_rel", null, "bool");
 
		set("this_account_is", null, "int");
 
		set("other_account", null, "ullong");
 		addFieldQualifier("rel_type","cpp_gen","define_legacy");
 
		set("rel_type", null, "sint8");
	}

	// {{{
	public void setLoadAccountRel(Boolean value) { this.set("load_account_rel", (Object)value); }
 	public Boolean getLoadAccountRel() { return (Boolean)this.get("load_account_rel"); }
	// }}}
	// {{{
	public void setThisAccountIs(Integer value) { this.set("this_account_is", (Object)value); }
 	public Integer getThisAccountIs() { return (Integer)this.get("this_account_is"); }
	// }}}
	// {{{
	public void setOtherAccount(BigInteger value) { this.set("other_account", (Object)value); }
 	public BigInteger getOtherAccount() { return (BigInteger)this.get("other_account"); }
	// }}}
	// {{{
	public void setRelType(Byte value) { this.set("rel_type", (Object)value); }
 	public Byte getRelType() { return (Byte)this.get("rel_type"); }
	// }}}
}