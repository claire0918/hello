/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/ProductConfiguration.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:40 2012 */

package com.paypal.user;

import java.math.BigInteger;

  
public enum ProductConfigCustomLayerType {
/**
			These are types of layers that are programmatically created, and
			are defined by user (or admin agent) actions against the system.
			They hold account specific customizations of configuration values.
			These layers will define values only for those configs that the
			product allows user customization on.
		*/
   	SHARED(new String("SHARED"), ""),
   	USER_PREFERENCE(new String("USER"), ""),
   	ADMIN_OVERRIDE(new String("ADMIN"), "");

	private final String value;
	private final String desc;

	private ProductConfigCustomLayerType(String value, String desc) {
		this.value = value;
		this.desc  = desc;
	}

	public String getValue() {
		return value;
	}

	public String getDesc() {
		return desc;
	}
}
