/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/PublicCredentialVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:40 2012 */

package com.paypal.user;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
  * 
   */

public class CredentialLinkVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((55785*55785)<<32)/*<-CredentialLinkVO*/+
         		44043/*<-public_credential_id*/*46168/*<-ullong*/+
         		30984/*<-channel*/*18443/*<-String*/+
         		56609/*<-login_id*/*46168/*<-ullong*/+
         		44458/*<-private_credential_id*/*46168/*<-ullong*/+
         		11619/*<-is_active*/*15044/*<-bool*/;
 
	public CredentialLinkVO() {
		super("User::CredentialLinkVO", TYPE_SIGNATURE);

 
		set("public_credential_id", null, "ullong");
 
		set("channel", null, "String");
 
		set("login_id", null, "ullong");
 
		set("private_credential_id", null, "ullong");
 
		set("is_active", null, "bool");
	}

	// {{{
	public void setPublicCredentialId(BigInteger value) { this.set("public_credential_id", (Object)value); }
 	public BigInteger getPublicCredentialId() { return (BigInteger)this.get("public_credential_id"); }
	// }}}
	// {{{
	public void setChannel(String value) { this.set("channel", (Object)value); }
 	public String getChannel() { return (String)this.get("channel"); }
	// }}}
	// {{{
	public void setLoginId(BigInteger value) { this.set("login_id", (Object)value); }
 	public BigInteger getLoginId() { return (BigInteger)this.get("login_id"); }
	// }}}
	// {{{
	public void setPrivateCredentialId(BigInteger value) { this.set("private_credential_id", (Object)value); }
 	public BigInteger getPrivateCredentialId() { return (BigInteger)this.get("private_credential_id"); }
	// }}}
	// {{{
	public void setIsActive(Boolean value) { this.set("is_active", (Object)value); }
 	public Boolean getIsActive() { return (Boolean)this.get("is_active"); }
	// }}}
}