/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AccountVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.user;

import java.math.BigInteger;

  
public enum AccountSubprimeSubCategory {
/**
			*** DEPRECATED *** User does not own the complete list of values and
			so these may be out of sync.
			NOTE: make sure you map subcat to apropriate values: A maps to 0, Z 
			to 25, and so on.
		*/
   	MERCHANT_A(new Long("0"), ""),
   	MERCHANT_B(new Long("1"), ""),
   	MERCHANT_C(new Long("2"), ""),
   	MERCHANT_D(new Long("3"), ""),
   	MERCHANT_E(new Long("4"), ""),
   	MERCHANT_I(new Long("8"), ""),
   	MERCHANT_J(new Long("9"), ""),
   	MERCHANT_K(new Long("10"), "");

	private final Long value;
	private final String desc;

	private AccountSubprimeSubCategory(Long value, String desc) {
		this.value = value;
		this.desc  = desc;
	}

	public Long getValue() {
		return value;
	}

	public String getDesc() {
		return desc;
	}
}
