/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/EmailVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:40 2012 */

package com.paypal.user;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
  * 
   */

public class NewEmailVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((38167*38167)<<32)/*<-NewEmailVO*/+
         		20062/*<-email*/*18443/*<-String*/+
         		59512/*<-make_primary*/*15044/*<-bool*/+
         		3252/*<-confirmation_status*/*18443/*<-String*/+
         		35924/*<-confirmation_authority*/*18443/*<-String*/+
         		56803/*<-confirmation_status_for_relationship*/*18443/*<-String*/+
         		15925/*<-confirmation_authority_for_relationship*/*18443/*<-String*/+
         		13359/*<-tags*/*47/*<-repeating*/*18443/*<-String*/+
         		24422/*<-is_confirmed*/*15044/*<-bool*/+
         		30840/*<-confirmed_by*/*62361/*<-sint8*/+
         		28048/*<-is_admin*/*15044/*<-bool*/;
 
	public NewEmailVO() {
		super("User::NewEmailVO", TYPE_SIGNATURE);

 		addFieldQualifier("email","required","true");
 
		set("email", null, "String");
 
		set("make_primary", null, "bool");
 
		set("confirmation_status", null, "String");
 
		set("confirmation_authority", null, "String");
 
		set("confirmation_status_for_relationship", null, "String");
 
		set("confirmation_authority_for_relationship", null, "String");
 
		set("tags", null, "List<String>");
 
		set("is_confirmed", null, "bool");
 
		set("confirmed_by", null, "sint8");
 
		set("is_admin", null, "bool");
	}

	// {{{
	public void setEmail(String value) { this.set("email", (Object)value); }
 	public String getEmail() { return (String)this.get("email"); }
	// }}}
	// {{{
	public void setMakePrimary(Boolean value) { this.set("make_primary", (Object)value); }
 	public Boolean getMakePrimary() { return (Boolean)this.get("make_primary"); }
	// }}}
	// {{{
	public void setConfirmationStatus(String value) { this.set("confirmation_status", (Object)value); }
 	public String getConfirmationStatus() { return (String)this.get("confirmation_status"); }
	// }}}
	// {{{
	public void setConfirmationAuthority(String value) { this.set("confirmation_authority", (Object)value); }
 	public String getConfirmationAuthority() { return (String)this.get("confirmation_authority"); }
	// }}}
	// {{{
	public void setConfirmationStatusForRelationship(String value) { this.set("confirmation_status_for_relationship", (Object)value); }
 	public String getConfirmationStatusForRelationship() { return (String)this.get("confirmation_status_for_relationship"); }
	// }}}
	// {{{
	public void setConfirmationAuthorityForRelationship(String value) { this.set("confirmation_authority_for_relationship", (Object)value); }
 	public String getConfirmationAuthorityForRelationship() { return (String)this.get("confirmation_authority_for_relationship"); }
	// }}}
	// {{{
	public void setTags(List<String> value) { this.set("tags", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<String> getTags() { return (List<String>)this.get("tags"); }
	// }}}
	// {{{
	public void setIsConfirmed(Boolean value) { this.set("is_confirmed", (Object)value); }
 	public Boolean getIsConfirmed() { return (Boolean)this.get("is_confirmed"); }
	// }}}
	// {{{
	public void setConfirmedBy(Byte value) { this.set("confirmed_by", (Object)value); }
 	public Byte getConfirmedBy() { return (Byte)this.get("confirmed_by"); }
	// }}}
	// {{{
	public void setIsAdmin(Boolean value) { this.set("is_admin", (Object)value); }
 	public Boolean getIsAdmin() { return (Boolean)this.get("is_admin"); }
	// }}}
}