/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/PhoneVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:40 2012 */

package com.paypal.user;

import java.math.BigInteger;

  
public enum PartyPhoneConfirmationAuthority {
/***/
   	NONE(new String("NONE"), "should always be paired with validation status NONE."),
   	AUTHENTIFY(new String("AUTHNTFY"), ""),
   	MANUAL(new String("MANUAL"), ""),
   	SMS(new String("SMS"), "We sent them an SMS, they told us the secret code in the SMS"),
   	SMS_REPLY(new String("SMS_RPLY"), "We sent them an SMS, they responded to it."),
   	CARRIER(new String("CARRIER"), "The mobile provider (e.g. Verizon) confirmed the relationship."),
   	ADMIN(new String("ADMIN"), "Relationship status is known by the CSR (Admin) process. Typically, the person is talking on the phone to the agent, and the IVR system knows the phone number and the agent confirms the person's identity.");

	private final String value;
	private final String desc;

	private PartyPhoneConfirmationAuthority(String value, String desc) {
		this.value = value;
		this.desc  = desc;
	}

	public String getValue() {
		return value;
	}

	public String getDesc() {
		return desc;
	}
}
