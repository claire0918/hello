/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/ProductConfiguration.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:40 2012 */

package com.paypal.user;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
  * 
   */

public class NVPairVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((40708*40708)<<32)/*<-NVPairVO*/+
         		31416/*<-name*/*18443/*<-String*/+
         		38877/*<-value*/*18443/*<-String*/;
 
	public NVPairVO() {
		super("User::NVPairVO", TYPE_SIGNATURE);

 		addFieldQualifier("name","required","true");
 
		set("name", null, "String");
 		addFieldQualifier("value","required","true");
 
		set("value", null, "String");
	}

	// {{{
	public void setName(String value) { this.set("name", (Object)value); }
 	public String getName() { return (String)this.get("name"); }
	// }}}
	// {{{
	public void setValue(String value) { this.set("value", (Object)value); }
 	public String getValue() { return (String)this.get("value"); }
	// }}}
}