/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/PhoneVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:40 2012 */

package com.paypal.user;

import java.math.BigInteger;

  
public enum PhoneType {
/***/
   	NONE(new Long("0"), "not a real type."),
   	HOME(new Long("1"), ""),
   	WORK(new Long("2"), ""),
   	OTHER(new Long("3"), ""),
   	RELATIVE_OR_FRIEND(new Long("4"), ""),
   	VALIDATED_SESSION(new Long("5"), ""),
   	BUSINESS(new Long("6"), ""),
   	CUSTOMER_SERVICE(new Long("7"), ""),
   	WAX(new Long("8"), ""),
   	UPS(new Long("9"), ""),
   	MOBILE(new Long("10"), ""),
   	VERISIGN_BILLING(new Long("11"), ""),
   	FAX_VERISIGN_BILLING(new Long("12"), "Billing fax num for a Verisign merchant - who has a PayPal business acct linked to his Verisign Merchant acct (Unified User Model)"),
   	FAX_HOME(new Long("13"), ""),
   	FAX_BUSINESS(new Long("14"), "Fax number for a PayPal Business account");

	private final Long value;
	private final String desc;

	private PhoneType(Long value, String desc) {
		this.value = value;
		this.desc  = desc;
	}

	public Long getValue() {
		return value;
	}

	public String getDesc() {
		return desc;
	}
}
