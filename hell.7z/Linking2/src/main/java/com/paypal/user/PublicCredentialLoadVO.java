/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/PublicCredentialVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:40 2012 */

package com.paypal.user;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
  * 
   */

public class PublicCredentialLoadVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((54847*54847)<<32)/*<-PublicCredentialLoadVO*/+
         		6387/*<-public_credential*/*47/*<-repeating*/*PublicCredentialUniqueKey.TYPE_SIGNATURE/*<-PublicCredentialUniqueKey*/+
         		44043/*<-public_credential_id*/*47/*<-repeating*/*46168/*<-ullong*/+
         		56647/*<-party_criteria*/*PartyCriteriaVO.TYPE_SIGNATURE/*<-PartyCriteriaVO*/+
         		44062/*<-account_criteria*/*AccountCriteriaVO.TYPE_SIGNATURE/*<-AccountCriteriaVO*/+
         		50007/*<-access_point_criteria*/*AccessPointCriteriaVO.TYPE_SIGNATURE/*<-AccessPointCriteriaVO*/;
 
	public PublicCredentialLoadVO() {
		super("User::PublicCredentialLoadVO", TYPE_SIGNATURE);

 
		set("public_credential", null, "List<User::PublicCredentialUniqueKey>");
 
		set("public_credential_id", null, "List<ullong>");
 
		set("party_criteria", null, "User::PartyCriteriaVO");
 
		set("account_criteria", null, "User::AccountCriteriaVO");
 
		set("access_point_criteria", null, "User::AccessPointCriteriaVO");
	}

	// {{{
	public void setPublicCredential(List<PublicCredentialUniqueKey> value) { this.set("public_credential", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<PublicCredentialUniqueKey> getPublicCredential() { return (List<PublicCredentialUniqueKey>)this.get("public_credential"); }
	// }}}
	// {{{
	public void setPublicCredentialId(List<BigInteger> value) { this.set("public_credential_id", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<BigInteger> getPublicCredentialId() { return (List<BigInteger>)this.get("public_credential_id"); }
	// }}}
	// {{{
	public void setPartyCriteria(PartyCriteriaVO value) { this.set("party_criteria", (Object)value); }
 	public PartyCriteriaVO getPartyCriteria() { return (PartyCriteriaVO)this.get("party_criteria"); }
	// }}}
	// {{{
	public void setAccountCriteria(AccountCriteriaVO value) { this.set("account_criteria", (Object)value); }
 	public AccountCriteriaVO getAccountCriteria() { return (AccountCriteriaVO)this.get("account_criteria"); }
	// }}}
	// {{{
	public void setAccessPointCriteria(AccessPointCriteriaVO value) { this.set("access_point_criteria", (Object)value); }
 	public AccessPointCriteriaVO getAccessPointCriteria() { return (AccessPointCriteriaVO)this.get("access_point_criteria"); }
	// }}}
}