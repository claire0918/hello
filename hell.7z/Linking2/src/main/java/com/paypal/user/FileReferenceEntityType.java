/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/FileReferenceVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:40 2012 */

package com.paypal.user;

import java.math.BigInteger;

  
public enum FileReferenceEntityType {
/***/
   	ACCOUNT(new String("ACCOUNT"), ""),
   	PARTY(new String("PARTY"), "");

	private final String value;
	private final String desc;

	private FileReferenceEntityType(String value, String desc) {
		this.value = value;
		this.desc  = desc;
	}

	public String getValue() {
		return value;
	}

	public String getDesc() {
		return desc;
	}
}
