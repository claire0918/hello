/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AddressVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.user;

import java.math.BigInteger;

  
public enum PostalNormalizationStatus {
/***/
   	UNKNOWN(new String("UNKNOWN"), "The normalization status of the address is not known"),
   	NORMALIZED(new String("NORMAL"), "The address is reported as being normalized"),
   	NORMALIZATION_REJECTED(new String("NON_NORM"), "The address is reported as being specifically not normalized. This would happen when the front-end app recommends a normalized alternative and the user rejects it and keeps this instead.");

	private final String value;
	private final String desc;

	private PostalNormalizationStatus(String value, String desc) {
		this.value = value;
		this.desc  = desc;
	}

	public String getValue() {
		return value;
	}

	public String getDesc() {
		return desc;
	}
}
