/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/PhoneVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:40 2012 */

package com.paypal.user;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
  * 
   */

public class NewPhoneVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((24001*24001)<<32)/*<-NewPhoneVO*/+
         		36620/*<-type*/*33490/*<-ulong*/+
         		16570/*<-phone_number*/*18443/*<-String*/+
         		22340/*<-phone_entered*/*18443/*<-String*/+
         		23729/*<-country_code*/*18443/*<-String*/+
         		8002/*<-extension*/*18443/*<-String*/+
         		42850/*<-contact_name*/*18443/*<-String*/+
         		59512/*<-make_primary*/*15044/*<-bool*/+
         		13359/*<-tags*/*47/*<-repeating*/*18443/*<-String*/+
         		3252/*<-confirmation_status*/*18443/*<-String*/+
         		35924/*<-confirmation_authority*/*18443/*<-String*/+
         		56803/*<-confirmation_status_for_relationship*/*18443/*<-String*/+
         		15925/*<-confirmation_authority_for_relationship*/*18443/*<-String*/+
         		1177/*<-is_mobile_payment_enabled*/*15044/*<-bool*/+
         		47483/*<-validation_status*/*62361/*<-sint8*/+
         		52257/*<-validation_style*/*62361/*<-sint8*/+
         		5801/*<-has_fraud_alert*/*15044/*<-bool*/;
 
	public NewPhoneVO() {
		super("User::NewPhoneVO", TYPE_SIGNATURE);

 		addFieldQualifier("type","cpp_gen","define_legacy");
 
		set("type", null, "ulong");
 
		set("phone_number", null, "String");
 		addFieldQualifier("phone_entered","required","true");
 
		set("phone_entered", null, "String");
 		addFieldQualifier("country_code","required","true");
 
		set("country_code", null, "String");
 
		set("extension", null, "String");
 
		set("contact_name", null, "String");
 
		set("make_primary", null, "bool");
 
		set("tags", null, "List<String>");
 
		set("confirmation_status", null, "String");
 
		set("confirmation_authority", null, "String");
 
		set("confirmation_status_for_relationship", null, "String");
 
		set("confirmation_authority_for_relationship", null, "String");
 
		set("is_mobile_payment_enabled", null, "bool");
 
		set("validation_status", null, "sint8");
 
		set("validation_style", null, "sint8");
 
		set("has_fraud_alert", null, "bool");
	}

	// {{{
	public void setType(Long value) { this.set("type", (Object)value); }
 	public Long getType() { return (Long)this.get("type"); }
	// }}}
	// {{{
	public void setPhoneNumber(String value) { this.set("phone_number", (Object)value); }
 	public String getPhoneNumber() { return (String)this.get("phone_number"); }
	// }}}
	// {{{
	public void setPhoneEntered(String value) { this.set("phone_entered", (Object)value); }
 	public String getPhoneEntered() { return (String)this.get("phone_entered"); }
	// }}}
	// {{{
	public void setCountryCode(String value) { this.set("country_code", (Object)value); }
 	public String getCountryCode() { return (String)this.get("country_code"); }
	// }}}
	// {{{
	public void setExtension(String value) { this.set("extension", (Object)value); }
 	public String getExtension() { return (String)this.get("extension"); }
	// }}}
	// {{{
	public void setContactName(String value) { this.set("contact_name", (Object)value); }
 	public String getContactName() { return (String)this.get("contact_name"); }
	// }}}
	// {{{
	public void setMakePrimary(Boolean value) { this.set("make_primary", (Object)value); }
 	public Boolean getMakePrimary() { return (Boolean)this.get("make_primary"); }
	// }}}
	// {{{
	public void setTags(List<String> value) { this.set("tags", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<String> getTags() { return (List<String>)this.get("tags"); }
	// }}}
	// {{{
	public void setConfirmationStatus(String value) { this.set("confirmation_status", (Object)value); }
 	public String getConfirmationStatus() { return (String)this.get("confirmation_status"); }
	// }}}
	// {{{
	public void setConfirmationAuthority(String value) { this.set("confirmation_authority", (Object)value); }
 	public String getConfirmationAuthority() { return (String)this.get("confirmation_authority"); }
	// }}}
	// {{{
	public void setConfirmationStatusForRelationship(String value) { this.set("confirmation_status_for_relationship", (Object)value); }
 	public String getConfirmationStatusForRelationship() { return (String)this.get("confirmation_status_for_relationship"); }
	// }}}
	// {{{
	public void setConfirmationAuthorityForRelationship(String value) { this.set("confirmation_authority_for_relationship", (Object)value); }
 	public String getConfirmationAuthorityForRelationship() { return (String)this.get("confirmation_authority_for_relationship"); }
	// }}}
	// {{{
	public void setIsMobilePaymentEnabled(Boolean value) { this.set("is_mobile_payment_enabled", (Object)value); }
 	public Boolean getIsMobilePaymentEnabled() { return (Boolean)this.get("is_mobile_payment_enabled"); }
	// }}}
	// {{{
	public void setValidationStatus(Byte value) { this.set("validation_status", (Object)value); }
 	public Byte getValidationStatus() { return (Byte)this.get("validation_status"); }
	// }}}
	// {{{
	public void setValidationStyle(Byte value) { this.set("validation_style", (Object)value); }
 	public Byte getValidationStyle() { return (Byte)this.get("validation_style"); }
	// }}}
	// {{{
	public void setHasFraudAlert(Boolean value) { this.set("has_fraud_alert", (Object)value); }
 	public Boolean getHasFraudAlert() { return (Boolean)this.get("has_fraud_alert"); }
	// }}}
}