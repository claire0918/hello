/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/UserFlagsVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:41 2012 */

package com.paypal.user;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
  * 
   */

public class UserFlagsVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((65516*65516)<<32)/*<-UserFlagsVO*/+
         		62145/*<-account_number*/*46168/*<-ullong*/+
         		17568/*<-flag_group_id*/*33490/*<-ulong*/+
         		27251/*<-flag_group_value*/*33490/*<-ulong*/;
 
	public UserFlagsVO() {
		super("User::UserFlagsVO", TYPE_SIGNATURE);

 
		set("account_number", null, "ullong");
 
		set("flag_group_id", null, "ulong");
 
		set("flag_group_value", null, "ulong");
	}

	// {{{
	public void setAccountNumber(BigInteger value) { this.set("account_number", (Object)value); }
 	public BigInteger getAccountNumber() { return (BigInteger)this.get("account_number"); }
	// }}}
	// {{{
	public void setFlagGroupId(Long value) { this.set("flag_group_id", (Object)value); }
 	public Long getFlagGroupId() { return (Long)this.get("flag_group_id"); }
	// }}}
	// {{{
	public void setFlagGroupValue(Long value) { this.set("flag_group_value", (Object)value); }
 	public Long getFlagGroupValue() { return (Long)this.get("flag_group_value"); }
	// }}}
}