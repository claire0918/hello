/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/FileReferenceVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:40 2012 */

package com.paypal.user;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
  * 
   */

public class FileReferenceVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((2254*2254)<<32)/*<-FileReferenceVO*/+
         		33580/*<-file_reference*/*18443/*<-String*/+
         		24179/*<-entity_type*/*18443/*<-String*/+
         		56620/*<-entity_id*/*46168/*<-ullong*/+
         		25999/*<-file_category*/*18443/*<-String*/+
         		61764/*<-is_primary*/*15044/*<-bool*/+
         		11619/*<-is_active*/*15044/*<-bool*/+
         		13359/*<-tags*/*47/*<-repeating*/*18443/*<-String*/;
 
	public FileReferenceVO() {
		super("User::FileReferenceVO", TYPE_SIGNATURE);

 
		set("file_reference", null, "String");
 		addFieldQualifier("entity_type","default","PARTY");
 
		set("entity_type", null, "String");
 
		set("entity_id", null, "ullong");
 
		set("file_category", null, "String");
 
		set("is_primary", null, "bool");
 
		set("is_active", null, "bool");
 
		set("tags", null, "List<String>");
	}

	// {{{
	public void setFileReference(String value) { this.set("file_reference", (Object)value); }
 	public String getFileReference() { return (String)this.get("file_reference"); }
	// }}}
	// {{{
	public void setEntityType(String value) { this.set("entity_type", (Object)value); }
 	public String getEntityType() { return (String)this.get("entity_type"); }
	// }}}
	// {{{
	public void setEntityId(BigInteger value) { this.set("entity_id", (Object)value); }
 	public BigInteger getEntityId() { return (BigInteger)this.get("entity_id"); }
	// }}}
	// {{{
	public void setFileCategory(String value) { this.set("file_category", (Object)value); }
 	public String getFileCategory() { return (String)this.get("file_category"); }
	// }}}
	// {{{
	public void setIsPrimary(Boolean value) { this.set("is_primary", (Object)value); }
 	public Boolean getIsPrimary() { return (Boolean)this.get("is_primary"); }
	// }}}
	// {{{
	public void setIsActive(Boolean value) { this.set("is_active", (Object)value); }
 	public Boolean getIsActive() { return (Boolean)this.get("is_active"); }
	// }}}
	// {{{
	public void setTags(List<String> value) { this.set("tags", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<String> getTags() { return (List<String>)this.get("tags"); }
	// }}}
}