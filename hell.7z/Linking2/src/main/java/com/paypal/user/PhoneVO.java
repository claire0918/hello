/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/PhoneVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:40 2012 */

package com.paypal.user;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
  * 
   */

public class PhoneVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((15165*15165)<<32)/*<-PhoneVO*/+
         		3355/*<-id*/*46168/*<-ullong*/+
         		41975/*<-party_id*/*46168/*<-ullong*/+
         		36620/*<-type*/*33490/*<-ulong*/+
         		23729/*<-country_code*/*18443/*<-String*/+
         		16570/*<-phone_number*/*18443/*<-String*/+
         		8002/*<-extension*/*18443/*<-String*/+
         		54248/*<-user_entered_phone_number*/*18443/*<-String*/+
         		52222/*<-phone_string*/*18443/*<-String*/+
         		42850/*<-contact_name*/*18443/*<-String*/+
         		11619/*<-is_active*/*15044/*<-bool*/+
         		61764/*<-is_primary*/*15044/*<-bool*/+
         		13359/*<-tags*/*47/*<-repeating*/*18443/*<-String*/+
         		3252/*<-confirmation_status*/*18443/*<-String*/+
         		35924/*<-confirmation_authority*/*18443/*<-String*/+
         		56803/*<-confirmation_status_for_relationship*/*18443/*<-String*/+
         		15925/*<-confirmation_authority_for_relationship*/*18443/*<-String*/+
         		22809/*<-time_created*/*33490/*<-ulong*/+
         		62170/*<-time_removed*/*33490/*<-ulong*/+
         		62145/*<-account_number*/*46168/*<-ullong*/+
         		43592/*<-is_inactive*/*15044/*<-bool*/+
         		1177/*<-is_mobile_payment_enabled*/*15044/*<-bool*/+
         		47483/*<-validation_status*/*62361/*<-sint8*/+
         		52257/*<-validation_style*/*62361/*<-sint8*/+
         		5801/*<-has_fraud_alert*/*15044/*<-bool*/+
         		60232/*<-flags*/*33490/*<-ulong*/+
         		52543/*<-status*/*37752/*<-char*/;
 
	public PhoneVO() {
		super("User::PhoneVO", TYPE_SIGNATURE);

 
		set("id", null, "ullong");
 
		set("party_id", null, "ullong");
 		addFieldQualifier("type","cpp_gen","define_legacy");
 
		set("type", null, "ulong");
 
		set("country_code", null, "String");
 
		set("phone_number", null, "String");
 
		set("extension", null, "String");
 
		set("user_entered_phone_number", null, "String");
 
		set("phone_string", null, "String");
 
		set("contact_name", null, "String");
 
		set("is_active", null, "bool");
 
		set("is_primary", null, "bool");
 
		set("tags", null, "List<String>");
 
		set("confirmation_status", null, "String");
 
		set("confirmation_authority", null, "String");
 
		set("confirmation_status_for_relationship", null, "String");
 
		set("confirmation_authority_for_relationship", null, "String");
 
		set("time_created", null, "ulong");
 
		set("time_removed", null, "ulong");
 
		set("account_number", null, "ullong");
 
		set("is_inactive", null, "bool");
 
		set("is_mobile_payment_enabled", null, "bool");
 
		set("validation_status", null, "sint8");
 
		set("validation_style", null, "sint8");
 
		set("has_fraud_alert", null, "bool");
 
		set("flags", null, "ulong");
 
		set("status", null, "char");
	}

	// {{{
	public void setId(BigInteger value) { this.set("id", (Object)value); }
 	public BigInteger getId() { return (BigInteger)this.get("id"); }
	// }}}
	// {{{
	public void setPartyId(BigInteger value) { this.set("party_id", (Object)value); }
 	public BigInteger getPartyId() { return (BigInteger)this.get("party_id"); }
	// }}}
	// {{{
	public void setType(Long value) { this.set("type", (Object)value); }
 	public Long getType() { return (Long)this.get("type"); }
	// }}}
	// {{{
	public void setCountryCode(String value) { this.set("country_code", (Object)value); }
 	public String getCountryCode() { return (String)this.get("country_code"); }
	// }}}
	// {{{
	public void setPhoneNumber(String value) { this.set("phone_number", (Object)value); }
 	public String getPhoneNumber() { return (String)this.get("phone_number"); }
	// }}}
	// {{{
	public void setExtension(String value) { this.set("extension", (Object)value); }
 	public String getExtension() { return (String)this.get("extension"); }
	// }}}
	// {{{
	public void setUserEnteredPhoneNumber(String value) { this.set("user_entered_phone_number", (Object)value); }
 	public String getUserEnteredPhoneNumber() { return (String)this.get("user_entered_phone_number"); }
	// }}}
	// {{{
	public void setPhoneString(String value) { this.set("phone_string", (Object)value); }
 	public String getPhoneString() { return (String)this.get("phone_string"); }
	// }}}
	// {{{
	public void setContactName(String value) { this.set("contact_name", (Object)value); }
 	public String getContactName() { return (String)this.get("contact_name"); }
	// }}}
	// {{{
	public void setIsActive(Boolean value) { this.set("is_active", (Object)value); }
 	public Boolean getIsActive() { return (Boolean)this.get("is_active"); }
	// }}}
	// {{{
	public void setIsPrimary(Boolean value) { this.set("is_primary", (Object)value); }
 	public Boolean getIsPrimary() { return (Boolean)this.get("is_primary"); }
	// }}}
	// {{{
	public void setTags(List<String> value) { this.set("tags", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<String> getTags() { return (List<String>)this.get("tags"); }
	// }}}
	// {{{
	public void setConfirmationStatus(String value) { this.set("confirmation_status", (Object)value); }
 	public String getConfirmationStatus() { return (String)this.get("confirmation_status"); }
	// }}}
	// {{{
	public void setConfirmationAuthority(String value) { this.set("confirmation_authority", (Object)value); }
 	public String getConfirmationAuthority() { return (String)this.get("confirmation_authority"); }
	// }}}
	// {{{
	public void setConfirmationStatusForRelationship(String value) { this.set("confirmation_status_for_relationship", (Object)value); }
 	public String getConfirmationStatusForRelationship() { return (String)this.get("confirmation_status_for_relationship"); }
	// }}}
	// {{{
	public void setConfirmationAuthorityForRelationship(String value) { this.set("confirmation_authority_for_relationship", (Object)value); }
 	public String getConfirmationAuthorityForRelationship() { return (String)this.get("confirmation_authority_for_relationship"); }
	// }}}
	// {{{
	public void setTimeCreated(Long value) { this.set("time_created", (Object)value); }
 	public Long getTimeCreated() { return (Long)this.get("time_created"); }
	// }}}
	// {{{
	public void setTimeRemoved(Long value) { this.set("time_removed", (Object)value); }
 	public Long getTimeRemoved() { return (Long)this.get("time_removed"); }
	// }}}
	// {{{
	public void setAccountNumber(BigInteger value) { this.set("account_number", (Object)value); }
 	public BigInteger getAccountNumber() { return (BigInteger)this.get("account_number"); }
	// }}}
	// {{{
	public void setIsInactive(Boolean value) { this.set("is_inactive", (Object)value); }
 	public Boolean getIsInactive() { return (Boolean)this.get("is_inactive"); }
	// }}}
	// {{{
	public void setIsMobilePaymentEnabled(Boolean value) { this.set("is_mobile_payment_enabled", (Object)value); }
 	public Boolean getIsMobilePaymentEnabled() { return (Boolean)this.get("is_mobile_payment_enabled"); }
	// }}}
	// {{{
	public void setValidationStatus(Byte value) { this.set("validation_status", (Object)value); }
 	public Byte getValidationStatus() { return (Byte)this.get("validation_status"); }
	// }}}
	// {{{
	public void setValidationStyle(Byte value) { this.set("validation_style", (Object)value); }
 	public Byte getValidationStyle() { return (Byte)this.get("validation_style"); }
	// }}}
	// {{{
	public void setHasFraudAlert(Boolean value) { this.set("has_fraud_alert", (Object)value); }
 	public Boolean getHasFraudAlert() { return (Boolean)this.get("has_fraud_alert"); }
	// }}}
	// {{{
	public void setFlags(Long value) { this.set("flags", (Object)value); }
 	public Long getFlags() { return (Long)this.get("flags"); }
	// }}}
	// {{{
	public void setStatus(Byte value) { this.set("status", (Object)value); }
 	public Byte getStatus() { return (Byte)this.get("status"); }
	// }}}
}