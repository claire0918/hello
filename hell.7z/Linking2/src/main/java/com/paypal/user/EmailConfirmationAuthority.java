/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/EmailVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:40 2012 */

package com.paypal.user;

import java.math.BigInteger;

  
public enum EmailConfirmationAuthority {
/***/
   	NONE(new String("NONE"), ""),
   	UNKNOWN(new String("UNKNOWN"), "We didn't take note of who or what set the status"),
   	PARTY_RELATIONSHIP(new String("PRTY_REL"), "Marking the email confirmation status based on the confirmation status of at least one party.");

	private final String value;
	private final String desc;

	private EmailConfirmationAuthority(String value, String desc) {
		this.value = value;
		this.desc  = desc;
	}

	public String getValue() {
		return value;
	}

	public String getDesc() {
		return desc;
	}
}
