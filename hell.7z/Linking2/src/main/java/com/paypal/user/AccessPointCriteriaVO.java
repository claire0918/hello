/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AccessPointVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.user;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
  * 
   */

public class AccessPointCriteriaVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((28336*28336)<<32)/*<-AccessPointCriteriaVO*/+
         		7722/*<-load_access_point*/*15044/*<-bool*/+
         		45738/*<-filter_to_channel*/*47/*<-repeating*/*18443/*<-String*/+
         		35424/*<-public_credential_criteria*/*PublicCredentialCriteriaVO.TYPE_SIGNATURE/*<-PublicCredentialCriteriaVO*/+
         		56732/*<-remembered_actor_criteria*/*RememberedActorCriteriaVO.TYPE_SIGNATURE/*<-RememberedActorCriteriaVO*/+
         		44062/*<-account_criteria*/*AccessedAccountCriteriaVO.TYPE_SIGNATURE/*<-AccessedAccountCriteriaVO*/;
 
	public AccessPointCriteriaVO() {
		super("User::AccessPointCriteriaVO", TYPE_SIGNATURE);

 
		set("load_access_point", null, "bool");
 
		set("filter_to_channel", null, "List<String>");
 
		set("public_credential_criteria", null, "User::PublicCredentialCriteriaVO");
 
		set("remembered_actor_criteria", null, "User::RememberedActorCriteriaVO");
 
		set("account_criteria", null, "User::AccessedAccountCriteriaVO");
	}

	// {{{
	public void setLoadAccessPoint(Boolean value) { this.set("load_access_point", (Object)value); }
 	public Boolean getLoadAccessPoint() { return (Boolean)this.get("load_access_point"); }
	// }}}
	// {{{
	public void setFilterToChannel(List<String> value) { this.set("filter_to_channel", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<String> getFilterToChannel() { return (List<String>)this.get("filter_to_channel"); }
	// }}}
	// {{{
	public void setPublicCredentialCriteria(PublicCredentialCriteriaVO value) { this.set("public_credential_criteria", (Object)value); }
 	public PublicCredentialCriteriaVO getPublicCredentialCriteria() { return (PublicCredentialCriteriaVO)this.get("public_credential_criteria"); }
	// }}}
	// {{{
	public void setRememberedActorCriteria(RememberedActorCriteriaVO value) { this.set("remembered_actor_criteria", (Object)value); }
 	public RememberedActorCriteriaVO getRememberedActorCriteria() { return (RememberedActorCriteriaVO)this.get("remembered_actor_criteria"); }
	// }}}
	// {{{
	public void setAccountCriteria(AccessedAccountCriteriaVO value) { this.set("account_criteria", (Object)value); }
 	public AccessedAccountCriteriaVO getAccountCriteria() { return (AccessedAccountCriteriaVO)this.get("account_criteria"); }
	// }}}
}