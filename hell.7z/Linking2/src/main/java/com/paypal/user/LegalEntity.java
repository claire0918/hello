/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AccountVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.user;

import java.math.BigInteger;

  
public enum LegalEntity {
/**
			Legal entity definitions. It is generally based on the primary residence,
			but could differ for legacy accounts.
		*/
   	INC(new Byte("73"), "Paypal INC."),
   	EUROPE(new Byte("69"), "legal entity for Europe countries."),
   	CHINA(new Byte("67"), "legal entity for China region."),
   	AUSTRALIA(new Byte("83"), "legal entity for Australia countries."),
   	CANADA(new Byte("68"), "legal entity for Canada region."),
   	PVT_LTD(new Byte("80"), "legal entity as Paypal Private Ltd."),
   	INDIA(new Byte("84"), "legal entity for India region."),
   	BRAZIL(new Byte("66"), "legal entity for Brazil region."),
   	INDIA_BRANCH(new Byte("65"), "This entity is back end specific. For FinOps and Accounting the entity INDIA is grouped into two sub-entites from backend perspective One will be 3PL/4PL and will hold all non-INR currency files Another will hold all INR transactions only files"),
   	JAPAN(new Byte("74"), "legal entity for Japan region."),
   	RUSSIA(new Byte("82"), "legal entity for Russia region.");

	private final Byte value;
	private final String desc;

	private LegalEntity(Byte value, String desc) {
		this.value = value;
		this.desc  = desc;
	}

	public Byte getValue() {
		return value;
	}

	public String getDesc() {
		return desc;
	}
}
