/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AddressVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.user;

import java.math.BigInteger;

  
public enum AddressAuthorityCode {
/***/
   	NONE(new Byte("0"), "No authority code is set. If this authority code is specified with a new address, the address is determined to be valid or invalid, and then the authority code will be set appropriately to VALID or INVALID"),
   	INVALID(new Byte("1"), "This address was not given an authority code, and it looks invalid to us. If this authority code is specified with a new address and the address is determined to be valid, then the authority code will be changed to VALID."),
   	VALID(new Byte("2"), "This address appears valid to us. No external authority given, so this is on authority of PayPal logic. If this authority code is specified with a new address and the address is determined to be invalid, then an error will be returned. This allows clients to request an enforcement of stricter validation."),
   	NORMALIZED(new Byte("3"), "The address is on authority of the normalization logic. The client specified that this address is normalized."),
   	NON_NORMAL_VALID(new Byte("4"), "On authority of end user. We showed the user our normalization, but they rejected it and went with their own -- and it appears to be valid. If this authority code is specified with a new address and the address is determined to be invalid, then an error will be returned. This allows clients to request an enforcement of stricter validation."),
   	NON_NORMAL_INVALID(new Byte("5"), "Same as above, user rejected our normalization, but what they kept appears to be invalid by our logic. If this authority code is specified with a new address and the address is determined to be valid, then the authority code will be changed to NON_NORMAL_VALID.");

	private final Byte value;
	private final String desc;

	private AddressAuthorityCode(Byte value, String desc) {
		this.value = value;
		this.desc  = desc;
	}

	public Byte getValue() {
		return value;
	}

	public String getDesc() {
		return desc;
	}
}
