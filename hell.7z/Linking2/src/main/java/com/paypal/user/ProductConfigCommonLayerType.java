/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/ProductConfiguration.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:40 2012 */

package com.paypal.user;

import java.math.BigInteger;

  
public enum ProductConfigCommonLayerType {
/**
			These are types of layers that are manualy defined, have public
			names, and are hard-coded into the on-boarding code that sets them.
			They hold pre-determined configuration settings that drive the 
			basic behavior of the product.  Every config will be defined in one
			or more of these layers.
		*/
   	BASE(new String("BASE"), ""),
   	PRODUCT(new String("PRODUCT"), "");

	private final String value;
	private final String desc;

	private ProductConfigCommonLayerType(String value, String desc) {
		this.value = value;
		this.desc  = desc;
	}

	public String getValue() {
		return value;
	}

	public String getDesc() {
		return desc;
	}
}
