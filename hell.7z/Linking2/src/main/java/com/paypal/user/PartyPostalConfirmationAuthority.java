/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AddressVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.user;

import java.math.BigInteger;

  
public enum PartyPostalConfirmationAuthority {
/***/
   	NONE(new String("NONE"), ""),
   	MAIL(new String("MAIL"), ""),
   	PHONE(new String("PHONE"), ""),
   	PHONE_SOFT(new String("PHN_SOFT"), ""),
   	ADMIN(new String("ADMIN"), ""),
   	AUTO(new String("AUTO"), ""),
   	BUYER_CREDIT(new String("PPBC"), ""),
   	TRANSACTIONAL_BUYER_CREDIT(new String("PPTBC"), ""),
   	ALTERNATIVE_ADDRESS_CONFIRMATION(new String("AAC"), ""),
   	EV_MAIL(new String("EV_MAIL"), "I think EV = Enhanced Validation, but there aren't many reference to it in the code, so I'm not sure."),
   	THIRD_PARTY(new String("3RD_PRTY"), "A 3rd party (like Lexus-Nexus) has confirmed the address."),
   	POST_OFFICE(new String("PO"), "The address was confirmed by an in-country post office."),
   	DISCOVER(new String("DISCOVER"), "*** PROPOSED *** The Discover network confirmed the address.");

	private final String value;
	private final String desc;

	private PartyPostalConfirmationAuthority(String value, String desc) {
		this.value = value;
		this.desc  = desc;
	}

	public String getValue() {
		return value;
	}

	public String getDesc() {
		return desc;
	}
}
