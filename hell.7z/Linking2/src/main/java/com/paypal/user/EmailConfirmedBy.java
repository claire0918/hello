/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/EmailVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:40 2012 */

package com.paypal.user;

import java.math.BigInteger;

  
public enum EmailConfirmedBy {
/***/
   	STANDARD(new Byte("0"), ""),
   	SKYPE(new Byte("1"), ""),
   	TRANSACTIONAL_BUYER_CREDIT(new Byte("2"), "");

	private final Byte value;
	private final String desc;

	private EmailConfirmedBy(Byte value, String desc) {
		this.value = value;
		this.desc  = desc;
	}

	public Byte getValue() {
		return value;
	}

	public String getDesc() {
		return desc;
	}
}
