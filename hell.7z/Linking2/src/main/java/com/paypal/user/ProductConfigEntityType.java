/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/ProductConfiguration.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:40 2012 */

package com.paypal.user;

import java.math.BigInteger;

  
public enum ProductConfigEntityType {
/**
			Currently, product configs can only be attached to an account, but
			in the future we could support parties and party to account
			relationships.
		*/
   	ACCOUNT(new String("ACCOUNT"), "");

	private final String value;
	private final String desc;

	private ProductConfigEntityType(String value, String desc) {
		this.value = value;
		this.desc  = desc;
	}

	public String getValue() {
		return value;
	}

	public String getDesc() {
		return desc;
	}
}
