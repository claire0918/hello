/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AddressVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.user;

import java.math.BigInteger;

  
public enum AddressConfirmationStyle {
/***/
   	NONE(new Byte("0"), ""),
   	MAIL(new Byte("11"), ""),
   	PHONE(new Byte("12"), ""),
   	PHONE_SOFT(new Byte("13"), ""),
   	ADMIN(new Byte("14"), ""),
   	AUTO(new Byte("15"), ""),
   	PPBC(new Byte("16"), ""),
   	PPTBC(new Byte("17"), ""),
   	AAC(new Byte("18"), ""),
   	EV_MAIL(new Byte("19"), ""),
   	THIRD_PARTY(new Byte("20"), ""),
   	POST_OFFICE(new Byte("21"), "");

	private final Byte value;
	private final String desc;

	private AddressConfirmationStyle(Byte value, String desc) {
		this.value = value;
		this.desc  = desc;
	}

	public Byte getValue() {
		return value;
	}

	public String getDesc() {
		return desc;
	}
}
