/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/EmailVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:40 2012 */

package com.paypal.user;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
  * 
   */

public class EmailLoadVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((61430*61430)<<32)/*<-EmailLoadVO*/+
         		13760/*<-email_id*/*47/*<-repeating*/*46168/*<-ullong*/+
         		20062/*<-email*/*47/*<-repeating*/*18443/*<-String*/+
         		56647/*<-party_criteria*/*PartyCriteriaVO.TYPE_SIGNATURE/*<-PartyCriteriaVO*/;
 
	public EmailLoadVO() {
		super("User::EmailLoadVO", TYPE_SIGNATURE);

 
		set("email_id", null, "List<ullong>");
 
		set("email", null, "List<String>");
 
		set("party_criteria", null, "User::PartyCriteriaVO");
	}

	// {{{
	public void setEmailId(List<BigInteger> value) { this.set("email_id", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<BigInteger> getEmailId() { return (List<BigInteger>)this.get("email_id"); }
	// }}}
	// {{{
	public void setEmail(List<String> value) { this.set("email", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<String> getEmail() { return (List<String>)this.get("email"); }
	// }}}
	// {{{
	public void setPartyCriteria(PartyCriteriaVO value) { this.set("party_criteria", (Object)value); }
 	public PartyCriteriaVO getPartyCriteria() { return (PartyCriteriaVO)this.get("party_criteria"); }
	// }}}
}