/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/PartyToAccountRelationshipVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:40 2012 */

package com.paypal.user;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
  * 
   */

public class PartyAccountRelCriteriaVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((35689*35689)<<32)/*<-PartyAccountRelCriteriaVO*/+
         		24990/*<-load_party_account_rel*/*15044/*<-bool*/+
         		44062/*<-account_criteria*/*OwnedAccountCriteriaVO.TYPE_SIGNATURE/*<-OwnedAccountCriteriaVO*/;
 
	public PartyAccountRelCriteriaVO() {
		super("User::PartyAccountRelCriteriaVO", TYPE_SIGNATURE);

 
		set("load_party_account_rel", null, "bool");
 
		set("account_criteria", null, "User::OwnedAccountCriteriaVO");
	}

	// {{{
	public void setLoadPartyAccountRel(Boolean value) { this.set("load_party_account_rel", (Object)value); }
 	public Boolean getLoadPartyAccountRel() { return (Boolean)this.get("load_party_account_rel"); }
	// }}}
	// {{{
	public void setAccountCriteria(OwnedAccountCriteriaVO value) { this.set("account_criteria", (Object)value); }
 	public OwnedAccountCriteriaVO getAccountCriteria() { return (OwnedAccountCriteriaVO)this.get("account_criteria"); }
	// }}}
}