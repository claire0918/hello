/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/ProductConfiguration.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:40 2012 */

package com.paypal.user;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
  * 
   */

public class ModifyProductConfigVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((22688*22688)<<32)/*<-ModifyProductConfigVO*/+
         		5787/*<-type_of_layer_to_modify*/*18443/*<-String*/+
         		49516/*<-set_configs*/*47/*<-repeating*/*NVPairVO.TYPE_SIGNATURE/*<-NVPairVO*/;
 
	public ModifyProductConfigVO() {
		super("User::ModifyProductConfigVO", TYPE_SIGNATURE);

 		addFieldQualifier("type_of_layer_to_modify","required","true");
 
		set("type_of_layer_to_modify", null, "String");
 		addFieldQualifier("set_configs","required","true");
 
		set("set_configs", null, "List<User::NVPairVO>");
	}

	// {{{
	public void setTypeOfLayerToModify(String value) { this.set("type_of_layer_to_modify", (Object)value); }
 	public String getTypeOfLayerToModify() { return (String)this.get("type_of_layer_to_modify"); }
	// }}}
	// {{{
	public void setSetConfigs(List<NVPairVO> value) { this.set("set_configs", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<NVPairVO> getSetConfigs() { return (List<NVPairVO>)this.get("set_configs"); }
	// }}}
}