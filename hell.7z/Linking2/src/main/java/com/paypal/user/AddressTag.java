/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AddressVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.user;

import java.math.BigInteger;

  
public enum AddressTag {
/***/
   	WITHDRAWL_ALLOWED(new String("WITHDRAW"), ""),
   	PHYSICAL_DEBIT_CARD_REQUESTED(new String("DC_REQ"), ""),
   	CREDIT_CHECK(new String("CRED_CHK"), ""),
   	OBSOLETE_BUT_ATTACHED_WITH_CC(new String("HAS_CC"), ""),
   	DEFAULT_BILLING(new String("DEF_BILL"), "Can only be set, cannot be removed, and setting this tag auto- maticallly removes it from any other address for this party."),
   	DEFAULT_SHIPPING(new String("DEF_SHIP"), "Can only be set, cannot be removed, and setting this tag auto- maticallly removes it from any other address for this party."),
   	GIFT(new String("GIFT"), "DEPRECATED, the type element should be used instead."),
   	THIRD_PARTY(new String("3RD_PARTY"), "DEPRECATED, the type element should be used instead."),
   	OWNER(new String("OWNER"), "DEPRECATED, the type element should be used instead."),
   	SUPPLIER(new String("SUPPLIER"), "DEPRECATED, the type element should be used instead."),
   	PREVIOUS_BUSINESS(new String("PREV_BIZ"), "DEPRECATED, the type element should be used instead."),
   	ADDITIONAL_BUSINESS(new String("ADD_BIZ"), "DEPRECATED, the type element should be used instead."),
   	VERISIGN_BILLING(new String("VERISIGN"), "DEPRECATED, the type element should be used instead."),
   	PRIOR_ADDRESS(new String("PRIOR"), "DEPRECATED, the type element should be used instead."),
   	PRINCIPLE_BUSINESS(new String("MAIN_BIZ"), "DEPRECATED, the type element should be used instead."),
   	OFFICE(new String("OFFICE"), "DEPRECATED, the type element should be used instead."),
   	BUSINESS(new String("BUSINESS"), "DEPRECATED, the type element should be used instead.");

	private final String value;
	private final String desc;

	private AddressTag(String value, String desc) {
		this.value = value;
		this.desc  = desc;
	}

	public String getValue() {
		return value;
	}

	public String getDesc() {
		return desc;
	}
}
