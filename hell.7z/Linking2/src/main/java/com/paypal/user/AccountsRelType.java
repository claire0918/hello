/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AccountToAccountRelationshipVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.user;

import java.math.BigInteger;

  
public enum AccountsRelType {
/***/
   	ANY(new Byte("0"), "Shouldn't actually ever be put in the database. Just for specifying as a \"don't care\" parameter in loading relationships"),
   	PARTNER(new Byte("80"), "Account 1 grants transaction processing permission to account 2"),
   	BUSINESSUNIT(new Byte("66"), "Account 1 grants transaction processing permission to account 2"),
   	PARENT_YOUTH(new Byte("89"), "Account 1 is a youth account associated with account 2"),
   	API_ACCESS(new Byte("65"), "Account 1 is granting access to account 2 to make api calls on account 1's behalf"),
   	BUYER_MERCHANT(new Byte("77"), "Account 1 is granting access to account 2 to modify its address details account 1's behalf");

	private final Byte value;
	private final String desc;

	private AccountsRelType(Byte value, String desc) {
		this.value = value;
		this.desc  = desc;
	}

	public Byte getValue() {
		return value;
	}

	public String getDesc() {
		return desc;
	}
}
