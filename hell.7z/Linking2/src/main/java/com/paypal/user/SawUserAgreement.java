/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AccountVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.user;

import java.math.BigInteger;

  
public enum SawUserAgreement {
/***/
   	NONE(new Integer("0"), "No User Agreement was shown to the User."),
   	ONE_LINER(new Integer("1"), "A \"one liner\" agreement was shown. something like \"click here to accept user agreement and continue.\""),
   	FULL(new Integer("2"), "A text box with the full text of the user agreement was shown to the user.");

	private final Integer value;
	private final String desc;

	private SawUserAgreement(Integer value, String desc) {
		this.value = value;
		this.desc  = desc;
	}

	public Integer getValue() {
		return value;
	}

	public String getDesc() {
		return desc;
	}
}
