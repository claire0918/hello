/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AccessPointVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.user;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
  * 
   */

public class AccessPointVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((12474*12474)<<32)/*<-AccessPointVO*/+
         		41975/*<-party_id*/*46168/*<-ullong*/+
         		30984/*<-channel*/*18443/*<-String*/+
         		44043/*<-public_credential_id*/*46168/*<-ullong*/+
         		44458/*<-private_credential_id*/*46168/*<-ullong*/+
         		5727/*<-private_credential_type*/*18443/*<-String*/+
         		56124/*<-private_credential_strength*/*62361/*<-sint8*/+
         		52543/*<-status*/*18443/*<-String*/+
         		33339/*<-actor_id*/*46168/*<-ullong*/+
         		31450/*<-account_privileges*/*47/*<-repeating*/*AccountAccessPrivilege.TYPE_SIGNATURE/*<-AccountAccessPrivilege*/+
         		58956/*<-error_count*/*38894/*<-int*/+
         		56705/*<-is_locked*/*15044/*<-bool*/+
         		40863/*<-requires_2FA*/*15044/*<-bool*/+
         		15451/*<-needs_validation*/*62361/*<-sint8*/;
 
	public AccessPointVO() {
		super("User::AccessPointVO", TYPE_SIGNATURE);

 
		set("party_id", null, "ullong");
 
		set("channel", null, "String");
 
		set("public_credential_id", null, "ullong");
 
		set("private_credential_id", null, "ullong");
 
		set("private_credential_type", null, "String");
 
		set("private_credential_strength", null, "sint8");
 
		set("status", null, "String");
 
		set("actor_id", null, "ullong");
 
		set("account_privileges", null, "List<User::AccountAccessPrivilege>");
 
		set("error_count", null, "int");
 
		set("is_locked", null, "bool");
 
		set("requires_2FA", null, "bool");
 		addFieldQualifier("needs_validation","cpp_gen","define_legacy");
 
		set("needs_validation", null, "sint8");
	}

	// {{{
	public void setPartyId(BigInteger value) { this.set("party_id", (Object)value); }
 	public BigInteger getPartyId() { return (BigInteger)this.get("party_id"); }
	// }}}
	// {{{
	public void setChannel(String value) { this.set("channel", (Object)value); }
 	public String getChannel() { return (String)this.get("channel"); }
	// }}}
	// {{{
	public void setPublicCredentialId(BigInteger value) { this.set("public_credential_id", (Object)value); }
 	public BigInteger getPublicCredentialId() { return (BigInteger)this.get("public_credential_id"); }
	// }}}
	// {{{
	public void setPrivateCredentialId(BigInteger value) { this.set("private_credential_id", (Object)value); }
 	public BigInteger getPrivateCredentialId() { return (BigInteger)this.get("private_credential_id"); }
	// }}}
	// {{{
	public void setPrivateCredentialType(String value) { this.set("private_credential_type", (Object)value); }
 	public String getPrivateCredentialType() { return (String)this.get("private_credential_type"); }
	// }}}
	// {{{
	public void setPrivateCredentialStrength(Byte value) { this.set("private_credential_strength", (Object)value); }
 	public Byte getPrivateCredentialStrength() { return (Byte)this.get("private_credential_strength"); }
	// }}}
	// {{{
	public void setStatus(String value) { this.set("status", (Object)value); }
 	public String getStatus() { return (String)this.get("status"); }
	// }}}
	// {{{
	public void setActorId(BigInteger value) { this.set("actor_id", (Object)value); }
 	public BigInteger getActorId() { return (BigInteger)this.get("actor_id"); }
	// }}}
	// {{{
	public void setAccountPrivileges(List<AccountAccessPrivilege> value) { this.set("account_privileges", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<AccountAccessPrivilege> getAccountPrivileges() { return (List<AccountAccessPrivilege>)this.get("account_privileges"); }
	// }}}
	// {{{
	public void setErrorCount(Integer value) { this.set("error_count", (Object)value); }
 	public Integer getErrorCount() { return (Integer)this.get("error_count"); }
	// }}}
	// {{{
	public void setIsLocked(Boolean value) { this.set("is_locked", (Object)value); }
 	public Boolean getIsLocked() { return (Boolean)this.get("is_locked"); }
	// }}}
	// {{{
	public void setRequires2FA(Boolean value) { this.set("requires_2FA", (Object)value); }
 	public Boolean getRequires2FA() { return (Boolean)this.get("requires_2FA"); }
	// }}}
	// {{{
	public void setNeedsValidation(Byte value) { this.set("needs_validation", (Object)value); }
 	public Byte getNeedsValidation() { return (Byte)this.get("needs_validation"); }
	// }}}
}