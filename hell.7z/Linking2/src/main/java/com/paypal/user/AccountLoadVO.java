/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AccountVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.user;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
  * 
   */

public class AccountLoadVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((47385*47385)<<32)/*<-AccountLoadVO*/+
         		62145/*<-account_number*/*47/*<-repeating*/*46168/*<-ullong*/+
         		59101/*<-encrypted_account_number*/*47/*<-repeating*/*18443/*<-String*/+
         		44062/*<-account_criteria*/*AccountCriteriaVO.TYPE_SIGNATURE/*<-AccountCriteriaVO*/;
 
	public AccountLoadVO() {
		super("User::AccountLoadVO", TYPE_SIGNATURE);

 
		set("account_number", null, "List<ullong>");
 
		set("encrypted_account_number", null, "List<String>");
 
		set("account_criteria", null, "User::AccountCriteriaVO");
	}

	// {{{
	public void setAccountNumber(List<BigInteger> value) { this.set("account_number", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<BigInteger> getAccountNumber() { return (List<BigInteger>)this.get("account_number"); }
	// }}}
	// {{{
	public void setEncryptedAccountNumber(List<String> value) { this.set("encrypted_account_number", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<String> getEncryptedAccountNumber() { return (List<String>)this.get("encrypted_account_number"); }
	// }}}
	// {{{
	public void setAccountCriteria(AccountCriteriaVO value) { this.set("account_criteria", (Object)value); }
 	public AccountCriteriaVO getAccountCriteria() { return (AccountCriteriaVO)this.get("account_criteria"); }
	// }}}
}