/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/ProductConfiguration.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:40 2012 */

package com.paypal.user;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
  * 
   */

public class ProductConfigLayerVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((28119*28119)<<32)/*<-ProductConfigLayerVO*/+
         		3355/*<-id*/*46168/*<-ullong*/+
         		11619/*<-is_active*/*15044/*<-bool*/+
         		36620/*<-type*/*18443/*<-String*/+
         		31416/*<-name*/*18443/*<-String*/+
         		58817/*<-configs*/*47/*<-repeating*/*NVPairVO.TYPE_SIGNATURE/*<-NVPairVO*/;
 
	public ProductConfigLayerVO() {
		super("User::ProductConfigLayerVO", TYPE_SIGNATURE);

 		addFieldQualifier("id","required","true");
 
		set("id", null, "ullong");
 		addFieldQualifier("is_active","required","true");
 
		set("is_active", null, "bool");
 		addFieldQualifier("type","required","true");
 
		set("type", null, "String");
 
		set("name", null, "String");
 
		set("configs", null, "List<User::NVPairVO>");
	}

	// {{{
	public void setId(BigInteger value) { this.set("id", (Object)value); }
 	public BigInteger getId() { return (BigInteger)this.get("id"); }
	// }}}
	// {{{
	public void setIsActive(Boolean value) { this.set("is_active", (Object)value); }
 	public Boolean getIsActive() { return (Boolean)this.get("is_active"); }
	// }}}
	// {{{
	public void setType(String value) { this.set("type", (Object)value); }
 	public String getType() { return (String)this.get("type"); }
	// }}}
	// {{{
	public void setName(String value) { this.set("name", (Object)value); }
 	public String getName() { return (String)this.get("name"); }
	// }}}
	// {{{
	public void setConfigs(List<NVPairVO> value) { this.set("configs", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<NVPairVO> getConfigs() { return (List<NVPairVO>)this.get("configs"); }
	// }}}
}