/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/LegalLoggingVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:40 2012 */

package com.paypal.user;

import java.math.BigInteger;

  
public enum LegalAgreementType {
/***/
   	PRODUCT_DISCLOSURE_STATEMENT(new Byte("65"), "the PDS (intially in AU)"),
   	USER_AGREEMENT(new Byte("67"), "the site-wide UserAgreement"),
   	VDC_AGREEMENT(new Byte("118"), ""),
   	MOBILE_AGREEMENT_CHINA(new Byte("68"), "Mobile payment user agreement China EFR 6633"),
   	CE_AGREEMENT(new Byte("69"), "Merchant Services CE Agreement"),
   	VERISIGN_USER_AGREEMENT(new Byte("70"), ""),
   	VERISIGN_PRO_AGREEMENT(new Byte("71"), ""),
   	VERISIGN_PRIVACY_AGREEMENT(new Byte("72"), ""),
   	VERISIGN_PRICING_AGREEMENT(new Byte("73"), ""),
   	JTOS_AGREEMENT(new Byte("74"), ""),
   	CE_AGREEMENT_WF(new Byte("75"), "Merchant Services CE Agreement"),
   	CE_AGREEMENT_HSBC(new Byte("76"), "Merchant Services CE Agreement"),
   	CE_AGREEMENT_CPS(new Byte("77"), "Merchant Services CE Agreement"),
   	CE_AGREEMENT_RBS(new Byte("78"), "Merchant Services CE Agreement"),
   	EDELIVERY_CONSENT(new Byte("79"), "agreement to receive communications and documents electronically."),
   	POINT_OF_SALE_USAGE(new Byte("80"), "agreement to use the point of sale feature."),
   	KNUCKLEBUSTER_USER_AGREEMENT(new Byte("81"), "agreement to use the knucklebuster feature."),
   	POST_OFFICE_CASH_IN(new Byte("82"), "Agreement to use the \"cash in at Post office\" feature. This is a feature that allows users to deposit cash in the PayPal account via their local post office."),
   	CE_AGREEMENT_WP(new Byte("83"), "Merchant Services CE Agreement"),
   	FINANCIAL_BINDING_AUTHORITY(new Byte("84"), "agreement that Account Holder has the financial authority to bind the business to the agreement");

	private final Byte value;
	private final String desc;

	private LegalAgreementType(Byte value, String desc) {
		this.value = value;
		this.desc  = desc;
	}

	public Byte getValue() {
		return value;
	}

	public String getDesc() {
		return desc;
	}
}
