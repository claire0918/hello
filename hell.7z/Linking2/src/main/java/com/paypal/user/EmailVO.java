/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/EmailVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:40 2012 */

package com.paypal.user;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
  * 
   */

public class EmailVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((30371*30371)<<32)/*<-EmailVO*/+
         		3355/*<-id*/*46168/*<-ullong*/+
         		41975/*<-party_id*/*46168/*<-ullong*/+
         		20062/*<-email*/*18443/*<-String*/+
         		22809/*<-time_created*/*33490/*<-ulong*/+
         		11619/*<-is_active*/*15044/*<-bool*/+
         		61764/*<-is_primary*/*15044/*<-bool*/+
         		3252/*<-confirmation_status*/*18443/*<-String*/+
         		35924/*<-confirmation_authority*/*18443/*<-String*/+
         		56803/*<-confirmation_status_for_relationship*/*18443/*<-String*/+
         		15925/*<-confirmation_authority_for_relationship*/*18443/*<-String*/+
         		13359/*<-tags*/*47/*<-repeating*/*18443/*<-String*/+
         		43592/*<-is_inactive*/*15044/*<-bool*/+
         		24422/*<-is_confirmed*/*15044/*<-bool*/+
         		30840/*<-confirmed_by*/*62361/*<-sint8*/+
         		57020/*<-is_potentially_invalid*/*15044/*<-bool*/+
         		56798/*<-is_invalid*/*15044/*<-bool*/+
         		28048/*<-is_admin*/*15044/*<-bool*/;
 
	public EmailVO() {
		super("User::EmailVO", TYPE_SIGNATURE);

 		addFieldQualifier("id","required","true");
 
		set("id", null, "ullong");
 		addFieldQualifier("party_id","pii","true");
 		addFieldQualifier("party_id","required","true");
 
		set("party_id", null, "ullong");
 		addFieldQualifier("email","required","true");
 
		set("email", null, "String");
 
		set("time_created", null, "ulong");
 
		set("is_active", null, "bool");
 
		set("is_primary", null, "bool");
 
		set("confirmation_status", null, "String");
 
		set("confirmation_authority", null, "String");
 
		set("confirmation_status_for_relationship", null, "String");
 
		set("confirmation_authority_for_relationship", null, "String");
 
		set("tags", null, "List<String>");
 
		set("is_inactive", null, "bool");
 
		set("is_confirmed", null, "bool");
 
		set("confirmed_by", null, "sint8");
 
		set("is_potentially_invalid", null, "bool");
 
		set("is_invalid", null, "bool");
 
		set("is_admin", null, "bool");
	}

	// {{{
	public void setId(BigInteger value) { this.set("id", (Object)value); }
 	public BigInteger getId() { return (BigInteger)this.get("id"); }
	// }}}
	// {{{
	public void setPartyId(BigInteger value) { this.set("party_id", (Object)value); }
 	public BigInteger getPartyId() { return (BigInteger)this.get("party_id"); }
	// }}}
	// {{{
	public void setEmail(String value) { this.set("email", (Object)value); }
 	public String getEmail() { return (String)this.get("email"); }
	// }}}
	// {{{
	public void setTimeCreated(Long value) { this.set("time_created", (Object)value); }
 	public Long getTimeCreated() { return (Long)this.get("time_created"); }
	// }}}
	// {{{
	public void setIsActive(Boolean value) { this.set("is_active", (Object)value); }
 	public Boolean getIsActive() { return (Boolean)this.get("is_active"); }
	// }}}
	// {{{
	public void setIsPrimary(Boolean value) { this.set("is_primary", (Object)value); }
 	public Boolean getIsPrimary() { return (Boolean)this.get("is_primary"); }
	// }}}
	// {{{
	public void setConfirmationStatus(String value) { this.set("confirmation_status", (Object)value); }
 	public String getConfirmationStatus() { return (String)this.get("confirmation_status"); }
	// }}}
	// {{{
	public void setConfirmationAuthority(String value) { this.set("confirmation_authority", (Object)value); }
 	public String getConfirmationAuthority() { return (String)this.get("confirmation_authority"); }
	// }}}
	// {{{
	public void setConfirmationStatusForRelationship(String value) { this.set("confirmation_status_for_relationship", (Object)value); }
 	public String getConfirmationStatusForRelationship() { return (String)this.get("confirmation_status_for_relationship"); }
	// }}}
	// {{{
	public void setConfirmationAuthorityForRelationship(String value) { this.set("confirmation_authority_for_relationship", (Object)value); }
 	public String getConfirmationAuthorityForRelationship() { return (String)this.get("confirmation_authority_for_relationship"); }
	// }}}
	// {{{
	public void setTags(List<String> value) { this.set("tags", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<String> getTags() { return (List<String>)this.get("tags"); }
	// }}}
	// {{{
	public void setIsInactive(Boolean value) { this.set("is_inactive", (Object)value); }
 	public Boolean getIsInactive() { return (Boolean)this.get("is_inactive"); }
	// }}}
	// {{{
	public void setIsConfirmed(Boolean value) { this.set("is_confirmed", (Object)value); }
 	public Boolean getIsConfirmed() { return (Boolean)this.get("is_confirmed"); }
	// }}}
	// {{{
	public void setConfirmedBy(Byte value) { this.set("confirmed_by", (Object)value); }
 	public Byte getConfirmedBy() { return (Byte)this.get("confirmed_by"); }
	// }}}
	// {{{
	public void setIsPotentiallyInvalid(Boolean value) { this.set("is_potentially_invalid", (Object)value); }
 	public Boolean getIsPotentiallyInvalid() { return (Boolean)this.get("is_potentially_invalid"); }
	// }}}
	// {{{
	public void setIsInvalid(Boolean value) { this.set("is_invalid", (Object)value); }
 	public Boolean getIsInvalid() { return (Boolean)this.get("is_invalid"); }
	// }}}
	// {{{
	public void setIsAdmin(Boolean value) { this.set("is_admin", (Object)value); }
 	public Boolean getIsAdmin() { return (Boolean)this.get("is_admin"); }
	// }}}
}