/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/UserVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:41 2012 */

package com.paypal.user;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
  * 
   */

public class UserVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((7284*7284)<<32)/*<-UserVO*/+
         		62145/*<-account_number*/*46168/*<-ullong*/+
         		38420/*<-iso_primary_residence*/*18443/*<-String*/+
         		55493/*<-subprime*/*33490/*<-ulong*/+
         		64253/*<-is_international*/*15044/*<-bool*/+
         		57361/*<-is_gaming*/*15044/*<-bool*/;
 
	public UserVO() {
		super("User::UserVO", TYPE_SIGNATURE);

 
		set("account_number", null, "ullong");
 
		set("iso_primary_residence", null, "String");
 
		set("subprime", null, "ulong");
 
		set("is_international", null, "bool");
 
		set("is_gaming", null, "bool");
	}

	// {{{
	public void setAccountNumber(BigInteger value) { this.set("account_number", (Object)value); }
 	public BigInteger getAccountNumber() { return (BigInteger)this.get("account_number"); }
	// }}}
	// {{{
	public void setIsoPrimaryResidence(String value) { this.set("iso_primary_residence", (Object)value); }
 	public String getIsoPrimaryResidence() { return (String)this.get("iso_primary_residence"); }
	// }}}
	// {{{
	public void setSubprime(Long value) { this.set("subprime", (Object)value); }
 	public Long getSubprime() { return (Long)this.get("subprime"); }
	// }}}
	// {{{
	public void setIsInternational(Boolean value) { this.set("is_international", (Object)value); }
 	public Boolean getIsInternational() { return (Boolean)this.get("is_international"); }
	// }}}
	// {{{
	public void setIsGaming(Boolean value) { this.set("is_gaming", (Object)value); }
 	public Boolean getIsGaming() { return (Boolean)this.get("is_gaming"); }
	// }}}
}