/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/RememberedActorVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:40 2012 */

package com.paypal.user;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
  * 
   */

public class RememberedActorVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((24143*24143)<<32)/*<-RememberedActorVO*/+
         		3355/*<-id*/*46168/*<-ullong*/+
         		33339/*<-actor_id*/*46168/*<-ullong*/+
         		41975/*<-party_id*/*46168/*<-ullong*/+
         		62145/*<-account_number*/*46168/*<-ullong*/+
         		62367/*<-group*/*18443/*<-String*/+
         		49051/*<-tag*/*18443/*<-String*/+
         		22809/*<-time_created*/*33490/*<-ulong*/+
         		5095/*<-expiration_time*/*33490/*<-ulong*/+
         		11619/*<-is_active*/*15044/*<-bool*/;
 
	public RememberedActorVO() {
		super("User::RememberedActorVO", TYPE_SIGNATURE);

 
		set("id", null, "ullong");
 
		set("actor_id", null, "ullong");
 
		set("party_id", null, "ullong");
 
		set("account_number", null, "ullong");
 
		set("group", null, "String");
 
		set("tag", null, "String");
 
		set("time_created", null, "ulong");
 
		set("expiration_time", null, "ulong");
 
		set("is_active", null, "bool");
	}

	// {{{
	public void setId(BigInteger value) { this.set("id", (Object)value); }
 	public BigInteger getId() { return (BigInteger)this.get("id"); }
	// }}}
	// {{{
	public void setActorId(BigInteger value) { this.set("actor_id", (Object)value); }
 	public BigInteger getActorId() { return (BigInteger)this.get("actor_id"); }
	// }}}
	// {{{
	public void setPartyId(BigInteger value) { this.set("party_id", (Object)value); }
 	public BigInteger getPartyId() { return (BigInteger)this.get("party_id"); }
	// }}}
	// {{{
	public void setAccountNumber(BigInteger value) { this.set("account_number", (Object)value); }
 	public BigInteger getAccountNumber() { return (BigInteger)this.get("account_number"); }
	// }}}
	// {{{
	public void setGroup(String value) { this.set("group", (Object)value); }
 	public String getGroup() { return (String)this.get("group"); }
	// }}}
	// {{{
	public void setTag(String value) { this.set("tag", (Object)value); }
 	public String getTag() { return (String)this.get("tag"); }
	// }}}
	// {{{
	public void setTimeCreated(Long value) { this.set("time_created", (Object)value); }
 	public Long getTimeCreated() { return (Long)this.get("time_created"); }
	// }}}
	// {{{
	public void setExpirationTime(Long value) { this.set("expiration_time", (Object)value); }
 	public Long getExpirationTime() { return (Long)this.get("expiration_time"); }
	// }}}
	// {{{
	public void setIsActive(Boolean value) { this.set("is_active", (Object)value); }
 	public Boolean getIsActive() { return (Boolean)this.get("is_active"); }
	// }}}
}