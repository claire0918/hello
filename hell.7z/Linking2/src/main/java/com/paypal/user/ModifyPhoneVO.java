/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/PhoneVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:40 2012 */

package com.paypal.user;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
  * 
   */

public class ModifyPhoneVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((36156*36156)<<32)/*<-ModifyPhoneVO*/+
         		41975/*<-party_id*/*46168/*<-ullong*/+
         		5695/*<-phone_id*/*46168/*<-ullong*/+
         		20507/*<-make_inactive*/*15044/*<-bool*/+
         		59512/*<-make_primary*/*15044/*<-bool*/+
         		3252/*<-confirmation_status*/*18443/*<-String*/+
         		35924/*<-confirmation_authority*/*18443/*<-String*/+
         		42850/*<-contact_name*/*18443/*<-String*/+
         		56803/*<-confirmation_status_for_relationship*/*18443/*<-String*/+
         		15925/*<-confirmation_authority_for_relationship*/*18443/*<-String*/+
         		46753/*<-add_tags*/*47/*<-repeating*/*18443/*<-String*/+
         		41076/*<-remove_tags*/*47/*<-repeating*/*18443/*<-String*/;
 
	public ModifyPhoneVO() {
		super("User::ModifyPhoneVO", TYPE_SIGNATURE);

 
		set("party_id", null, "ullong");
 		addFieldQualifier("phone_id","required","true");
 
		set("phone_id", null, "ullong");
 
		set("make_inactive", null, "bool");
 
		set("make_primary", null, "bool");
 
		set("confirmation_status", null, "String");
 
		set("confirmation_authority", null, "String");
 
		set("contact_name", null, "String");
 
		set("confirmation_status_for_relationship", null, "String");
 
		set("confirmation_authority_for_relationship", null, "String");
 
		set("add_tags", null, "List<String>");
 
		set("remove_tags", null, "List<String>");
	}

	// {{{
	public void setPartyId(BigInteger value) { this.set("party_id", (Object)value); }
 	public BigInteger getPartyId() { return (BigInteger)this.get("party_id"); }
	// }}}
	// {{{
	public void setPhoneId(BigInteger value) { this.set("phone_id", (Object)value); }
 	public BigInteger getPhoneId() { return (BigInteger)this.get("phone_id"); }
	// }}}
	// {{{
	public void setMakeInactive(Boolean value) { this.set("make_inactive", (Object)value); }
 	public Boolean getMakeInactive() { return (Boolean)this.get("make_inactive"); }
	// }}}
	// {{{
	public void setMakePrimary(Boolean value) { this.set("make_primary", (Object)value); }
 	public Boolean getMakePrimary() { return (Boolean)this.get("make_primary"); }
	// }}}
	// {{{
	public void setConfirmationStatus(String value) { this.set("confirmation_status", (Object)value); }
 	public String getConfirmationStatus() { return (String)this.get("confirmation_status"); }
	// }}}
	// {{{
	public void setConfirmationAuthority(String value) { this.set("confirmation_authority", (Object)value); }
 	public String getConfirmationAuthority() { return (String)this.get("confirmation_authority"); }
	// }}}
	// {{{
	public void setContactName(String value) { this.set("contact_name", (Object)value); }
 	public String getContactName() { return (String)this.get("contact_name"); }
	// }}}
	// {{{
	public void setConfirmationStatusForRelationship(String value) { this.set("confirmation_status_for_relationship", (Object)value); }
 	public String getConfirmationStatusForRelationship() { return (String)this.get("confirmation_status_for_relationship"); }
	// }}}
	// {{{
	public void setConfirmationAuthorityForRelationship(String value) { this.set("confirmation_authority_for_relationship", (Object)value); }
 	public String getConfirmationAuthorityForRelationship() { return (String)this.get("confirmation_authority_for_relationship"); }
	// }}}
	// {{{
	public void setAddTags(List<String> value) { this.set("add_tags", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<String> getAddTags() { return (List<String>)this.get("add_tags"); }
	// }}}
	// {{{
	public void setRemoveTags(List<String> value) { this.set("remove_tags", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<String> getRemoveTags() { return (List<String>)this.get("remove_tags"); }
	// }}}
}