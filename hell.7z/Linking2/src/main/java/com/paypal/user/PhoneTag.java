/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/PhoneVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:40 2012 */

package com.paypal.user;

import java.math.BigInteger;

  
public enum PhoneTag {
/***/
   	ASSOCIATED_WITH_CREDIT_CARD(new String("TIE_CC"), ""),
   	ASSOCIATED_WITH_ADDRESS(new String("TIE_ADDR"), ""),
   	ASSOCIATED_WITH_BUYER_CREDIT(new String("TIE_BC"), ""),
   	FRAUD_NOTIFICATION(new String("FRAUD"), ""),
   	TOLL_FREE(new String("TOLLFREE"), ""),
   	HOME(new String("HOME"), "*** DEPRECATED *** Look at the type instead"),
   	WORK(new String("WORK"), "*** DEPRECATED *** Look at the type instead"),
   	OTHER(new String("OTHER"), "*** DEPRECATED *** Look at the type instead"),
   	RELATIVE_OR_FRIEND(new String("FRIEND"), "*** DEPRECATED *** Look at the type instead"),
   	VALIDATED_SESSION(new String("VAL_SESS"), "*** DEPRECATED *** Look at the type instead"),
   	BUSINESS(new String("BUSINESS"), "*** DEPRECATED *** Look at the type instead"),
   	CUSTOMER_SERVICE(new String("CUST_SRV"), "*** DEPRECATED *** Look at the type instead"),
   	UPS(new String("UPS"), "*** DEPRECATED *** Look at the type instead"),
   	MOBILE(new String("MOBILE"), "*** DEPRECATED *** Look at the type instead"),
   	VERISIGN_BILLING(new String("VERISIGN"), "*** DEPRECATED *** Look at the type instead"),
   	FAX(new String("FAX"), "*** DEPRECATED *** Look at the type instead"),
   	DEFAULT(new String("DEFAULT"), "*** DEPRECATED *** Look at is_primary instead"),
   	PAYMENT_ENABLED(new String("PAY_ABLE"), "*** DEPRECATED *** Was created by the now defunct China Mobile project and may not mean quite what you think it means. Whether a phone number can be used to receive payments should be determined by looking for a coordinating Public Credential. Please discontinue use of this tag."),
   	SMS_NOTIFICATION(new String("SMS_NOTE"), "*** DEPRECATED *** Doesn't mean at all what you think it means. This was created as part of the now defunct China Mobile project. Our best understanding is that it is an indicator of a \"pending verification\" status. This tag should be deprecated, and may be actually wiped from the database. Please stop using it.");

	private final String value;
	private final String desc;

	private PhoneTag(String value, String desc) {
		this.value = value;
		this.desc  = desc;
	}

	public String getValue() {
		return value;
	}

	public String getDesc() {
		return desc;
	}
}
