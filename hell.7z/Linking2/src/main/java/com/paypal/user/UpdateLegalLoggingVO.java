/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/LegalLoggingVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:40 2012 */

package com.paypal.user;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
  * 
   */

public class UpdateLegalLoggingVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((55723*55723)<<32)/*<-UpdateLegalLoggingVO*/+
         		36620/*<-type*/*62361/*<-sint8*/+
         		10813/*<-declined_upgrade*/*15044/*<-bool*/+
         		32983/*<-major_version_number*/*33490/*<-ulong*/+
         		6342/*<-minor_version_number*/*33490/*<-ulong*/+
         		51137/*<-action_memo*/*18443/*<-String*/;
 
	public UpdateLegalLoggingVO() {
		super("User::UpdateLegalLoggingVO", TYPE_SIGNATURE);

 		addFieldQualifier("type","cpp_gen","define_legacy");
 		addFieldQualifier("type","required","true");
 
		set("type", null, "sint8");
 
		set("declined_upgrade", null, "bool");
 		addFieldQualifier("major_version_number","required","true");
 
		set("major_version_number", null, "ulong");
 		addFieldQualifier("minor_version_number","required","true");
 
		set("minor_version_number", null, "ulong");
 
		set("action_memo", null, "String");
	}

	// {{{
	public void setType(Byte value) { this.set("type", (Object)value); }
 	public Byte getType() { return (Byte)this.get("type"); }
	// }}}
	// {{{
	public void setDeclinedUpgrade(Boolean value) { this.set("declined_upgrade", (Object)value); }
 	public Boolean getDeclinedUpgrade() { return (Boolean)this.get("declined_upgrade"); }
	// }}}
	// {{{
	public void setMajorVersionNumber(Long value) { this.set("major_version_number", (Object)value); }
 	public Long getMajorVersionNumber() { return (Long)this.get("major_version_number"); }
	// }}}
	// {{{
	public void setMinorVersionNumber(Long value) { this.set("minor_version_number", (Object)value); }
 	public Long getMinorVersionNumber() { return (Long)this.get("minor_version_number"); }
	// }}}
	// {{{
	public void setActionMemo(String value) { this.set("action_memo", (Object)value); }
 	public String getActionMemo() { return (String)this.get("action_memo"); }
	// }}}
}