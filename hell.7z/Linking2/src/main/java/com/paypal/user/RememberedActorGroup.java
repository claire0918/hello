/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/RememberedActorVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:40 2012 */

package com.paypal.user;

import java.math.BigInteger;

  
public enum RememberedActorGroup {
/***/
   	DIGITAL_GOODS(new String("DG"), ""),
   	MERCHANT_INTEGRATED_CHECKOUT(new String("IXO"), ""),
   	MOBILE_CHECKOUT(new String("MXO"), "");

	private final String value;
	private final String desc;

	private RememberedActorGroup(String value, String desc) {
		this.value = value;
		this.desc  = desc;
	}

	public String getValue() {
		return value;
	}

	public String getDesc() {
		return desc;
	}
}
