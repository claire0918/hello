/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AccountVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.user;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
  * 
   */

public class UpdateAccountVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((10554*10554)<<32)/*<-UpdateAccountVO*/+
         		62145/*<-account_number*/*46168/*<-ullong*/+
         		51561/*<-last_name*/*18443/*<-String*/+
         		35037/*<-first_name*/*18443/*<-String*/+
         		38026/*<-language*/*18443/*<-String*/+
         		2233/*<-primary_currency_code*/*18443/*<-String*/+
         		57575/*<-citizenship*/*18443/*<-String*/+
         		17350/*<-timezone*/*18443/*<-String*/+
         		28425/*<-subprime_category*/*33490/*<-ulong*/+
         		3328/*<-subprime_subcategory*/*33490/*<-ulong*/+
         		63182/*<-fraud_score*/*46796/*<-llong*/+
         		56705/*<-is_locked*/*15044/*<-bool*/+
         		43592/*<-is_inactive*/*15044/*<-bool*/+
         		30573/*<-is_verified*/*15044/*<-bool*/+
         		22150/*<-is_restricted*/*15044/*<-bool*/+
         		54989/*<-is_high_restricted*/*15044/*<-bool*/+
         		2090/*<-is_sanction_list_locked*/*15044/*<-bool*/+
         		31122/*<-is_commercial_entity*/*15044/*<-bool*/+
         		47801/*<-set_flags*/*47/*<-repeating*/*UserFlagsVO.TYPE_SIGNATURE/*<-UserFlagsVO*/+
         		2841/*<-unset_flags*/*47/*<-repeating*/*UserFlagsVO.TYPE_SIGNATURE/*<-UserFlagsVO*/+
         		64599/*<-account_name*/*18443/*<-String*/;
 
	public UpdateAccountVO() {
		super("User::UpdateAccountVO", TYPE_SIGNATURE);

 
		set("account_number", null, "ullong");
 
		set("last_name", null, "String");
 
		set("first_name", null, "String");
 
		set("language", null, "String");
 
		set("primary_currency_code", null, "String");
 
		set("citizenship", null, "String");
 
		set("timezone", null, "String");
 
		set("subprime_category", null, "ulong");
 
		set("subprime_subcategory", null, "ulong");
 
		set("fraud_score", null, "llong");
 
		set("is_locked", null, "bool");
 
		set("is_inactive", null, "bool");
 
		set("is_verified", null, "bool");
 
		set("is_restricted", null, "bool");
 
		set("is_high_restricted", null, "bool");
 
		set("is_sanction_list_locked", null, "bool");
 
		set("is_commercial_entity", null, "bool");
 
		set("set_flags", null, "List<User::UserFlagsVO>");
 
		set("unset_flags", null, "List<User::UserFlagsVO>");
 
		set("account_name", null, "String");
	}

	// {{{
	public void setAccountNumber(BigInteger value) { this.set("account_number", (Object)value); }
 	public BigInteger getAccountNumber() { return (BigInteger)this.get("account_number"); }
	// }}}
	// {{{
	public void setLastName(String value) { this.set("last_name", (Object)value); }
 	public String getLastName() { return (String)this.get("last_name"); }
	// }}}
	// {{{
	public void setFirstName(String value) { this.set("first_name", (Object)value); }
 	public String getFirstName() { return (String)this.get("first_name"); }
	// }}}
	// {{{
	public void setLanguage(String value) { this.set("language", (Object)value); }
 	public String getLanguage() { return (String)this.get("language"); }
	// }}}
	// {{{
	public void setPrimaryCurrencyCode(String value) { this.set("primary_currency_code", (Object)value); }
 	public String getPrimaryCurrencyCode() { return (String)this.get("primary_currency_code"); }
	// }}}
	// {{{
	public void setCitizenship(String value) { this.set("citizenship", (Object)value); }
 	public String getCitizenship() { return (String)this.get("citizenship"); }
	// }}}
	// {{{
	public void setTimezone(String value) { this.set("timezone", (Object)value); }
 	public String getTimezone() { return (String)this.get("timezone"); }
	// }}}
	// {{{
	public void setSubprimeCategory(Long value) { this.set("subprime_category", (Object)value); }
 	public Long getSubprimeCategory() { return (Long)this.get("subprime_category"); }
	// }}}
	// {{{
	public void setSubprimeSubcategory(Long value) { this.set("subprime_subcategory", (Object)value); }
 	public Long getSubprimeSubcategory() { return (Long)this.get("subprime_subcategory"); }
	// }}}
	// {{{
	public void setFraudScore(Long value) { this.set("fraud_score", (Object)value); }
 	public Long getFraudScore() { return (Long)this.get("fraud_score"); }
	// }}}
	// {{{
	public void setIsLocked(Boolean value) { this.set("is_locked", (Object)value); }
 	public Boolean getIsLocked() { return (Boolean)this.get("is_locked"); }
	// }}}
	// {{{
	public void setIsInactive(Boolean value) { this.set("is_inactive", (Object)value); }
 	public Boolean getIsInactive() { return (Boolean)this.get("is_inactive"); }
	// }}}
	// {{{
	public void setIsVerified(Boolean value) { this.set("is_verified", (Object)value); }
 	public Boolean getIsVerified() { return (Boolean)this.get("is_verified"); }
	// }}}
	// {{{
	public void setIsRestricted(Boolean value) { this.set("is_restricted", (Object)value); }
 	public Boolean getIsRestricted() { return (Boolean)this.get("is_restricted"); }
	// }}}
	// {{{
	public void setIsHighRestricted(Boolean value) { this.set("is_high_restricted", (Object)value); }
 	public Boolean getIsHighRestricted() { return (Boolean)this.get("is_high_restricted"); }
	// }}}
	// {{{
	public void setIsSanctionListLocked(Boolean value) { this.set("is_sanction_list_locked", (Object)value); }
 	public Boolean getIsSanctionListLocked() { return (Boolean)this.get("is_sanction_list_locked"); }
	// }}}
	// {{{
	public void setIsCommercialEntity(Boolean value) { this.set("is_commercial_entity", (Object)value); }
 	public Boolean getIsCommercialEntity() { return (Boolean)this.get("is_commercial_entity"); }
	// }}}
	// {{{
	public void setSetFlags(List<UserFlagsVO> value) { this.set("set_flags", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<UserFlagsVO> getSetFlags() { return (List<UserFlagsVO>)this.get("set_flags"); }
	// }}}
	// {{{
	public void setUnsetFlags(List<UserFlagsVO> value) { this.set("unset_flags", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<UserFlagsVO> getUnsetFlags() { return (List<UserFlagsVO>)this.get("unset_flags"); }
	// }}}
	// {{{
	public void setAccountName(String value) { this.set("account_name", (Object)value); }
 	public String getAccountName() { return (String)this.get("account_name"); }
	// }}}
}