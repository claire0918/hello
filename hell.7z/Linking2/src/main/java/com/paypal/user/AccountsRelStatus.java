/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AccountToAccountRelationshipVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.user;

import java.math.BigInteger;

  
public enum AccountsRelStatus {
/***/
   	ACTIVE(new Byte("65"), "normal status"),
   	DEPRECATED(new Byte("68"), "cancelled relationship"),
   	PENDING(new Byte("80"), "relationship creation in progress");

	private final Byte value;
	private final String desc;

	private AccountsRelStatus(Byte value, String desc) {
		this.value = value;
		this.desc  = desc;
	}

	public Byte getValue() {
		return value;
	}

	public String getDesc() {
		return desc;
	}
}
