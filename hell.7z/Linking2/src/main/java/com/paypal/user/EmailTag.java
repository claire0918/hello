/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/EmailVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:40 2012 */

package com.paypal.user;

import java.math.BigInteger;

  
public enum EmailTag {
/***/
   	ADMIN(new String("ADMIN"), "This email is the email address of the account admin (different than the primary account holder). The admin email cannot be the primary email. This tag cannot be removed, it can only be added, and it automatically removes itself from any other email belonging to the party when it is added to an email."),
   	DISPUTE(new String("DISPUTE"), "This email is the dispute email for a business. It is where disputes should be sent. Currently only supported for businesses"),
   	SERVICE(new String("SERVICE"), "This is the service email for a business. It is where support contacts should be sent. Currently only supported for businesses");

	private final String value;
	private final String desc;

	private EmailTag(String value, String desc) {
		this.value = value;
		this.desc  = desc;
	}

	public String getValue() {
		return value;
	}

	public String getDesc() {
		return desc;
	}
}
