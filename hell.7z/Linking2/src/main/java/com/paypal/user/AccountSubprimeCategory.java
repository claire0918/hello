/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AccountVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.user;

import java.math.BigInteger;

  
public enum AccountSubprimeCategory {
/**
			*** DEPRECATED *** User does not own the complete list of values and
			so these may be out of sync.
			In UDSConstants.h there are several #defines that define min and max 
			values for special ranges of this enum.  So, these values need to be 
			kept in sync with the #defines there.
		*/
   	NORMAL(new Long("0"), "not a \"subprime\" market"),
   	GAMING(new Long("1"), "casino / gambling / gaming"),
   	HIGH_RISK(new Long("2"), "high risk groups"),
   	PUBLISHER(new Long("3"), "recipients of subscription payments"),
   	DIGITAL_GOODS(new Long("4"), "digital goods retailers"),
   	ALLOWED_GAMING(new Long("5"), "allowed gaming merchants (at 37.0 only Betfair will be in this category)"),
   	ALLOWED_ADULT(new Long("6"), "allowed adult merchants (for efr 240682 mcc code only online dating will be in this category)"),
   	SPECIAL_PERSONAL(new Long("7"), "a category for personal users to accept credit card payments"),
   	ETAILER(new Long("8"), "on-line retailer"),
   	POWER_SELLER(new Long("9"), "high-volume ebay sellers"),
   	HIGH(new Long("10"), ""),
   	MED(new Long("11"), ""),
   	LOW(new Long("12"), ""),
   	VERY_HIGH(new Long("20"), ""),
   	MERCHANT_PULL(new Long("30"), "special category for merchant pull enabled accounts"),
   	PAYMENT_INTERMEDIARY(new Long("88"), "a special category for receiving payments on behalf of a seller."),
   	POSTAL_CARRIER(new Long("97"), "collector accounts for postal carriers, e.g., USPS"),
   	CONNECTION_TO_EBAY(new Long("98"), "a special category for Accenture Connection to eBay account"),
   	EBAY_ACCOUNT(new Long("99"), "a special category for corporate EBay PayPal accounts cat99a (subprime 99, subprime_subcat 0) users have some special properties: the wuser and wuser_holding rows for such users are not locked when payments are made to them, so that they can receive payments at a high rate. The payments are all held as pending and accepted later by a daemon. As a side effect, the following properties/stats are not maintained for cat99a users: UDS_ACCOUNT__FLAG2_AUCTION_SELLER UDS_ACCOUNT__FLAG3_WEB_ACCEPT_SELLER wuser.volume_completed_plus_pending_usd (note: wuser.volume_completed_usd *is* maintained for cat99a users) wuser_contact.* wuser_stats.total_amt_payments_received_usd wuser_stats.total_num_payments_received wuser_stats.last_time_pmt_rcvd");

	private final Long value;
	private final String desc;

	private AccountSubprimeCategory(Long value, String desc) {
		this.value = value;
		this.desc  = desc;
	}

	public Long getValue() {
		return value;
	}

	public String getDesc() {
		return desc;
	}
}
