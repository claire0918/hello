/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/PartyVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:40 2012 */

package com.paypal.user;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
  * 
   */

public class PartyCriteriaVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((21762*21762)<<32)/*<-PartyCriteriaVO*/+
         		30992/*<-load_party*/*15044/*<-bool*/+
         		55817/*<-load_all_tags*/*15044/*<-bool*/+
         		35424/*<-public_credential_criteria*/*PublicCredentialCriteriaVO.TYPE_SIGNATURE/*<-PublicCredentialCriteriaVO*/+
         		27501/*<-private_credential_criteria*/*PrivateCredentialCriteriaVO.TYPE_SIGNATURE/*<-PrivateCredentialCriteriaVO*/+
         		17446/*<-name_criteria*/*NameCriteriaVO.TYPE_SIGNATURE/*<-NameCriteriaVO*/+
         		4992/*<-email_criteria*/*EmailCriteriaVO.TYPE_SIGNATURE/*<-EmailCriteriaVO*/+
         		41679/*<-address_criteria*/*AddressCriteriaVO.TYPE_SIGNATURE/*<-AddressCriteriaVO*/+
         		3671/*<-phone_criteria*/*PhoneCriteriaVO.TYPE_SIGNATURE/*<-PhoneCriteriaVO*/+
         		25032/*<-doc_id_criteria*/*DocumentIdentifierCriteriaVO.TYPE_SIGNATURE/*<-DocumentIdentifierCriteriaVO*/+
         		59537/*<-security_question_criteria*/*SecurityQuestionsCriteriaVO.TYPE_SIGNATURE/*<-SecurityQuestionsCriteriaVO*/+
         		9469/*<-date_of_birth_criteria*/*DateOfBirthCriteriaVO.TYPE_SIGNATURE/*<-DateOfBirthCriteriaVO*/+
         		19361/*<-party_property_criteria*/*UserPropertyCriteriaVO.TYPE_SIGNATURE/*<-UserPropertyCriteriaVO*/+
         		55456/*<-file_reference_criteria*/*FileReferenceCriteriaVO.TYPE_SIGNATURE/*<-FileReferenceCriteriaVO*/+
         		41669/*<-party_relationship_criteria*/*PartyRelCriteriaVO.TYPE_SIGNATURE/*<-PartyRelCriteriaVO*/+
         		35621/*<-party_account_relationship_criteria*/*PartyAccountRelCriteriaVO.TYPE_SIGNATURE/*<-PartyAccountRelCriteriaVO*/+
         		50007/*<-access_point_criteria*/*AccessPointCriteriaVO.TYPE_SIGNATURE/*<-AccessPointCriteriaVO*/;
 
	public PartyCriteriaVO() {
		super("User::PartyCriteriaVO", TYPE_SIGNATURE);

 
		set("load_party", null, "bool");
 
		set("load_all_tags", null, "bool");
 
		set("public_credential_criteria", null, "User::PublicCredentialCriteriaVO");
 
		set("private_credential_criteria", null, "User::PrivateCredentialCriteriaVO");
 
		set("name_criteria", null, "User::NameCriteriaVO");
 
		set("email_criteria", null, "User::EmailCriteriaVO");
 
		set("address_criteria", null, "User::AddressCriteriaVO");
 
		set("phone_criteria", null, "User::PhoneCriteriaVO");
 
		set("doc_id_criteria", null, "User::DocumentIdentifierCriteriaVO");
 
		set("security_question_criteria", null, "User::SecurityQuestionsCriteriaVO");
 
		set("date_of_birth_criteria", null, "User::DateOfBirthCriteriaVO");
 
		set("party_property_criteria", null, "User::UserPropertyCriteriaVO");
 
		set("file_reference_criteria", null, "User::FileReferenceCriteriaVO");
 
		set("party_relationship_criteria", null, "User::PartyRelCriteriaVO");
 
		set("party_account_relationship_criteria", null, "User::PartyAccountRelCriteriaVO");
 
		set("access_point_criteria", null, "User::AccessPointCriteriaVO");
	}

	// {{{
	public void setLoadParty(Boolean value) { this.set("load_party", (Object)value); }
 	public Boolean getLoadParty() { return (Boolean)this.get("load_party"); }
	// }}}
	// {{{
	public void setLoadAllTags(Boolean value) { this.set("load_all_tags", (Object)value); }
 	public Boolean getLoadAllTags() { return (Boolean)this.get("load_all_tags"); }
	// }}}
	// {{{
	public void setPublicCredentialCriteria(PublicCredentialCriteriaVO value) { this.set("public_credential_criteria", (Object)value); }
 	public PublicCredentialCriteriaVO getPublicCredentialCriteria() { return (PublicCredentialCriteriaVO)this.get("public_credential_criteria"); }
	// }}}
	// {{{
	public void setPrivateCredentialCriteria(PrivateCredentialCriteriaVO value) { this.set("private_credential_criteria", (Object)value); }
 	public PrivateCredentialCriteriaVO getPrivateCredentialCriteria() { return (PrivateCredentialCriteriaVO)this.get("private_credential_criteria"); }
	// }}}
	// {{{
	public void setNameCriteria(NameCriteriaVO value) { this.set("name_criteria", (Object)value); }
 	public NameCriteriaVO getNameCriteria() { return (NameCriteriaVO)this.get("name_criteria"); }
	// }}}
	// {{{
	public void setEmailCriteria(EmailCriteriaVO value) { this.set("email_criteria", (Object)value); }
 	public EmailCriteriaVO getEmailCriteria() { return (EmailCriteriaVO)this.get("email_criteria"); }
	// }}}
	// {{{
	public void setAddressCriteria(AddressCriteriaVO value) { this.set("address_criteria", (Object)value); }
 	public AddressCriteriaVO getAddressCriteria() { return (AddressCriteriaVO)this.get("address_criteria"); }
	// }}}
	// {{{
	public void setPhoneCriteria(PhoneCriteriaVO value) { this.set("phone_criteria", (Object)value); }
 	public PhoneCriteriaVO getPhoneCriteria() { return (PhoneCriteriaVO)this.get("phone_criteria"); }
	// }}}
	// {{{
	public void setDocIdCriteria(DocumentIdentifierCriteriaVO value) { this.set("doc_id_criteria", (Object)value); }
 	public DocumentIdentifierCriteriaVO getDocIdCriteria() { return (DocumentIdentifierCriteriaVO)this.get("doc_id_criteria"); }
	// }}}
	// {{{
	public void setSecurityQuestionCriteria(SecurityQuestionsCriteriaVO value) { this.set("security_question_criteria", (Object)value); }
 	public SecurityQuestionsCriteriaVO getSecurityQuestionCriteria() { return (SecurityQuestionsCriteriaVO)this.get("security_question_criteria"); }
	// }}}
	// {{{
	public void setDateOfBirthCriteria(DateOfBirthCriteriaVO value) { this.set("date_of_birth_criteria", (Object)value); }
 	public DateOfBirthCriteriaVO getDateOfBirthCriteria() { return (DateOfBirthCriteriaVO)this.get("date_of_birth_criteria"); }
	// }}}
	// {{{
	public void setPartyPropertyCriteria(UserPropertyCriteriaVO value) { this.set("party_property_criteria", (Object)value); }
 	public UserPropertyCriteriaVO getPartyPropertyCriteria() { return (UserPropertyCriteriaVO)this.get("party_property_criteria"); }
	// }}}
	// {{{
	public void setFileReferenceCriteria(FileReferenceCriteriaVO value) { this.set("file_reference_criteria", (Object)value); }
 	public FileReferenceCriteriaVO getFileReferenceCriteria() { return (FileReferenceCriteriaVO)this.get("file_reference_criteria"); }
	// }}}
	// {{{
	public void setPartyRelationshipCriteria(PartyRelCriteriaVO value) { this.set("party_relationship_criteria", (Object)value); }
 	public PartyRelCriteriaVO getPartyRelationshipCriteria() { return (PartyRelCriteriaVO)this.get("party_relationship_criteria"); }
	// }}}
	// {{{
	public void setPartyAccountRelationshipCriteria(PartyAccountRelCriteriaVO value) { this.set("party_account_relationship_criteria", (Object)value); }
 	public PartyAccountRelCriteriaVO getPartyAccountRelationshipCriteria() { return (PartyAccountRelCriteriaVO)this.get("party_account_relationship_criteria"); }
	// }}}
	// {{{
	public void setAccessPointCriteria(AccessPointCriteriaVO value) { this.set("access_point_criteria", (Object)value); }
 	public AccessPointCriteriaVO getAccessPointCriteria() { return (AccessPointCriteriaVO)this.get("access_point_criteria"); }
	// }}}
}