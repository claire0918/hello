/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/PhoneVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:40 2012 */

package com.paypal.user;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
  * 
   */

public class PhoneCriteriaVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((60541*60541)<<32)/*<-PhoneCriteriaVO*/+
         		42933/*<-load_phone*/*15044/*<-bool*/+
         		33376/*<-load_primary_only*/*15044/*<-bool*/+
         		31109/*<-filter_by_tags*/*47/*<-repeating*/*18443/*<-String*/;
 
	public PhoneCriteriaVO() {
		super("User::PhoneCriteriaVO", TYPE_SIGNATURE);

 
		set("load_phone", null, "bool");
 
		set("load_primary_only", null, "bool");
 
		set("filter_by_tags", null, "List<String>");
	}

	// {{{
	public void setLoadPhone(Boolean value) { this.set("load_phone", (Object)value); }
 	public Boolean getLoadPhone() { return (Boolean)this.get("load_phone"); }
	// }}}
	// {{{
	public void setLoadPrimaryOnly(Boolean value) { this.set("load_primary_only", (Object)value); }
 	public Boolean getLoadPrimaryOnly() { return (Boolean)this.get("load_primary_only"); }
	// }}}
	// {{{
	public void setFilterByTags(List<String> value) { this.set("filter_by_tags", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<String> getFilterByTags() { return (List<String>)this.get("filter_by_tags"); }
	// }}}
}