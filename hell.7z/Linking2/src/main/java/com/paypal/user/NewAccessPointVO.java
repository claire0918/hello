/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AccessPointVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.user;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
  * 
   */

public class NewAccessPointVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((30239*30239)<<32)/*<-NewAccessPointVO*/+
         		30984/*<-channel*/*18443/*<-String*/+
         		44043/*<-public_credential_id*/*46168/*<-ullong*/+
         		6387/*<-public_credential*/*PublicCredentialUniqueKey.TYPE_SIGNATURE/*<-PublicCredentialUniqueKey*/+
         		44458/*<-private_credential_id*/*46168/*<-ullong*/+
         		58900/*<-new_private_credential_type*/*18443/*<-String*/+
         		42836/*<-new_private_credential_clear_text*/*18443/*<-String*/+
         		33339/*<-actor_id*/*46168/*<-ullong*/+
         		41759/*<-new_account_access_list*/*47/*<-repeating*/*AccountAccessPrivilege.TYPE_SIGNATURE/*<-AccountAccessPrivilege*/+
         		40863/*<-requires_2FA*/*15044/*<-bool*/+
         		15451/*<-needs_validation*/*62361/*<-sint8*/;
 
	public NewAccessPointVO() {
		super("User::NewAccessPointVO", TYPE_SIGNATURE);

 		addFieldQualifier("channel","required","true");
 
		set("channel", null, "String");
 
		set("public_credential_id", null, "ullong");
 
		set("public_credential", null, "User::PublicCredentialUniqueKey");
 
		set("private_credential_id", null, "ullong");
 
		set("new_private_credential_type", null, "String");
 
		set("new_private_credential_clear_text", null, "String");
 
		set("actor_id", null, "ullong");
 
		set("new_account_access_list", null, "List<User::AccountAccessPrivilege>");
 
		set("requires_2FA", null, "bool");
 		addFieldQualifier("needs_validation","cpp_gen","define_legacy");
 
		set("needs_validation", null, "sint8");
	}

	// {{{
	public void setChannel(String value) { this.set("channel", (Object)value); }
 	public String getChannel() { return (String)this.get("channel"); }
	// }}}
	// {{{
	public void setPublicCredentialId(BigInteger value) { this.set("public_credential_id", (Object)value); }
 	public BigInteger getPublicCredentialId() { return (BigInteger)this.get("public_credential_id"); }
	// }}}
	// {{{
	public void setPublicCredential(PublicCredentialUniqueKey value) { this.set("public_credential", (Object)value); }
 	public PublicCredentialUniqueKey getPublicCredential() { return (PublicCredentialUniqueKey)this.get("public_credential"); }
	// }}}
	// {{{
	public void setPrivateCredentialId(BigInteger value) { this.set("private_credential_id", (Object)value); }
 	public BigInteger getPrivateCredentialId() { return (BigInteger)this.get("private_credential_id"); }
	// }}}
	// {{{
	public void setNewPrivateCredentialType(String value) { this.set("new_private_credential_type", (Object)value); }
 	public String getNewPrivateCredentialType() { return (String)this.get("new_private_credential_type"); }
	// }}}
	// {{{
	public void setNewPrivateCredentialClearText(String value) { this.set("new_private_credential_clear_text", (Object)value); }
 	public String getNewPrivateCredentialClearText() { return (String)this.get("new_private_credential_clear_text"); }
	// }}}
	// {{{
	public void setActorId(BigInteger value) { this.set("actor_id", (Object)value); }
 	public BigInteger getActorId() { return (BigInteger)this.get("actor_id"); }
	// }}}
	// {{{
	public void setNewAccountAccessList(List<AccountAccessPrivilege> value) { this.set("new_account_access_list", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<AccountAccessPrivilege> getNewAccountAccessList() { return (List<AccountAccessPrivilege>)this.get("new_account_access_list"); }
	// }}}
	// {{{
	public void setRequires2FA(Boolean value) { this.set("requires_2FA", (Object)value); }
 	public Boolean getRequires2FA() { return (Boolean)this.get("requires_2FA"); }
	// }}}
	// {{{
	public void setNeedsValidation(Byte value) { this.set("needs_validation", (Object)value); }
 	public Byte getNeedsValidation() { return (Byte)this.get("needs_validation"); }
	// }}}
}