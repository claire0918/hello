/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/EmailVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:40 2012 */

package com.paypal.user;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
  * 
   */

public class UpdateEmailVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((44798*44798)<<32)/*<-UpdateEmailVO*/+
         		3355/*<-id*/*46168/*<-ullong*/+
         		59512/*<-make_primary*/*15044/*<-bool*/+
         		24422/*<-is_confirmed*/*15044/*<-bool*/+
         		30840/*<-confirmed_by*/*62361/*<-sint8*/+
         		57020/*<-is_potentially_invalid*/*15044/*<-bool*/+
         		56798/*<-is_invalid*/*15044/*<-bool*/;
 
	public UpdateEmailVO() {
		super("User::UpdateEmailVO", TYPE_SIGNATURE);

 
		set("id", null, "ullong");
 
		set("make_primary", null, "bool");
 
		set("is_confirmed", null, "bool");
 
		set("confirmed_by", null, "sint8");
 
		set("is_potentially_invalid", null, "bool");
 
		set("is_invalid", null, "bool");
	}

	// {{{
	public void setId(BigInteger value) { this.set("id", (Object)value); }
 	public BigInteger getId() { return (BigInteger)this.get("id"); }
	// }}}
	// {{{
	public void setMakePrimary(Boolean value) { this.set("make_primary", (Object)value); }
 	public Boolean getMakePrimary() { return (Boolean)this.get("make_primary"); }
	// }}}
	// {{{
	public void setIsConfirmed(Boolean value) { this.set("is_confirmed", (Object)value); }
 	public Boolean getIsConfirmed() { return (Boolean)this.get("is_confirmed"); }
	// }}}
	// {{{
	public void setConfirmedBy(Byte value) { this.set("confirmed_by", (Object)value); }
 	public Byte getConfirmedBy() { return (Byte)this.get("confirmed_by"); }
	// }}}
	// {{{
	public void setIsPotentiallyInvalid(Boolean value) { this.set("is_potentially_invalid", (Object)value); }
 	public Boolean getIsPotentiallyInvalid() { return (Boolean)this.get("is_potentially_invalid"); }
	// }}}
	// {{{
	public void setIsInvalid(Boolean value) { this.set("is_invalid", (Object)value); }
 	public Boolean getIsInvalid() { return (Boolean)this.get("is_invalid"); }
	// }}}
}