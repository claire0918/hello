/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AccountVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.user;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
  * 
   */

public class AccountVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((57101*57101)<<32)/*<-AccountVO*/+
         		62145/*<-account_number*/*46168/*<-ullong*/+
         		59101/*<-encrypted_account_number*/*18443/*<-String*/+
         		36620/*<-type*/*18443/*<-String*/+
         		22809/*<-time_created*/*33490/*<-ulong*/+
         		15454/*<-time_closed*/*33490/*<-ulong*/+
         		52543/*<-status*/*18443/*<-String*/+
         		64599/*<-account_name*/*18443/*<-String*/+
         		39594/*<-legal_country*/*18443/*<-String*/+
         		44954/*<-legal_entity*/*37752/*<-char*/+
         		13359/*<-tags*/*47/*<-repeating*/*18443/*<-String*/+
         		4866/*<-account_type*/*38894/*<-int*/+
         		930/*<-user_group*/*33490/*<-ulong*/+
         		2233/*<-primary_currency_code*/*18443/*<-String*/+
         		28425/*<-subprime_category*/*23389/*<-uint16*/+
         		3328/*<-subprime_subcategory*/*23389/*<-uint16*/+
         		63182/*<-fraud_score*/*46796/*<-llong*/+
         		35037/*<-first_name*/*18443/*<-String*/+
         		51561/*<-last_name*/*18443/*<-String*/+
         		38026/*<-language*/*18443/*<-String*/+
         		57575/*<-citizenship*/*18443/*<-String*/+
         		17350/*<-timezone*/*18443/*<-String*/+
         		35999/*<-is_closed*/*15044/*<-bool*/+
         		56705/*<-is_locked*/*15044/*<-bool*/+
         		43592/*<-is_inactive*/*15044/*<-bool*/+
         		30573/*<-is_verified*/*15044/*<-bool*/+
         		22150/*<-is_restricted*/*15044/*<-bool*/+
         		54989/*<-is_high_restricted*/*15044/*<-bool*/+
         		2090/*<-is_sanction_list_locked*/*15044/*<-bool*/+
         		31122/*<-is_commercial_entity*/*15044/*<-bool*/+
         		64388/*<-user_flags*/*47/*<-repeating*/*UserFlagsVO.TYPE_SIGNATURE/*<-UserFlagsVO*/+
         		60232/*<-flags*/*33490/*<-ulong*/+
         		59046/*<-flags2*/*33490/*<-ulong*/+
         		59041/*<-flags3*/*33490/*<-ulong*/+
         		59040/*<-flags4*/*33490/*<-ulong*/+
         		28591/*<-authentications*/*33490/*<-ulong*/+
         		55493/*<-subprime*/*33490/*<-ulong*/+
         		38420/*<-iso_primary_residence*/*18443/*<-String*/+
         		14410/*<-iso_citizenship*/*18443/*<-String*/+
         		65026/*<-server_current_transaction*/*46168/*<-ullong*/+
         		61651/*<-primary_email_id*/*46168/*<-ullong*/+
         		39725/*<-primary_email_name*/*18443/*<-String*/+
         		59048/*<-address_id*/*46168/*<-ullong*/;
 
	public AccountVO() {
		super("User::AccountVO", TYPE_SIGNATURE);

 
		set("account_number", null, "ullong");
 
		set("encrypted_account_number", null, "String");
 
		set("type", null, "String");
 
		set("time_created", null, "ulong");
 
		set("time_closed", null, "ulong");
 
		set("status", null, "String");
 
		set("account_name", null, "String");
 
		set("legal_country", null, "String");
 		addFieldQualifier("legal_entity","cpp_gen","define_legacy");
 
		set("legal_entity", null, "char");
 
		set("tags", null, "List<String>");
 		addFieldQualifier("account_type","cpp_gen","define_legacy");
 
		set("account_type", null, "int");
 		addFieldQualifier("user_group","cpp_gen","define_legacy");
 
		set("user_group", null, "ulong");
 
		set("primary_currency_code", null, "String");
 
		set("subprime_category", null, "uint16");
 
		set("subprime_subcategory", null, "uint16");
 
		set("fraud_score", null, "llong");
 
		set("first_name", null, "String");
 
		set("last_name", null, "String");
 
		set("language", null, "String");
 
		set("citizenship", null, "String");
 
		set("timezone", null, "String");
 
		set("is_closed", null, "bool");
 
		set("is_locked", null, "bool");
 
		set("is_inactive", null, "bool");
 
		set("is_verified", null, "bool");
 
		set("is_restricted", null, "bool");
 
		set("is_high_restricted", null, "bool");
 
		set("is_sanction_list_locked", null, "bool");
 
		set("is_commercial_entity", null, "bool");
 
		set("user_flags", null, "List<User::UserFlagsVO>");
 
		set("flags", null, "ulong");
 
		set("flags2", null, "ulong");
 
		set("flags3", null, "ulong");
 
		set("flags4", null, "ulong");
 
		set("authentications", null, "ulong");
 
		set("subprime", null, "ulong");
 
		set("iso_primary_residence", null, "String");
 
		set("iso_citizenship", null, "String");
 
		set("server_current_transaction", null, "ullong");
 
		set("primary_email_id", null, "ullong");
 
		set("primary_email_name", null, "String");
 
		set("address_id", null, "ullong");
	}

	// {{{
	public void setAccountNumber(BigInteger value) { this.set("account_number", (Object)value); }
 	public BigInteger getAccountNumber() { return (BigInteger)this.get("account_number"); }
	// }}}
	// {{{
	public void setEncryptedAccountNumber(String value) { this.set("encrypted_account_number", (Object)value); }
 	public String getEncryptedAccountNumber() { return (String)this.get("encrypted_account_number"); }
	// }}}
	// {{{
	public void setType(String value) { this.set("type", (Object)value); }
 	public String getType() { return (String)this.get("type"); }
	// }}}
	// {{{
	public void setTimeCreated(Long value) { this.set("time_created", (Object)value); }
 	public Long getTimeCreated() { return (Long)this.get("time_created"); }
	// }}}
	// {{{
	public void setTimeClosed(Long value) { this.set("time_closed", (Object)value); }
 	public Long getTimeClosed() { return (Long)this.get("time_closed"); }
	// }}}
	// {{{
	public void setStatus(String value) { this.set("status", (Object)value); }
 	public String getStatus() { return (String)this.get("status"); }
	// }}}
	// {{{
	public void setAccountName(String value) { this.set("account_name", (Object)value); }
 	public String getAccountName() { return (String)this.get("account_name"); }
	// }}}
	// {{{
	public void setLegalCountry(String value) { this.set("legal_country", (Object)value); }
 	public String getLegalCountry() { return (String)this.get("legal_country"); }
	// }}}
	// {{{
	public void setLegalEntity(Byte value) { this.set("legal_entity", (Object)value); }
 	public Byte getLegalEntity() { return (Byte)this.get("legal_entity"); }
	// }}}
	// {{{
	public void setTags(List<String> value) { this.set("tags", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<String> getTags() { return (List<String>)this.get("tags"); }
	// }}}
	// {{{
	public void setAccountType(Integer value) { this.set("account_type", (Object)value); }
 	public Integer getAccountType() { return (Integer)this.get("account_type"); }
	// }}}
	// {{{
	public void setUserGroup(Long value) { this.set("user_group", (Object)value); }
 	public Long getUserGroup() { return (Long)this.get("user_group"); }
	// }}}
	// {{{
	public void setPrimaryCurrencyCode(String value) { this.set("primary_currency_code", (Object)value); }
 	public String getPrimaryCurrencyCode() { return (String)this.get("primary_currency_code"); }
	// }}}
	// {{{
	public void setSubprimeCategory(Integer value) { this.set("subprime_category", (Object)value); }
 	public Integer getSubprimeCategory() { return (Integer)this.get("subprime_category"); }
	// }}}
	// {{{
	public void setSubprimeSubcategory(Integer value) { this.set("subprime_subcategory", (Object)value); }
 	public Integer getSubprimeSubcategory() { return (Integer)this.get("subprime_subcategory"); }
	// }}}
	// {{{
	public void setFraudScore(Long value) { this.set("fraud_score", (Object)value); }
 	public Long getFraudScore() { return (Long)this.get("fraud_score"); }
	// }}}
	// {{{
	public void setFirstName(String value) { this.set("first_name", (Object)value); }
 	public String getFirstName() { return (String)this.get("first_name"); }
	// }}}
	// {{{
	public void setLastName(String value) { this.set("last_name", (Object)value); }
 	public String getLastName() { return (String)this.get("last_name"); }
	// }}}
	// {{{
	public void setLanguage(String value) { this.set("language", (Object)value); }
 	public String getLanguage() { return (String)this.get("language"); }
	// }}}
	// {{{
	public void setCitizenship(String value) { this.set("citizenship", (Object)value); }
 	public String getCitizenship() { return (String)this.get("citizenship"); }
	// }}}
	// {{{
	public void setTimezone(String value) { this.set("timezone", (Object)value); }
 	public String getTimezone() { return (String)this.get("timezone"); }
	// }}}
	// {{{
	public void setIsClosed(Boolean value) { this.set("is_closed", (Object)value); }
 	public Boolean getIsClosed() { return (Boolean)this.get("is_closed"); }
	// }}}
	// {{{
	public void setIsLocked(Boolean value) { this.set("is_locked", (Object)value); }
 	public Boolean getIsLocked() { return (Boolean)this.get("is_locked"); }
	// }}}
	// {{{
	public void setIsInactive(Boolean value) { this.set("is_inactive", (Object)value); }
 	public Boolean getIsInactive() { return (Boolean)this.get("is_inactive"); }
	// }}}
	// {{{
	public void setIsVerified(Boolean value) { this.set("is_verified", (Object)value); }
 	public Boolean getIsVerified() { return (Boolean)this.get("is_verified"); }
	// }}}
	// {{{
	public void setIsRestricted(Boolean value) { this.set("is_restricted", (Object)value); }
 	public Boolean getIsRestricted() { return (Boolean)this.get("is_restricted"); }
	// }}}
	// {{{
	public void setIsHighRestricted(Boolean value) { this.set("is_high_restricted", (Object)value); }
 	public Boolean getIsHighRestricted() { return (Boolean)this.get("is_high_restricted"); }
	// }}}
	// {{{
	public void setIsSanctionListLocked(Boolean value) { this.set("is_sanction_list_locked", (Object)value); }
 	public Boolean getIsSanctionListLocked() { return (Boolean)this.get("is_sanction_list_locked"); }
	// }}}
	// {{{
	public void setIsCommercialEntity(Boolean value) { this.set("is_commercial_entity", (Object)value); }
 	public Boolean getIsCommercialEntity() { return (Boolean)this.get("is_commercial_entity"); }
	// }}}
	// {{{
	public void setUserFlags(List<UserFlagsVO> value) { this.set("user_flags", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<UserFlagsVO> getUserFlags() { return (List<UserFlagsVO>)this.get("user_flags"); }
	// }}}
	// {{{
	public void setFlags(Long value) { this.set("flags", (Object)value); }
 	public Long getFlags() { return (Long)this.get("flags"); }
	// }}}
	// {{{
	public void setFlags2(Long value) { this.set("flags2", (Object)value); }
 	public Long getFlags2() { return (Long)this.get("flags2"); }
	// }}}
	// {{{
	public void setFlags3(Long value) { this.set("flags3", (Object)value); }
 	public Long getFlags3() { return (Long)this.get("flags3"); }
	// }}}
	// {{{
	public void setFlags4(Long value) { this.set("flags4", (Object)value); }
 	public Long getFlags4() { return (Long)this.get("flags4"); }
	// }}}
	// {{{
	public void setAuthentications(Long value) { this.set("authentications", (Object)value); }
 	public Long getAuthentications() { return (Long)this.get("authentications"); }
	// }}}
	// {{{
	public void setSubprime(Long value) { this.set("subprime", (Object)value); }
 	public Long getSubprime() { return (Long)this.get("subprime"); }
	// }}}
	// {{{
	public void setIsoPrimaryResidence(String value) { this.set("iso_primary_residence", (Object)value); }
 	public String getIsoPrimaryResidence() { return (String)this.get("iso_primary_residence"); }
	// }}}
	// {{{
	public void setIsoCitizenship(String value) { this.set("iso_citizenship", (Object)value); }
 	public String getIsoCitizenship() { return (String)this.get("iso_citizenship"); }
	// }}}
	// {{{
	public void setServerCurrentTransaction(BigInteger value) { this.set("server_current_transaction", (Object)value); }
 	public BigInteger getServerCurrentTransaction() { return (BigInteger)this.get("server_current_transaction"); }
	// }}}
	// {{{
	public void setPrimaryEmailId(BigInteger value) { this.set("primary_email_id", (Object)value); }
 	public BigInteger getPrimaryEmailId() { return (BigInteger)this.get("primary_email_id"); }
	// }}}
	// {{{
	public void setPrimaryEmailName(String value) { this.set("primary_email_name", (Object)value); }
 	public String getPrimaryEmailName() { return (String)this.get("primary_email_name"); }
	// }}}
	// {{{
	public void setAddressId(BigInteger value) { this.set("address_id", (Object)value); }
 	public BigInteger getAddressId() { return (BigInteger)this.get("address_id"); }
	// }}}
}