/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/PartyVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:40 2012 */

package com.paypal.user;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
  * 
   */

public class ModifyPartyVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((60009*60009)<<32)/*<-ModifyPartyVO*/+
         		3355/*<-id*/*46168/*<-ullong*/+
         		20628/*<-merged_into_party_id*/*46168/*<-ullong*/+
         		16094/*<-preferred_language*/*18443/*<-String*/+
         		57575/*<-citizenship*/*18443/*<-String*/+
         		17350/*<-timezone*/*18443/*<-String*/+
         		46753/*<-add_tags*/*47/*<-repeating*/*18443/*<-String*/+
         		41076/*<-remove_tags*/*47/*<-repeating*/*18443/*<-String*/;
 
	public ModifyPartyVO() {
		super("User::ModifyPartyVO", TYPE_SIGNATURE);

 
		set("id", null, "ullong");
 
		set("merged_into_party_id", null, "ullong");
 
		set("preferred_language", null, "String");
 
		set("citizenship", null, "String");
 
		set("timezone", null, "String");
 
		set("add_tags", null, "List<String>");
 
		set("remove_tags", null, "List<String>");
	}

	// {{{
	public void setId(BigInteger value) { this.set("id", (Object)value); }
 	public BigInteger getId() { return (BigInteger)this.get("id"); }
	// }}}
	// {{{
	public void setMergedIntoPartyId(BigInteger value) { this.set("merged_into_party_id", (Object)value); }
 	public BigInteger getMergedIntoPartyId() { return (BigInteger)this.get("merged_into_party_id"); }
	// }}}
	// {{{
	public void setPreferredLanguage(String value) { this.set("preferred_language", (Object)value); }
 	public String getPreferredLanguage() { return (String)this.get("preferred_language"); }
	// }}}
	// {{{
	public void setCitizenship(String value) { this.set("citizenship", (Object)value); }
 	public String getCitizenship() { return (String)this.get("citizenship"); }
	// }}}
	// {{{
	public void setTimezone(String value) { this.set("timezone", (Object)value); }
 	public String getTimezone() { return (String)this.get("timezone"); }
	// }}}
	// {{{
	public void setAddTags(List<String> value) { this.set("add_tags", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<String> getAddTags() { return (List<String>)this.get("add_tags"); }
	// }}}
	// {{{
	public void setRemoveTags(List<String> value) { this.set("remove_tags", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<String> getRemoveTags() { return (List<String>)this.get("remove_tags"); }
	// }}}
}