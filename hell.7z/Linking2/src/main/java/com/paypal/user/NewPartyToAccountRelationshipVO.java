/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/PartyToAccountRelationshipVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:40 2012 */

package com.paypal.user;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
  * 
   */

public class NewPartyToAccountRelationshipVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((57608*57608)<<32)/*<-NewPartyToAccountRelationshipVO*/+
         		41975/*<-party_id*/*46168/*<-ullong*/+
         		62145/*<-account_number*/*46168/*<-ullong*/;
 
	public NewPartyToAccountRelationshipVO() {
		super("User::NewPartyToAccountRelationshipVO", TYPE_SIGNATURE);

 
		set("party_id", null, "ullong");
 
		set("account_number", null, "ullong");
	}

	// {{{
	public void setPartyId(BigInteger value) { this.set("party_id", (Object)value); }
 	public BigInteger getPartyId() { return (BigInteger)this.get("party_id"); }
	// }}}
	// {{{
	public void setAccountNumber(BigInteger value) { this.set("account_number", (Object)value); }
 	public BigInteger getAccountNumber() { return (BigInteger)this.get("account_number"); }
	// }}}
}