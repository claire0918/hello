/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AddressVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.user;

import java.math.BigInteger;

  
public enum PartyPostalConfirmationStatus {
/***/
   	UNCONFIRMED(new String("UNCONF"), ""),
   	REQUESTED(new String("REQUEST"), ""),
   	SENT(new String("SENT"), ""),
   	PENDING(new String("PENDING"), "Used for \"pending phone\" and \"passed AAC\" (which for some reason is different than sent or confirmed)"),
   	FAILED(new String("FAIL"), ""),
   	CONFIRMED(new String("CONFIRM"), "");

	private final String value;
	private final String desc;

	private PartyPostalConfirmationStatus(String value, String desc) {
		this.value = value;
		this.desc  = desc;
	}

	public String getValue() {
		return value;
	}

	public String getDesc() {
		return desc;
	}
}
