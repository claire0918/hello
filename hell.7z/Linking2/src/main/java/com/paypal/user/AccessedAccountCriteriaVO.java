/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AccountVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.user;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
  * 
   */

public class AccessedAccountCriteriaVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((19335*19335)<<32)/*<-AccessedAccountCriteriaVO*/+
         		43225/*<-load_account*/*15044/*<-bool*/+
         		50129/*<-default_only*/*15044/*<-bool*/+
         		55817/*<-load_all_tags*/*15044/*<-bool*/+
         		18455/*<-legal_logging_criteria*/*LegalLoggingCriteriaVO.TYPE_SIGNATURE/*<-LegalLoggingCriteriaVO*/+
         		36450/*<-statement_name_criteria*/*StatementNameCriteriaVO.TYPE_SIGNATURE/*<-StatementNameCriteriaVO*/+
         		56732/*<-remembered_actor_criteria*/*RememberedActorCriteriaVO.TYPE_SIGNATURE/*<-RememberedActorCriteriaVO*/+
         		35424/*<-public_credential_criteria*/*PublicCredentialCriteriaVO.TYPE_SIGNATURE/*<-PublicCredentialCriteriaVO*/+
         		5319/*<-account_property_criteria*/*UserPropertyCriteriaVO.TYPE_SIGNATURE/*<-UserPropertyCriteriaVO*/+
         		55456/*<-file_reference_criteria*/*FileReferenceCriteriaVO.TYPE_SIGNATURE/*<-FileReferenceCriteriaVO*/+
         		31027/*<-product_config_criteria*/*ProductConfigCriteriaVO.TYPE_SIGNATURE/*<-ProductConfigCriteriaVO*/+
         		34556/*<-product_config_stack_criteria*/*ProductConfigStackCriteriaVO.TYPE_SIGNATURE/*<-ProductConfigStackCriteriaVO*/+
         		21612/*<-account_relationship_criteria*/*AccountRelCriteriaVO.TYPE_SIGNATURE/*<-AccountRelCriteriaVO*/;
 
	public AccessedAccountCriteriaVO() {
		super("User::AccessedAccountCriteriaVO", TYPE_SIGNATURE);

 
		set("load_account", null, "bool");
 
		set("default_only", null, "bool");
 
		set("load_all_tags", null, "bool");
 
		set("legal_logging_criteria", null, "User::LegalLoggingCriteriaVO");
 
		set("statement_name_criteria", null, "User::StatementNameCriteriaVO");
 
		set("remembered_actor_criteria", null, "User::RememberedActorCriteriaVO");
 
		set("public_credential_criteria", null, "User::PublicCredentialCriteriaVO");
 
		set("account_property_criteria", null, "User::UserPropertyCriteriaVO");
 
		set("file_reference_criteria", null, "User::FileReferenceCriteriaVO");
 
		set("product_config_criteria", null, "User::ProductConfigCriteriaVO");
 
		set("product_config_stack_criteria", null, "User::ProductConfigStackCriteriaVO");
 
		set("account_relationship_criteria", null, "User::AccountRelCriteriaVO");
	}

	// {{{
	public void setLoadAccount(Boolean value) { this.set("load_account", (Object)value); }
 	public Boolean getLoadAccount() { return (Boolean)this.get("load_account"); }
	// }}}
	// {{{
	public void setDefaultOnly(Boolean value) { this.set("default_only", (Object)value); }
 	public Boolean getDefaultOnly() { return (Boolean)this.get("default_only"); }
	// }}}
	// {{{
	public void setLoadAllTags(Boolean value) { this.set("load_all_tags", (Object)value); }
 	public Boolean getLoadAllTags() { return (Boolean)this.get("load_all_tags"); }
	// }}}
	// {{{
	public void setLegalLoggingCriteria(LegalLoggingCriteriaVO value) { this.set("legal_logging_criteria", (Object)value); }
 	public LegalLoggingCriteriaVO getLegalLoggingCriteria() { return (LegalLoggingCriteriaVO)this.get("legal_logging_criteria"); }
	// }}}
	// {{{
	public void setStatementNameCriteria(StatementNameCriteriaVO value) { this.set("statement_name_criteria", (Object)value); }
 	public StatementNameCriteriaVO getStatementNameCriteria() { return (StatementNameCriteriaVO)this.get("statement_name_criteria"); }
	// }}}
	// {{{
	public void setRememberedActorCriteria(RememberedActorCriteriaVO value) { this.set("remembered_actor_criteria", (Object)value); }
 	public RememberedActorCriteriaVO getRememberedActorCriteria() { return (RememberedActorCriteriaVO)this.get("remembered_actor_criteria"); }
	// }}}
	// {{{
	public void setPublicCredentialCriteria(PublicCredentialCriteriaVO value) { this.set("public_credential_criteria", (Object)value); }
 	public PublicCredentialCriteriaVO getPublicCredentialCriteria() { return (PublicCredentialCriteriaVO)this.get("public_credential_criteria"); }
	// }}}
	// {{{
	public void setAccountPropertyCriteria(UserPropertyCriteriaVO value) { this.set("account_property_criteria", (Object)value); }
 	public UserPropertyCriteriaVO getAccountPropertyCriteria() { return (UserPropertyCriteriaVO)this.get("account_property_criteria"); }
	// }}}
	// {{{
	public void setFileReferenceCriteria(FileReferenceCriteriaVO value) { this.set("file_reference_criteria", (Object)value); }
 	public FileReferenceCriteriaVO getFileReferenceCriteria() { return (FileReferenceCriteriaVO)this.get("file_reference_criteria"); }
	// }}}
	// {{{
	public void setProductConfigCriteria(ProductConfigCriteriaVO value) { this.set("product_config_criteria", (Object)value); }
 	public ProductConfigCriteriaVO getProductConfigCriteria() { return (ProductConfigCriteriaVO)this.get("product_config_criteria"); }
	// }}}
	// {{{
	public void setProductConfigStackCriteria(ProductConfigStackCriteriaVO value) { this.set("product_config_stack_criteria", (Object)value); }
 	public ProductConfigStackCriteriaVO getProductConfigStackCriteria() { return (ProductConfigStackCriteriaVO)this.get("product_config_stack_criteria"); }
	// }}}
	// {{{
	public void setAccountRelationshipCriteria(AccountRelCriteriaVO value) { this.set("account_relationship_criteria", (Object)value); }
 	public AccountRelCriteriaVO getAccountRelationshipCriteria() { return (AccountRelCriteriaVO)this.get("account_relationship_criteria"); }
	// }}}
}