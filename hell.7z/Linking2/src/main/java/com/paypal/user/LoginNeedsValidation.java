/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AccessPointVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.user;

import java.math.BigInteger;

  
public enum LoginNeedsValidation {
/***/
   	NO(new Byte("0"), ""),
   	FOR_SPOOF(new Byte("11"), ""),
   	FOR_BAD_IP(new Byte("12"), ""),
   	FOR_RESTRICTION(new Byte("13"), "");

	private final Byte value;
	private final String desc;

	private LoginNeedsValidation(Byte value, String desc) {
		this.value = value;
		this.desc  = desc;
	}

	public Byte getValue() {
		return value;
	}

	public String getDesc() {
		return desc;
	}
}
