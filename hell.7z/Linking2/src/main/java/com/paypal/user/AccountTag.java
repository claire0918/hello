/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AccountVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.user;

import java.math.BigInteger;

  
public enum AccountTag {
/***/
   	RESTRICTED(new String("RSTRCTD"), ""),
   	COMPLIANCE_LOCK_DOWN(new String("OFAC_LCK"), ""),
   	IS_VERIFIED(new String("VERIFIED"), ""),
   	RESTRICT_FUND_RECV(new String("NO_RCV"), ""),
   	RESTRICT_NEXT_TRANSACTION(new String("RSTRT_NT"), ""),
   	POS_ENABLED(new String("POS_ON"), ""),
   	GETS_AMEX_SPECIAL_FEE(new String("AMEX_FEE"), "Indicates that a merchant has done enough volume with American Express to qualify for their special rate. (Requires something like a half million in payments via AMEX, so this will be only for very large merchants.) The flag is set (or unset) via a manual process in admin."),
   	SANDBOX_NEGATIVE_TESTING_ENABLED(new String("NEG_TEST"), "Setting this tag enables negative testing on the account in the sandbox environment. This causes API calls against the account to fail with client specified error codes so that merchants can test the failure scenarios of their integrations. This flag is set and unset via devscr and can only ever be set in sandbox. It is impossible to set this tag on live."),
   	NON_EC_COMPLIANCE_FEE(new String("NoECComp"), "If a website violates the product terms of Express Checkout (EC) (such as not listing PayPal as a payment option) then we may put this tag on their account which causes them to be charged a higher fee for transactions. This tag is set and unset manually by the admin tool."),
   	BUSINESS_HAS_STAKEHOLDER(new String("StkHldr"), "Indicates that this account has a business party that has stake holder data attached to it. This tag is set when the data is added, and is removed if all stake holder relationships are removed. Eventually we would like to migrate the stake holder data into the party data model and then the relationship can be directly checked and this tag will be deprecated."),
   	BUSINESS_HAS_BENEFICIAL_OWNER(new String("BenOwner"), "Indicates that this account has a business party that has beneficial owner data attached to it. This tag is set when the data is added, and is removed if all beneficial owner relationships are removed. Eventually we would like to migrate the beneficial owner data into the party data model and then the relationship can be directly checked and this tag will be deprecated."),
   	BUSINESS_HAS_THIRD_PARTIES(new String("has3rdPt"), "Indicates that this party (most likely a business) has third parties associated to it. This tag is set when the data is added, and is removed if all associated third parties are removed. Eventually we would like to migrate the 3rd party data into the party data model and then the relationship can be directly checked and this tag will be deprecated.");

	private final String value;
	private final String desc;

	private AccountTag(String value, String desc) {
		this.value = value;
		this.desc  = desc;
	}

	public String getValue() {
		return value;
	}

	public String getDesc() {
		return desc;
	}
}
