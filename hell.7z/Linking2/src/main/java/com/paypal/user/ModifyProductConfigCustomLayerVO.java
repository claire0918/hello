/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/ProductConfiguration.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:40 2012 */

package com.paypal.user;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
  * 
   */

public class ModifyProductConfigCustomLayerVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((45899*45899)<<32)/*<-ModifyProductConfigCustomLayerVO*/+
         		20748/*<-existing_layer_id*/*46168/*<-ullong*/+
         		16223/*<-type_for_new_layer*/*18443/*<-String*/+
         		31416/*<-name*/*18443/*<-String*/+
         		49516/*<-set_configs*/*47/*<-repeating*/*NVPairVO.TYPE_SIGNATURE/*<-NVPairVO*/;
 
	public ModifyProductConfigCustomLayerVO() {
		super("User::ModifyProductConfigCustomLayerVO", TYPE_SIGNATURE);

 
		set("existing_layer_id", null, "ullong");
 		addFieldQualifier("type_for_new_layer","emum","ProductConfigCustomLayerType");
 
		set("type_for_new_layer", null, "String");
 
		set("name", null, "String");
 
		set("set_configs", null, "List<User::NVPairVO>");
	}

	// {{{
	public void setExistingLayerId(BigInteger value) { this.set("existing_layer_id", (Object)value); }
 	public BigInteger getExistingLayerId() { return (BigInteger)this.get("existing_layer_id"); }
	// }}}
	// {{{
	public void setTypeForNewLayer(String value) { this.set("type_for_new_layer", (Object)value); }
 	public String getTypeForNewLayer() { return (String)this.get("type_for_new_layer"); }
	// }}}
	// {{{
	public void setName(String value) { this.set("name", (Object)value); }
 	public String getName() { return (String)this.get("name"); }
	// }}}
	// {{{
	public void setSetConfigs(List<NVPairVO> value) { this.set("set_configs", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<NVPairVO> getSetConfigs() { return (List<NVPairVO>)this.get("set_configs"); }
	// }}}
}