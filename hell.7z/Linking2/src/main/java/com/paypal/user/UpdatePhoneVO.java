/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/PhoneVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:40 2012 */

package com.paypal.user;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
  * 
   */

public class UpdatePhoneVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((28040*28040)<<32)/*<-UpdatePhoneVO*/+
         		3355/*<-id*/*46168/*<-ullong*/+
         		42850/*<-contact_name*/*18443/*<-String*/+
         		1177/*<-is_mobile_payment_enabled*/*15044/*<-bool*/+
         		47483/*<-validation_status*/*62361/*<-sint8*/+
         		52257/*<-validation_style*/*62361/*<-sint8*/+
         		5801/*<-has_fraud_alert*/*15044/*<-bool*/;
 
	public UpdatePhoneVO() {
		super("User::UpdatePhoneVO", TYPE_SIGNATURE);

 
		set("id", null, "ullong");
 
		set("contact_name", null, "String");
 
		set("is_mobile_payment_enabled", null, "bool");
 
		set("validation_status", null, "sint8");
 
		set("validation_style", null, "sint8");
 
		set("has_fraud_alert", null, "bool");
	}

	// {{{
	public void setId(BigInteger value) { this.set("id", (Object)value); }
 	public BigInteger getId() { return (BigInteger)this.get("id"); }
	// }}}
	// {{{
	public void setContactName(String value) { this.set("contact_name", (Object)value); }
 	public String getContactName() { return (String)this.get("contact_name"); }
	// }}}
	// {{{
	public void setIsMobilePaymentEnabled(Boolean value) { this.set("is_mobile_payment_enabled", (Object)value); }
 	public Boolean getIsMobilePaymentEnabled() { return (Boolean)this.get("is_mobile_payment_enabled"); }
	// }}}
	// {{{
	public void setValidationStatus(Byte value) { this.set("validation_status", (Object)value); }
 	public Byte getValidationStatus() { return (Byte)this.get("validation_status"); }
	// }}}
	// {{{
	public void setValidationStyle(Byte value) { this.set("validation_style", (Object)value); }
 	public Byte getValidationStyle() { return (Byte)this.get("validation_style"); }
	// }}}
	// {{{
	public void setHasFraudAlert(Boolean value) { this.set("has_fraud_alert", (Object)value); }
 	public Boolean getHasFraudAlert() { return (Boolean)this.get("has_fraud_alert"); }
	// }}}
}