/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AddressVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.user;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
  * 
   */

public class UpdateAddressVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((59977*59977)<<32)/*<-UpdateAddressVO*/+
         		3355/*<-id*/*46168/*<-ullong*/+
         		3252/*<-confirmation_status*/*62361/*<-sint8*/+
         		21104/*<-confirmation_style*/*62361/*<-sint8*/+
         		59512/*<-make_primary*/*15044/*<-bool*/+
         		35316/*<-make_default_billing*/*15044/*<-bool*/+
         		45890/*<-make_business*/*15044/*<-bool*/+
         		56798/*<-is_invalid*/*15044/*<-bool*/+
         		13544/*<-is_partial_location*/*15044/*<-bool*/;
 
	public UpdateAddressVO() {
		super("User::UpdateAddressVO", TYPE_SIGNATURE);

 
		set("id", null, "ullong");
 		addFieldQualifier("confirmation_status","cpp_gen","define_legacy");
 
		set("confirmation_status", null, "sint8");
 		addFieldQualifier("confirmation_style","cpp_gen","define_legacy");
 
		set("confirmation_style", null, "sint8");
 
		set("make_primary", null, "bool");
 
		set("make_default_billing", null, "bool");
 
		set("make_business", null, "bool");
 
		set("is_invalid", null, "bool");
 
		set("is_partial_location", null, "bool");
	}

	// {{{
	public void setId(BigInteger value) { this.set("id", (Object)value); }
 	public BigInteger getId() { return (BigInteger)this.get("id"); }
	// }}}
	// {{{
	public void setConfirmationStatus(Byte value) { this.set("confirmation_status", (Object)value); }
 	public Byte getConfirmationStatus() { return (Byte)this.get("confirmation_status"); }
	// }}}
	// {{{
	public void setConfirmationStyle(Byte value) { this.set("confirmation_style", (Object)value); }
 	public Byte getConfirmationStyle() { return (Byte)this.get("confirmation_style"); }
	// }}}
	// {{{
	public void setMakePrimary(Boolean value) { this.set("make_primary", (Object)value); }
 	public Boolean getMakePrimary() { return (Boolean)this.get("make_primary"); }
	// }}}
	// {{{
	public void setMakeDefaultBilling(Boolean value) { this.set("make_default_billing", (Object)value); }
 	public Boolean getMakeDefaultBilling() { return (Boolean)this.get("make_default_billing"); }
	// }}}
	// {{{
	public void setMakeBusiness(Boolean value) { this.set("make_business", (Object)value); }
 	public Boolean getMakeBusiness() { return (Boolean)this.get("make_business"); }
	// }}}
	// {{{
	public void setIsInvalid(Boolean value) { this.set("is_invalid", (Object)value); }
 	public Boolean getIsInvalid() { return (Boolean)this.get("is_invalid"); }
	// }}}
	// {{{
	public void setIsPartialLocation(Boolean value) { this.set("is_partial_location", (Object)value); }
 	public Boolean getIsPartialLocation() { return (Boolean)this.get("is_partial_location"); }
	// }}}
}