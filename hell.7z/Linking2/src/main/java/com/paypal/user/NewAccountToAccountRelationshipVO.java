/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AccountToAccountRelationshipVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.user;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
  * 
   */

public class NewAccountToAccountRelationshipVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((19463*19463)<<32)/*<-NewAccountToAccountRelationshipVO*/+
         		39857/*<-subject_account*/*46168/*<-ullong*/+
         		39813/*<-acting_account*/*46168/*<-ullong*/+
         		36620/*<-type*/*62361/*<-sint8*/+
         		52543/*<-status*/*62361/*<-sint8*/+
         		55937/*<-privileges*/*47/*<-repeating*/*18443/*<-String*/;
 
	public NewAccountToAccountRelationshipVO() {
		super("User::NewAccountToAccountRelationshipVO", TYPE_SIGNATURE);

 
		set("subject_account", null, "ullong");
 
		set("acting_account", null, "ullong");
 		addFieldQualifier("type","cpp_gen","define_legacy");
 
		set("type", null, "sint8");
 		addFieldQualifier("status","cpp_gen","define_legacy");
 
		set("status", null, "sint8");
 
		set("privileges", null, "List<String>");
	}

	// {{{
	public void setSubjectAccount(BigInteger value) { this.set("subject_account", (Object)value); }
 	public BigInteger getSubjectAccount() { return (BigInteger)this.get("subject_account"); }
	// }}}
	// {{{
	public void setActingAccount(BigInteger value) { this.set("acting_account", (Object)value); }
 	public BigInteger getActingAccount() { return (BigInteger)this.get("acting_account"); }
	// }}}
	// {{{
	public void setType(Byte value) { this.set("type", (Object)value); }
 	public Byte getType() { return (Byte)this.get("type"); }
	// }}}
	// {{{
	public void setStatus(Byte value) { this.set("status", (Object)value); }
 	public Byte getStatus() { return (Byte)this.get("status"); }
	// }}}
	// {{{
	public void setPrivileges(List<String> value) { this.set("privileges", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<String> getPrivileges() { return (List<String>)this.get("privileges"); }
	// }}}
}