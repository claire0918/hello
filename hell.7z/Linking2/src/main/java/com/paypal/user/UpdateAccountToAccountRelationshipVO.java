/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AccountToAccountRelationshipVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.user;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
  * 
   */

public class UpdateAccountToAccountRelationshipVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((8251*8251)<<32)/*<-UpdateAccountToAccountRelationshipVO*/+
         		3355/*<-id*/*46168/*<-ullong*/+
         		52543/*<-status*/*62361/*<-sint8*/+
         		47518/*<-add_privileges*/*47/*<-repeating*/*18443/*<-String*/+
         		33272/*<-remove_privileges*/*47/*<-repeating*/*18443/*<-String*/;
 
	public UpdateAccountToAccountRelationshipVO() {
		super("User::UpdateAccountToAccountRelationshipVO", TYPE_SIGNATURE);

 
		set("id", null, "ullong");
 		addFieldQualifier("status","cpp_gen","define_legacy");
 
		set("status", null, "sint8");
 
		set("add_privileges", null, "List<String>");
 
		set("remove_privileges", null, "List<String>");
	}

	// {{{
	public void setId(BigInteger value) { this.set("id", (Object)value); }
 	public BigInteger getId() { return (BigInteger)this.get("id"); }
	// }}}
	// {{{
	public void setStatus(Byte value) { this.set("status", (Object)value); }
 	public Byte getStatus() { return (Byte)this.get("status"); }
	// }}}
	// {{{
	public void setAddPrivileges(List<String> value) { this.set("add_privileges", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<String> getAddPrivileges() { return (List<String>)this.get("add_privileges"); }
	// }}}
	// {{{
	public void setRemovePrivileges(List<String> value) { this.set("remove_privileges", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<String> getRemovePrivileges() { return (List<String>)this.get("remove_privileges"); }
	// }}}
}