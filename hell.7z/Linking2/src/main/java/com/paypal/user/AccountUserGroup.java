/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AccountVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.user;

import java.math.BigInteger;

  
public enum AccountUserGroup {
/***/
   	PERSONAL(new Long("0"), ""),
   	PREMIER(new Long("1"), ""),
   	BUSINESS(new Long("2"), "");

	private final Long value;
	private final String desc;

	private AccountUserGroup(Long value, String desc) {
		this.value = value;
		this.desc  = desc;
	}

	public Long getValue() {
		return value;
	}

	public String getDesc() {
		return desc;
	}
}
