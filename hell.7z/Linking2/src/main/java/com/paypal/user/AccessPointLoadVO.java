/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AccessPointVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.user;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
  * 
   */

public class AccessPointLoadVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((44374*44374)<<32)/*<-AccessPointLoadVO*/+
         		41975/*<-party_id*/*47/*<-repeating*/*46168/*<-ullong*/+
         		33339/*<-actor_id*/*47/*<-repeating*/*46168/*<-ullong*/+
         		7722/*<-load_access_point*/*15044/*<-bool*/+
         		35424/*<-public_credential_criteria*/*PublicCredentialCriteriaVO.TYPE_SIGNATURE/*<-PublicCredentialCriteriaVO*/+
         		27501/*<-private_credential_criteria*/*PrivateCredentialCriteriaVO.TYPE_SIGNATURE/*<-PrivateCredentialCriteriaVO*/+
         		56732/*<-remembered_actor_criteria*/*RememberedActorCriteriaVO.TYPE_SIGNATURE/*<-RememberedActorCriteriaVO*/+
         		56647/*<-party_criteria*/*PartyCriteriaVO.TYPE_SIGNATURE/*<-PartyCriteriaVO*/+
         		44062/*<-account_criteria*/*AccountCriteriaVO.TYPE_SIGNATURE/*<-AccountCriteriaVO*/;
 
	public AccessPointLoadVO() {
		super("User::AccessPointLoadVO", TYPE_SIGNATURE);

 
		set("party_id", null, "List<ullong>");
 
		set("actor_id", null, "List<ullong>");
 
		set("load_access_point", null, "bool");
 
		set("public_credential_criteria", null, "User::PublicCredentialCriteriaVO");
 
		set("private_credential_criteria", null, "User::PrivateCredentialCriteriaVO");
 
		set("remembered_actor_criteria", null, "User::RememberedActorCriteriaVO");
 
		set("party_criteria", null, "User::PartyCriteriaVO");
 
		set("account_criteria", null, "User::AccountCriteriaVO");
	}

	// {{{
	public void setPartyId(List<BigInteger> value) { this.set("party_id", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<BigInteger> getPartyId() { return (List<BigInteger>)this.get("party_id"); }
	// }}}
	// {{{
	public void setActorId(List<BigInteger> value) { this.set("actor_id", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<BigInteger> getActorId() { return (List<BigInteger>)this.get("actor_id"); }
	// }}}
	// {{{
	public void setLoadAccessPoint(Boolean value) { this.set("load_access_point", (Object)value); }
 	public Boolean getLoadAccessPoint() { return (Boolean)this.get("load_access_point"); }
	// }}}
	// {{{
	public void setPublicCredentialCriteria(PublicCredentialCriteriaVO value) { this.set("public_credential_criteria", (Object)value); }
 	public PublicCredentialCriteriaVO getPublicCredentialCriteria() { return (PublicCredentialCriteriaVO)this.get("public_credential_criteria"); }
	// }}}
	// {{{
	public void setPrivateCredentialCriteria(PrivateCredentialCriteriaVO value) { this.set("private_credential_criteria", (Object)value); }
 	public PrivateCredentialCriteriaVO getPrivateCredentialCriteria() { return (PrivateCredentialCriteriaVO)this.get("private_credential_criteria"); }
	// }}}
	// {{{
	public void setRememberedActorCriteria(RememberedActorCriteriaVO value) { this.set("remembered_actor_criteria", (Object)value); }
 	public RememberedActorCriteriaVO getRememberedActorCriteria() { return (RememberedActorCriteriaVO)this.get("remembered_actor_criteria"); }
	// }}}
	// {{{
	public void setPartyCriteria(PartyCriteriaVO value) { this.set("party_criteria", (Object)value); }
 	public PartyCriteriaVO getPartyCriteria() { return (PartyCriteriaVO)this.get("party_criteria"); }
	// }}}
	// {{{
	public void setAccountCriteria(AccountCriteriaVO value) { this.set("account_criteria", (Object)value); }
 	public AccountCriteriaVO getAccountCriteria() { return (AccountCriteriaVO)this.get("account_criteria"); }
	// }}}
}