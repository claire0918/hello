/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/StatementNameVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:41 2012 */

package com.paypal.user;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
  * 
   */

public class UpdateStatementNameVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((8026*8026)<<32)/*<-UpdateStatementNameVO*/+
         		31416/*<-name*/*18443/*<-String*/+
         		7630/*<-long_name*/*18443/*<-String*/+
         		61949/*<-not_editable*/*15044/*<-bool*/+
         		46753/*<-add_tags*/*47/*<-repeating*/*18443/*<-String*/+
         		41076/*<-remove_tags*/*47/*<-repeating*/*18443/*<-String*/+
         		47487/*<-use_individual_cs_number*/*15044/*<-bool*/;
 
	public UpdateStatementNameVO() {
		super("User::UpdateStatementNameVO", TYPE_SIGNATURE);

 
		set("name", null, "String");
 
		set("long_name", null, "String");
 
		set("not_editable", null, "bool");
 
		set("add_tags", null, "List<String>");
 
		set("remove_tags", null, "List<String>");
 
		set("use_individual_cs_number", null, "bool");
	}

	// {{{
	public void setName(String value) { this.set("name", (Object)value); }
 	public String getName() { return (String)this.get("name"); }
	// }}}
	// {{{
	public void setLongName(String value) { this.set("long_name", (Object)value); }
 	public String getLongName() { return (String)this.get("long_name"); }
	// }}}
	// {{{
	public void setNotEditable(Boolean value) { this.set("not_editable", (Object)value); }
 	public Boolean getNotEditable() { return (Boolean)this.get("not_editable"); }
	// }}}
	// {{{
	public void setAddTags(List<String> value) { this.set("add_tags", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<String> getAddTags() { return (List<String>)this.get("add_tags"); }
	// }}}
	// {{{
	public void setRemoveTags(List<String> value) { this.set("remove_tags", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<String> getRemoveTags() { return (List<String>)this.get("remove_tags"); }
	// }}}
	// {{{
	public void setUseIndividualCsNumber(Boolean value) { this.set("use_individual_cs_number", (Object)value); }
 	public Boolean getUseIndividualCsNumber() { return (Boolean)this.get("use_individual_cs_number"); }
	// }}}
}