/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AddressVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.user;

import java.math.BigInteger;

  
public enum AddressType {
/***/
   	HOME_OR_WORK(new Byte("0"), ""),
   	GIFT(new Byte("71"), "gift address - *not* one of the user's home/work addresses"),
   	THIRD_PARTY(new Byte("3"), "3rd party address - *not* one of the user's home/work addresses"),
   	SMI_OWNER(new Byte("79"), "Address of the owner of the business. (owner is different from account holder)"),
   	SMI_SUPPLIER(new Byte("83"), "address of the supplier for the business"),
   	SMI_PREV_BUSINESS(new Byte("80"), "previous address of the business conducted by the account holder"),
   	SMI_ADDITIONAL_BUSINESS(new Byte("65"), "additional business address"),
   	WAX(new Byte("88"), "billing address added to a WAX (WebAcceptExpress) account"),
   	WAX_GIFT(new Byte("87"), "shipping/gift address added to a WAX (WebAcceptExpress) account"),
   	THIRD_PARTY_NO_ADDRESSEE(new Byte("78"), "3rd party address that doesn't have an addressee name ('N' for No Addressee!)"),
   	VERISIGN_BILLING(new Byte("86"), "F-11569 (45.0) billing address for a Verisign Merchant"),
   	PRIOR_ADDRESS(new Byte("82"), "An address that used to be the address of the user."),
   	PRINCIPLE_BUSINESS(new Byte("66"), "main business address"),
   	OFFICE(new Byte("70"), "office address"),
   	COMMUNICATION(new Byte("67"), "*** PROPOSED for AUSTRAC *** an alternate communication (home/mailing) address for the user. Could be international or PO box etc.");

	private final Byte value;
	private final String desc;

	private AddressType(Byte value, String desc) {
		this.value = value;
		this.desc  = desc;
	}

	public Byte getValue() {
		return value;
	}

	public String getDesc() {
		return desc;
	}
}
