/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AddressVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.user;

import java.math.BigInteger;

  
public enum AddressConfirmationStatus {
/***/
   	UNCONFIRMED(new Byte("0"), ""),
   	REQUESTED(new Byte("1"), ""),
   	SENT(new Byte("2"), ""),
   	PENDING(new Byte("3"), ""),
   	FAILED(new Byte("4"), ""),
   	CONFIRMED(new Byte("5"), "");

	private final Byte value;
	private final String desc;

	private AddressConfirmationStatus(Byte value, String desc) {
		this.value = value;
		this.desc  = desc;
	}

	public Byte getValue() {
		return value;
	}

	public String getDesc() {
		return desc;
	}
}
