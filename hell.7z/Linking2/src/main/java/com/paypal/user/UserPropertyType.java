/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/UserPropertyVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:41 2012 */

package com.paypal.user;

import java.math.BigInteger;

  
public enum UserPropertyType {
/***/
   	ACCOUNT(new String("ACCOUNT"), ""),
   	PARTY(new String("PARTY"), ""),
   	PARTY_TO_PARTY_RELATIONSHIP(new String("PartyRel"), "");

	private final String value;
	private final String desc;

	private UserPropertyType(String value, String desc) {
		this.value = value;
		this.desc  = desc;
	}

	public String getValue() {
		return value;
	}

	public String getDesc() {
		return desc;
	}
}
