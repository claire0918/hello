/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AccountVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.user;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
  * 
   */

public class ModifyAccountVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((18554*18554)<<32)/*<-ModifyAccountVO*/+
         		62145/*<-account_number*/*46168/*<-ullong*/+
         		36620/*<-type*/*18443/*<-String*/+
         		64599/*<-account_name*/*18443/*<-String*/+
         		46753/*<-add_tags*/*47/*<-repeating*/*18443/*<-String*/+
         		41076/*<-remove_tags*/*47/*<-repeating*/*18443/*<-String*/;
 
	public ModifyAccountVO() {
		super("User::ModifyAccountVO", TYPE_SIGNATURE);

 
		set("account_number", null, "ullong");
 
		set("type", null, "String");
 
		set("account_name", null, "String");
 
		set("add_tags", null, "List<String>");
 
		set("remove_tags", null, "List<String>");
	}

	// {{{
	public void setAccountNumber(BigInteger value) { this.set("account_number", (Object)value); }
 	public BigInteger getAccountNumber() { return (BigInteger)this.get("account_number"); }
	// }}}
	// {{{
	public void setType(String value) { this.set("type", (Object)value); }
 	public String getType() { return (String)this.get("type"); }
	// }}}
	// {{{
	public void setAccountName(String value) { this.set("account_name", (Object)value); }
 	public String getAccountName() { return (String)this.get("account_name"); }
	// }}}
	// {{{
	public void setAddTags(List<String> value) { this.set("add_tags", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<String> getAddTags() { return (List<String>)this.get("add_tags"); }
	// }}}
	// {{{
	public void setRemoveTags(List<String> value) { this.set("remove_tags", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<String> getRemoveTags() { return (List<String>)this.get("remove_tags"); }
	// }}}
}