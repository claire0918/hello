/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/PartyToAccountRelationshipVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:40 2012 */

package com.paypal.user;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
  * 
   */

public class AccountPartyRelCriteriaVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((50666*50666)<<32)/*<-AccountPartyRelCriteriaVO*/+
         		24990/*<-load_party_account_rel*/*15044/*<-bool*/+
         		56647/*<-party_criteria*/*PartyCriteriaVO.TYPE_SIGNATURE/*<-PartyCriteriaVO*/;
 
	public AccountPartyRelCriteriaVO() {
		super("User::AccountPartyRelCriteriaVO", TYPE_SIGNATURE);

 
		set("load_party_account_rel", null, "bool");
 
		set("party_criteria", null, "User::PartyCriteriaVO");
	}

	// {{{
	public void setLoadPartyAccountRel(Boolean value) { this.set("load_party_account_rel", (Object)value); }
 	public Boolean getLoadPartyAccountRel() { return (Boolean)this.get("load_party_account_rel"); }
	// }}}
	// {{{
	public void setPartyCriteria(PartyCriteriaVO value) { this.set("party_criteria", (Object)value); }
 	public PartyCriteriaVO getPartyCriteria() { return (PartyCriteriaVO)this.get("party_criteria"); }
	// }}}
}