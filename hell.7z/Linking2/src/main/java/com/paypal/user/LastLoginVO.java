/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/LastLoginVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:40 2012 */

package com.paypal.user;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
  * 
   */

public class LastLoginVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((31827*31827)<<32)/*<-LastLoginVO*/+
         		62145/*<-account_number*/*46168/*<-ullong*/+
         		1750/*<-last_login_ip*/*18443/*<-String*/+
         		44089/*<-last_web_access*/*33490/*<-ulong*/+
         		1706/*<-last_login_id*/*46168/*<-ullong*/;
 
	public LastLoginVO() {
		super("User::LastLoginVO", TYPE_SIGNATURE);

 
		set("account_number", null, "ullong");
 
		set("last_login_ip", null, "String");
 
		set("last_web_access", null, "ulong");
 
		set("last_login_id", null, "ullong");
	}

	// {{{
	public void setAccountNumber(BigInteger value) { this.set("account_number", (Object)value); }
 	public BigInteger getAccountNumber() { return (BigInteger)this.get("account_number"); }
	// }}}
	// {{{
	public void setLastLoginIp(String value) { this.set("last_login_ip", (Object)value); }
 	public String getLastLoginIp() { return (String)this.get("last_login_ip"); }
	// }}}
	// {{{
	public void setLastWebAccess(Long value) { this.set("last_web_access", (Object)value); }
 	public Long getLastWebAccess() { return (Long)this.get("last_web_access"); }
	// }}}
	// {{{
	public void setLastLoginId(BigInteger value) { this.set("last_login_id", (Object)value); }
 	public BigInteger getLastLoginId() { return (BigInteger)this.get("last_login_id"); }
	// }}}
}