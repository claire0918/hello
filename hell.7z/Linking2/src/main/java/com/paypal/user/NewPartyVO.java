/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/PartyVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:40 2012 */

package com.paypal.user;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
  * 
   */

public class NewPartyVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((47486*47486)<<32)/*<-NewPartyVO*/+
         		3355/*<-id*/*46168/*<-ullong*/+
         		36620/*<-type*/*18443/*<-String*/+
         		16094/*<-preferred_language*/*18443/*<-String*/+
         		57575/*<-citizenship*/*18443/*<-String*/+
         		17350/*<-timezone*/*18443/*<-String*/+
         		13359/*<-tags*/*47/*<-repeating*/*18443/*<-String*/+
         		36831/*<-new_name*/*47/*<-repeating*/*NewNameVO.TYPE_SIGNATURE/*<-NewNameVO*/+
         		40991/*<-new_email*/*47/*<-repeating*/*NewEmailVO.TYPE_SIGNATURE/*<-NewEmailVO*/+
         		19296/*<-new_address*/*47/*<-repeating*/*NewAddressVO.TYPE_SIGNATURE/*<-NewAddressVO*/+
         		37556/*<-new_phone*/*47/*<-repeating*/*NewPhoneVO.TYPE_SIGNATURE/*<-NewPhoneVO*/+
         		33688/*<-new_doc_id*/*47/*<-repeating*/*NewDocumentIdentifierVO.TYPE_SIGNATURE/*<-NewDocumentIdentifierVO*/+
         		40877/*<-new_security_questions*/*47/*<-repeating*/*UpdateSecurityQuestionsVO.TYPE_SIGNATURE/*<-UpdateSecurityQuestionsVO*/+
         		5644/*<-new_date_of_birth*/*ModifyDateOfBirthVO.TYPE_SIGNATURE/*<-ModifyDateOfBirthVO*/+
         		53397/*<-new_file_reference*/*47/*<-repeating*/*NewFileReferenceVO.TYPE_SIGNATURE/*<-NewFileReferenceVO*/+
         		12824/*<-new_access_point*/*47/*<-repeating*/*NewAccessPointVO.TYPE_SIGNATURE/*<-NewAccessPointVO*/+
         		30070/*<-new_pub_cred*/*47/*<-repeating*/*NewPublicCredentialVO.TYPE_SIGNATURE/*<-NewPublicCredentialVO*/+
         		37057/*<-new_private_credential*/*47/*<-repeating*/*NewPrivateCredentialVO.TYPE_SIGNATURE/*<-NewPrivateCredentialVO*/;
 
	public NewPartyVO() {
		super("User::NewPartyVO", TYPE_SIGNATURE);

 
		set("id", null, "ullong");
 
		set("type", null, "String");
 
		set("preferred_language", null, "String");
 
		set("citizenship", null, "String");
 
		set("timezone", null, "String");
 
		set("tags", null, "List<String>");
 
		set("new_name", null, "List<User::NewNameVO>");
 
		set("new_email", null, "List<User::NewEmailVO>");
 
		set("new_address", null, "List<User::NewAddressVO>");
 
		set("new_phone", null, "List<User::NewPhoneVO>");
 
		set("new_doc_id", null, "List<User::NewDocumentIdentifierVO>");
 
		set("new_security_questions", null, "List<User::UpdateSecurityQuestionsVO>");
 
		set("new_date_of_birth", null, "User::ModifyDateOfBirthVO");
 
		set("new_file_reference", null, "List<User::NewFileReferenceVO>");
 
		set("new_access_point", null, "List<User::NewAccessPointVO>");
 
		set("new_pub_cred", null, "List<User::NewPublicCredentialVO>");
 
		set("new_private_credential", null, "List<User::NewPrivateCredentialVO>");
	}

	// {{{
	public void setId(BigInteger value) { this.set("id", (Object)value); }
 	public BigInteger getId() { return (BigInteger)this.get("id"); }
	// }}}
	// {{{
	public void setType(String value) { this.set("type", (Object)value); }
 	public String getType() { return (String)this.get("type"); }
	// }}}
	// {{{
	public void setPreferredLanguage(String value) { this.set("preferred_language", (Object)value); }
 	public String getPreferredLanguage() { return (String)this.get("preferred_language"); }
	// }}}
	// {{{
	public void setCitizenship(String value) { this.set("citizenship", (Object)value); }
 	public String getCitizenship() { return (String)this.get("citizenship"); }
	// }}}
	// {{{
	public void setTimezone(String value) { this.set("timezone", (Object)value); }
 	public String getTimezone() { return (String)this.get("timezone"); }
	// }}}
	// {{{
	public void setTags(List<String> value) { this.set("tags", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<String> getTags() { return (List<String>)this.get("tags"); }
	// }}}
	// {{{
	public void setNewName(List<NewNameVO> value) { this.set("new_name", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<NewNameVO> getNewName() { return (List<NewNameVO>)this.get("new_name"); }
	// }}}
	// {{{
	public void setNewEmail(List<NewEmailVO> value) { this.set("new_email", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<NewEmailVO> getNewEmail() { return (List<NewEmailVO>)this.get("new_email"); }
	// }}}
	// {{{
	public void setNewAddress(List<NewAddressVO> value) { this.set("new_address", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<NewAddressVO> getNewAddress() { return (List<NewAddressVO>)this.get("new_address"); }
	// }}}
	// {{{
	public void setNewPhone(List<NewPhoneVO> value) { this.set("new_phone", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<NewPhoneVO> getNewPhone() { return (List<NewPhoneVO>)this.get("new_phone"); }
	// }}}
	// {{{
	public void setNewDocId(List<NewDocumentIdentifierVO> value) { this.set("new_doc_id", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<NewDocumentIdentifierVO> getNewDocId() { return (List<NewDocumentIdentifierVO>)this.get("new_doc_id"); }
	// }}}
	// {{{
	public void setNewSecurityQuestions(List<UpdateSecurityQuestionsVO> value) { this.set("new_security_questions", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<UpdateSecurityQuestionsVO> getNewSecurityQuestions() { return (List<UpdateSecurityQuestionsVO>)this.get("new_security_questions"); }
	// }}}
	// {{{
	public void setNewDateOfBirth(ModifyDateOfBirthVO value) { this.set("new_date_of_birth", (Object)value); }
 	public ModifyDateOfBirthVO getNewDateOfBirth() { return (ModifyDateOfBirthVO)this.get("new_date_of_birth"); }
	// }}}
	// {{{
	public void setNewFileReference(List<NewFileReferenceVO> value) { this.set("new_file_reference", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<NewFileReferenceVO> getNewFileReference() { return (List<NewFileReferenceVO>)this.get("new_file_reference"); }
	// }}}
	// {{{
	public void setNewAccessPoint(List<NewAccessPointVO> value) { this.set("new_access_point", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<NewAccessPointVO> getNewAccessPoint() { return (List<NewAccessPointVO>)this.get("new_access_point"); }
	// }}}
	// {{{
	public void setNewPubCred(List<NewPublicCredentialVO> value) { this.set("new_pub_cred", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<NewPublicCredentialVO> getNewPubCred() { return (List<NewPublicCredentialVO>)this.get("new_pub_cred"); }
	// }}}
	// {{{
	public void setNewPrivateCredential(List<NewPrivateCredentialVO> value) { this.set("new_private_credential", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<NewPrivateCredentialVO> getNewPrivateCredential() { return (List<NewPrivateCredentialVO>)this.get("new_private_credential"); }
	// }}}
}