/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AccountVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.user;

import java.math.BigInteger;

  
public enum AccountType {
/***/
   	FULL(new Integer("0"), "Full, regular account. Could be personal, premier, or business as set by user_group. This is your standad PayPal user, they know they are using PayPal and have an account."),
   	GUEST(new Integer("11"), "Guest account. In this case the user does not know that a PayPal account has been created for them. (typically for guest payment flows when the account will be attached to a financial instrument and identified that way)"),
   	ANONYMOUS(new Integer("12"), "Guest, anonymous account. The user does not even know that they have used PayPal. (typically used for the counterparty in a DCC or VT scenario where a merchant is directly charging a credit card.)");

	private final Integer value;
	private final String desc;

	private AccountType(Integer value, String desc) {
		this.value = value;
		this.desc  = desc;
	}

	public Integer getValue() {
		return value;
	}

	public String getDesc() {
		return desc;
	}
}
