/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AccountVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.user;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
  * 
   */

public class NewAccountVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((23308*23308)<<32)/*<-NewAccountVO*/+
         		62145/*<-account_number*/*46168/*<-ullong*/+
         		36620/*<-type*/*18443/*<-String*/+
         		4866/*<-account_type*/*38894/*<-int*/+
         		930/*<-user_group*/*33490/*<-ulong*/+
         		39594/*<-legal_country*/*18443/*<-String*/+
         		64599/*<-account_name*/*18443/*<-String*/+
         		13359/*<-tags*/*47/*<-repeating*/*18443/*<-String*/+
         		18400/*<-new_owner*/*47/*<-repeating*/*NewPartyVO.TYPE_SIGNATURE/*<-NewPartyVO*/+
         		63311/*<-existing_owner*/*47/*<-repeating*/*46168/*<-ullong*/+
         		41687/*<-user_agreement_accepted*/*38894/*<-int*/+
         		7103/*<-new_legal_agreement*/*47/*<-repeating*/*UpdateLegalLoggingVO.TYPE_SIGNATURE/*<-UpdateLegalLoggingVO*/+
         		16444/*<-modify_product_config_stack*/*47/*<-repeating*/*ModifyProductConfigStackVO.TYPE_SIGNATURE/*<-ModifyProductConfigStackVO*/+
         		53397/*<-new_file_reference*/*47/*<-repeating*/*NewFileReferenceVO.TYPE_SIGNATURE/*<-NewFileReferenceVO*/+
         		11562/*<-new_account_rel*/*47/*<-repeating*/*NewAccountToAccountRelationshipVO.TYPE_SIGNATURE/*<-NewAccountToAccountRelationshipVO*/+
         		51561/*<-last_name*/*18443/*<-String*/+
         		35037/*<-first_name*/*18443/*<-String*/+
         		38026/*<-language*/*18443/*<-String*/+
         		2233/*<-primary_currency_code*/*18443/*<-String*/+
         		57575/*<-citizenship*/*18443/*<-String*/+
         		17350/*<-timezone*/*18443/*<-String*/+
         		28425/*<-subprime_category*/*33490/*<-ulong*/+
         		3328/*<-subprime_subcategory*/*33490/*<-ulong*/+
         		63182/*<-fraud_score*/*46796/*<-llong*/+
         		56705/*<-is_locked*/*15044/*<-bool*/+
         		43592/*<-is_inactive*/*15044/*<-bool*/+
         		30573/*<-is_verified*/*15044/*<-bool*/+
         		22150/*<-is_restricted*/*15044/*<-bool*/+
         		54989/*<-is_high_restricted*/*15044/*<-bool*/+
         		2090/*<-is_sanction_list_locked*/*15044/*<-bool*/+
         		31122/*<-is_commercial_entity*/*15044/*<-bool*/+
         		47801/*<-set_flags*/*47/*<-repeating*/*UserFlagsVO.TYPE_SIGNATURE/*<-UserFlagsVO*/+
         		55939/*<-public_credentials*/*47/*<-repeating*/*NewPublicCredentialVO.TYPE_SIGNATURE/*<-NewPublicCredentialVO*/;
 
	public NewAccountVO() {
		super("User::NewAccountVO", TYPE_SIGNATURE);

 
		set("account_number", null, "ullong");
 
		set("type", null, "String");
 		addFieldQualifier("account_type","cpp_gen","define_legacy");
 
		set("account_type", null, "int");
 		addFieldQualifier("user_group","cpp_gen","define_legacy");
 
		set("user_group", null, "ulong");
 
		set("legal_country", null, "String");
 
		set("account_name", null, "String");
 
		set("tags", null, "List<String>");
 
		set("new_owner", null, "List<User::NewPartyVO>");
 
		set("existing_owner", null, "List<ullong>");
 		addFieldQualifier("user_agreement_accepted","cpp_gen","define_legacy");
 
		set("user_agreement_accepted", null, "int");
 
		set("new_legal_agreement", null, "List<User::UpdateLegalLoggingVO>");
 
		set("modify_product_config_stack", null, "List<User::ModifyProductConfigStackVO>");
 
		set("new_file_reference", null, "List<User::NewFileReferenceVO>");
 
		set("new_account_rel", null, "List<User::NewAccountToAccountRelationshipVO>");
 
		set("last_name", null, "String");
 
		set("first_name", null, "String");
 
		set("language", null, "String");
 
		set("primary_currency_code", null, "String");
 
		set("citizenship", null, "String");
 
		set("timezone", null, "String");
 
		set("subprime_category", null, "ulong");
 
		set("subprime_subcategory", null, "ulong");
 
		set("fraud_score", null, "llong");
 
		set("is_locked", null, "bool");
 
		set("is_inactive", null, "bool");
 
		set("is_verified", null, "bool");
 
		set("is_restricted", null, "bool");
 
		set("is_high_restricted", null, "bool");
 
		set("is_sanction_list_locked", null, "bool");
 
		set("is_commercial_entity", null, "bool");
 
		set("set_flags", null, "List<User::UserFlagsVO>");
 
		set("public_credentials", null, "List<User::NewPublicCredentialVO>");
	}

	// {{{
	public void setAccountNumber(BigInteger value) { this.set("account_number", (Object)value); }
 	public BigInteger getAccountNumber() { return (BigInteger)this.get("account_number"); }
	// }}}
	// {{{
	public void setType(String value) { this.set("type", (Object)value); }
 	public String getType() { return (String)this.get("type"); }
	// }}}
	// {{{
	public void setAccountType(Integer value) { this.set("account_type", (Object)value); }
 	public Integer getAccountType() { return (Integer)this.get("account_type"); }
	// }}}
	// {{{
	public void setUserGroup(Long value) { this.set("user_group", (Object)value); }
 	public Long getUserGroup() { return (Long)this.get("user_group"); }
	// }}}
	// {{{
	public void setLegalCountry(String value) { this.set("legal_country", (Object)value); }
 	public String getLegalCountry() { return (String)this.get("legal_country"); }
	// }}}
	// {{{
	public void setAccountName(String value) { this.set("account_name", (Object)value); }
 	public String getAccountName() { return (String)this.get("account_name"); }
	// }}}
	// {{{
	public void setTags(List<String> value) { this.set("tags", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<String> getTags() { return (List<String>)this.get("tags"); }
	// }}}
	// {{{
	public void setNewOwner(List<NewPartyVO> value) { this.set("new_owner", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<NewPartyVO> getNewOwner() { return (List<NewPartyVO>)this.get("new_owner"); }
	// }}}
	// {{{
	public void setExistingOwner(List<BigInteger> value) { this.set("existing_owner", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<BigInteger> getExistingOwner() { return (List<BigInteger>)this.get("existing_owner"); }
	// }}}
	// {{{
	public void setUserAgreementAccepted(Integer value) { this.set("user_agreement_accepted", (Object)value); }
 	public Integer getUserAgreementAccepted() { return (Integer)this.get("user_agreement_accepted"); }
	// }}}
	// {{{
	public void setNewLegalAgreement(List<UpdateLegalLoggingVO> value) { this.set("new_legal_agreement", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<UpdateLegalLoggingVO> getNewLegalAgreement() { return (List<UpdateLegalLoggingVO>)this.get("new_legal_agreement"); }
	// }}}
	// {{{
	public void setModifyProductConfigStack(List<ModifyProductConfigStackVO> value) { this.set("modify_product_config_stack", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<ModifyProductConfigStackVO> getModifyProductConfigStack() { return (List<ModifyProductConfigStackVO>)this.get("modify_product_config_stack"); }
	// }}}
	// {{{
	public void setNewFileReference(List<NewFileReferenceVO> value) { this.set("new_file_reference", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<NewFileReferenceVO> getNewFileReference() { return (List<NewFileReferenceVO>)this.get("new_file_reference"); }
	// }}}
	// {{{
	public void setNewAccountRel(List<NewAccountToAccountRelationshipVO> value) { this.set("new_account_rel", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<NewAccountToAccountRelationshipVO> getNewAccountRel() { return (List<NewAccountToAccountRelationshipVO>)this.get("new_account_rel"); }
	// }}}
	// {{{
	public void setLastName(String value) { this.set("last_name", (Object)value); }
 	public String getLastName() { return (String)this.get("last_name"); }
	// }}}
	// {{{
	public void setFirstName(String value) { this.set("first_name", (Object)value); }
 	public String getFirstName() { return (String)this.get("first_name"); }
	// }}}
	// {{{
	public void setLanguage(String value) { this.set("language", (Object)value); }
 	public String getLanguage() { return (String)this.get("language"); }
	// }}}
	// {{{
	public void setPrimaryCurrencyCode(String value) { this.set("primary_currency_code", (Object)value); }
 	public String getPrimaryCurrencyCode() { return (String)this.get("primary_currency_code"); }
	// }}}
	// {{{
	public void setCitizenship(String value) { this.set("citizenship", (Object)value); }
 	public String getCitizenship() { return (String)this.get("citizenship"); }
	// }}}
	// {{{
	public void setTimezone(String value) { this.set("timezone", (Object)value); }
 	public String getTimezone() { return (String)this.get("timezone"); }
	// }}}
	// {{{
	public void setSubprimeCategory(Long value) { this.set("subprime_category", (Object)value); }
 	public Long getSubprimeCategory() { return (Long)this.get("subprime_category"); }
	// }}}
	// {{{
	public void setSubprimeSubcategory(Long value) { this.set("subprime_subcategory", (Object)value); }
 	public Long getSubprimeSubcategory() { return (Long)this.get("subprime_subcategory"); }
	// }}}
	// {{{
	public void setFraudScore(Long value) { this.set("fraud_score", (Object)value); }
 	public Long getFraudScore() { return (Long)this.get("fraud_score"); }
	// }}}
	// {{{
	public void setIsLocked(Boolean value) { this.set("is_locked", (Object)value); }
 	public Boolean getIsLocked() { return (Boolean)this.get("is_locked"); }
	// }}}
	// {{{
	public void setIsInactive(Boolean value) { this.set("is_inactive", (Object)value); }
 	public Boolean getIsInactive() { return (Boolean)this.get("is_inactive"); }
	// }}}
	// {{{
	public void setIsVerified(Boolean value) { this.set("is_verified", (Object)value); }
 	public Boolean getIsVerified() { return (Boolean)this.get("is_verified"); }
	// }}}
	// {{{
	public void setIsRestricted(Boolean value) { this.set("is_restricted", (Object)value); }
 	public Boolean getIsRestricted() { return (Boolean)this.get("is_restricted"); }
	// }}}
	// {{{
	public void setIsHighRestricted(Boolean value) { this.set("is_high_restricted", (Object)value); }
 	public Boolean getIsHighRestricted() { return (Boolean)this.get("is_high_restricted"); }
	// }}}
	// {{{
	public void setIsSanctionListLocked(Boolean value) { this.set("is_sanction_list_locked", (Object)value); }
 	public Boolean getIsSanctionListLocked() { return (Boolean)this.get("is_sanction_list_locked"); }
	// }}}
	// {{{
	public void setIsCommercialEntity(Boolean value) { this.set("is_commercial_entity", (Object)value); }
 	public Boolean getIsCommercialEntity() { return (Boolean)this.get("is_commercial_entity"); }
	// }}}
	// {{{
	public void setSetFlags(List<UserFlagsVO> value) { this.set("set_flags", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<UserFlagsVO> getSetFlags() { return (List<UserFlagsVO>)this.get("set_flags"); }
	// }}}
	// {{{
	public void setPublicCredentials(List<NewPublicCredentialVO> value) { this.set("public_credentials", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<NewPublicCredentialVO> getPublicCredentials() { return (List<NewPublicCredentialVO>)this.get("public_credentials"); }
	// }}}
}