/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AddressVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.user;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
  * 
   */

public class NewAddressVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((6172*6172)<<32)/*<-NewAddressVO*/+
         		36620/*<-type*/*37752/*<-char*/+
         		53689/*<-addressee_name*/*18443/*<-String*/+
         		3064/*<-street_number*/*18443/*<-String*/+
         		28110/*<-street_name*/*18443/*<-String*/+
         		33146/*<-street_type*/*18443/*<-String*/+
         		58854/*<-address1*/*18443/*<-String*/+
         		58853/*<-address2*/*18443/*<-String*/+
         		39237/*<-city*/*18443/*<-String*/+
         		49691/*<-state*/*18443/*<-String*/+
         		55072/*<-zip*/*18443/*<-String*/+
         		18370/*<-iso_country*/*18443/*<-String*/+
         		59512/*<-make_primary*/*15044/*<-bool*/+
         		20816/*<-is_po_box*/*15044/*<-bool*/+
         		13544/*<-is_partial_location*/*15044/*<-bool*/+
         		44410/*<-normalization_status*/*18443/*<-String*/+
         		18760/*<-is_hidden*/*15044/*<-bool*/+
         		50872/*<-is_not_counted_against_quota*/*15044/*<-bool*/+
         		16692/*<-postal_confirmation_status*/*18443/*<-String*/+
         		15208/*<-postal_confirmation_authority*/*18443/*<-String*/+
         		56803/*<-confirmation_status_for_relationship*/*18443/*<-String*/+
         		15925/*<-confirmation_authority_for_relationship*/*18443/*<-String*/+
         		13359/*<-tags*/*47/*<-repeating*/*18443/*<-String*/+
         		29535/*<-authority_code*/*62361/*<-sint8*/+
         		3252/*<-confirmation_status*/*62361/*<-sint8*/+
         		21104/*<-confirmation_style*/*62361/*<-sint8*/+
         		35316/*<-make_default_billing*/*15044/*<-bool*/+
         		45890/*<-make_business*/*15044/*<-bool*/+
         		56798/*<-is_invalid*/*15044/*<-bool*/;
 
	public NewAddressVO() {
		super("User::NewAddressVO", TYPE_SIGNATURE);

 		addFieldQualifier("type","cpp_gen","define_legacy");
 
		set("type", null, "char");
 
		set("addressee_name", null, "String");
 
		set("street_number", null, "String");
 
		set("street_name", null, "String");
 
		set("street_type", null, "String");
 
		set("address1", null, "String");
 
		set("address2", null, "String");
 
		set("city", null, "String");
 
		set("state", null, "String");
 
		set("zip", null, "String");
 
		set("iso_country", null, "String");
 
		set("make_primary", null, "bool");
 
		set("is_po_box", null, "bool");
 
		set("is_partial_location", null, "bool");
 
		set("normalization_status", null, "String");
 
		set("is_hidden", null, "bool");
 
		set("is_not_counted_against_quota", null, "bool");
 
		set("postal_confirmation_status", null, "String");
 
		set("postal_confirmation_authority", null, "String");
 
		set("confirmation_status_for_relationship", null, "String");
 
		set("confirmation_authority_for_relationship", null, "String");
 
		set("tags", null, "List<String>");
 
		set("authority_code", null, "sint8");
 		addFieldQualifier("confirmation_status","cpp_gen","define_legacy");
 
		set("confirmation_status", null, "sint8");
 		addFieldQualifier("confirmation_style","cpp_gen","define_legacy");
 
		set("confirmation_style", null, "sint8");
 
		set("make_default_billing", null, "bool");
 
		set("make_business", null, "bool");
 
		set("is_invalid", null, "bool");
	}

	// {{{
	public void setType(Byte value) { this.set("type", (Object)value); }
 	public Byte getType() { return (Byte)this.get("type"); }
	// }}}
	// {{{
	public void setAddresseeName(String value) { this.set("addressee_name", (Object)value); }
 	public String getAddresseeName() { return (String)this.get("addressee_name"); }
	// }}}
	// {{{
	public void setStreetNumber(String value) { this.set("street_number", (Object)value); }
 	public String getStreetNumber() { return (String)this.get("street_number"); }
	// }}}
	// {{{
	public void setStreetName(String value) { this.set("street_name", (Object)value); }
 	public String getStreetName() { return (String)this.get("street_name"); }
	// }}}
	// {{{
	public void setStreetType(String value) { this.set("street_type", (Object)value); }
 	public String getStreetType() { return (String)this.get("street_type"); }
	// }}}
	// {{{
	public void setAddress1(String value) { this.set("address1", (Object)value); }
 	public String getAddress1() { return (String)this.get("address1"); }
	// }}}
	// {{{
	public void setAddress2(String value) { this.set("address2", (Object)value); }
 	public String getAddress2() { return (String)this.get("address2"); }
	// }}}
	// {{{
	public void setCity(String value) { this.set("city", (Object)value); }
 	public String getCity() { return (String)this.get("city"); }
	// }}}
	// {{{
	public void setState(String value) { this.set("state", (Object)value); }
 	public String getState() { return (String)this.get("state"); }
	// }}}
	// {{{
	public void setZip(String value) { this.set("zip", (Object)value); }
 	public String getZip() { return (String)this.get("zip"); }
	// }}}
	// {{{
	public void setIsoCountry(String value) { this.set("iso_country", (Object)value); }
 	public String getIsoCountry() { return (String)this.get("iso_country"); }
	// }}}
	// {{{
	public void setMakePrimary(Boolean value) { this.set("make_primary", (Object)value); }
 	public Boolean getMakePrimary() { return (Boolean)this.get("make_primary"); }
	// }}}
	// {{{
	public void setIsPoBox(Boolean value) { this.set("is_po_box", (Object)value); }
 	public Boolean getIsPoBox() { return (Boolean)this.get("is_po_box"); }
	// }}}
	// {{{
	public void setIsPartialLocation(Boolean value) { this.set("is_partial_location", (Object)value); }
 	public Boolean getIsPartialLocation() { return (Boolean)this.get("is_partial_location"); }
	// }}}
	// {{{
	public void setNormalizationStatus(String value) { this.set("normalization_status", (Object)value); }
 	public String getNormalizationStatus() { return (String)this.get("normalization_status"); }
	// }}}
	// {{{
	public void setIsHidden(Boolean value) { this.set("is_hidden", (Object)value); }
 	public Boolean getIsHidden() { return (Boolean)this.get("is_hidden"); }
	// }}}
	// {{{
	public void setIsNotCountedAgainstQuota(Boolean value) { this.set("is_not_counted_against_quota", (Object)value); }
 	public Boolean getIsNotCountedAgainstQuota() { return (Boolean)this.get("is_not_counted_against_quota"); }
	// }}}
	// {{{
	public void setPostalConfirmationStatus(String value) { this.set("postal_confirmation_status", (Object)value); }
 	public String getPostalConfirmationStatus() { return (String)this.get("postal_confirmation_status"); }
	// }}}
	// {{{
	public void setPostalConfirmationAuthority(String value) { this.set("postal_confirmation_authority", (Object)value); }
 	public String getPostalConfirmationAuthority() { return (String)this.get("postal_confirmation_authority"); }
	// }}}
	// {{{
	public void setConfirmationStatusForRelationship(String value) { this.set("confirmation_status_for_relationship", (Object)value); }
 	public String getConfirmationStatusForRelationship() { return (String)this.get("confirmation_status_for_relationship"); }
	// }}}
	// {{{
	public void setConfirmationAuthorityForRelationship(String value) { this.set("confirmation_authority_for_relationship", (Object)value); }
 	public String getConfirmationAuthorityForRelationship() { return (String)this.get("confirmation_authority_for_relationship"); }
	// }}}
	// {{{
	public void setTags(List<String> value) { this.set("tags", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<String> getTags() { return (List<String>)this.get("tags"); }
	// }}}
	// {{{
	public void setAuthorityCode(Byte value) { this.set("authority_code", (Object)value); }
 	public Byte getAuthorityCode() { return (Byte)this.get("authority_code"); }
	// }}}
	// {{{
	public void setConfirmationStatus(Byte value) { this.set("confirmation_status", (Object)value); }
 	public Byte getConfirmationStatus() { return (Byte)this.get("confirmation_status"); }
	// }}}
	// {{{
	public void setConfirmationStyle(Byte value) { this.set("confirmation_style", (Object)value); }
 	public Byte getConfirmationStyle() { return (Byte)this.get("confirmation_style"); }
	// }}}
	// {{{
	public void setMakeDefaultBilling(Boolean value) { this.set("make_default_billing", (Object)value); }
 	public Boolean getMakeDefaultBilling() { return (Boolean)this.get("make_default_billing"); }
	// }}}
	// {{{
	public void setMakeBusiness(Boolean value) { this.set("make_business", (Object)value); }
 	public Boolean getMakeBusiness() { return (Boolean)this.get("make_business"); }
	// }}}
	// {{{
	public void setIsInvalid(Boolean value) { this.set("is_invalid", (Object)value); }
 	public Boolean getIsInvalid() { return (Boolean)this.get("is_invalid"); }
	// }}}
}