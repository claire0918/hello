/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AccountVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.user;

import java.math.BigInteger;

  
public enum TypeOfAccount {
/***/
   	ANONYMOUS(new String("ANONYMS"), ""),
   	ANONYMOUS_PREMIER(new String("ANON_PRE"), "Deprecated"),
   	GUEST(new String("GUEST"), ""),
   	GUEST_PREMIER(new String("GUEST_PR"), "Deprecated"),
   	PERSONAL(new String("PERSONAL"), ""),
   	PREMIER(new String("PREMIER"), ""),
   	BUSINESS(new String("BUSINESS"), "");

	private final String value;
	private final String desc;

	private TypeOfAccount(String value, String desc) {
		this.value = value;
		this.desc  = desc;
	}

	public String getValue() {
		return value;
	}

	public String getDesc() {
		return desc;
	}
}
