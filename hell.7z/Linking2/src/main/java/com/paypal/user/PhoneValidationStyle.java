/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/PhoneVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:40 2012 */

package com.paypal.user;

import java.math.BigInteger;

  
public enum PhoneValidationStyle {
/**
			*** DEPRECATED ***
		*/
   	NONE(new Byte("0"), "should always be paired with validation status NONE."),
   	AUTHENTIFY(new Byte("111"), ""),
   	MANUAL(new Byte("112"), ""),
   	SMS(new Byte("113"), ""),
   	SMS_REPLY(new Byte("114"), "We sent them an SMS, they responded to it."),
   	CARRIER(new Byte("115"), "The mobile provider (e.g. Verizon) confirmed the relationship."),
   	ADMIN(new Byte("116"), "Relationship status is known by the CSR (Admin) process. Typically, the person is talking on the phone to the agent, and the IVR system knows the phone number and the agent confirms the person's identity.");

	private final Byte value;
	private final String desc;

	private PhoneValidationStyle(Byte value, String desc) {
		this.value = value;
		this.desc  = desc;
	}

	public Byte getValue() {
		return value;
	}

	public String getDesc() {
		return desc;
	}
}
