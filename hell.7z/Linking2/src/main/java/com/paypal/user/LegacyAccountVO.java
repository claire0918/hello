/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/LegacyAccountVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:40 2012 */

package com.paypal.user;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
  * 
   */

public class LegacyAccountVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((54243*54243)<<32)/*<-LegacyAccountVO*/+
         		7701/*<-account_vo*/*AccountVO.TYPE_SIGNATURE/*<-AccountVO*/+
         		37229/*<-account_risk_vo*/*AccountRiskVO.TYPE_SIGNATURE/*<-AccountRiskVO*/+
         		30900/*<-account_fin_vo*/*AccountFinancialInstVO.TYPE_SIGNATURE/*<-AccountFinancialInstVO*/+
         		8516/*<-account_limits_vo*/*AccountLimitsCountersVO.TYPE_SIGNATURE/*<-AccountLimitsCountersVO*/+
         		32595/*<-account_unmapped_vo*/*AccountUnmappedVO.TYPE_SIGNATURE/*<-AccountUnmappedVO*/;
 
	public LegacyAccountVO() {
		super("User::LegacyAccountVO", TYPE_SIGNATURE);

 
		set("account_vo", null, "User::AccountVO");
 
		set("account_risk_vo", null, "User::AccountRiskVO");
 
		set("account_fin_vo", null, "User::AccountFinancialInstVO");
 
		set("account_limits_vo", null, "User::AccountLimitsCountersVO");
 
		set("account_unmapped_vo", null, "User::AccountUnmappedVO");
	}

	// {{{
	public void setAccountVo(AccountVO value) { this.set("account_vo", (Object)value); }
 	public AccountVO getAccountVo() { return (AccountVO)this.get("account_vo"); }
	// }}}
	// {{{
	public void setAccountRiskVo(AccountRiskVO value) { this.set("account_risk_vo", (Object)value); }
 	public AccountRiskVO getAccountRiskVo() { return (AccountRiskVO)this.get("account_risk_vo"); }
	// }}}
	// {{{
	public void setAccountFinVo(AccountFinancialInstVO value) { this.set("account_fin_vo", (Object)value); }
 	public AccountFinancialInstVO getAccountFinVo() { return (AccountFinancialInstVO)this.get("account_fin_vo"); }
	// }}}
	// {{{
	public void setAccountLimitsVo(AccountLimitsCountersVO value) { this.set("account_limits_vo", (Object)value); }
 	public AccountLimitsCountersVO getAccountLimitsVo() { return (AccountLimitsCountersVO)this.get("account_limits_vo"); }
	// }}}
	// {{{
	public void setAccountUnmappedVo(AccountUnmappedVO value) { this.set("account_unmapped_vo", (Object)value); }
 	public AccountUnmappedVO getAccountUnmappedVo() { return (AccountUnmappedVO)this.get("account_unmapped_vo"); }
	// }}}
}