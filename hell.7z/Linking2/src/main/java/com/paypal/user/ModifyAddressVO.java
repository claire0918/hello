/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AddressVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.user;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
  * 
   */

public class ModifyAddressVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((3950*3950)<<32)/*<-ModifyAddressVO*/+
         		59048/*<-address_id*/*46168/*<-ullong*/+
         		20507/*<-make_inactive*/*15044/*<-bool*/+
         		59512/*<-make_primary*/*15044/*<-bool*/+
         		46753/*<-add_tags*/*47/*<-repeating*/*18443/*<-String*/+
         		41076/*<-remove_tags*/*47/*<-repeating*/*18443/*<-String*/+
         		16692/*<-postal_confirmation_status*/*18443/*<-String*/+
         		15208/*<-postal_confirmation_authority*/*18443/*<-String*/+
         		56803/*<-confirmation_status_for_relationship*/*18443/*<-String*/+
         		15925/*<-confirmation_authority_for_relationship*/*18443/*<-String*/;
 
	public ModifyAddressVO() {
		super("User::ModifyAddressVO", TYPE_SIGNATURE);

 		addFieldQualifier("address_id","required","true");
 
		set("address_id", null, "ullong");
 
		set("make_inactive", null, "bool");
 
		set("make_primary", null, "bool");
 
		set("add_tags", null, "List<String>");
 
		set("remove_tags", null, "List<String>");
 
		set("postal_confirmation_status", null, "String");
 
		set("postal_confirmation_authority", null, "String");
 
		set("confirmation_status_for_relationship", null, "String");
 
		set("confirmation_authority_for_relationship", null, "String");
	}

	// {{{
	public void setAddressId(BigInteger value) { this.set("address_id", (Object)value); }
 	public BigInteger getAddressId() { return (BigInteger)this.get("address_id"); }
	// }}}
	// {{{
	public void setMakeInactive(Boolean value) { this.set("make_inactive", (Object)value); }
 	public Boolean getMakeInactive() { return (Boolean)this.get("make_inactive"); }
	// }}}
	// {{{
	public void setMakePrimary(Boolean value) { this.set("make_primary", (Object)value); }
 	public Boolean getMakePrimary() { return (Boolean)this.get("make_primary"); }
	// }}}
	// {{{
	public void setAddTags(List<String> value) { this.set("add_tags", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<String> getAddTags() { return (List<String>)this.get("add_tags"); }
	// }}}
	// {{{
	public void setRemoveTags(List<String> value) { this.set("remove_tags", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<String> getRemoveTags() { return (List<String>)this.get("remove_tags"); }
	// }}}
	// {{{
	public void setPostalConfirmationStatus(String value) { this.set("postal_confirmation_status", (Object)value); }
 	public String getPostalConfirmationStatus() { return (String)this.get("postal_confirmation_status"); }
	// }}}
	// {{{
	public void setPostalConfirmationAuthority(String value) { this.set("postal_confirmation_authority", (Object)value); }
 	public String getPostalConfirmationAuthority() { return (String)this.get("postal_confirmation_authority"); }
	// }}}
	// {{{
	public void setConfirmationStatusForRelationship(String value) { this.set("confirmation_status_for_relationship", (Object)value); }
 	public String getConfirmationStatusForRelationship() { return (String)this.get("confirmation_status_for_relationship"); }
	// }}}
	// {{{
	public void setConfirmationAuthorityForRelationship(String value) { this.set("confirmation_authority_for_relationship", (Object)value); }
 	public String getConfirmationAuthorityForRelationship() { return (String)this.get("confirmation_authority_for_relationship"); }
	// }}}
}