/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/PhoneVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:40 2012 */

package com.paypal.user;

import java.math.BigInteger;

  
public enum PartyPhoneConfirmationStatus {
/***/
   	NONE(new String("NONE"), "should always be paired with validation style NONE."),
   	VALID(new String("VALID"), "aka: Confirmed"),
   	INVALID(new String("INVALID"), "Explicitly known to be invalid, not just unconfirmed.");

	private final String value;
	private final String desc;

	private PartyPhoneConfirmationStatus(String value, String desc) {
		this.value = value;
		this.desc  = desc;
	}

	public String getValue() {
		return value;
	}

	public String getDesc() {
		return desc;
	}
}
