/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/PhoneVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:40 2012 */

package com.paypal.user;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
  * 
   */

public class PhoneLoadVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((46471*46471)<<32)/*<-PhoneLoadVO*/+
         		5695/*<-phone_id*/*47/*<-repeating*/*46168/*<-ullong*/+
         		16570/*<-phone_number*/*18443/*<-String*/+
         		23729/*<-country_code*/*18443/*<-String*/+
         		8002/*<-extension*/*18443/*<-String*/+
         		56647/*<-party_criteria*/*PartyCriteriaVO.TYPE_SIGNATURE/*<-PartyCriteriaVO*/;
 
	public PhoneLoadVO() {
		super("User::PhoneLoadVO", TYPE_SIGNATURE);

 
		set("phone_id", null, "List<ullong>");
 
		set("phone_number", null, "String");
 
		set("country_code", null, "String");
 
		set("extension", null, "String");
 
		set("party_criteria", null, "User::PartyCriteriaVO");
	}

	// {{{
	public void setPhoneId(List<BigInteger> value) { this.set("phone_id", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<BigInteger> getPhoneId() { return (List<BigInteger>)this.get("phone_id"); }
	// }}}
	// {{{
	public void setPhoneNumber(String value) { this.set("phone_number", (Object)value); }
 	public String getPhoneNumber() { return (String)this.get("phone_number"); }
	// }}}
	// {{{
	public void setCountryCode(String value) { this.set("country_code", (Object)value); }
 	public String getCountryCode() { return (String)this.get("country_code"); }
	// }}}
	// {{{
	public void setExtension(String value) { this.set("extension", (Object)value); }
 	public String getExtension() { return (String)this.get("extension"); }
	// }}}
	// {{{
	public void setPartyCriteria(PartyCriteriaVO value) { this.set("party_criteria", (Object)value); }
 	public PartyCriteriaVO getPartyCriteria() { return (PartyCriteriaVO)this.get("party_criteria"); }
	// }}}
}