/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/FileReferenceVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:40 2012 */

package com.paypal.user;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
  * 
   */

public class NewFileReferenceVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((42371*42371)<<32)/*<-NewFileReferenceVO*/+
         		25999/*<-file_category*/*18443/*<-String*/+
         		33580/*<-file_reference*/*18443/*<-String*/+
         		59512/*<-make_primary*/*15044/*<-bool*/+
         		13359/*<-tags*/*47/*<-repeating*/*18443/*<-String*/;
 
	public NewFileReferenceVO() {
		super("User::NewFileReferenceVO", TYPE_SIGNATURE);

 		addFieldQualifier("file_category","required","true");
 
		set("file_category", null, "String");
 		addFieldQualifier("file_reference","required","true");
 
		set("file_reference", null, "String");
 
		set("make_primary", null, "bool");
 
		set("tags", null, "List<String>");
	}

	// {{{
	public void setFileCategory(String value) { this.set("file_category", (Object)value); }
 	public String getFileCategory() { return (String)this.get("file_category"); }
	// }}}
	// {{{
	public void setFileReference(String value) { this.set("file_reference", (Object)value); }
 	public String getFileReference() { return (String)this.get("file_reference"); }
	// }}}
	// {{{
	public void setMakePrimary(Boolean value) { this.set("make_primary", (Object)value); }
 	public Boolean getMakePrimary() { return (Boolean)this.get("make_primary"); }
	// }}}
	// {{{
	public void setTags(List<String> value) { this.set("tags", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<String> getTags() { return (List<String>)this.get("tags"); }
	// }}}
}