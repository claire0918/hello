/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AccessPointVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.user;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
  * 
   */

public class AccountAccessPrivilege extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((52823*52823)<<32)/*<-AccountAccessPrivilege*/+
         		62145/*<-account_number*/*46168/*<-ullong*/+
         		9632/*<-access_class*/*37752/*<-char*/+
         		55937/*<-privileges*/*47/*<-repeating*/*18443/*<-String*/;
 
	public AccountAccessPrivilege() {
		super("User::AccountAccessPrivilege", TYPE_SIGNATURE);

 
		set("account_number", null, "ullong");
 
		set("access_class", null, "char");
 
		set("privileges", null, "List<String>");
	}

	// {{{
	public void setAccountNumber(BigInteger value) { this.set("account_number", (Object)value); }
 	public BigInteger getAccountNumber() { return (BigInteger)this.get("account_number"); }
	// }}}
	// {{{
	public void setAccessClass(Byte value) { this.set("access_class", (Object)value); }
 	public Byte getAccessClass() { return (Byte)this.get("access_class"); }
	// }}}
	// {{{
	public void setPrivileges(List<String> value) { this.set("privileges", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<String> getPrivileges() { return (List<String>)this.get("privileges"); }
	// }}}
}