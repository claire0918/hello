/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/ProductConfiguration.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:40 2012 */

package com.paypal.user;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
  * 
   */

public class ModifyProductConfigStackVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((22880*22880)<<32)/*<-ModifyProductConfigStackVO*/+
         		19635/*<-layer_id*/*46168/*<-ullong*/+
         		26495/*<-common_layer_name*/*18443/*<-String*/+
         		2903/*<-new_custom_layer*/*ModifyProductConfigCustomLayerVO.TYPE_SIGNATURE/*<-ModifyProductConfigCustomLayerVO*/+
         		20507/*<-make_inactive*/*15044/*<-bool*/+
         		5847/*<-move_above_layer_id*/*46168/*<-ullong*/+
         		6028/*<-move_below_layer_id*/*46168/*<-ullong*/;
 
	public ModifyProductConfigStackVO() {
		super("User::ModifyProductConfigStackVO", TYPE_SIGNATURE);

 
		set("layer_id", null, "ullong");
 
		set("common_layer_name", null, "String");
 
		set("new_custom_layer", null, "User::ModifyProductConfigCustomLayerVO");
 
		set("make_inactive", null, "bool");
 
		set("move_above_layer_id", null, "ullong");
 
		set("move_below_layer_id", null, "ullong");
	}

	// {{{
	public void setLayerId(BigInteger value) { this.set("layer_id", (Object)value); }
 	public BigInteger getLayerId() { return (BigInteger)this.get("layer_id"); }
	// }}}
	// {{{
	public void setCommonLayerName(String value) { this.set("common_layer_name", (Object)value); }
 	public String getCommonLayerName() { return (String)this.get("common_layer_name"); }
	// }}}
	// {{{
	public void setNewCustomLayer(ModifyProductConfigCustomLayerVO value) { this.set("new_custom_layer", (Object)value); }
 	public ModifyProductConfigCustomLayerVO getNewCustomLayer() { return (ModifyProductConfigCustomLayerVO)this.get("new_custom_layer"); }
	// }}}
	// {{{
	public void setMakeInactive(Boolean value) { this.set("make_inactive", (Object)value); }
 	public Boolean getMakeInactive() { return (Boolean)this.get("make_inactive"); }
	// }}}
	// {{{
	public void setMoveAboveLayerId(BigInteger value) { this.set("move_above_layer_id", (Object)value); }
 	public BigInteger getMoveAboveLayerId() { return (BigInteger)this.get("move_above_layer_id"); }
	// }}}
	// {{{
	public void setMoveBelowLayerId(BigInteger value) { this.set("move_below_layer_id", (Object)value); }
 	public BigInteger getMoveBelowLayerId() { return (BigInteger)this.get("move_below_layer_id"); }
	// }}}
}