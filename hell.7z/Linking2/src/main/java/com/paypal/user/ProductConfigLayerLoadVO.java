/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/ProductConfiguration.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:40 2012 */

package com.paypal.user;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
  * 
   */

public class ProductConfigLayerLoadVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((3873*3873)<<32)/*<-ProductConfigLayerLoadVO*/+
         		47350/*<-common_names_to_load*/*47/*<-repeating*/*18443/*<-String*/+
         		34276/*<-common_groups_to_load*/*47/*<-repeating*/*18443/*<-String*/+
         		3306/*<-layer_ids_to_load*/*47/*<-repeating*/*46168/*<-ullong*/;
 
	public ProductConfigLayerLoadVO() {
		super("User::ProductConfigLayerLoadVO", TYPE_SIGNATURE);

 
		set("common_names_to_load", null, "List<String>");
 
		set("common_groups_to_load", null, "List<String>");
 
		set("layer_ids_to_load", null, "List<ullong>");
	}

	// {{{
	public void setCommonNamesToLoad(List<String> value) { this.set("common_names_to_load", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<String> getCommonNamesToLoad() { return (List<String>)this.get("common_names_to_load"); }
	// }}}
	// {{{
	public void setCommonGroupsToLoad(List<String> value) { this.set("common_groups_to_load", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<String> getCommonGroupsToLoad() { return (List<String>)this.get("common_groups_to_load"); }
	// }}}
	// {{{
	public void setLayerIdsToLoad(List<BigInteger> value) { this.set("layer_ids_to_load", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<BigInteger> getLayerIdsToLoad() { return (List<BigInteger>)this.get("layer_ids_to_load"); }
	// }}}
}