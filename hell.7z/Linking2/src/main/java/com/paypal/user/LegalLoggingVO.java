/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/LegalLoggingVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:40 2012 */

package com.paypal.user;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
  * 
   */

public class LegalLoggingVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((1349*1349)<<32)/*<-LegalLoggingVO*/+
         		3355/*<-id*/*46168/*<-ullong*/+
         		62145/*<-account_number*/*46168/*<-ullong*/+
         		36620/*<-type*/*62361/*<-sint8*/+
         		32983/*<-major_version_number*/*33490/*<-ulong*/+
         		6342/*<-minor_version_number*/*33490/*<-ulong*/+
         		21456/*<-time_accepted*/*33490/*<-ulong*/+
         		63436/*<-time_last_updated*/*33490/*<-ulong*/+
         		10813/*<-declined_upgrade*/*15044/*<-bool*/+
         		22150/*<-is_restricted*/*15044/*<-bool*/;
 
	public LegalLoggingVO() {
		super("User::LegalLoggingVO", TYPE_SIGNATURE);

 
		set("id", null, "ullong");
 
		set("account_number", null, "ullong");
 		addFieldQualifier("type","cpp_gen","define_legacy");
 
		set("type", null, "sint8");
 
		set("major_version_number", null, "ulong");
 
		set("minor_version_number", null, "ulong");
 
		set("time_accepted", null, "ulong");
 
		set("time_last_updated", null, "ulong");
 
		set("declined_upgrade", null, "bool");
 
		set("is_restricted", null, "bool");
	}

	// {{{
	public void setId(BigInteger value) { this.set("id", (Object)value); }
 	public BigInteger getId() { return (BigInteger)this.get("id"); }
	// }}}
	// {{{
	public void setAccountNumber(BigInteger value) { this.set("account_number", (Object)value); }
 	public BigInteger getAccountNumber() { return (BigInteger)this.get("account_number"); }
	// }}}
	// {{{
	public void setType(Byte value) { this.set("type", (Object)value); }
 	public Byte getType() { return (Byte)this.get("type"); }
	// }}}
	// {{{
	public void setMajorVersionNumber(Long value) { this.set("major_version_number", (Object)value); }
 	public Long getMajorVersionNumber() { return (Long)this.get("major_version_number"); }
	// }}}
	// {{{
	public void setMinorVersionNumber(Long value) { this.set("minor_version_number", (Object)value); }
 	public Long getMinorVersionNumber() { return (Long)this.get("minor_version_number"); }
	// }}}
	// {{{
	public void setTimeAccepted(Long value) { this.set("time_accepted", (Object)value); }
 	public Long getTimeAccepted() { return (Long)this.get("time_accepted"); }
	// }}}
	// {{{
	public void setTimeLastUpdated(Long value) { this.set("time_last_updated", (Object)value); }
 	public Long getTimeLastUpdated() { return (Long)this.get("time_last_updated"); }
	// }}}
	// {{{
	public void setDeclinedUpgrade(Boolean value) { this.set("declined_upgrade", (Object)value); }
 	public Boolean getDeclinedUpgrade() { return (Boolean)this.get("declined_upgrade"); }
	// }}}
	// {{{
	public void setIsRestricted(Boolean value) { this.set("is_restricted", (Object)value); }
 	public Boolean getIsRestricted() { return (Boolean)this.get("is_restricted"); }
	// }}}
}