/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AccessPointVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.user;

import java.math.BigInteger;

  
public enum AccessClassType {
/***/
   	LIMITED(new Byte("76"), "No access to the account except what is listed in the privileges"),
   	FULL(new Byte("70"), "Full access to the account, privileges are ignored");

	private final Byte value;
	private final String desc;

	private AccessClassType(Byte value, String desc) {
		this.value = value;
		this.desc  = desc;
	}

	public Byte getValue() {
		return value;
	}

	public String getDesc() {
		return desc;
	}
}
