/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/ProductConfiguration.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:40 2012 */

package com.paypal.user;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
  * 
   */

public class ProductConfigStackVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((57506*57506)<<32)/*<-ProductConfigStackVO*/+
         		24179/*<-entity_type*/*18443/*<-String*/+
         		56620/*<-entity_id*/*46168/*<-ullong*/+
         		53400/*<-layers*/*47/*<-repeating*/*ProductConfigLayerVO.TYPE_SIGNATURE/*<-ProductConfigLayerVO*/;
 
	public ProductConfigStackVO() {
		super("User::ProductConfigStackVO", TYPE_SIGNATURE);

 		addFieldQualifier("entity_type","required","true");
 
		set("entity_type", null, "String");
 		addFieldQualifier("entity_id","required","true");
 
		set("entity_id", null, "ullong");
 		addFieldQualifier("layers","required","true");
 
		set("layers", null, "List<User::ProductConfigLayerVO>");
	}

	// {{{
	public void setEntityType(String value) { this.set("entity_type", (Object)value); }
 	public String getEntityType() { return (String)this.get("entity_type"); }
	// }}}
	// {{{
	public void setEntityId(BigInteger value) { this.set("entity_id", (Object)value); }
 	public BigInteger getEntityId() { return (BigInteger)this.get("entity_id"); }
	// }}}
	// {{{
	public void setLayers(List<ProductConfigLayerVO> value) { this.set("layers", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<ProductConfigLayerVO> getLayers() { return (List<ProductConfigLayerVO>)this.get("layers"); }
	// }}}
}