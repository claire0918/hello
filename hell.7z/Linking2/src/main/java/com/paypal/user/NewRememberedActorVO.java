/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/RememberedActorVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:40 2012 */

package com.paypal.user;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
  * 
   */

public class NewRememberedActorVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((24231*24231)<<32)/*<-NewRememberedActorVO*/+
         		33339/*<-actor_id*/*46168/*<-ullong*/+
         		62145/*<-account_number*/*46168/*<-ullong*/+
         		62367/*<-group*/*18443/*<-String*/+
         		49051/*<-tag*/*18443/*<-String*/+
         		22809/*<-time_created*/*33490/*<-ulong*/+
         		5095/*<-expiration_time*/*33490/*<-ulong*/;
 
	public NewRememberedActorVO() {
		super("User::NewRememberedActorVO", TYPE_SIGNATURE);

 		addFieldQualifier("actor_id","required","true");
 
		set("actor_id", null, "ullong");
 
		set("account_number", null, "ullong");
 		addFieldQualifier("group","required","true");
 
		set("group", null, "String");
 
		set("tag", null, "String");
 
		set("time_created", null, "ulong");
 		addFieldQualifier("expiration_time","required","true");
 
		set("expiration_time", null, "ulong");
	}

	// {{{
	public void setActorId(BigInteger value) { this.set("actor_id", (Object)value); }
 	public BigInteger getActorId() { return (BigInteger)this.get("actor_id"); }
	// }}}
	// {{{
	public void setAccountNumber(BigInteger value) { this.set("account_number", (Object)value); }
 	public BigInteger getAccountNumber() { return (BigInteger)this.get("account_number"); }
	// }}}
	// {{{
	public void setGroup(String value) { this.set("group", (Object)value); }
 	public String getGroup() { return (String)this.get("group"); }
	// }}}
	// {{{
	public void setTag(String value) { this.set("tag", (Object)value); }
 	public String getTag() { return (String)this.get("tag"); }
	// }}}
	// {{{
	public void setTimeCreated(Long value) { this.set("time_created", (Object)value); }
 	public Long getTimeCreated() { return (Long)this.get("time_created"); }
	// }}}
	// {{{
	public void setExpirationTime(Long value) { this.set("expiration_time", (Object)value); }
 	public Long getExpirationTime() { return (Long)this.get("expiration_time"); }
	// }}}
}