/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/ActorInfoVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.common;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
  * 
   */

public class ActorInfoVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((12143*12143)<<32)/*<-ActorInfoVO*/+
         		36708/*<-actor_type*/*62361/*<-sint8*/+
         		11229/*<-actor_auth_type*/*37752/*<-char*/+
         		15863/*<-actor_auth_credential*/*37752/*<-char*/+
         		19174/*<-actor_auth_level*/*37752/*<-char*/+
         		60054/*<-actor_account_number*/*46168/*<-ullong*/+
         		33339/*<-actor_id*/*46168/*<-ullong*/+
         		11160/*<-actor_session_id*/*18443/*<-String*/+
         		62832/*<-actor_ip_addr*/*18443/*<-String*/+
         		9181/*<-entry_point*/*18443/*<-String*/+
         		48200/*<-visitor_id*/*46168/*<-ullong*/+
         		38585/*<-guid*/*46168/*<-ullong*/+
         		49007/*<-token*/*34592/*<-Buffer*/+
         		59340/*<-token_type*/*62361/*<-sint8*/+
         		7260/*<-actor_risk_details*/*com.paypal.common.OpaqueDataElementVO.TYPE_SIGNATURE/*<-Common::OpaqueDataElementVO*/;
 
	public ActorInfoVO() {
		super("Common::ActorInfoVO", TYPE_SIGNATURE);

 
		set("actor_type", null, "sint8");
 
		set("actor_auth_type", null, "char");
 
		set("actor_auth_credential", null, "char");
 
		set("actor_auth_level", null, "char");
 
		set("actor_account_number", null, "ullong");
 
		set("actor_id", null, "ullong");
 
		set("actor_session_id", null, "String");
 
		set("actor_ip_addr", null, "String");
 
		set("entry_point", null, "String");
 
		set("visitor_id", null, "ullong");
 
		set("guid", null, "ullong");
 
		set("token", null, "Buffer");
 
		set("token_type", null, "sint8");
 
		set("actor_risk_details", null, "Common::OpaqueDataElementVO");
	}

	// {{{
	public void setActorType(Byte value) { this.set("actor_type", (Object)value); }
 	public Byte getActorType() { return (Byte)this.get("actor_type"); }
	// }}}
	// {{{
	public void setActorAuthType(Byte value) { this.set("actor_auth_type", (Object)value); }
 	public Byte getActorAuthType() { return (Byte)this.get("actor_auth_type"); }
	// }}}
	// {{{
	public void setActorAuthCredential(Byte value) { this.set("actor_auth_credential", (Object)value); }
 	public Byte getActorAuthCredential() { return (Byte)this.get("actor_auth_credential"); }
	// }}}
	// {{{
	public void setActorAuthLevel(Byte value) { this.set("actor_auth_level", (Object)value); }
 	public Byte getActorAuthLevel() { return (Byte)this.get("actor_auth_level"); }
	// }}}
	// {{{
	public void setActorAccountNumber(BigInteger value) { this.set("actor_account_number", (Object)value); }
 	public BigInteger getActorAccountNumber() { return (BigInteger)this.get("actor_account_number"); }
	// }}}
	// {{{
	public void setActorId(BigInteger value) { this.set("actor_id", (Object)value); }
 	public BigInteger getActorId() { return (BigInteger)this.get("actor_id"); }
	// }}}
	// {{{
	public void setActorSessionId(String value) { this.set("actor_session_id", (Object)value); }
 	public String getActorSessionId() { return (String)this.get("actor_session_id"); }
	// }}}
	// {{{
	public void setActorIpAddr(String value) { this.set("actor_ip_addr", (Object)value); }
 	public String getActorIpAddr() { return (String)this.get("actor_ip_addr"); }
	// }}}
	// {{{
	public void setEntryPoint(String value) { this.set("entry_point", (Object)value); }
 	public String getEntryPoint() { return (String)this.get("entry_point"); }
	// }}}
	// {{{
	public void setVisitorId(BigInteger value) { this.set("visitor_id", (Object)value); }
 	public BigInteger getVisitorId() { return (BigInteger)this.get("visitor_id"); }
	// }}}
	// {{{
	public void setGuid(BigInteger value) { this.set("guid", (Object)value); }
 	public BigInteger getGuid() { return (BigInteger)this.get("guid"); }
	// }}}
	// {{{
	public void setToken(byte[] value) { this.set("token", (Object)value); }
 	public byte[] getToken() { return (byte[])this.get("token"); }
	// }}}
	// {{{
	public void setTokenType(Byte value) { this.set("token_type", (Object)value); }
 	public Byte getTokenType() { return (Byte)this.get("token_type"); }
	// }}}
	// {{{
	public void setActorRiskDetails(com.paypal.common.OpaqueDataElementVO value) { this.set("actor_risk_details", (Object)value); }
 	public com.paypal.common.OpaqueDataElementVO getActorRiskDetails() { return (com.paypal.common.OpaqueDataElementVO)this.get("actor_risk_details"); }
	// }}}
}