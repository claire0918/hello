/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/OpaqueDataElementVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:40 2012 */

package com.paypal.common;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
  * 
   */

public class OpaqueDataElementVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((63712*63712)<<32)/*<-OpaqueDataElementVO*/+
         		45661/*<-class_name*/*18443/*<-String*/+
         		52604/*<-serialization_form*/*37752/*<-char*/+
         		1962/*<-serialized_data*/*34592/*<-Buffer*/;
 
	public OpaqueDataElementVO() {
		super("Common::OpaqueDataElementVO", TYPE_SIGNATURE);

 		addFieldQualifier("class_name","optional","false");
 
		set("class_name", null, "String");
 		addFieldQualifier("serialization_form","optional","false");
 
		set("serialization_form", null, "char");
 		addFieldQualifier("serialized_data","optional","false");
 
		set("serialized_data", null, "Buffer");
	}

	// {{{
	public void setClassName(String value) { this.set("class_name", (Object)value); }
 	public String getClassName() { return (String)this.get("class_name"); }
	// }}}
	// {{{
	public void setSerializationForm(Byte value) { this.set("serialization_form", (Object)value); }
 	public Byte getSerializationForm() { return (Byte)this.get("serialization_form"); }
	// }}}
	// {{{
	public void setSerializedData(byte[] value) { this.set("serialized_data", (Object)value); }
 	public byte[] getSerializedData() { return (byte[])this.get("serialized_data"); }
	// }}}
}