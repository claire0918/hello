/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/CardPresentDefines.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:40 2012 */

package com.paypal.finsys;

import java.math.BigInteger;

  
public enum ManufacturerEnum {
/**
			Enumeration to provide information about the Manufacturer of the Device
		*/
   	MIURA(new String("Miura"), ""),
   	MAGTEK(new String("Magtek"), ""),
   	ROAM(new String("Roam"), ""),
   	UNKNOWN(new String("Unknown"), "");

	private final String value;
	private final String desc;

	private ManufacturerEnum(String value, String desc) {
		this.value = value;
		this.desc  = desc;
	}

	public String getValue() {
		return value;
	}

	public String getDesc() {
		return desc;
	}
}
