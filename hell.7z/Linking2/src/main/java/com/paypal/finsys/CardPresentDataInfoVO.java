/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/CardPresentDefines.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:40 2012 */

package com.paypal.finsys;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * Contains Enumerations for Card Present Data, Device Capability and Manufacturer
  * 
  * 04-02-2012
   * @author Nithila Govindaraju
  */

public class CardPresentDataInfoVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((28515*28515)<<32)/*<-CardPresentDataInfoVO*/+
         		35821/*<-card_present*/*18443/*<-String*/+
         		34712/*<-signature_present*/*15044/*<-bool*/+
         		26941/*<-pin_present*/*15044/*<-bool*/+
         		6121/*<-fallback_swipe*/*15044/*<-bool*/;
 
	public CardPresentDataInfoVO() {
		super("FinSys::CardPresentDataInfoVO", TYPE_SIGNATURE);

 
		set("card_present", null, "String");
 		addFieldQualifier("signature_present","default","false");
 
		set("signature_present", null, "bool");
 		addFieldQualifier("pin_present","default","false");
 
		set("pin_present", null, "bool");
 		addFieldQualifier("fallback_swipe","default","false");
 
		set("fallback_swipe", null, "bool");
	}

	// {{{
	public void setCardPresent(String value) { this.set("card_present", (Object)value); }
 	public String getCardPresent() { return (String)this.get("card_present"); }
	// }}}
	// {{{
	public void setSignaturePresent(Boolean value) { this.set("signature_present", (Object)value); }
 	public Boolean getSignaturePresent() { return (Boolean)this.get("signature_present"); }
	// }}}
	// {{{
	public void setPinPresent(Boolean value) { this.set("pin_present", (Object)value); }
 	public Boolean getPinPresent() { return (Boolean)this.get("pin_present"); }
	// }}}
	// {{{
	public void setFallbackSwipe(Boolean value) { this.set("fallback_swipe", (Object)value); }
 	public Boolean getFallbackSwipe() { return (Boolean)this.get("fallback_swipe"); }
	// }}}
}