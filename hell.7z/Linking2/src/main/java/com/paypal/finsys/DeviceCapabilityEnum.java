/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/CardPresentDefines.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:40 2012 */

package com.paypal.finsys;

import java.math.BigInteger;

  
public enum DeviceCapabilityEnum {
/**
			Enumeration to provide information about Capability of the device used during the transaction
		*/
   	SWIPE(new String("Swipe"), ""),
   	CHIP(new String("Chip"), ""),
   	MANUAL_KEY_ENTRY(new String("Key"), ""),
   	IMAGE(new String("Image"), ""),
   	UNKNOWN(new String("Unknown"), "");

	private final String value;
	private final String desc;

	private DeviceCapabilityEnum(String value, String desc) {
		this.value = value;
		this.desc  = desc;
	}

	public String getValue() {
		return value;
	}

	public String getDesc() {
		return desc;
	}
}
