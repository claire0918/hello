/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AdaptivePaymentCommonParams.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.adaptivepayment;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * Common header for all AdaptivePayment APIs
  * 
  * 2008-02-29
   * @author Rohit Sahney
  */

public class APInstitutionCustomer extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((28154*28154)<<32)/*<-APInstitutionCustomer*/+
         		20623/*<-institution_id*/*18443/*<-String*/+
         		35037/*<-first_name*/*18443/*<-String*/+
         		51561/*<-last_name*/*18443/*<-String*/+
         		17324/*<-display_name*/*18443/*<-String*/+
         		44870/*<-institution_customer_id*/*18443/*<-String*/+
         		23729/*<-country_code*/*18443/*<-String*/;
 
	public APInstitutionCustomer() {
		super("AdaptivePayment::APInstitutionCustomer", TYPE_SIGNATURE);

 		addFieldQualifier("institution_id","required","true");
 
		set("institution_id", null, "String");
 		addFieldQualifier("first_name","required","true");
 
		set("first_name", null, "String");
 		addFieldQualifier("last_name","required","true");
 
		set("last_name", null, "String");
 		addFieldQualifier("display_name","required","true");
 
		set("display_name", null, "String");
 		addFieldQualifier("institution_customer_id","required","true");
 
		set("institution_customer_id", null, "String");
 		addFieldQualifier("country_code","required","true");
 
		set("country_code", null, "String");
	}

	// {{{
	public void setInstitutionId(String value) { this.set("institution_id", (Object)value); }
 	public String getInstitutionId() { return (String)this.get("institution_id"); }
	// }}}
	// {{{
	public void setFirstName(String value) { this.set("first_name", (Object)value); }
 	public String getFirstName() { return (String)this.get("first_name"); }
	// }}}
	// {{{
	public void setLastName(String value) { this.set("last_name", (Object)value); }
 	public String getLastName() { return (String)this.get("last_name"); }
	// }}}
	// {{{
	public void setDisplayName(String value) { this.set("display_name", (Object)value); }
 	public String getDisplayName() { return (String)this.get("display_name"); }
	// }}}
	// {{{
	public void setInstitutionCustomerId(String value) { this.set("institution_customer_id", (Object)value); }
 	public String getInstitutionCustomerId() { return (String)this.get("institution_customer_id"); }
	// }}}
	// {{{
	public void setCountryCode(String value) { this.set("country_code", (Object)value); }
 	public String getCountryCode() { return (String)this.get("country_code"); }
	// }}}
}