/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AdaptivePaymentCommonParams.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.adaptivepayment;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * Common header for all AdaptivePayment APIs
  * 
  * 2008-02-29
   * @author Rohit Sahney
  */

public class APPaymentActivityVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((63443*63443)<<32)/*<-APPaymentActivityVO*/+
         		14046/*<-receiver_activity_list*/*47/*<-repeating*/*APReceiverActivity.TYPE_SIGNATURE/*<-APReceiverActivity*/+
         		9761/*<-payment_activity_id*/*46168/*<-ullong*/;
 
	public APPaymentActivityVO() {
		super("AdaptivePayment::APPaymentActivityVO", TYPE_SIGNATURE);

 
		set("receiver_activity_list", null, "List<AdaptivePayment::APReceiverActivity>");
 
		set("payment_activity_id", null, "ullong");
	}

	// {{{
	public void setReceiverActivityList(List<APReceiverActivity> value) { this.set("receiver_activity_list", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<APReceiverActivity> getReceiverActivityList() { return (List<APReceiverActivity>)this.get("receiver_activity_list"); }
	// }}}
	// {{{
	public void setPaymentActivityId(BigInteger value) { this.set("payment_activity_id", (Object)value); }
 	public BigInteger getPaymentActivityId() { return (BigInteger)this.get("payment_activity_id"); }
	// }}}
}