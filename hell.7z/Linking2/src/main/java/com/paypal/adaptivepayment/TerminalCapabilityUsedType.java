/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AdaptivePaymentCommonParams.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.adaptivepayment;

import java.math.BigInteger;

  
public enum TerminalCapabilityUsedType {
/***/
   	TERMINAL_UNKNOWN(new String("TERMINAL_UNKNOWN"), ""),
   	TERMINAL_NOT_USED(new String("TERMINAL_NOT_USED"), ""),
   	READ_MAGNETIC_STRIPE_CARD(new String("READ_MAGNETIC_STRIPE_CARD"), ""),
   	READ_IC_CARD(new String("READ_IC_CARD"), ""),
   	READ_CONTACTLESS_CHIP(new String("READ_CONTACTLESS_CHIP"), ""),
   	READ_CONTACTLESS_MAGNETIC_STRIPE_CARD(new String("READ_CONTACTLESS_MAGNETIC_STRIPE_CARD"), "");

	private final String value;
	private final String desc;

	private TerminalCapabilityUsedType(String value, String desc) {
		this.value = value;
		this.desc  = desc;
	}

	public String getValue() {
		return value;
	}

	public String getDesc() {
		return desc;
	}
}
