/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AdaptivePaymentCommonParams.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.adaptivepayment;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * Common header for all AdaptivePayment APIs
  * 
  * 2008-02-29
   * @author Rohit Sahney
  */

public class APFXInfo extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((5378*5378)<<32)/*<-APFXInfo*/+
         		62145/*<-account_number*/*46168/*<-ullong*/+
         		23729/*<-country_code*/*18443/*<-String*/+
         		59204/*<-fx_Type*/*18443/*<-String*/;
 
	public APFXInfo() {
		super("AdaptivePayment::APFXInfo", TYPE_SIGNATURE);

 
		set("account_number", null, "ullong");
 
		set("country_code", null, "String");
 
		set("fx_Type", null, "String");
	}

	// {{{
	public void setAccountNumber(BigInteger value) { this.set("account_number", (Object)value); }
 	public BigInteger getAccountNumber() { return (BigInteger)this.get("account_number"); }
	// }}}
	// {{{
	public void setCountryCode(String value) { this.set("country_code", (Object)value); }
 	public String getCountryCode() { return (String)this.get("country_code"); }
	// }}}
	// {{{
	public void setFxType(String value) { this.set("fx_Type", (Object)value); }
 	public String getFxType() { return (String)this.get("fx_Type"); }
	// }}}
}