/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AdaptivePaymentCommonParams.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.adaptivepayment;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * Common header for all AdaptivePayment APIs
  * 
  * 2008-02-29
   * @author Rohit Sahney
  */

public class APInvoiceData extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((16897*16897)<<32)/*<-APInvoiceData*/+
         		58164/*<-invoice_item*/*47/*<-repeating*/*APInvoiceItem.TYPE_SIGNATURE/*<-APInvoiceItem*/+
         		36268/*<-total_tax*/*APPayAmount.TYPE_SIGNATURE/*<-APPayAmount*/+
         		41048/*<-total_shipping*/*APPayAmount.TYPE_SIGNATURE/*<-APPayAmount*/+
         		36620/*<-type*/*18443/*<-String*/+
         		3355/*<-id*/*18443/*<-String*/+
         		23984/*<-purchase_order_identifier*/*18443/*<-String*/+
         		54037/*<-soft_descriptor*/*18443/*<-String*/+
         		29961/*<-discount*/*47/*<-repeating*/*APDiscountInfo.TYPE_SIGNATURE/*<-APDiscountInfo*/+
         		52029/*<-is_partial_tender*/*15044/*<-bool*/;
 
	public APInvoiceData() {
		super("AdaptivePayment::APInvoiceData", TYPE_SIGNATURE);

 
		set("invoice_item", null, "List<AdaptivePayment::APInvoiceItem>");
 
		set("total_tax", null, "AdaptivePayment::APPayAmount");
 
		set("total_shipping", null, "AdaptivePayment::APPayAmount");
 
		set("type", null, "String");
 
		set("id", null, "String");
 		addFieldQualifier("purchase_order_identifier","max_length","256");
 
		set("purchase_order_identifier", null, "String");
 		addFieldQualifier("soft_descriptor","max_length","22");
 
		set("soft_descriptor", null, "String");
 
		set("discount", null, "List<AdaptivePayment::APDiscountInfo>");
 
		set("is_partial_tender", null, "bool");
	}

	// {{{
	public void setInvoiceItem(List<APInvoiceItem> value) { this.set("invoice_item", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<APInvoiceItem> getInvoiceItem() { return (List<APInvoiceItem>)this.get("invoice_item"); }
	// }}}
	// {{{
	public void setTotalTax(APPayAmount value) { this.set("total_tax", (Object)value); }
 	public APPayAmount getTotalTax() { return (APPayAmount)this.get("total_tax"); }
	// }}}
	// {{{
	public void setTotalShipping(APPayAmount value) { this.set("total_shipping", (Object)value); }
 	public APPayAmount getTotalShipping() { return (APPayAmount)this.get("total_shipping"); }
	// }}}
	// {{{
	public void setType(String value) { this.set("type", (Object)value); }
 	public String getType() { return (String)this.get("type"); }
	// }}}
	// {{{
	public void setId(String value) { this.set("id", (Object)value); }
 	public String getId() { return (String)this.get("id"); }
	// }}}
	// {{{
	public void setPurchaseOrderIdentifier(String value) { this.set("purchase_order_identifier", (Object)value); }
 	public String getPurchaseOrderIdentifier() { return (String)this.get("purchase_order_identifier"); }
	// }}}
	// {{{
	public void setSoftDescriptor(String value) { this.set("soft_descriptor", (Object)value); }
 	public String getSoftDescriptor() { return (String)this.get("soft_descriptor"); }
	// }}}
	// {{{
	public void setDiscount(List<APDiscountInfo> value) { this.set("discount", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<APDiscountInfo> getDiscount() { return (List<APDiscountInfo>)this.get("discount"); }
	// }}}
	// {{{
	public void setIsPartialTender(Boolean value) { this.set("is_partial_tender", (Object)value); }
 	public Boolean getIsPartialTender() { return (Boolean)this.get("is_partial_tender"); }
	// }}}
}