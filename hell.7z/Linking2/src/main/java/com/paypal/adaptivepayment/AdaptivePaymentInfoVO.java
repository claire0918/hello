/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AdaptivePaymentInfoVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.adaptivepayment;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * VOs for Risk Analysis. BabyGopher project 36240	
  * 
  * 2011-01-11
   * @author Kai Xu
  */

public class AdaptivePaymentInfoVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((22260*22260)<<32)/*<-AdaptivePaymentInfoVO*/+
         		27380/*<-ap_cart*/*47/*<-repeating*/*PayLegInfoVO.TYPE_SIGNATURE/*<-PayLegInfoVO*/+
         		61652/*<-sender_acct_num*/*46168/*<-ullong*/+
         		14064/*<-receiver_acct_num*/*46168/*<-ullong*/+
         		18372/*<-caller_acct_num*/*46168/*<-ullong*/+
         		65205/*<-total_amount*/*21015/*<-Currency*/+
         		12298/*<-app_cat*/*18443/*<-String*/+
         		45821/*<-split_pay_type*/*37752/*<-char*/+
         		52973/*<-authorization_type*/*37752/*<-char*/+
         		9761/*<-payment_activity_id*/*46168/*<-ullong*/+
         		60253/*<-pay_key*/*18443/*<-String*/+
         		13141/*<-preapproval_key*/*18443/*<-String*/+
         		15945/*<-caller_session_id*/*18443/*<-String*/+
         		5073/*<-sender_session_id*/*18443/*<-String*/+
         		51040/*<-store_id*/*18443/*<-String*/+
         		49241/*<-issuer_list*/*47/*<-repeating*/*46168/*<-ullong*/+
         		64958/*<-pos_pinless_info*/*com.paypal.adaptivepayment.POSPinlessInfoVO.TYPE_SIGNATURE/*<-AdaptivePayment::POSPinlessInfoVO*/+
         		51913/*<-store_address*/*com.paypal.user.AddressVO.TYPE_SIGNATURE/*<-User::AddressVO*/;
 
	public AdaptivePaymentInfoVO() {
		super("AdaptivePayment::AdaptivePaymentInfoVO", TYPE_SIGNATURE);

 		addFieldQualifier("ap_cart","require","true");
 
		set("ap_cart", null, "List<AdaptivePayment::PayLegInfoVO>");
 		addFieldQualifier("sender_acct_num","require","true");
 
		set("sender_acct_num", null, "ullong");
 		addFieldQualifier("receiver_acct_num","require","true");
 
		set("receiver_acct_num", null, "ullong");
 		addFieldQualifier("caller_acct_num","require","true");
 
		set("caller_acct_num", null, "ullong");
 		addFieldQualifier("total_amount","require","true");
 
		set("total_amount", null, "Currency");
 
		set("app_cat", null, "String");
 		addFieldQualifier("split_pay_type","require","true");
 
		set("split_pay_type", null, "char");
 		addFieldQualifier("authorization_type","require","true");
 
		set("authorization_type", null, "char");
 		addFieldQualifier("payment_activity_id","require","true");
 
		set("payment_activity_id", null, "ullong");
 		addFieldQualifier("pay_key","require","true");
 
		set("pay_key", null, "String");
 		addFieldQualifier("preapproval_key","require","false");
 
		set("preapproval_key", null, "String");
 		addFieldQualifier("caller_session_id","require","true");
 
		set("caller_session_id", null, "String");
 		addFieldQualifier("sender_session_id","require","true");
 
		set("sender_session_id", null, "String");
 		addFieldQualifier("store_id","require","false");
 
		set("store_id", null, "String");
 
		set("issuer_list", null, "List<ullong>");
 
		set("pos_pinless_info", null, "AdaptivePayment::POSPinlessInfoVO");
 
		set("store_address", null, "User::AddressVO");
	}

	// {{{
	public void setApCart(List<PayLegInfoVO> value) { this.set("ap_cart", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<PayLegInfoVO> getApCart() { return (List<PayLegInfoVO>)this.get("ap_cart"); }
	// }}}
	// {{{
	public void setSenderAcctNum(BigInteger value) { this.set("sender_acct_num", (Object)value); }
 	public BigInteger getSenderAcctNum() { return (BigInteger)this.get("sender_acct_num"); }
	// }}}
	// {{{
	public void setReceiverAcctNum(BigInteger value) { this.set("receiver_acct_num", (Object)value); }
 	public BigInteger getReceiverAcctNum() { return (BigInteger)this.get("receiver_acct_num"); }
	// }}}
	// {{{
	public void setCallerAcctNum(BigInteger value) { this.set("caller_acct_num", (Object)value); }
 	public BigInteger getCallerAcctNum() { return (BigInteger)this.get("caller_acct_num"); }
	// }}}
	// {{{
	public void setTotalAmount(Currency value) { this.set("total_amount", (Object)value); }
 	public Currency getTotalAmount() { return (Currency)this.get("total_amount"); }
	// }}}
	// {{{
	public void setAppCat(String value) { this.set("app_cat", (Object)value); }
 	public String getAppCat() { return (String)this.get("app_cat"); }
	// }}}
	// {{{
	public void setSplitPayType(Byte value) { this.set("split_pay_type", (Object)value); }
 	public Byte getSplitPayType() { return (Byte)this.get("split_pay_type"); }
	// }}}
	// {{{
	public void setAuthorizationType(Byte value) { this.set("authorization_type", (Object)value); }
 	public Byte getAuthorizationType() { return (Byte)this.get("authorization_type"); }
	// }}}
	// {{{
	public void setPaymentActivityId(BigInteger value) { this.set("payment_activity_id", (Object)value); }
 	public BigInteger getPaymentActivityId() { return (BigInteger)this.get("payment_activity_id"); }
	// }}}
	// {{{
	public void setPayKey(String value) { this.set("pay_key", (Object)value); }
 	public String getPayKey() { return (String)this.get("pay_key"); }
	// }}}
	// {{{
	public void setPreapprovalKey(String value) { this.set("preapproval_key", (Object)value); }
 	public String getPreapprovalKey() { return (String)this.get("preapproval_key"); }
	// }}}
	// {{{
	public void setCallerSessionId(String value) { this.set("caller_session_id", (Object)value); }
 	public String getCallerSessionId() { return (String)this.get("caller_session_id"); }
	// }}}
	// {{{
	public void setSenderSessionId(String value) { this.set("sender_session_id", (Object)value); }
 	public String getSenderSessionId() { return (String)this.get("sender_session_id"); }
	// }}}
	// {{{
	public void setStoreId(String value) { this.set("store_id", (Object)value); }
 	public String getStoreId() { return (String)this.get("store_id"); }
	// }}}
	// {{{
	public void setIssuerList(List<BigInteger> value) { this.set("issuer_list", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<BigInteger> getIssuerList() { return (List<BigInteger>)this.get("issuer_list"); }
	// }}}
	// {{{
	public void setPosPinlessInfo(com.paypal.adaptivepayment.POSPinlessInfoVO value) { this.set("pos_pinless_info", (Object)value); }
 	public com.paypal.adaptivepayment.POSPinlessInfoVO getPosPinlessInfo() { return (com.paypal.adaptivepayment.POSPinlessInfoVO)this.get("pos_pinless_info"); }
	// }}}
	// {{{
	public void setStoreAddress(com.paypal.user.AddressVO value) { this.set("store_address", (Object)value); }
 	public com.paypal.user.AddressVO getStoreAddress() { return (com.paypal.user.AddressVO)this.get("store_address"); }
	// }}}
}