/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AdaptivePaymentCommonParams.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.adaptivepayment;

import java.math.BigInteger;

  
public enum FXType {
/**sender or receiver side ffx */
   	SENDER_SIDE(new String("SENDER_SIDE"), ""),
   	RECEIVER_SIDE(new String("RECEIVER_SIDE"), ""),
   	BALANCE_TRANSFER(new String("BALANCE_TRANSFER"), "");

	private final String value;
	private final String desc;

	private FXType(String value, String desc) {
		this.value = value;
		this.desc  = desc;
	}

	public String getValue() {
		return value;
	}

	public String getDesc() {
		return desc;
	}
}
