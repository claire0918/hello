/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AdaptivePaymentCommonParams.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.adaptivepayment;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * Common header for all AdaptivePayment APIs
  * 
  * 2008-02-29
   * @author Rohit Sahney
  */

public class APRefundDetails extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((63626*63626)<<32)/*<-APRefundDetails*/+
         		20000/*<-transaction_id*/*46168/*<-ullong*/+
         		32593/*<-receiver_account_number*/*46168/*<-ullong*/+
         		10321/*<-less_than_original_amount*/*15044/*<-bool*/+
         		4826/*<-less_than_refundable_amount*/*15044/*<-bool*/+
         		2919/*<-pay_amount*/*APPayAmount.TYPE_SIGNATURE/*<-APPayAmount*/+
         		47128/*<-pre_refund_feeable_amount*/*APPayAmount.TYPE_SIGNATURE/*<-APPayAmount*/+
         		22103/*<-post_refund_feeable_amount*/*APPayAmount.TYPE_SIGNATURE/*<-APPayAmount*/+
         		28952/*<-activity_id*/*46168/*<-ullong*/;
 
	public APRefundDetails() {
		super("AdaptivePayment::APRefundDetails", TYPE_SIGNATURE);

 
		set("transaction_id", null, "ullong");
 
		set("receiver_account_number", null, "ullong");
 
		set("less_than_original_amount", null, "bool");
 
		set("less_than_refundable_amount", null, "bool");
 
		set("pay_amount", null, "AdaptivePayment::APPayAmount");
 
		set("pre_refund_feeable_amount", null, "AdaptivePayment::APPayAmount");
 
		set("post_refund_feeable_amount", null, "AdaptivePayment::APPayAmount");
 
		set("activity_id", null, "ullong");
	}

	// {{{
	public void setTransactionId(BigInteger value) { this.set("transaction_id", (Object)value); }
 	public BigInteger getTransactionId() { return (BigInteger)this.get("transaction_id"); }
	// }}}
	// {{{
	public void setReceiverAccountNumber(BigInteger value) { this.set("receiver_account_number", (Object)value); }
 	public BigInteger getReceiverAccountNumber() { return (BigInteger)this.get("receiver_account_number"); }
	// }}}
	// {{{
	public void setLessThanOriginalAmount(Boolean value) { this.set("less_than_original_amount", (Object)value); }
 	public Boolean getLessThanOriginalAmount() { return (Boolean)this.get("less_than_original_amount"); }
	// }}}
	// {{{
	public void setLessThanRefundableAmount(Boolean value) { this.set("less_than_refundable_amount", (Object)value); }
 	public Boolean getLessThanRefundableAmount() { return (Boolean)this.get("less_than_refundable_amount"); }
	// }}}
	// {{{
	public void setPayAmount(APPayAmount value) { this.set("pay_amount", (Object)value); }
 	public APPayAmount getPayAmount() { return (APPayAmount)this.get("pay_amount"); }
	// }}}
	// {{{
	public void setPreRefundFeeableAmount(APPayAmount value) { this.set("pre_refund_feeable_amount", (Object)value); }
 	public APPayAmount getPreRefundFeeableAmount() { return (APPayAmount)this.get("pre_refund_feeable_amount"); }
	// }}}
	// {{{
	public void setPostRefundFeeableAmount(APPayAmount value) { this.set("post_refund_feeable_amount", (Object)value); }
 	public APPayAmount getPostRefundFeeableAmount() { return (APPayAmount)this.get("post_refund_feeable_amount"); }
	// }}}
	// {{{
	public void setActivityId(BigInteger value) { this.set("activity_id", (Object)value); }
 	public BigInteger getActivityId() { return (BigInteger)this.get("activity_id"); }
	// }}}
}