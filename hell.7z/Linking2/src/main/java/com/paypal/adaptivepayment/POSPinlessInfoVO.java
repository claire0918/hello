/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/POSPinlessInfoVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:40 2012 */

package com.paypal.adaptivepayment;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  *  Adaptive Payments to supply PINLess transaction information for POS transactions
  * 
  * 2012-03-20
   * @author Elavarasi Arunachalam
  */

public class POSPinlessInfoVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((22727*22727)<<32)/*<-POSPinlessInfoVO*/+
         		44447/*<-merchant_pinless_threshold*/*21015/*<-Currency*/+
         		28290/*<-paypal_pinless_threshold*/*21015/*<-Currency*/+
         		57920/*<-terminal_type*/*38894/*<-int*/+
         		39114/*<-pin_captured*/*15044/*<-bool*/;
 
	public POSPinlessInfoVO() {
		super("AdaptivePayment::POSPinlessInfoVO", TYPE_SIGNATURE);

 
		set("merchant_pinless_threshold", null, "Currency");
 
		set("paypal_pinless_threshold", null, "Currency");
 
		set("terminal_type", null, "int");
 
		set("pin_captured", null, "bool");
	}

	// {{{
	public void setMerchantPinlessThreshold(Currency value) { this.set("merchant_pinless_threshold", (Object)value); }
 	public Currency getMerchantPinlessThreshold() { return (Currency)this.get("merchant_pinless_threshold"); }
	// }}}
	// {{{
	public void setPaypalPinlessThreshold(Currency value) { this.set("paypal_pinless_threshold", (Object)value); }
 	public Currency getPaypalPinlessThreshold() { return (Currency)this.get("paypal_pinless_threshold"); }
	// }}}
	// {{{
	public void setTerminalType(Integer value) { this.set("terminal_type", (Object)value); }
 	public Integer getTerminalType() { return (Integer)this.get("terminal_type"); }
	// }}}
	// {{{
	public void setPinCaptured(Boolean value) { this.set("pin_captured", (Object)value); }
 	public Boolean getPinCaptured() { return (Boolean)this.get("pin_captured"); }
	// }}}
}