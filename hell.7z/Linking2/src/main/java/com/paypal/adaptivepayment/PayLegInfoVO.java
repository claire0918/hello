/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/PayLegInfoVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:40 2012 */

package com.paypal.adaptivepayment;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * VOs for Risk Analysis. BabyGopher project 36240	
  * 
  * 2011-01-11
   * @author Kai Xu
  */

public class PayLegInfoVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((17302*17302)<<32)/*<-PayLegInfoVO*/+
         		61652/*<-sender_acct_num*/*46168/*<-ullong*/+
         		21236/*<-counterparty_acct_num*/*46168/*<-ullong*/+
         		49626/*<-pay_type*/*37752/*<-char*/+
         		11041/*<-pay_purpose*/*18443/*<-String*/+
         		21474/*<-amount*/*21015/*<-Currency*/+
         		23048/*<-amount_usd*/*21015/*<-Currency*/+
         		23164/*<-item_description*/*18443/*<-String*/+
         		604/*<-is_pri_receiver*/*15044/*<-bool*/+
         		9761/*<-payment_activity_id*/*46168/*<-ullong*/+
         		24243/*<-invoice_data*/*APInvoiceData.TYPE_SIGNATURE/*<-APInvoiceData*/;
 
	public PayLegInfoVO() {
		super("AdaptivePayment::PayLegInfoVO", TYPE_SIGNATURE);

 		addFieldQualifier("sender_acct_num","require","true");
 
		set("sender_acct_num", null, "ullong");
 		addFieldQualifier("counterparty_acct_num","require","true");
 
		set("counterparty_acct_num", null, "ullong");
 		addFieldQualifier("pay_type","require","true");
 
		set("pay_type", null, "char");
 
		set("pay_purpose", null, "String");
 		addFieldQualifier("amount","require","true");
 
		set("amount", null, "Currency");
 		addFieldQualifier("amount_usd","require","true");
 
		set("amount_usd", null, "Currency");
 
		set("item_description", null, "String");
 		addFieldQualifier("is_pri_receiver","require","true");
 
		set("is_pri_receiver", null, "bool");
 		addFieldQualifier("payment_activity_id","require","true");
 
		set("payment_activity_id", null, "ullong");
 		addFieldQualifier("invoice_data","require","true");
 
		set("invoice_data", null, "AdaptivePayment::APInvoiceData");
	}

	// {{{
	public void setSenderAcctNum(BigInteger value) { this.set("sender_acct_num", (Object)value); }
 	public BigInteger getSenderAcctNum() { return (BigInteger)this.get("sender_acct_num"); }
	// }}}
	// {{{
	public void setCounterpartyAcctNum(BigInteger value) { this.set("counterparty_acct_num", (Object)value); }
 	public BigInteger getCounterpartyAcctNum() { return (BigInteger)this.get("counterparty_acct_num"); }
	// }}}
	// {{{
	public void setPayType(Byte value) { this.set("pay_type", (Object)value); }
 	public Byte getPayType() { return (Byte)this.get("pay_type"); }
	// }}}
	// {{{
	public void setPayPurpose(String value) { this.set("pay_purpose", (Object)value); }
 	public String getPayPurpose() { return (String)this.get("pay_purpose"); }
	// }}}
	// {{{
	public void setAmount(Currency value) { this.set("amount", (Object)value); }
 	public Currency getAmount() { return (Currency)this.get("amount"); }
	// }}}
	// {{{
	public void setAmountUsd(Currency value) { this.set("amount_usd", (Object)value); }
 	public Currency getAmountUsd() { return (Currency)this.get("amount_usd"); }
	// }}}
	// {{{
	public void setItemDescription(String value) { this.set("item_description", (Object)value); }
 	public String getItemDescription() { return (String)this.get("item_description"); }
	// }}}
	// {{{
	public void setIsPriReceiver(Boolean value) { this.set("is_pri_receiver", (Object)value); }
 	public Boolean getIsPriReceiver() { return (Boolean)this.get("is_pri_receiver"); }
	// }}}
	// {{{
	public void setPaymentActivityId(BigInteger value) { this.set("payment_activity_id", (Object)value); }
 	public BigInteger getPaymentActivityId() { return (BigInteger)this.get("payment_activity_id"); }
	// }}}
	// {{{
	public void setInvoiceData(APInvoiceData value) { this.set("invoice_data", (Object)value); }
 	public APInvoiceData getInvoiceData() { return (APInvoiceData)this.get("invoice_data"); }
	// }}}
}