/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AdaptivePaymentCommonParams.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.adaptivepayment;

import java.math.BigInteger;

  
public enum FeesPayerType {
/**
			Identify which parties will pay transaction fees
			SENDER - Sender pays all fees (for personal, implicit simple/parallel payments;
			                               do not use for chained or unilateral payments)
			PRIMARYRECEIVER - Primary receiver pays all fees (chained payments only)
			EACHRECEIVER - ach receiver pays their own fee (default, personal and unilateral payments)
			SECONDARYONLY - Secondary receivers pay all fees (use only for chained payments with one secondary receiver)
		*/
   	EACHRECEIVER(new String("EACHRECEIVER"), ""),
   	SENDER(new String("SENDER"), ""),
   	PRIMARYRECEIVER(new String("PRIMARYRECEIVER"), ""),
   	SECONDARYONLY(new String("SECONDARYONLY"), ""),
   	NOFEE(new String("NOFEE"), "");

	private final String value;
	private final String desc;

	private FeesPayerType(String value, String desc) {
		this.value = value;
		this.desc  = desc;
	}

	public String getValue() {
		return value;
	}

	public String getDesc() {
		return desc;
	}
}
