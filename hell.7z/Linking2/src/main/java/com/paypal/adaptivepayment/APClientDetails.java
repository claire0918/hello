/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AdaptivePaymentCommonParams.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.adaptivepayment;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * Common header for all AdaptivePayment APIs
  * 
  * 2008-02-29
   * @author Rohit Sahney
  */

public class APClientDetails extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((64385*64385)<<32)/*<-APClientDetails*/+
         		55626/*<-client_ip_address*/*18443/*<-String*/+
         		51040/*<-store_id*/*18443/*<-String*/+
         		44239/*<-merchant_store_info*/*APMerchantStoreInfo.TYPE_SIGNATURE/*<-APMerchantStoreInfo*/+
         		43556/*<-device_id*/*18443/*<-String*/+
         		63518/*<-terminal_id*/*18443/*<-String*/+
         		57920/*<-terminal_type*/*18443/*<-String*/+
         		23686/*<-terminal_capability_used*/*18443/*<-String*/+
         		64794/*<-model*/*18443/*<-String*/+
         		60835/*<-geo_location*/*18443/*<-String*/+
         		704/*<-customer_type*/*18443/*<-String*/+
         		4614/*<-partner_name*/*18443/*<-String*/+
         		31612/*<-customer_id*/*18443/*<-String*/;
 
	public APClientDetails() {
		super("AdaptivePayment::APClientDetails", TYPE_SIGNATURE);

 		addFieldQualifier("client_ip_address","required","true");
 
		set("client_ip_address", null, "String");
 
		set("store_id", null, "String");
 
		set("merchant_store_info", null, "AdaptivePayment::APMerchantStoreInfo");
 
		set("device_id", null, "String");
 
		set("terminal_id", null, "String");
 
		set("terminal_type", null, "String");
 
		set("terminal_capability_used", null, "String");
 
		set("model", null, "String");
 
		set("geo_location", null, "String");
 
		set("customer_type", null, "String");
 
		set("partner_name", null, "String");
 
		set("customer_id", null, "String");
	}

	// {{{
	public void setClientIpAddress(String value) { this.set("client_ip_address", (Object)value); }
 	public String getClientIpAddress() { return (String)this.get("client_ip_address"); }
	// }}}
	// {{{
	public void setStoreId(String value) { this.set("store_id", (Object)value); }
 	public String getStoreId() { return (String)this.get("store_id"); }
	// }}}
	// {{{
	public void setMerchantStoreInfo(APMerchantStoreInfo value) { this.set("merchant_store_info", (Object)value); }
 	public APMerchantStoreInfo getMerchantStoreInfo() { return (APMerchantStoreInfo)this.get("merchant_store_info"); }
	// }}}
	// {{{
	public void setDeviceId(String value) { this.set("device_id", (Object)value); }
 	public String getDeviceId() { return (String)this.get("device_id"); }
	// }}}
	// {{{
	public void setTerminalId(String value) { this.set("terminal_id", (Object)value); }
 	public String getTerminalId() { return (String)this.get("terminal_id"); }
	// }}}
	// {{{
	public void setTerminalType(String value) { this.set("terminal_type", (Object)value); }
 	public String getTerminalType() { return (String)this.get("terminal_type"); }
	// }}}
	// {{{
	public void setTerminalCapabilityUsed(String value) { this.set("terminal_capability_used", (Object)value); }
 	public String getTerminalCapabilityUsed() { return (String)this.get("terminal_capability_used"); }
	// }}}
	// {{{
	public void setModel(String value) { this.set("model", (Object)value); }
 	public String getModel() { return (String)this.get("model"); }
	// }}}
	// {{{
	public void setGeoLocation(String value) { this.set("geo_location", (Object)value); }
 	public String getGeoLocation() { return (String)this.get("geo_location"); }
	// }}}
	// {{{
	public void setCustomerType(String value) { this.set("customer_type", (Object)value); }
 	public String getCustomerType() { return (String)this.get("customer_type"); }
	// }}}
	// {{{
	public void setPartnerName(String value) { this.set("partner_name", (Object)value); }
 	public String getPartnerName() { return (String)this.get("partner_name"); }
	// }}}
	// {{{
	public void setCustomerId(String value) { this.set("customer_id", (Object)value); }
 	public String getCustomerId() { return (String)this.get("customer_id"); }
	// }}}
}