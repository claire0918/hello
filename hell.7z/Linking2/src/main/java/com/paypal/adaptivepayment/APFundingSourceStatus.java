/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AdaptivePaymentCommonParams.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.adaptivepayment;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * Common header for all AdaptivePayment APIs
  * 
  * 2008-02-29
   * @author Rohit Sahney
  */

public class APFundingSourceStatus extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((1099*1099)<<32)/*<-APFundingSourceStatus*/+
         		24778/*<-instrument*/*com.paypal.money.InstrumentIdentifierVO.TYPE_SIGNATURE/*<-Money::InstrumentIdentifierVO*/+
         		48323/*<-status_code*/*18443/*<-String*/;
 
	public APFundingSourceStatus() {
		super("AdaptivePayment::APFundingSourceStatus", TYPE_SIGNATURE);

 
		set("instrument", null, "Money::InstrumentIdentifierVO");
 
		set("status_code", null, "String");
	}

	// {{{
	public void setInstrument(com.paypal.money.InstrumentIdentifierVO value) { this.set("instrument", (Object)value); }
 	public com.paypal.money.InstrumentIdentifierVO getInstrument() { return (com.paypal.money.InstrumentIdentifierVO)this.get("instrument"); }
	// }}}
	// {{{
	public void setStatusCode(String value) { this.set("status_code", (Object)value); }
 	public String getStatusCode() { return (String)this.get("status_code"); }
	// }}}
}