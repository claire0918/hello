/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AdaptivePaymentCommonParams.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.adaptivepayment;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * Common header for all AdaptivePayment APIs
  * 
  * 2008-02-29
   * @author Rohit Sahney
  */

public class APPaymentFlowVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((41551*41551)<<32)/*<-APPaymentFlowVO*/+
         		15509/*<-ap_payemnt_activity_vo*/*APPaymentActivityVO.TYPE_SIGNATURE/*<-APPaymentActivityVO*/+
         		55709/*<-payment_flow*/*com.paypal.money.PaymentFlowVO.TYPE_SIGNATURE/*<-Money::PaymentFlowVO*/;
 
	public APPaymentFlowVO() {
		super("AdaptivePayment::APPaymentFlowVO", TYPE_SIGNATURE);

 
		set("ap_payemnt_activity_vo", null, "AdaptivePayment::APPaymentActivityVO");
 
		set("payment_flow", null, "Money::PaymentFlowVO");
	}

	// {{{
	public void setApPayemntActivityVo(APPaymentActivityVO value) { this.set("ap_payemnt_activity_vo", (Object)value); }
 	public APPaymentActivityVO getApPayemntActivityVo() { return (APPaymentActivityVO)this.get("ap_payemnt_activity_vo"); }
	// }}}
	// {{{
	public void setPaymentFlow(com.paypal.money.PaymentFlowVO value) { this.set("payment_flow", (Object)value); }
 	public com.paypal.money.PaymentFlowVO getPaymentFlow() { return (com.paypal.money.PaymentFlowVO)this.get("payment_flow"); }
	// }}}
}