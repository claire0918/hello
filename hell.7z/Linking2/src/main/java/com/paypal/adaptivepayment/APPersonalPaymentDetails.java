/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AdaptivePaymentCommonParams.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.adaptivepayment;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * Common header for all AdaptivePayment APIs
  * 
  * 2008-02-29
   * @author Rohit Sahney
  */

public class APPersonalPaymentDetails extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((64693*64693)<<32)/*<-APPersonalPaymentDetails*/+
         		61799/*<-sender_account_number*/*46168/*<-ullong*/+
         		28952/*<-activity_id*/*46168/*<-ullong*/+
         		27570/*<-payment_type*/*37752/*<-char*/+
         		55108/*<-personal_payment_type*/*37752/*<-char*/+
         		62496/*<-fees_payer_type*/*38894/*<-int*/+
         		1307/*<-payment_source*/*18443/*<-String*/;
 
	public APPersonalPaymentDetails() {
		super("AdaptivePayment::APPersonalPaymentDetails", TYPE_SIGNATURE);

 
		set("sender_account_number", null, "ullong");
 
		set("activity_id", null, "ullong");
 
		set("payment_type", null, "char");
 
		set("personal_payment_type", null, "char");
 
		set("fees_payer_type", null, "int");
 
		set("payment_source", null, "String");
	}

	// {{{
	public void setSenderAccountNumber(BigInteger value) { this.set("sender_account_number", (Object)value); }
 	public BigInteger getSenderAccountNumber() { return (BigInteger)this.get("sender_account_number"); }
	// }}}
	// {{{
	public void setActivityId(BigInteger value) { this.set("activity_id", (Object)value); }
 	public BigInteger getActivityId() { return (BigInteger)this.get("activity_id"); }
	// }}}
	// {{{
	public void setPaymentType(Byte value) { this.set("payment_type", (Object)value); }
 	public Byte getPaymentType() { return (Byte)this.get("payment_type"); }
	// }}}
	// {{{
	public void setPersonalPaymentType(Byte value) { this.set("personal_payment_type", (Object)value); }
 	public Byte getPersonalPaymentType() { return (Byte)this.get("personal_payment_type"); }
	// }}}
	// {{{
	public void setFeesPayerType(Integer value) { this.set("fees_payer_type", (Object)value); }
 	public Integer getFeesPayerType() { return (Integer)this.get("fees_payer_type"); }
	// }}}
	// {{{
	public void setPaymentSource(String value) { this.set("payment_source", (Object)value); }
 	public String getPaymentSource() { return (String)this.get("payment_source"); }
	// }}}
}