/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AdaptivePaymentCommonParams.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.adaptivepayment;

import java.math.BigInteger;

  
public enum FundingSelectionType {
/**
			Allowed funding selections for payments.
			Can be combined in any order to allow payments to use the indicated funding type.
			ECHECK and CREDITCARD include BALANCE implicitly.
			RECEIVABLE is only allowed for API callers with specific permission to use it.
			*TBD* There may be other restrictions on RECEIVABLE funding type as well,
			such as that it's only permitted for implicit payments
			(sender is the same as caller, and subject is not provided or is the same as caller).
		*/
   	BALANCE(new String("BALANCE"), ""),
   	ECHECK(new String("ECHECK"), ""),
   	CREDITCARD(new String("CREDITCARD"), ""),
   	RECEIVABLE(new String("RECEIVABLE"), "");

	private final String value;
	private final String desc;

	private FundingSelectionType(String value, String desc) {
		this.value = value;
		this.desc  = desc;
	}

	public String getValue() {
		return value;
	}

	public String getDesc() {
		return desc;
	}
}
