/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AdaptivePaymentCommonParams.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.adaptivepayment;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * Common header for all AdaptivePayment APIs
  * 
  * 2008-02-29
   * @author Rohit Sahney
  */

public class APRefundAnalysisInfo extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((45398*45398)<<32)/*<-APRefundAnalysisInfo*/+
         		63044/*<-activity*/*APPaymentExecActivity.TYPE_SIGNATURE/*<-APPaymentExecActivity*/+
         		20000/*<-transaction_id*/*46168/*<-ullong*/+
         		42031/*<-refunded_amount*/*APPayAmount.TYPE_SIGNATURE/*<-APPayAmount*/+
         		41602/*<-receiver_balance*/*APPayAmount.TYPE_SIGNATURE/*<-APPayAmount*/+
         		16407/*<-original_amount*/*APPayAmount.TYPE_SIGNATURE/*<-APPayAmount*/+
         		26942/*<-has_valid_ach*/*15044/*<-bool*/+
         		10195/*<-allows_api_access*/*15044/*<-bool*/+
         		35755/*<-refund_allowed*/*15044/*<-bool*/+
         		44060/*<-pending_refund*/*15044/*<-bool*/+
         		46167/*<-email_unconfirmed*/*15044/*<-bool*/;
 
	public APRefundAnalysisInfo() {
		super("AdaptivePayment::APRefundAnalysisInfo", TYPE_SIGNATURE);

 
		set("activity", null, "AdaptivePayment::APPaymentExecActivity");
 
		set("transaction_id", null, "ullong");
 
		set("refunded_amount", null, "AdaptivePayment::APPayAmount");
 
		set("receiver_balance", null, "AdaptivePayment::APPayAmount");
 
		set("original_amount", null, "AdaptivePayment::APPayAmount");
 
		set("has_valid_ach", null, "bool");
 
		set("allows_api_access", null, "bool");
 
		set("refund_allowed", null, "bool");
 
		set("pending_refund", null, "bool");
 
		set("email_unconfirmed", null, "bool");
	}

	// {{{
	public void setActivity(APPaymentExecActivity value) { this.set("activity", (Object)value); }
 	public APPaymentExecActivity getActivity() { return (APPaymentExecActivity)this.get("activity"); }
	// }}}
	// {{{
	public void setTransactionId(BigInteger value) { this.set("transaction_id", (Object)value); }
 	public BigInteger getTransactionId() { return (BigInteger)this.get("transaction_id"); }
	// }}}
	// {{{
	public void setRefundedAmount(APPayAmount value) { this.set("refunded_amount", (Object)value); }
 	public APPayAmount getRefundedAmount() { return (APPayAmount)this.get("refunded_amount"); }
	// }}}
	// {{{
	public void setReceiverBalance(APPayAmount value) { this.set("receiver_balance", (Object)value); }
 	public APPayAmount getReceiverBalance() { return (APPayAmount)this.get("receiver_balance"); }
	// }}}
	// {{{
	public void setOriginalAmount(APPayAmount value) { this.set("original_amount", (Object)value); }
 	public APPayAmount getOriginalAmount() { return (APPayAmount)this.get("original_amount"); }
	// }}}
	// {{{
	public void setHasValidAch(Boolean value) { this.set("has_valid_ach", (Object)value); }
 	public Boolean getHasValidAch() { return (Boolean)this.get("has_valid_ach"); }
	// }}}
	// {{{
	public void setAllowsApiAccess(Boolean value) { this.set("allows_api_access", (Object)value); }
 	public Boolean getAllowsApiAccess() { return (Boolean)this.get("allows_api_access"); }
	// }}}
	// {{{
	public void setRefundAllowed(Boolean value) { this.set("refund_allowed", (Object)value); }
 	public Boolean getRefundAllowed() { return (Boolean)this.get("refund_allowed"); }
	// }}}
	// {{{
	public void setPendingRefund(Boolean value) { this.set("pending_refund", (Object)value); }
 	public Boolean getPendingRefund() { return (Boolean)this.get("pending_refund"); }
	// }}}
	// {{{
	public void setEmailUnconfirmed(Boolean value) { this.set("email_unconfirmed", (Object)value); }
 	public Boolean getEmailUnconfirmed() { return (Boolean)this.get("email_unconfirmed"); }
	// }}}
}