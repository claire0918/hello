/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AdaptivePaymentCommonParams.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.adaptivepayment;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * Common header for all AdaptivePayment APIs
  * 
  * 2008-02-29
   * @author Rohit Sahney
  */

public class APPaymentExecActivity extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((45835*45835)<<32)/*<-APPaymentExecActivity*/+
         		28952/*<-activity_id*/*46168/*<-ullong*/+
         		55015/*<-pay_receiver_account*/*46168/*<-ullong*/+
         		52543/*<-status*/*37752/*<-char*/+
         		53860/*<-auth_id*/*18443/*<-String*/+
         		34913/*<-idempotency_id*/*18443/*<-String*/+
         		42747/*<-pap_funding_info*/*PAPFundingPlanInfoVO.TYPE_SIGNATURE/*<-PAPFundingPlanInfoVO*/+
         		8300/*<-successful_funding_plan*/*com.paypal.fundingmix.FundingPlanVO.TYPE_SIGNATURE/*<-FundingMix::FundingPlanVO*/+
         		45523/*<-sender_wallet_preferences*/*com.paypal.financialinstrument.WalletPreferenceDetailsVO.TYPE_SIGNATURE/*<-FinancialInstrument::WalletPreferenceDetailsVO*/+
         		7007/*<-rejected_funding_instruments*/*47/*<-repeating*/*APFundingSourceStatus.TYPE_SIGNATURE/*<-APFundingSourceStatus*/;
 
	public APPaymentExecActivity() {
		super("AdaptivePayment::APPaymentExecActivity", TYPE_SIGNATURE);

 
		set("activity_id", null, "ullong");
 
		set("pay_receiver_account", null, "ullong");
 
		set("status", null, "char");
 
		set("auth_id", null, "String");
 		addFieldQualifier("idempotency_id","required","false");
 
		set("idempotency_id", null, "String");
 		addFieldQualifier("pap_funding_info","required","false");
 
		set("pap_funding_info", null, "AdaptivePayment::PAPFundingPlanInfoVO");
 
		set("successful_funding_plan", null, "FundingMix::FundingPlanVO");
 
		set("sender_wallet_preferences", null, "FinancialInstrument::WalletPreferenceDetailsVO");
 
		set("rejected_funding_instruments", null, "List<AdaptivePayment::APFundingSourceStatus>");
	}

	// {{{
	public void setActivityId(BigInteger value) { this.set("activity_id", (Object)value); }
 	public BigInteger getActivityId() { return (BigInteger)this.get("activity_id"); }
	// }}}
	// {{{
	public void setPayReceiverAccount(BigInteger value) { this.set("pay_receiver_account", (Object)value); }
 	public BigInteger getPayReceiverAccount() { return (BigInteger)this.get("pay_receiver_account"); }
	// }}}
	// {{{
	public void setStatus(Byte value) { this.set("status", (Object)value); }
 	public Byte getStatus() { return (Byte)this.get("status"); }
	// }}}
	// {{{
	public void setAuthId(String value) { this.set("auth_id", (Object)value); }
 	public String getAuthId() { return (String)this.get("auth_id"); }
	// }}}
	// {{{
	public void setIdempotencyId(String value) { this.set("idempotency_id", (Object)value); }
 	public String getIdempotencyId() { return (String)this.get("idempotency_id"); }
	// }}}
	// {{{
	public void setPapFundingInfo(PAPFundingPlanInfoVO value) { this.set("pap_funding_info", (Object)value); }
 	public PAPFundingPlanInfoVO getPapFundingInfo() { return (PAPFundingPlanInfoVO)this.get("pap_funding_info"); }
	// }}}
	// {{{
	public void setSuccessfulFundingPlan(com.paypal.fundingmix.FundingPlanVO value) { this.set("successful_funding_plan", (Object)value); }
 	public com.paypal.fundingmix.FundingPlanVO getSuccessfulFundingPlan() { return (com.paypal.fundingmix.FundingPlanVO)this.get("successful_funding_plan"); }
	// }}}
	// {{{
	public void setSenderWalletPreferences(com.paypal.financialinstrument.WalletPreferenceDetailsVO value) { this.set("sender_wallet_preferences", (Object)value); }
 	public com.paypal.financialinstrument.WalletPreferenceDetailsVO getSenderWalletPreferences() { return (com.paypal.financialinstrument.WalletPreferenceDetailsVO)this.get("sender_wallet_preferences"); }
	// }}}
	// {{{
	public void setRejectedFundingInstruments(List<APFundingSourceStatus> value) { this.set("rejected_funding_instruments", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<APFundingSourceStatus> getRejectedFundingInstruments() { return (List<APFundingSourceStatus>)this.get("rejected_funding_instruments"); }
	// }}}
}