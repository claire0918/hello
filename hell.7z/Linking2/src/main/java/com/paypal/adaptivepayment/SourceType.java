/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AdaptivePaymentCommonParams.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.adaptivepayment;

import java.math.BigInteger;

  
public enum SourceType {
/***/
   	WEB(new String("WEB"), ""),
   	API(new String("API"), ""),
   	POS(new String("POS"), ""),
   	MOBILE(new String("MOBILE"), ""),
   	CARDREADER(new String("CARDREADER"), "");

	private final String value;
	private final String desc;

	private SourceType(String value, String desc) {
		this.value = value;
		this.desc  = desc;
	}

	public String getValue() {
		return value;
	}

	public String getDesc() {
		return desc;
	}
}
