/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AdaptivePaymentCommonParams.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.adaptivepayment;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * Common header for all AdaptivePayment APIs
  * 
  * 2008-02-29
   * @author Rohit Sahney
  */

public class APDiscountInfo extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((22420*22420)<<32)/*<-APDiscountInfo*/+
         		31416/*<-name*/*18443/*<-String*/+
         		33481/*<-description*/*18443/*<-String*/+
         		44483/*<-code*/*18443/*<-String*/+
         		36620/*<-type*/*51052/*<-uint*/+
         		21474/*<-amount*/*21015/*<-Currency*/;
 
	public APDiscountInfo() {
		super("AdaptivePayment::APDiscountInfo", TYPE_SIGNATURE);

 
		set("name", null, "String");
 
		set("description", null, "String");
 
		set("code", null, "String");
 
		set("type", null, "uint");
 
		set("amount", null, "Currency");
	}

	// {{{
	public void setName(String value) { this.set("name", (Object)value); }
 	public String getName() { return (String)this.get("name"); }
	// }}}
	// {{{
	public void setDescription(String value) { this.set("description", (Object)value); }
 	public String getDescription() { return (String)this.get("description"); }
	// }}}
	// {{{
	public void setCode(String value) { this.set("code", (Object)value); }
 	public String getCode() { return (String)this.get("code"); }
	// }}}
	// {{{
	public void setType(Long value) { this.set("type", (Object)value); }
 	public Long getType() { return (Long)this.get("type"); }
	// }}}
	// {{{
	public void setAmount(Currency value) { this.set("amount", (Object)value); }
 	public Currency getAmount() { return (Currency)this.get("amount"); }
	// }}}
}