/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AdaptivePaymentCommonParams.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.adaptivepayment;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * Common header for all AdaptivePayment APIs
  * 
  * 2008-02-29
   * @author Rohit Sahney
  */

public class APPaymentRequest extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((32623*32623)<<32)/*<-APPaymentRequest*/+
         		32025/*<-action*/*38894/*<-int*/+
         		62496/*<-fees_payer_type*/*38894/*<-int*/+
         		5385/*<-memo*/*18443/*<-String*/+
         		4104/*<-notification_url*/*18443/*<-String*/+
         		50270/*<-tracking_id*/*18443/*<-String*/+
         		4885/*<-apiuser_account_number*/*46168/*<-ullong*/+
         		51388/*<-apiuser*/*APUser.TYPE_SIGNATURE/*<-APUser*/+
         		7769/*<-return_url*/*18443/*<-String*/+
         		22205/*<-cancel_url*/*18443/*<-String*/+
         		60232/*<-flags*/*38894/*<-int*/+
         		22809/*<-time_created*/*33490/*<-ulong*/+
         		9803/*<-allow_unilateral*/*15044/*<-bool*/+
         		37273/*<-allow_gxo*/*15044/*<-bool*/+
         		6197/*<-sender*/*APSender.TYPE_SIGNATURE/*<-APSender*/+
         		60964/*<-receiver*/*47/*<-repeating*/*APReceiver.TYPE_SIGNATURE/*<-APReceiver*/+
         		55336/*<-funding_type*/*47/*<-repeating*/*18443/*<-String*/+
         		59963/*<-application_info*/*com.paypal.money.ApplicationInfoVO.TYPE_SIGNATURE/*<-Money::ApplicationInfoVO*/+
         		44057/*<-ap_session_info*/*AdaptivePaymentSessionInfoVO.TYPE_SIGNATURE/*<-AdaptivePaymentSessionInfoVO*/+
         		64958/*<-pos_pinless_info*/*com.paypal.adaptivepayment.POSPinlessInfoVO.TYPE_SIGNATURE/*<-AdaptivePayment::POSPinlessInfoVO*/+
         		46261/*<-preapproval_flag*/*15044/*<-bool*/+
         		52982/*<-channel_source*/*18443/*<-String*/+
         		51913/*<-store_address*/*com.paypal.user.AddressVO.TYPE_SIGNATURE/*<-User::AddressVO*/;
 
	public APPaymentRequest() {
		super("AdaptivePayment::APPaymentRequest", TYPE_SIGNATURE);

 
		set("action", null, "int");
 
		set("fees_payer_type", null, "int");
 
		set("memo", null, "String");
 
		set("notification_url", null, "String");
 
		set("tracking_id", null, "String");
 
		set("apiuser_account_number", null, "ullong");
 
		set("apiuser", null, "AdaptivePayment::APUser");
 
		set("return_url", null, "String");
 
		set("cancel_url", null, "String");
 
		set("flags", null, "int");
 
		set("time_created", null, "ulong");
 
		set("allow_unilateral", null, "bool");
 
		set("allow_gxo", null, "bool");
 
		set("sender", null, "AdaptivePayment::APSender");
 
		set("receiver", null, "List<AdaptivePayment::APReceiver>");
 
		set("funding_type", null, "List<String>");
 
		set("application_info", null, "Money::ApplicationInfoVO");
 
		set("ap_session_info", null, "AdaptivePayment::AdaptivePaymentSessionInfoVO");
 
		set("pos_pinless_info", null, "AdaptivePayment::POSPinlessInfoVO");
 
		set("preapproval_flag", null, "bool");
 
		set("channel_source", null, "String");
 
		set("store_address", null, "User::AddressVO");
	}

	// {{{
	public void setAction(Integer value) { this.set("action", (Object)value); }
 	public Integer getAction() { return (Integer)this.get("action"); }
	// }}}
	// {{{
	public void setFeesPayerType(Integer value) { this.set("fees_payer_type", (Object)value); }
 	public Integer getFeesPayerType() { return (Integer)this.get("fees_payer_type"); }
	// }}}
	// {{{
	public void setMemo(String value) { this.set("memo", (Object)value); }
 	public String getMemo() { return (String)this.get("memo"); }
	// }}}
	// {{{
	public void setNotificationUrl(String value) { this.set("notification_url", (Object)value); }
 	public String getNotificationUrl() { return (String)this.get("notification_url"); }
	// }}}
	// {{{
	public void setTrackingId(String value) { this.set("tracking_id", (Object)value); }
 	public String getTrackingId() { return (String)this.get("tracking_id"); }
	// }}}
	// {{{
	public void setApiuserAccountNumber(BigInteger value) { this.set("apiuser_account_number", (Object)value); }
 	public BigInteger getApiuserAccountNumber() { return (BigInteger)this.get("apiuser_account_number"); }
	// }}}
	// {{{
	public void setApiuser(APUser value) { this.set("apiuser", (Object)value); }
 	public APUser getApiuser() { return (APUser)this.get("apiuser"); }
	// }}}
	// {{{
	public void setReturnUrl(String value) { this.set("return_url", (Object)value); }
 	public String getReturnUrl() { return (String)this.get("return_url"); }
	// }}}
	// {{{
	public void setCancelUrl(String value) { this.set("cancel_url", (Object)value); }
 	public String getCancelUrl() { return (String)this.get("cancel_url"); }
	// }}}
	// {{{
	public void setFlags(Integer value) { this.set("flags", (Object)value); }
 	public Integer getFlags() { return (Integer)this.get("flags"); }
	// }}}
	// {{{
	public void setTimeCreated(Long value) { this.set("time_created", (Object)value); }
 	public Long getTimeCreated() { return (Long)this.get("time_created"); }
	// }}}
	// {{{
	public void setAllowUnilateral(Boolean value) { this.set("allow_unilateral", (Object)value); }
 	public Boolean getAllowUnilateral() { return (Boolean)this.get("allow_unilateral"); }
	// }}}
	// {{{
	public void setAllowGxo(Boolean value) { this.set("allow_gxo", (Object)value); }
 	public Boolean getAllowGxo() { return (Boolean)this.get("allow_gxo"); }
	// }}}
	// {{{
	public void setSender(APSender value) { this.set("sender", (Object)value); }
 	public APSender getSender() { return (APSender)this.get("sender"); }
	// }}}
	// {{{
	public void setReceiver(List<APReceiver> value) { this.set("receiver", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<APReceiver> getReceiver() { return (List<APReceiver>)this.get("receiver"); }
	// }}}
	// {{{
	public void setFundingType(List<String> value) { this.set("funding_type", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<String> getFundingType() { return (List<String>)this.get("funding_type"); }
	// }}}
	// {{{
	public void setApplicationInfo(com.paypal.money.ApplicationInfoVO value) { this.set("application_info", (Object)value); }
 	public com.paypal.money.ApplicationInfoVO getApplicationInfo() { return (com.paypal.money.ApplicationInfoVO)this.get("application_info"); }
	// }}}
	// {{{
	public void setApSessionInfo(AdaptivePaymentSessionInfoVO value) { this.set("ap_session_info", (Object)value); }
 	public AdaptivePaymentSessionInfoVO getApSessionInfo() { return (AdaptivePaymentSessionInfoVO)this.get("ap_session_info"); }
	// }}}
	// {{{
	public void setPosPinlessInfo(com.paypal.adaptivepayment.POSPinlessInfoVO value) { this.set("pos_pinless_info", (Object)value); }
 	public com.paypal.adaptivepayment.POSPinlessInfoVO getPosPinlessInfo() { return (com.paypal.adaptivepayment.POSPinlessInfoVO)this.get("pos_pinless_info"); }
	// }}}
	// {{{
	public void setPreapprovalFlag(Boolean value) { this.set("preapproval_flag", (Object)value); }
 	public Boolean getPreapprovalFlag() { return (Boolean)this.get("preapproval_flag"); }
	// }}}
	// {{{
	public void setChannelSource(String value) { this.set("channel_source", (Object)value); }
 	public String getChannelSource() { return (String)this.get("channel_source"); }
	// }}}
	// {{{
	public void setStoreAddress(com.paypal.user.AddressVO value) { this.set("store_address", (Object)value); }
 	public com.paypal.user.AddressVO getStoreAddress() { return (com.paypal.user.AddressVO)this.get("store_address"); }
	// }}}
}