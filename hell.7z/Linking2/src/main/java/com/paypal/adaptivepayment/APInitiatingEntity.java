/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AdaptivePaymentCommonParams.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.adaptivepayment;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * Common header for all AdaptivePayment APIs
  * 
  * 2008-02-29
   * @author Rohit Sahney
  */

public class APInitiatingEntity extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((42353*42353)<<32)/*<-APInitiatingEntity*/+
         		65450/*<-institution_customer*/*APInstitutionCustomer.TYPE_SIGNATURE/*<-APInstitutionCustomer*/;
 
	public APInitiatingEntity() {
		super("AdaptivePayment::APInitiatingEntity", TYPE_SIGNATURE);

 
		set("institution_customer", null, "AdaptivePayment::APInstitutionCustomer");
	}

	// {{{
	public void setInstitutionCustomer(APInstitutionCustomer value) { this.set("institution_customer", (Object)value); }
 	public APInstitutionCustomer getInstitutionCustomer() { return (APInstitutionCustomer)this.get("institution_customer"); }
	// }}}
}