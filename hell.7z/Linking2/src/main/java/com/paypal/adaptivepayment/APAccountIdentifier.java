/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AdaptivePaymentCommonParams.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.adaptivepayment;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * Common header for all AdaptivePayment APIs
  * 
  * 2008-02-29
   * @author Rohit Sahney
  */

public class APAccountIdentifier extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((48093*48093)<<32)/*<-APAccountIdentifier*/+
         		10032/*<-alias_type*/*18443/*<-String*/+
         		37849/*<-alias*/*18443/*<-String*/+
         		62145/*<-account_number*/*46168/*<-ullong*/;
 
	public APAccountIdentifier() {
		super("AdaptivePayment::APAccountIdentifier", TYPE_SIGNATURE);

 		addFieldQualifier("alias_type","required","true");
 
		set("alias_type", null, "String");
 		addFieldQualifier("alias","required","true");
 
		set("alias", null, "String");
 		addFieldQualifier("account_number","required","true");
 
		set("account_number", null, "ullong");
	}

	// {{{
	public void setAliasType(String value) { this.set("alias_type", (Object)value); }
 	public String getAliasType() { return (String)this.get("alias_type"); }
	// }}}
	// {{{
	public void setAlias(String value) { this.set("alias", (Object)value); }
 	public String getAlias() { return (String)this.get("alias"); }
	// }}}
	// {{{
	public void setAccountNumber(BigInteger value) { this.set("account_number", (Object)value); }
 	public BigInteger getAccountNumber() { return (BigInteger)this.get("account_number"); }
	// }}}
}