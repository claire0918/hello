/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AdaptivePaymentCommonParams.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.adaptivepayment;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * Common header for all AdaptivePayment APIs
  * 
  * 2008-02-29
   * @author Rohit Sahney
  */

public class APReceiver extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((45200*45200)<<32)/*<-APReceiver*/+
         		35838/*<-account*/*46168/*<-ullong*/+
         		35037/*<-first_name*/*18443/*<-String*/+
         		51561/*<-last_name*/*18443/*<-String*/+
         		20001/*<-business_name*/*18443/*<-String*/+
         		20062/*<-email*/*18443/*<-String*/+
         		13760/*<-email_id*/*46168/*<-ullong*/+
         		15157/*<-phone*/*com.paypal.user.PhoneVO.TYPE_SIGNATURE/*<-User::PhoneVO*/+
         		60232/*<-flags*/*38894/*<-int*/+
         		42340/*<-role_type*/*46168/*<-ullong*/+
         		2919/*<-pay_amount*/*APPayAmount.TYPE_SIGNATURE/*<-APPayAmount*/+
         		4866/*<-account_type*/*33490/*<-ulong*/+
         		49817/*<-invoice_id*/*18443/*<-String*/+
         		27570/*<-payment_type*/*37752/*<-char*/+
         		22100/*<-payment_sub_type*/*18443/*<-String*/+
         		37849/*<-alias*/*18443/*<-String*/+
         		10032/*<-alias_type*/*37752/*<-char*/+
         		930/*<-user_group*/*38894/*<-int*/+
         		1165/*<-internal_non_standard_primary_reference*/*18443/*<-String*/+
         		34913/*<-idempotency_id*/*18443/*<-String*/;
 
	public APReceiver() {
		super("AdaptivePayment::APReceiver", TYPE_SIGNATURE);

 
		set("account", null, "ullong");
 
		set("first_name", null, "String");
 
		set("last_name", null, "String");
 
		set("business_name", null, "String");
 
		set("email", null, "String");
 
		set("email_id", null, "ullong");
 
		set("phone", null, "User::PhoneVO");
 
		set("flags", null, "int");
 
		set("role_type", null, "ullong");
 
		set("pay_amount", null, "AdaptivePayment::APPayAmount");
 
		set("account_type", null, "ulong");
 
		set("invoice_id", null, "String");
 
		set("payment_type", null, "char");
 
		set("payment_sub_type", null, "String");
 
		set("alias", null, "String");
 
		set("alias_type", null, "char");
 
		set("user_group", null, "int");
 
		set("internal_non_standard_primary_reference", null, "String");
 		addFieldQualifier("idempotency_id","required","false");
 
		set("idempotency_id", null, "String");
	}

	// {{{
	public void setAccount(BigInteger value) { this.set("account", (Object)value); }
 	public BigInteger getAccount() { return (BigInteger)this.get("account"); }
	// }}}
	// {{{
	public void setFirstName(String value) { this.set("first_name", (Object)value); }
 	public String getFirstName() { return (String)this.get("first_name"); }
	// }}}
	// {{{
	public void setLastName(String value) { this.set("last_name", (Object)value); }
 	public String getLastName() { return (String)this.get("last_name"); }
	// }}}
	// {{{
	public void setBusinessName(String value) { this.set("business_name", (Object)value); }
 	public String getBusinessName() { return (String)this.get("business_name"); }
	// }}}
	// {{{
	public void setEmail(String value) { this.set("email", (Object)value); }
 	public String getEmail() { return (String)this.get("email"); }
	// }}}
	// {{{
	public void setEmailId(BigInteger value) { this.set("email_id", (Object)value); }
 	public BigInteger getEmailId() { return (BigInteger)this.get("email_id"); }
	// }}}
	// {{{
	public void setPhone(com.paypal.user.PhoneVO value) { this.set("phone", (Object)value); }
 	public com.paypal.user.PhoneVO getPhone() { return (com.paypal.user.PhoneVO)this.get("phone"); }
	// }}}
	// {{{
	public void setFlags(Integer value) { this.set("flags", (Object)value); }
 	public Integer getFlags() { return (Integer)this.get("flags"); }
	// }}}
	// {{{
	public void setRoleType(BigInteger value) { this.set("role_type", (Object)value); }
 	public BigInteger getRoleType() { return (BigInteger)this.get("role_type"); }
	// }}}
	// {{{
	public void setPayAmount(APPayAmount value) { this.set("pay_amount", (Object)value); }
 	public APPayAmount getPayAmount() { return (APPayAmount)this.get("pay_amount"); }
	// }}}
	// {{{
	public void setAccountType(Long value) { this.set("account_type", (Object)value); }
 	public Long getAccountType() { return (Long)this.get("account_type"); }
	// }}}
	// {{{
	public void setInvoiceId(String value) { this.set("invoice_id", (Object)value); }
 	public String getInvoiceId() { return (String)this.get("invoice_id"); }
	// }}}
	// {{{
	public void setPaymentType(Byte value) { this.set("payment_type", (Object)value); }
 	public Byte getPaymentType() { return (Byte)this.get("payment_type"); }
	// }}}
	// {{{
	public void setPaymentSubType(String value) { this.set("payment_sub_type", (Object)value); }
 	public String getPaymentSubType() { return (String)this.get("payment_sub_type"); }
	// }}}
	// {{{
	public void setAlias(String value) { this.set("alias", (Object)value); }
 	public String getAlias() { return (String)this.get("alias"); }
	// }}}
	// {{{
	public void setAliasType(Byte value) { this.set("alias_type", (Object)value); }
 	public Byte getAliasType() { return (Byte)this.get("alias_type"); }
	// }}}
	// {{{
	public void setUserGroup(Integer value) { this.set("user_group", (Object)value); }
 	public Integer getUserGroup() { return (Integer)this.get("user_group"); }
	// }}}
	// {{{
	public void setInternalNonStandardPrimaryReference(String value) { this.set("internal_non_standard_primary_reference", (Object)value); }
 	public String getInternalNonStandardPrimaryReference() { return (String)this.get("internal_non_standard_primary_reference"); }
	// }}}
	// {{{
	public void setIdempotencyId(String value) { this.set("idempotency_id", (Object)value); }
 	public String getIdempotencyId() { return (String)this.get("idempotency_id"); }
	// }}}
}