/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AdaptivePaymentCommonParams.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.adaptivepayment;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * Common header for all AdaptivePayment APIs
  * 
  * 2008-02-29
   * @author Rohit Sahney
  */

public class APPaymentExecRequest extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((3526*3526)<<32)/*<-APPaymentExecRequest*/+
         		13141/*<-preapproval_key*/*18443/*<-String*/+
         		52543/*<-status*/*37752/*<-char*/+
         		14838/*<-activities*/*47/*<-repeating*/*APPaymentExecActivity.TYPE_SIGNATURE/*<-APPaymentExecActivity*/;
 
	public APPaymentExecRequest() {
		super("AdaptivePayment::APPaymentExecRequest", TYPE_SIGNATURE);

 
		set("preapproval_key", null, "String");
 
		set("status", null, "char");
 
		set("activities", null, "List<AdaptivePayment::APPaymentExecActivity>");
	}

	// {{{
	public void setPreapprovalKey(String value) { this.set("preapproval_key", (Object)value); }
 	public String getPreapprovalKey() { return (String)this.get("preapproval_key"); }
	// }}}
	// {{{
	public void setStatus(Byte value) { this.set("status", (Object)value); }
 	public Byte getStatus() { return (Byte)this.get("status"); }
	// }}}
	// {{{
	public void setActivities(List<APPaymentExecActivity> value) { this.set("activities", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<APPaymentExecActivity> getActivities() { return (List<APPaymentExecActivity>)this.get("activities"); }
	// }}}
}