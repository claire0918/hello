/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AdaptivePaymentCommonParams.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.adaptivepayment;

import java.math.BigInteger;

  
public enum ActionType {
/**
			Payment action for each leg of the Adaptive Payment. It's a verb.
		*/
   	CREATE(new String("CREATE"), ""),
   	PAY(new String("PAY"), ""),
   	AUTH(new String("AUTH"), ""),
   	RECORD(new String("RECORD"), "");

	private final String value;
	private final String desc;

	private ActionType(String value, String desc) {
		this.value = value;
		this.desc  = desc;
	}

	public String getValue() {
		return value;
	}

	public String getDesc() {
		return desc;
	}
}
