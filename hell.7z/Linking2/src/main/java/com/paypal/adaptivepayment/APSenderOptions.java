/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AdaptivePaymentCommonParams.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.adaptivepayment;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * Common header for all AdaptivePayment APIs
  * 
  * 2008-02-29
   * @author Rohit Sahney
  */

public class APSenderOptions extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((15914*15914)<<32)/*<-APSenderOptions*/+
         		47048/*<-requireShippingAddressSelection*/*15044/*<-bool*/+
         		37851/*<-shipping_address*/*com.paypal.user.AddressVO.TYPE_SIGNATURE/*<-User::AddressVO*/+
         		28251/*<-validate_shipping_address*/*15044/*<-bool*/+
         		47876/*<-save_shipping_address*/*15044/*<-bool*/;
 
	public APSenderOptions() {
		super("AdaptivePayment::APSenderOptions", TYPE_SIGNATURE);

 
		set("requireShippingAddressSelection", null, "bool");
 
		set("shipping_address", null, "User::AddressVO");
 
		set("validate_shipping_address", null, "bool");
 
		set("save_shipping_address", null, "bool");
	}

	// {{{
	public void setRequireShippingAddressSelection(Boolean value) { this.set("requireShippingAddressSelection", (Object)value); }
 	public Boolean getRequireShippingAddressSelection() { return (Boolean)this.get("requireShippingAddressSelection"); }
	// }}}
	// {{{
	public void setShippingAddress(com.paypal.user.AddressVO value) { this.set("shipping_address", (Object)value); }
 	public com.paypal.user.AddressVO getShippingAddress() { return (com.paypal.user.AddressVO)this.get("shipping_address"); }
	// }}}
	// {{{
	public void setValidateShippingAddress(Boolean value) { this.set("validate_shipping_address", (Object)value); }
 	public Boolean getValidateShippingAddress() { return (Boolean)this.get("validate_shipping_address"); }
	// }}}
	// {{{
	public void setSaveShippingAddress(Boolean value) { this.set("save_shipping_address", (Object)value); }
 	public Boolean getSaveShippingAddress() { return (Boolean)this.get("save_shipping_address"); }
	// }}}
}