/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AdaptivePaymentCommonParams.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.adaptivepayment;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * Common header for all AdaptivePayment APIs
  * 
  * 2008-02-29
   * @author Rohit Sahney
  */

public class APSender extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((60615*60615)<<32)/*<-APSender*/+
         		35838/*<-account*/*46168/*<-ullong*/+
         		20062/*<-email*/*18443/*<-String*/+
         		13760/*<-email_id*/*46168/*<-ullong*/+
         		15157/*<-phone*/*com.paypal.user.PhoneVO.TYPE_SIGNATURE/*<-User::PhoneVO*/+
         		17324/*<-display_name*/*18443/*<-String*/+
         		60232/*<-flags*/*38894/*<-int*/+
         		930/*<-user_group*/*38894/*<-int*/+
         		1165/*<-internal_non_standard_primary_reference*/*18443/*<-String*/;
 
	public APSender() {
		super("AdaptivePayment::APSender", TYPE_SIGNATURE);

 
		set("account", null, "ullong");
 
		set("email", null, "String");
 
		set("email_id", null, "ullong");
 
		set("phone", null, "User::PhoneVO");
 
		set("display_name", null, "String");
 
		set("flags", null, "int");
 
		set("user_group", null, "int");
 
		set("internal_non_standard_primary_reference", null, "String");
	}

	// {{{
	public void setAccount(BigInteger value) { this.set("account", (Object)value); }
 	public BigInteger getAccount() { return (BigInteger)this.get("account"); }
	// }}}
	// {{{
	public void setEmail(String value) { this.set("email", (Object)value); }
 	public String getEmail() { return (String)this.get("email"); }
	// }}}
	// {{{
	public void setEmailId(BigInteger value) { this.set("email_id", (Object)value); }
 	public BigInteger getEmailId() { return (BigInteger)this.get("email_id"); }
	// }}}
	// {{{
	public void setPhone(com.paypal.user.PhoneVO value) { this.set("phone", (Object)value); }
 	public com.paypal.user.PhoneVO getPhone() { return (com.paypal.user.PhoneVO)this.get("phone"); }
	// }}}
	// {{{
	public void setDisplayName(String value) { this.set("display_name", (Object)value); }
 	public String getDisplayName() { return (String)this.get("display_name"); }
	// }}}
	// {{{
	public void setFlags(Integer value) { this.set("flags", (Object)value); }
 	public Integer getFlags() { return (Integer)this.get("flags"); }
	// }}}
	// {{{
	public void setUserGroup(Integer value) { this.set("user_group", (Object)value); }
 	public Integer getUserGroup() { return (Integer)this.get("user_group"); }
	// }}}
	// {{{
	public void setInternalNonStandardPrimaryReference(String value) { this.set("internal_non_standard_primary_reference", (Object)value); }
 	public String getInternalNonStandardPrimaryReference() { return (String)this.get("internal_non_standard_primary_reference"); }
	// }}}
}