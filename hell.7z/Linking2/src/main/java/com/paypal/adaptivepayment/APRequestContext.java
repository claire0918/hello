/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AdaptivePaymentCommonParams.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.adaptivepayment;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * Common header for all AdaptivePayment APIs
  * 
  * 2008-02-29
   * @author Rohit Sahney
  */

public class APRequestContext extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((729*729)<<32)/*<-APRequestContext*/+
         		52982/*<-channel_source*/*18443/*<-String*/+
         		60054/*<-actor_account_number*/*46168/*<-ullong*/+
         		11160/*<-actor_session_id*/*18443/*<-String*/+
         		34964/*<-subject_account_number*/*46168/*<-ullong*/+
         		43309/*<-application_id*/*18443/*<-String*/+
         		9181/*<-entry_point*/*18443/*<-String*/;
 
	public APRequestContext() {
		super("AdaptivePayment::APRequestContext", TYPE_SIGNATURE);

 		addFieldQualifier("channel_source","required","true");
 
		set("channel_source", null, "String");
 		addFieldQualifier("actor_account_number","required","true");
 
		set("actor_account_number", null, "ullong");
 		addFieldQualifier("actor_session_id","required","true");
 
		set("actor_session_id", null, "String");
 		addFieldQualifier("subject_account_number","required","true");
 
		set("subject_account_number", null, "ullong");
 		addFieldQualifier("application_id","required","true");
 
		set("application_id", null, "String");
 		addFieldQualifier("entry_point","required","false");
 
		set("entry_point", null, "String");
	}

	// {{{
	public void setChannelSource(String value) { this.set("channel_source", (Object)value); }
 	public String getChannelSource() { return (String)this.get("channel_source"); }
	// }}}
	// {{{
	public void setActorAccountNumber(BigInteger value) { this.set("actor_account_number", (Object)value); }
 	public BigInteger getActorAccountNumber() { return (BigInteger)this.get("actor_account_number"); }
	// }}}
	// {{{
	public void setActorSessionId(String value) { this.set("actor_session_id", (Object)value); }
 	public String getActorSessionId() { return (String)this.get("actor_session_id"); }
	// }}}
	// {{{
	public void setSubjectAccountNumber(BigInteger value) { this.set("subject_account_number", (Object)value); }
 	public BigInteger getSubjectAccountNumber() { return (BigInteger)this.get("subject_account_number"); }
	// }}}
	// {{{
	public void setApplicationId(String value) { this.set("application_id", (Object)value); }
 	public String getApplicationId() { return (String)this.get("application_id"); }
	// }}}
	// {{{
	public void setEntryPoint(String value) { this.set("entry_point", (Object)value); }
 	public String getEntryPoint() { return (String)this.get("entry_point"); }
	// }}}
}