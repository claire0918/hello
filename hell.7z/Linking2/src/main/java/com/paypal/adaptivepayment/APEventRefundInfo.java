/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AdaptivePaymentCommonParams.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.adaptivepayment;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * Common header for all AdaptivePayment APIs
  * 
  * 2008-02-29
   * @author Rohit Sahney
  */

public class APEventRefundInfo extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((64477*64477)<<32)/*<-APEventRefundInfo*/+
         		233/*<-activity_id_encrypted*/*18443/*<-String*/+
         		11159/*<-parent_activity_id*/*46168/*<-ullong*/+
         		36953/*<-refund_amount*/*APPayAmount.TYPE_SIGNATURE/*<-APPayAmount*/+
         		4357/*<-parent_activity_id_encrypted*/*18443/*<-String*/+
         		51226/*<-email_charged*/*18443/*<-String*/;
 
	public APEventRefundInfo() {
		super("AdaptivePayment::APEventRefundInfo", TYPE_SIGNATURE);

 
		set("activity_id_encrypted", null, "String");
 
		set("parent_activity_id", null, "ullong");
 
		set("refund_amount", null, "AdaptivePayment::APPayAmount");
 
		set("parent_activity_id_encrypted", null, "String");
 
		set("email_charged", null, "String");
	}

	// {{{
	public void setActivityIdEncrypted(String value) { this.set("activity_id_encrypted", (Object)value); }
 	public String getActivityIdEncrypted() { return (String)this.get("activity_id_encrypted"); }
	// }}}
	// {{{
	public void setParentActivityId(BigInteger value) { this.set("parent_activity_id", (Object)value); }
 	public BigInteger getParentActivityId() { return (BigInteger)this.get("parent_activity_id"); }
	// }}}
	// {{{
	public void setRefundAmount(APPayAmount value) { this.set("refund_amount", (Object)value); }
 	public APPayAmount getRefundAmount() { return (APPayAmount)this.get("refund_amount"); }
	// }}}
	// {{{
	public void setParentActivityIdEncrypted(String value) { this.set("parent_activity_id_encrypted", (Object)value); }
 	public String getParentActivityIdEncrypted() { return (String)this.get("parent_activity_id_encrypted"); }
	// }}}
	// {{{
	public void setEmailCharged(String value) { this.set("email_charged", (Object)value); }
 	public String getEmailCharged() { return (String)this.get("email_charged"); }
	// }}}
}