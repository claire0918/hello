/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AdaptivePaymentCommonParams.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.adaptivepayment;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * Common header for all AdaptivePayment APIs
  * 
  * 2008-02-29
   * @author Rohit Sahney
  */

public class APUser extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((48096*48096)<<32)/*<-APUser*/+
         		35838/*<-account*/*46168/*<-ullong*/+
         		4866/*<-account_type*/*33490/*<-ulong*/+
         		7283/*<-account_id*/*18443/*<-String*/+
         		20062/*<-email*/*18443/*<-String*/+
         		56164/*<-email_type*/*37752/*<-char*/+
         		13760/*<-email_id*/*46168/*<-ullong*/+
         		15157/*<-phone*/*com.paypal.user.PhoneVO.TYPE_SIGNATURE/*<-User::PhoneVO*/+
         		35037/*<-first_name*/*18443/*<-String*/+
         		51561/*<-last_name*/*18443/*<-String*/+
         		20001/*<-business_name*/*18443/*<-String*/+
         		17324/*<-display_name*/*18443/*<-String*/+
         		60232/*<-flags*/*38894/*<-int*/+
         		930/*<-user_group*/*38894/*<-int*/+
         		1165/*<-internal_non_standard_primary_reference*/*18443/*<-String*/;
 
	public APUser() {
		super("AdaptivePayment::APUser", TYPE_SIGNATURE);

 
		set("account", null, "ullong");
 
		set("account_type", null, "ulong");
 
		set("account_id", null, "String");
 
		set("email", null, "String");
 
		set("email_type", null, "char");
 
		set("email_id", null, "ullong");
 
		set("phone", null, "User::PhoneVO");
 
		set("first_name", null, "String");
 
		set("last_name", null, "String");
 
		set("business_name", null, "String");
 
		set("display_name", null, "String");
 
		set("flags", null, "int");
 
		set("user_group", null, "int");
 
		set("internal_non_standard_primary_reference", null, "String");
	}

	// {{{
	public void setAccount(BigInteger value) { this.set("account", (Object)value); }
 	public BigInteger getAccount() { return (BigInteger)this.get("account"); }
	// }}}
	// {{{
	public void setAccountType(Long value) { this.set("account_type", (Object)value); }
 	public Long getAccountType() { return (Long)this.get("account_type"); }
	// }}}
	// {{{
	public void setAccountId(String value) { this.set("account_id", (Object)value); }
 	public String getAccountId() { return (String)this.get("account_id"); }
	// }}}
	// {{{
	public void setEmail(String value) { this.set("email", (Object)value); }
 	public String getEmail() { return (String)this.get("email"); }
	// }}}
	// {{{
	public void setEmailType(Byte value) { this.set("email_type", (Object)value); }
 	public Byte getEmailType() { return (Byte)this.get("email_type"); }
	// }}}
	// {{{
	public void setEmailId(BigInteger value) { this.set("email_id", (Object)value); }
 	public BigInteger getEmailId() { return (BigInteger)this.get("email_id"); }
	// }}}
	// {{{
	public void setPhone(com.paypal.user.PhoneVO value) { this.set("phone", (Object)value); }
 	public com.paypal.user.PhoneVO getPhone() { return (com.paypal.user.PhoneVO)this.get("phone"); }
	// }}}
	// {{{
	public void setFirstName(String value) { this.set("first_name", (Object)value); }
 	public String getFirstName() { return (String)this.get("first_name"); }
	// }}}
	// {{{
	public void setLastName(String value) { this.set("last_name", (Object)value); }
 	public String getLastName() { return (String)this.get("last_name"); }
	// }}}
	// {{{
	public void setBusinessName(String value) { this.set("business_name", (Object)value); }
 	public String getBusinessName() { return (String)this.get("business_name"); }
	// }}}
	// {{{
	public void setDisplayName(String value) { this.set("display_name", (Object)value); }
 	public String getDisplayName() { return (String)this.get("display_name"); }
	// }}}
	// {{{
	public void setFlags(Integer value) { this.set("flags", (Object)value); }
 	public Integer getFlags() { return (Integer)this.get("flags"); }
	// }}}
	// {{{
	public void setUserGroup(Integer value) { this.set("user_group", (Object)value); }
 	public Integer getUserGroup() { return (Integer)this.get("user_group"); }
	// }}}
	// {{{
	public void setInternalNonStandardPrimaryReference(String value) { this.set("internal_non_standard_primary_reference", (Object)value); }
 	public String getInternalNonStandardPrimaryReference() { return (String)this.get("internal_non_standard_primary_reference"); }
	// }}}
}