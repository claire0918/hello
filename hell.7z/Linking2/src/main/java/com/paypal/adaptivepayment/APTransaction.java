/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AdaptivePaymentCommonParams.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.adaptivepayment;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * Common header for all AdaptivePayment APIs
  * 
  * 2008-02-29
   * @author Rohit Sahney
  */

public class APTransaction extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((52989*52989)<<32)/*<-APTransaction*/+
         		32025/*<-action*/*18443/*<-String*/+
         		21474/*<-amount*/*21015/*<-Currency*/+
         		6197/*<-sender*/*APAccountIdentifier.TYPE_SIGNATURE/*<-APAccountIdentifier*/+
         		60964/*<-receiver*/*APAccountIdentifier.TYPE_SIGNATURE/*<-APAccountIdentifier*/+
         		34913/*<-idempotency_id*/*18443/*<-String*/+
         		36620/*<-type*/*18443/*<-String*/+
         		30165/*<-sub_type*/*18443/*<-String*/+
         		24243/*<-invoice_data*/*APInvoiceData.TYPE_SIGNATURE/*<-APInvoiceData*/+
         		44447/*<-initiating_entity*/*APInitiatingEntity.TYPE_SIGNATURE/*<-APInitiatingEntity*/+
         		17171/*<-sender_options*/*APSenderOptions.TYPE_SIGNATURE/*<-APSenderOptions*/+
         		13126/*<-funding_constraints*/*APFundingConstraints.TYPE_SIGNATURE/*<-APFundingConstraints*/+
         		24223/*<-is_forced_post*/*15044/*<-bool*/+
         		33481/*<-description*/*18443/*<-String*/+
         		6034/*<-opaque_data*/*47/*<-repeating*/*com.paypal.common.OpaqueDataElementVO.TYPE_SIGNATURE/*<-Common::OpaqueDataElementVO*/;
 
	public APTransaction() {
		super("AdaptivePayment::APTransaction", TYPE_SIGNATURE);

 		addFieldQualifier("action","required","true");
 
		set("action", null, "String");
 		addFieldQualifier("amount","required","true");
 
		set("amount", null, "Currency");
 		addFieldQualifier("sender","required","true");
 
		set("sender", null, "AdaptivePayment::APAccountIdentifier");
 		addFieldQualifier("receiver","required","true");
 
		set("receiver", null, "AdaptivePayment::APAccountIdentifier");
 		addFieldQualifier("idempotency_id","required","false");
 
		set("idempotency_id", null, "String");
 		addFieldQualifier("type","required","true");
 
		set("type", null, "String");
 
		set("sub_type", null, "String");
 
		set("invoice_data", null, "AdaptivePayment::APInvoiceData");
 
		set("initiating_entity", null, "AdaptivePayment::APInitiatingEntity");
 
		set("sender_options", null, "AdaptivePayment::APSenderOptions");
 
		set("funding_constraints", null, "AdaptivePayment::APFundingConstraints");
 
		set("is_forced_post", null, "bool");
 
		set("description", null, "String");
 
		set("opaque_data", null, "List<Common::OpaqueDataElementVO>");
	}

	// {{{
	public void setAction(String value) { this.set("action", (Object)value); }
 	public String getAction() { return (String)this.get("action"); }
	// }}}
	// {{{
	public void setAmount(Currency value) { this.set("amount", (Object)value); }
 	public Currency getAmount() { return (Currency)this.get("amount"); }
	// }}}
	// {{{
	public void setSender(APAccountIdentifier value) { this.set("sender", (Object)value); }
 	public APAccountIdentifier getSender() { return (APAccountIdentifier)this.get("sender"); }
	// }}}
	// {{{
	public void setReceiver(APAccountIdentifier value) { this.set("receiver", (Object)value); }
 	public APAccountIdentifier getReceiver() { return (APAccountIdentifier)this.get("receiver"); }
	// }}}
	// {{{
	public void setIdempotencyId(String value) { this.set("idempotency_id", (Object)value); }
 	public String getIdempotencyId() { return (String)this.get("idempotency_id"); }
	// }}}
	// {{{
	public void setType(String value) { this.set("type", (Object)value); }
 	public String getType() { return (String)this.get("type"); }
	// }}}
	// {{{
	public void setSubType(String value) { this.set("sub_type", (Object)value); }
 	public String getSubType() { return (String)this.get("sub_type"); }
	// }}}
	// {{{
	public void setInvoiceData(APInvoiceData value) { this.set("invoice_data", (Object)value); }
 	public APInvoiceData getInvoiceData() { return (APInvoiceData)this.get("invoice_data"); }
	// }}}
	// {{{
	public void setInitiatingEntity(APInitiatingEntity value) { this.set("initiating_entity", (Object)value); }
 	public APInitiatingEntity getInitiatingEntity() { return (APInitiatingEntity)this.get("initiating_entity"); }
	// }}}
	// {{{
	public void setSenderOptions(APSenderOptions value) { this.set("sender_options", (Object)value); }
 	public APSenderOptions getSenderOptions() { return (APSenderOptions)this.get("sender_options"); }
	// }}}
	// {{{
	public void setFundingConstraints(APFundingConstraints value) { this.set("funding_constraints", (Object)value); }
 	public APFundingConstraints getFundingConstraints() { return (APFundingConstraints)this.get("funding_constraints"); }
	// }}}
	// {{{
	public void setIsForcedPost(Boolean value) { this.set("is_forced_post", (Object)value); }
 	public Boolean getIsForcedPost() { return (Boolean)this.get("is_forced_post"); }
	// }}}
	// {{{
	public void setDescription(String value) { this.set("description", (Object)value); }
 	public String getDescription() { return (String)this.get("description"); }
	// }}}
	// {{{
	public void setOpaqueData(List<com.paypal.common.OpaqueDataElementVO> value) { this.set("opaque_data", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<com.paypal.common.OpaqueDataElementVO> getOpaqueData() { return (List<com.paypal.common.OpaqueDataElementVO>)this.get("opaque_data"); }
	// }}}
}