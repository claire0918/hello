/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AdaptivePaymentCommonParams.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.adaptivepayment;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * Common header for all AdaptivePayment APIs
  * 
  * 2008-02-29
   * @author Rohit Sahney
  */

public class AdaptivePaymentSessionInfoVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((58839*58839)<<32)/*<-AdaptivePaymentSessionInfoVO*/+
         		15945/*<-caller_session_id*/*18443/*<-String*/+
         		5073/*<-sender_session_id*/*18443/*<-String*/+
         		24478/*<-secondary_sender_ip*/*18443/*<-String*/;
 
	public AdaptivePaymentSessionInfoVO() {
		super("AdaptivePayment::AdaptivePaymentSessionInfoVO", TYPE_SIGNATURE);

 
		set("caller_session_id", null, "String");
 
		set("sender_session_id", null, "String");
 
		set("secondary_sender_ip", null, "String");
	}

	// {{{
	public void setCallerSessionId(String value) { this.set("caller_session_id", (Object)value); }
 	public String getCallerSessionId() { return (String)this.get("caller_session_id"); }
	// }}}
	// {{{
	public void setSenderSessionId(String value) { this.set("sender_session_id", (Object)value); }
 	public String getSenderSessionId() { return (String)this.get("sender_session_id"); }
	// }}}
	// {{{
	public void setSecondarySenderIp(String value) { this.set("secondary_sender_ip", (Object)value); }
 	public String getSecondarySenderIp() { return (String)this.get("secondary_sender_ip"); }
	// }}}
}