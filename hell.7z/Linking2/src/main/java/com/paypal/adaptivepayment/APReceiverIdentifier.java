/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AdaptivePaymentCommonParams.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.adaptivepayment;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * Common header for all AdaptivePayment APIs
  * 
  * 2008-02-29
   * @author Rohit Sahney
  */

public class APReceiverIdentifier extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((52532*52532)<<32)/*<-APReceiverIdentifier*/+
         		20062/*<-email*/*18443/*<-String*/+
         		15157/*<-phone*/*18443/*<-String*/;
 
	public APReceiverIdentifier() {
		super("AdaptivePayment::APReceiverIdentifier", TYPE_SIGNATURE);

 
		set("email", null, "String");
 
		set("phone", null, "String");
	}

	// {{{
	public void setEmail(String value) { this.set("email", (Object)value); }
 	public String getEmail() { return (String)this.get("email"); }
	// }}}
	// {{{
	public void setPhone(String value) { this.set("phone", (Object)value); }
 	public String getPhone() { return (String)this.get("phone"); }
	// }}}
}