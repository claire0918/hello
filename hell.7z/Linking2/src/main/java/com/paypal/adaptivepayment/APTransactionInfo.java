/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AdaptivePaymentCommonParams.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.adaptivepayment;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * Common header for all AdaptivePayment APIs
  * 
  * 2008-02-29
   * @author Rohit Sahney
  */

public class APTransactionInfo extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((30961*30961)<<32)/*<-APTransactionInfo*/+
         		46437/*<-encrypted_id*/*18443/*<-String*/+
         		52543/*<-status*/*18443/*<-String*/+
         		23254/*<-pending_reason*/*18443/*<-String*/+
         		4965/*<-raw_status*/*37752/*<-char*/;
 
	public APTransactionInfo() {
		super("AdaptivePayment::APTransactionInfo", TYPE_SIGNATURE);

 
		set("encrypted_id", null, "String");
 
		set("status", null, "String");
 
		set("pending_reason", null, "String");
 
		set("raw_status", null, "char");
	}

	// {{{
	public void setEncryptedId(String value) { this.set("encrypted_id", (Object)value); }
 	public String getEncryptedId() { return (String)this.get("encrypted_id"); }
	// }}}
	// {{{
	public void setStatus(String value) { this.set("status", (Object)value); }
 	public String getStatus() { return (String)this.get("status"); }
	// }}}
	// {{{
	public void setPendingReason(String value) { this.set("pending_reason", (Object)value); }
 	public String getPendingReason() { return (String)this.get("pending_reason"); }
	// }}}
	// {{{
	public void setRawStatus(Byte value) { this.set("raw_status", (Object)value); }
 	public Byte getRawStatus() { return (Byte)this.get("raw_status"); }
	// }}}
}