/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AdaptivePaymentCommonParams.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.adaptivepayment;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * Common header for all AdaptivePayment APIs
  * 
  * 2008-02-29
   * @author Rohit Sahney
  */

public class APNotificationControl extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((51102*51102)<<32)/*<-APNotificationControl*/+
         		9887/*<-ipn_url*/*18443/*<-String*/+
         		36623/*<-email_header_image_url*/*18443/*<-String*/+
         		15608/*<-email_marketing_image_url*/*18443/*<-String*/+
         		18878/*<-header_image_url*/*18443/*<-String*/+
         		20001/*<-business_name*/*18443/*<-String*/;
 
	public APNotificationControl() {
		super("AdaptivePayment::APNotificationControl", TYPE_SIGNATURE);

 
		set("ipn_url", null, "String");
 
		set("email_header_image_url", null, "String");
 
		set("email_marketing_image_url", null, "String");
 
		set("header_image_url", null, "String");
 
		set("business_name", null, "String");
	}

	// {{{
	public void setIpnUrl(String value) { this.set("ipn_url", (Object)value); }
 	public String getIpnUrl() { return (String)this.get("ipn_url"); }
	// }}}
	// {{{
	public void setEmailHeaderImageUrl(String value) { this.set("email_header_image_url", (Object)value); }
 	public String getEmailHeaderImageUrl() { return (String)this.get("email_header_image_url"); }
	// }}}
	// {{{
	public void setEmailMarketingImageUrl(String value) { this.set("email_marketing_image_url", (Object)value); }
 	public String getEmailMarketingImageUrl() { return (String)this.get("email_marketing_image_url"); }
	// }}}
	// {{{
	public void setHeaderImageUrl(String value) { this.set("header_image_url", (Object)value); }
 	public String getHeaderImageUrl() { return (String)this.get("header_image_url"); }
	// }}}
	// {{{
	public void setBusinessName(String value) { this.set("business_name", (Object)value); }
 	public String getBusinessName() { return (String)this.get("business_name"); }
	// }}}
}