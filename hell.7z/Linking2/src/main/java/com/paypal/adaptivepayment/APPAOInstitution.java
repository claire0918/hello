/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AdaptivePaymentCommonParams.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.adaptivepayment;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * Common header for all AdaptivePayment APIs
  * 
  * 2008-02-29
   * @author Rohit Sahney
  */

public class APPAOInstitution extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((36826*36826)<<32)/*<-APPAOInstitution*/+
         		3355/*<-id*/*18443/*<-String*/+
         		1143/*<-row_version*/*46168/*<-ullong*/+
         		32291/*<-aggregator_account_number*/*46168/*<-ullong*/+
         		31416/*<-name*/*18443/*<-String*/+
         		52543/*<-status*/*18443/*<-String*/+
         		42850/*<-contact_name*/*18443/*<-String*/+
         		11652/*<-contact_phone*/*18443/*<-String*/+
         		15055/*<-contact_email*/*18443/*<-String*/+
         		34138/*<-block_img_url*/*15044/*<-bool*/;
 
	public APPAOInstitution() {
		super("AdaptivePayment::APPAOInstitution", TYPE_SIGNATURE);

 
		set("id", null, "String");
 
		set("row_version", null, "ullong");
 
		set("aggregator_account_number", null, "ullong");
 
		set("name", null, "String");
 
		set("status", null, "String");
 
		set("contact_name", null, "String");
 
		set("contact_phone", null, "String");
 
		set("contact_email", null, "String");
 
		set("block_img_url", null, "bool");
	}

	// {{{
	public void setId(String value) { this.set("id", (Object)value); }
 	public String getId() { return (String)this.get("id"); }
	// }}}
	// {{{
	public void setRowVersion(BigInteger value) { this.set("row_version", (Object)value); }
 	public BigInteger getRowVersion() { return (BigInteger)this.get("row_version"); }
	// }}}
	// {{{
	public void setAggregatorAccountNumber(BigInteger value) { this.set("aggregator_account_number", (Object)value); }
 	public BigInteger getAggregatorAccountNumber() { return (BigInteger)this.get("aggregator_account_number"); }
	// }}}
	// {{{
	public void setName(String value) { this.set("name", (Object)value); }
 	public String getName() { return (String)this.get("name"); }
	// }}}
	// {{{
	public void setStatus(String value) { this.set("status", (Object)value); }
 	public String getStatus() { return (String)this.get("status"); }
	// }}}
	// {{{
	public void setContactName(String value) { this.set("contact_name", (Object)value); }
 	public String getContactName() { return (String)this.get("contact_name"); }
	// }}}
	// {{{
	public void setContactPhone(String value) { this.set("contact_phone", (Object)value); }
 	public String getContactPhone() { return (String)this.get("contact_phone"); }
	// }}}
	// {{{
	public void setContactEmail(String value) { this.set("contact_email", (Object)value); }
 	public String getContactEmail() { return (String)this.get("contact_email"); }
	// }}}
	// {{{
	public void setBlockImgUrl(Boolean value) { this.set("block_img_url", (Object)value); }
 	public Boolean getBlockImgUrl() { return (Boolean)this.get("block_img_url"); }
	// }}}
}