/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AdaptivePaymentCommonParams.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.adaptivepayment;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * Common header for all AdaptivePayment APIs
  * 
  * 2008-02-29
   * @author Rohit Sahney
  */

public class APInvoiceItem extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((55034*55034)<<32)/*<-APInvoiceItem*/+
         		31416/*<-name*/*18443/*<-String*/+
         		43809/*<-identifier*/*18443/*<-String*/+
         		46870/*<-price*/*APPayAmount.TYPE_SIGNATURE/*<-APPayAmount*/+
         		21672/*<-count*/*33490/*<-ulong*/+
         		43333/*<-count_double*/*31526/*<-double*/+
         		27876/*<-total_price*/*APPayAmount.TYPE_SIGNATURE/*<-APPayAmount*/+
         		33572/*<-taxable*/*15044/*<-bool*/+
         		45514/*<-reimbursable*/*15044/*<-bool*/+
         		34643/*<-ean*/*18443/*<-String*/+
         		48412/*<-sku*/*18443/*<-String*/+
         		33481/*<-description*/*18443/*<-String*/+
         		50647/*<-return_policy_identifier*/*18443/*<-String*/+
         		29961/*<-discount*/*47/*<-repeating*/*APDiscountInfo.TYPE_SIGNATURE/*<-APDiscountInfo*/+
         		59552/*<-itemCountUnit*/*38894/*<-int*/+
         		42794/*<-mpn*/*18443/*<-String*/+
         		30407/*<-isbn*/*18443/*<-String*/+
         		45560/*<-plu*/*18443/*<-String*/+
         		64378/*<-modelNumber*/*18443/*<-String*/+
         		6580/*<-styleNumber*/*18443/*<-String*/+
         		47025/*<-taxRate*/*31526/*<-double*/+
         		58271/*<-additionalFees*/*47/*<-repeating*/*APAdditionalFeeInfo.TYPE_SIGNATURE/*<-APAdditionalFeeInfo*/;
 
	public APInvoiceItem() {
		super("AdaptivePayment::APInvoiceItem", TYPE_SIGNATURE);

 
		set("name", null, "String");
 
		set("identifier", null, "String");
 
		set("price", null, "AdaptivePayment::APPayAmount");
 
		set("count", null, "ulong");
 
		set("count_double", null, "double");
 
		set("total_price", null, "AdaptivePayment::APPayAmount");
 
		set("taxable", null, "bool");
 
		set("reimbursable", null, "bool");
 
		set("ean", null, "String");
 
		set("sku", null, "String");
 
		set("description", null, "String");
 		addFieldQualifier("return_policy_identifier","max_length","8");
 
		set("return_policy_identifier", null, "String");
 
		set("discount", null, "List<AdaptivePayment::APDiscountInfo>");
 
		set("itemCountUnit", null, "int");
 
		set("mpn", null, "String");
 
		set("isbn", null, "String");
 
		set("plu", null, "String");
 
		set("modelNumber", null, "String");
 
		set("styleNumber", null, "String");
 
		set("taxRate", null, "double");
 
		set("additionalFees", null, "List<AdaptivePayment::APAdditionalFeeInfo>");
	}

	// {{{
	public void setName(String value) { this.set("name", (Object)value); }
 	public String getName() { return (String)this.get("name"); }
	// }}}
	// {{{
	public void setIdentifier(String value) { this.set("identifier", (Object)value); }
 	public String getIdentifier() { return (String)this.get("identifier"); }
	// }}}
	// {{{
	public void setPrice(APPayAmount value) { this.set("price", (Object)value); }
 	public APPayAmount getPrice() { return (APPayAmount)this.get("price"); }
	// }}}
	// {{{
	public void setCount(Long value) { this.set("count", (Object)value); }
 	public Long getCount() { return (Long)this.get("count"); }
	// }}}
	// {{{
	public void setCountDouble(Double value) { this.set("count_double", (Object)value); }
 	public Double getCountDouble() { return (Double)this.get("count_double"); }
	// }}}
	// {{{
	public void setTotalPrice(APPayAmount value) { this.set("total_price", (Object)value); }
 	public APPayAmount getTotalPrice() { return (APPayAmount)this.get("total_price"); }
	// }}}
	// {{{
	public void setTaxable(Boolean value) { this.set("taxable", (Object)value); }
 	public Boolean getTaxable() { return (Boolean)this.get("taxable"); }
	// }}}
	// {{{
	public void setReimbursable(Boolean value) { this.set("reimbursable", (Object)value); }
 	public Boolean getReimbursable() { return (Boolean)this.get("reimbursable"); }
	// }}}
	// {{{
	public void setEan(String value) { this.set("ean", (Object)value); }
 	public String getEan() { return (String)this.get("ean"); }
	// }}}
	// {{{
	public void setSku(String value) { this.set("sku", (Object)value); }
 	public String getSku() { return (String)this.get("sku"); }
	// }}}
	// {{{
	public void setDescription(String value) { this.set("description", (Object)value); }
 	public String getDescription() { return (String)this.get("description"); }
	// }}}
	// {{{
	public void setReturnPolicyIdentifier(String value) { this.set("return_policy_identifier", (Object)value); }
 	public String getReturnPolicyIdentifier() { return (String)this.get("return_policy_identifier"); }
	// }}}
	// {{{
	public void setDiscount(List<APDiscountInfo> value) { this.set("discount", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<APDiscountInfo> getDiscount() { return (List<APDiscountInfo>)this.get("discount"); }
	// }}}
	// {{{
	public void setItemCountUnit(Integer value) { this.set("itemCountUnit", (Object)value); }
 	public Integer getItemCountUnit() { return (Integer)this.get("itemCountUnit"); }
	// }}}
	// {{{
	public void setMpn(String value) { this.set("mpn", (Object)value); }
 	public String getMpn() { return (String)this.get("mpn"); }
	// }}}
	// {{{
	public void setIsbn(String value) { this.set("isbn", (Object)value); }
 	public String getIsbn() { return (String)this.get("isbn"); }
	// }}}
	// {{{
	public void setPlu(String value) { this.set("plu", (Object)value); }
 	public String getPlu() { return (String)this.get("plu"); }
	// }}}
	// {{{
	public void setModelNumber(String value) { this.set("modelNumber", (Object)value); }
 	public String getModelNumber() { return (String)this.get("modelNumber"); }
	// }}}
	// {{{
	public void setStyleNumber(String value) { this.set("styleNumber", (Object)value); }
 	public String getStyleNumber() { return (String)this.get("styleNumber"); }
	// }}}
	// {{{
	public void setTaxRate(Double value) { this.set("taxRate", (Object)value); }
 	public Double getTaxRate() { return (Double)this.get("taxRate"); }
	// }}}
	// {{{
	public void setAdditionalFees(List<APAdditionalFeeInfo> value) { this.set("additionalFees", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<APAdditionalFeeInfo> getAdditionalFees() { return (List<APAdditionalFeeInfo>)this.get("additionalFees"); }
	// }}}
}