/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AdaptivePaymentCommonParams.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.adaptivepayment;

import java.math.BigInteger;

  
public enum PaymentRequestType {
/***/
   	SIMPLE(new String("SIMPLE"), ""),
   	PARALLEL(new String("PARALLEL"), ""),
   	PARALLEL_BEST_EFFORT(new String("PARALLEL_BEST_EFFORT"), ""),
   	CHAIN(new String("CHAIN"), ""),
   	DELAYED_CHAIN(new String("DELAYED_CHAIN"), "");

	private final String value;
	private final String desc;

	private PaymentRequestType(String value, String desc) {
		this.value = value;
		this.desc  = desc;
	}

	public String getValue() {
		return value;
	}

	public String getDesc() {
		return desc;
	}
}
