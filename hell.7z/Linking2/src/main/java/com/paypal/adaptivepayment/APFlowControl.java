/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AdaptivePaymentCommonParams.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.adaptivepayment;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * Common header for all AdaptivePayment APIs
  * 
  * 2008-02-29
   * @author Rohit Sahney
  */

public class APFlowControl extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((60212*60212)<<32)/*<-APFlowControl*/+
         		22205/*<-cancel_url*/*18443/*<-String*/+
         		7769/*<-return_url*/*18443/*<-String*/;
 
	public APFlowControl() {
		super("AdaptivePayment::APFlowControl", TYPE_SIGNATURE);

 		addFieldQualifier("cancel_url","required","true");
 
		set("cancel_url", null, "String");
 		addFieldQualifier("return_url","required","true");
 
		set("return_url", null, "String");
	}

	// {{{
	public void setCancelUrl(String value) { this.set("cancel_url", (Object)value); }
 	public String getCancelUrl() { return (String)this.get("cancel_url"); }
	// }}}
	// {{{
	public void setReturnUrl(String value) { this.set("return_url", (Object)value); }
 	public String getReturnUrl() { return (String)this.get("return_url"); }
	// }}}
}