/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AdaptivePaymentCommonParams.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.adaptivepayment;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * Common header for all AdaptivePayment APIs
  * 
  * 2008-02-29
   * @author Rohit Sahney
  */

public class APPaymentExec extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((61010*61010)<<32)/*<-APPaymentExec*/+
         		60253/*<-pay_key*/*18443/*<-String*/+
         		13141/*<-preapproval_key*/*18443/*<-String*/+
         		52543/*<-status*/*18443/*<-String*/+
         		22809/*<-time_created*/*33490/*<-ulong*/+
         		44033/*<-time_executed*/*33490/*<-ulong*/;
 
	public APPaymentExec() {
		super("AdaptivePayment::APPaymentExec", TYPE_SIGNATURE);

 
		set("pay_key", null, "String");
 
		set("preapproval_key", null, "String");
 
		set("status", null, "String");
 
		set("time_created", null, "ulong");
 
		set("time_executed", null, "ulong");
	}

	// {{{
	public void setPayKey(String value) { this.set("pay_key", (Object)value); }
 	public String getPayKey() { return (String)this.get("pay_key"); }
	// }}}
	// {{{
	public void setPreapprovalKey(String value) { this.set("preapproval_key", (Object)value); }
 	public String getPreapprovalKey() { return (String)this.get("preapproval_key"); }
	// }}}
	// {{{
	public void setStatus(String value) { this.set("status", (Object)value); }
 	public String getStatus() { return (String)this.get("status"); }
	// }}}
	// {{{
	public void setTimeCreated(Long value) { this.set("time_created", (Object)value); }
 	public Long getTimeCreated() { return (Long)this.get("time_created"); }
	// }}}
	// {{{
	public void setTimeExecuted(Long value) { this.set("time_executed", (Object)value); }
 	public Long getTimeExecuted() { return (Long)this.get("time_executed"); }
	// }}}
}