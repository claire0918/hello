/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AdaptivePaymentCommonParams.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.adaptivepayment;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * Common header for all AdaptivePayment APIs
  * 
  * 2008-02-29
   * @author Rohit Sahney
  */

public class APRefundResults extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((19115*19115)<<32)/*<-APRefundResults*/+
         		16657/*<-refund_successful*/*15044/*<-bool*/+
         		7120/*<-refund_has_become_full*/*15044/*<-bool*/+
         		2712/*<-encrypted_refund_transaction_id*/*18443/*<-String*/+
         		10308/*<-refund_transaction_status*/*37752/*<-char*/+
         		25405/*<-transaction_info*/*APTransactionInfo.TYPE_SIGNATURE/*<-APTransactionInfo*/+
         		41514/*<-refund_net_amount*/*APPayAmount.TYPE_SIGNATURE/*<-APPayAmount*/+
         		32662/*<-refund_fee_amount*/*APPayAmount.TYPE_SIGNATURE/*<-APPayAmount*/+
         		62610/*<-refund_gross_amount*/*APPayAmount.TYPE_SIGNATURE/*<-APPayAmount*/+
         		34788/*<-total_of_all_refunds*/*APPayAmount.TYPE_SIGNATURE/*<-APPayAmount*/+
         		45722/*<-refund_pimp_rc*/*47/*<-repeating*/*46796/*<-llong*/;
 
	public APRefundResults() {
		super("AdaptivePayment::APRefundResults", TYPE_SIGNATURE);

 
		set("refund_successful", null, "bool");
 
		set("refund_has_become_full", null, "bool");
 
		set("encrypted_refund_transaction_id", null, "String");
 
		set("refund_transaction_status", null, "char");
 
		set("transaction_info", null, "AdaptivePayment::APTransactionInfo");
 
		set("refund_net_amount", null, "AdaptivePayment::APPayAmount");
 
		set("refund_fee_amount", null, "AdaptivePayment::APPayAmount");
 
		set("refund_gross_amount", null, "AdaptivePayment::APPayAmount");
 
		set("total_of_all_refunds", null, "AdaptivePayment::APPayAmount");
 
		set("refund_pimp_rc", null, "List<llong>");
	}

	// {{{
	public void setRefundSuccessful(Boolean value) { this.set("refund_successful", (Object)value); }
 	public Boolean getRefundSuccessful() { return (Boolean)this.get("refund_successful"); }
	// }}}
	// {{{
	public void setRefundHasBecomeFull(Boolean value) { this.set("refund_has_become_full", (Object)value); }
 	public Boolean getRefundHasBecomeFull() { return (Boolean)this.get("refund_has_become_full"); }
	// }}}
	// {{{
	public void setEncryptedRefundTransactionId(String value) { this.set("encrypted_refund_transaction_id", (Object)value); }
 	public String getEncryptedRefundTransactionId() { return (String)this.get("encrypted_refund_transaction_id"); }
	// }}}
	// {{{
	public void setRefundTransactionStatus(Byte value) { this.set("refund_transaction_status", (Object)value); }
 	public Byte getRefundTransactionStatus() { return (Byte)this.get("refund_transaction_status"); }
	// }}}
	// {{{
	public void setTransactionInfo(APTransactionInfo value) { this.set("transaction_info", (Object)value); }
 	public APTransactionInfo getTransactionInfo() { return (APTransactionInfo)this.get("transaction_info"); }
	// }}}
	// {{{
	public void setRefundNetAmount(APPayAmount value) { this.set("refund_net_amount", (Object)value); }
 	public APPayAmount getRefundNetAmount() { return (APPayAmount)this.get("refund_net_amount"); }
	// }}}
	// {{{
	public void setRefundFeeAmount(APPayAmount value) { this.set("refund_fee_amount", (Object)value); }
 	public APPayAmount getRefundFeeAmount() { return (APPayAmount)this.get("refund_fee_amount"); }
	// }}}
	// {{{
	public void setRefundGrossAmount(APPayAmount value) { this.set("refund_gross_amount", (Object)value); }
 	public APPayAmount getRefundGrossAmount() { return (APPayAmount)this.get("refund_gross_amount"); }
	// }}}
	// {{{
	public void setTotalOfAllRefunds(APPayAmount value) { this.set("total_of_all_refunds", (Object)value); }
 	public APPayAmount getTotalOfAllRefunds() { return (APPayAmount)this.get("total_of_all_refunds"); }
	// }}}
	// {{{
	public void setRefundPimpRc(List<Long> value) { this.set("refund_pimp_rc", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<Long> getRefundPimpRc() { return (List<Long>)this.get("refund_pimp_rc"); }
	// }}}
}