/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AdaptivePaymentCommonParams.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.adaptivepayment;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * Common header for all AdaptivePayment APIs
  * 
  * 2008-02-29
   * @author Rohit Sahney
  */

public class APPreapproval extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((50862*50862)<<32)/*<-APPreapproval*/+
         		17911/*<-funding_source_type*/*37752/*<-char*/+
         		12962/*<-funding_source_id*/*46168/*<-ullong*/+
         		45460/*<-pin*/*18443/*<-String*/+
         		17545/*<-preapprovalkey*/*18443/*<-String*/+
         		37851/*<-shipping_address*/*com.paypal.user.AddressVO.TYPE_SIGNATURE/*<-User::AddressVO*/+
         		4885/*<-apiuser_account_number*/*46168/*<-ullong*/+
         		7769/*<-return_url*/*18443/*<-String*/+
         		22205/*<-cancel_url*/*18443/*<-String*/+
         		24594/*<-approved*/*15044/*<-bool*/+
         		40073/*<-e_pin_required*/*15044/*<-bool*/+
         		60156/*<-chained_payment*/*15044/*<-bool*/+
         		52543/*<-status*/*37752/*<-char*/+
         		6197/*<-sender*/*APSender.TYPE_SIGNATURE/*<-APSender*/+
         		63331/*<-starting_date*/*46168/*<-ullong*/+
         		10300/*<-ending_date*/*46168/*<-ullong*/+
         		48832/*<-utc_offset*/*38894/*<-int*/+
         		42291/*<-max_number_of_payments*/*38894/*<-int*/+
         		10445/*<-max_number_of_payments_per_period*/*38894/*<-int*/+
         		28962/*<-period*/*18443/*<-String*/+
         		8393/*<-day_of_period*/*33490/*<-ulong*/+
         		57773/*<-remaining_payments*/*33490/*<-ulong*/+
         		16624/*<-cur_payments*/*33490/*<-ulong*/+
         		29616/*<-remaining_payments_in_period*/*33490/*<-ulong*/+
         		32934/*<-cur_period_attempts*/*33490/*<-ulong*/+
         		33618/*<-cur_period_ending_date*/*46168/*<-ullong*/+
         		53267/*<-pin_failed_attempts*/*38894/*<-int*/+
         		22809/*<-time_created*/*46168/*<-ullong*/+
         		47726/*<-time_updated*/*46168/*<-ullong*/+
         		1143/*<-row_version*/*33490/*<-ulong*/+
         		5385/*<-memo*/*18443/*<-String*/+
         		39824/*<-remaining_payments_amount*/*APPayAmount.TYPE_SIGNATURE/*<-APPayAmount*/+
         		40359/*<-cur_payments_amount*/*APPayAmount.TYPE_SIGNATURE/*<-APPayAmount*/+
         		47490/*<-max_total_amount_of_all_payments*/*APPayAmount.TYPE_SIGNATURE/*<-APPayAmount*/+
         		17626/*<-max_amount_per_payment*/*APPayAmount.TYPE_SIGNATURE/*<-APPayAmount*/+
         		47658/*<-source_type*/*18443/*<-String*/+
         		19152/*<-opt_in_payrequest_id*/*46168/*<-ullong*/+
         		62496/*<-fees_payer_type*/*38894/*<-int*/+
         		18475/*<-display_max_total_amount*/*15044/*<-bool*/+
         		15213/*<-instant_funding_source_required*/*15044/*<-bool*/+
         		1975/*<-hide_signup_page*/*15044/*<-bool*/;
 
	public APPreapproval() {
		super("AdaptivePayment::APPreapproval", TYPE_SIGNATURE);

 
		set("funding_source_type", null, "char");
 
		set("funding_source_id", null, "ullong");
 
		set("pin", null, "String");
 
		set("preapprovalkey", null, "String");
 
		set("shipping_address", null, "User::AddressVO");
 
		set("apiuser_account_number", null, "ullong");
 
		set("return_url", null, "String");
 
		set("cancel_url", null, "String");
 
		set("approved", null, "bool");
 
		set("e_pin_required", null, "bool");
 
		set("chained_payment", null, "bool");
 
		set("status", null, "char");
 
		set("sender", null, "AdaptivePayment::APSender");
 
		set("starting_date", null, "ullong");
 
		set("ending_date", null, "ullong");
 
		set("utc_offset", null, "int");
 
		set("max_number_of_payments", null, "int");
 
		set("max_number_of_payments_per_period", null, "int");
 
		set("period", null, "String");
 
		set("day_of_period", null, "ulong");
 
		set("remaining_payments", null, "ulong");
 
		set("cur_payments", null, "ulong");
 
		set("remaining_payments_in_period", null, "ulong");
 
		set("cur_period_attempts", null, "ulong");
 
		set("cur_period_ending_date", null, "ullong");
 
		set("pin_failed_attempts", null, "int");
 
		set("time_created", null, "ullong");
 
		set("time_updated", null, "ullong");
 
		set("row_version", null, "ulong");
 
		set("memo", null, "String");
 
		set("remaining_payments_amount", null, "AdaptivePayment::APPayAmount");
 
		set("cur_payments_amount", null, "AdaptivePayment::APPayAmount");
 
		set("max_total_amount_of_all_payments", null, "AdaptivePayment::APPayAmount");
 
		set("max_amount_per_payment", null, "AdaptivePayment::APPayAmount");
 
		set("source_type", null, "String");
 
		set("opt_in_payrequest_id", null, "ullong");
 
		set("fees_payer_type", null, "int");
 
		set("display_max_total_amount", null, "bool");
 
		set("instant_funding_source_required", null, "bool");
 
		set("hide_signup_page", null, "bool");
	}

	// {{{
	public void setFundingSourceType(Byte value) { this.set("funding_source_type", (Object)value); }
 	public Byte getFundingSourceType() { return (Byte)this.get("funding_source_type"); }
	// }}}
	// {{{
	public void setFundingSourceId(BigInteger value) { this.set("funding_source_id", (Object)value); }
 	public BigInteger getFundingSourceId() { return (BigInteger)this.get("funding_source_id"); }
	// }}}
	// {{{
	public void setPin(String value) { this.set("pin", (Object)value); }
 	public String getPin() { return (String)this.get("pin"); }
	// }}}
	// {{{
	public void setPreapprovalkey(String value) { this.set("preapprovalkey", (Object)value); }
 	public String getPreapprovalkey() { return (String)this.get("preapprovalkey"); }
	// }}}
	// {{{
	public void setShippingAddress(com.paypal.user.AddressVO value) { this.set("shipping_address", (Object)value); }
 	public com.paypal.user.AddressVO getShippingAddress() { return (com.paypal.user.AddressVO)this.get("shipping_address"); }
	// }}}
	// {{{
	public void setApiuserAccountNumber(BigInteger value) { this.set("apiuser_account_number", (Object)value); }
 	public BigInteger getApiuserAccountNumber() { return (BigInteger)this.get("apiuser_account_number"); }
	// }}}
	// {{{
	public void setReturnUrl(String value) { this.set("return_url", (Object)value); }
 	public String getReturnUrl() { return (String)this.get("return_url"); }
	// }}}
	// {{{
	public void setCancelUrl(String value) { this.set("cancel_url", (Object)value); }
 	public String getCancelUrl() { return (String)this.get("cancel_url"); }
	// }}}
	// {{{
	public void setApproved(Boolean value) { this.set("approved", (Object)value); }
 	public Boolean getApproved() { return (Boolean)this.get("approved"); }
	// }}}
	// {{{
	public void setEPinRequired(Boolean value) { this.set("e_pin_required", (Object)value); }
 	public Boolean getEPinRequired() { return (Boolean)this.get("e_pin_required"); }
	// }}}
	// {{{
	public void setChainedPayment(Boolean value) { this.set("chained_payment", (Object)value); }
 	public Boolean getChainedPayment() { return (Boolean)this.get("chained_payment"); }
	// }}}
	// {{{
	public void setStatus(Byte value) { this.set("status", (Object)value); }
 	public Byte getStatus() { return (Byte)this.get("status"); }
	// }}}
	// {{{
	public void setSender(APSender value) { this.set("sender", (Object)value); }
 	public APSender getSender() { return (APSender)this.get("sender"); }
	// }}}
	// {{{
	public void setStartingDate(BigInteger value) { this.set("starting_date", (Object)value); }
 	public BigInteger getStartingDate() { return (BigInteger)this.get("starting_date"); }
	// }}}
	// {{{
	public void setEndingDate(BigInteger value) { this.set("ending_date", (Object)value); }
 	public BigInteger getEndingDate() { return (BigInteger)this.get("ending_date"); }
	// }}}
	// {{{
	public void setUtcOffset(Integer value) { this.set("utc_offset", (Object)value); }
 	public Integer getUtcOffset() { return (Integer)this.get("utc_offset"); }
	// }}}
	// {{{
	public void setMaxNumberOfPayments(Integer value) { this.set("max_number_of_payments", (Object)value); }
 	public Integer getMaxNumberOfPayments() { return (Integer)this.get("max_number_of_payments"); }
	// }}}
	// {{{
	public void setMaxNumberOfPaymentsPerPeriod(Integer value) { this.set("max_number_of_payments_per_period", (Object)value); }
 	public Integer getMaxNumberOfPaymentsPerPeriod() { return (Integer)this.get("max_number_of_payments_per_period"); }
	// }}}
	// {{{
	public void setPeriod(String value) { this.set("period", (Object)value); }
 	public String getPeriod() { return (String)this.get("period"); }
	// }}}
	// {{{
	public void setDayOfPeriod(Long value) { this.set("day_of_period", (Object)value); }
 	public Long getDayOfPeriod() { return (Long)this.get("day_of_period"); }
	// }}}
	// {{{
	public void setRemainingPayments(Long value) { this.set("remaining_payments", (Object)value); }
 	public Long getRemainingPayments() { return (Long)this.get("remaining_payments"); }
	// }}}
	// {{{
	public void setCurPayments(Long value) { this.set("cur_payments", (Object)value); }
 	public Long getCurPayments() { return (Long)this.get("cur_payments"); }
	// }}}
	// {{{
	public void setRemainingPaymentsInPeriod(Long value) { this.set("remaining_payments_in_period", (Object)value); }
 	public Long getRemainingPaymentsInPeriod() { return (Long)this.get("remaining_payments_in_period"); }
	// }}}
	// {{{
	public void setCurPeriodAttempts(Long value) { this.set("cur_period_attempts", (Object)value); }
 	public Long getCurPeriodAttempts() { return (Long)this.get("cur_period_attempts"); }
	// }}}
	// {{{
	public void setCurPeriodEndingDate(BigInteger value) { this.set("cur_period_ending_date", (Object)value); }
 	public BigInteger getCurPeriodEndingDate() { return (BigInteger)this.get("cur_period_ending_date"); }
	// }}}
	// {{{
	public void setPinFailedAttempts(Integer value) { this.set("pin_failed_attempts", (Object)value); }
 	public Integer getPinFailedAttempts() { return (Integer)this.get("pin_failed_attempts"); }
	// }}}
	// {{{
	public void setTimeCreated(BigInteger value) { this.set("time_created", (Object)value); }
 	public BigInteger getTimeCreated() { return (BigInteger)this.get("time_created"); }
	// }}}
	// {{{
	public void setTimeUpdated(BigInteger value) { this.set("time_updated", (Object)value); }
 	public BigInteger getTimeUpdated() { return (BigInteger)this.get("time_updated"); }
	// }}}
	// {{{
	public void setRowVersion(Long value) { this.set("row_version", (Object)value); }
 	public Long getRowVersion() { return (Long)this.get("row_version"); }
	// }}}
	// {{{
	public void setMemo(String value) { this.set("memo", (Object)value); }
 	public String getMemo() { return (String)this.get("memo"); }
	// }}}
	// {{{
	public void setRemainingPaymentsAmount(APPayAmount value) { this.set("remaining_payments_amount", (Object)value); }
 	public APPayAmount getRemainingPaymentsAmount() { return (APPayAmount)this.get("remaining_payments_amount"); }
	// }}}
	// {{{
	public void setCurPaymentsAmount(APPayAmount value) { this.set("cur_payments_amount", (Object)value); }
 	public APPayAmount getCurPaymentsAmount() { return (APPayAmount)this.get("cur_payments_amount"); }
	// }}}
	// {{{
	public void setMaxTotalAmountOfAllPayments(APPayAmount value) { this.set("max_total_amount_of_all_payments", (Object)value); }
 	public APPayAmount getMaxTotalAmountOfAllPayments() { return (APPayAmount)this.get("max_total_amount_of_all_payments"); }
	// }}}
	// {{{
	public void setMaxAmountPerPayment(APPayAmount value) { this.set("max_amount_per_payment", (Object)value); }
 	public APPayAmount getMaxAmountPerPayment() { return (APPayAmount)this.get("max_amount_per_payment"); }
	// }}}
	// {{{
	public void setSourceType(String value) { this.set("source_type", (Object)value); }
 	public String getSourceType() { return (String)this.get("source_type"); }
	// }}}
	// {{{
	public void setOptInPayrequestId(BigInteger value) { this.set("opt_in_payrequest_id", (Object)value); }
 	public BigInteger getOptInPayrequestId() { return (BigInteger)this.get("opt_in_payrequest_id"); }
	// }}}
	// {{{
	public void setFeesPayerType(Integer value) { this.set("fees_payer_type", (Object)value); }
 	public Integer getFeesPayerType() { return (Integer)this.get("fees_payer_type"); }
	// }}}
	// {{{
	public void setDisplayMaxTotalAmount(Boolean value) { this.set("display_max_total_amount", (Object)value); }
 	public Boolean getDisplayMaxTotalAmount() { return (Boolean)this.get("display_max_total_amount"); }
	// }}}
	// {{{
	public void setInstantFundingSourceRequired(Boolean value) { this.set("instant_funding_source_required", (Object)value); }
 	public Boolean getInstantFundingSourceRequired() { return (Boolean)this.get("instant_funding_source_required"); }
	// }}}
	// {{{
	public void setHideSignupPage(Boolean value) { this.set("hide_signup_page", (Object)value); }
 	public Boolean getHideSignupPage() { return (Boolean)this.get("hide_signup_page"); }
	// }}}
}