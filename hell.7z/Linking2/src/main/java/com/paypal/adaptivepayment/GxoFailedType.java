/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AdaptivePaymentCommonParams.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.adaptivepayment;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * Common header for all AdaptivePayment APIs
  * 
  * 2008-02-29
   * @author Rohit Sahney
  */

public class GxoFailedType extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((57458*57458)<<32)/*<-GxoFailedType*/+
         		38877/*<-value*/*18443/*<-String*/+
         		37377/*<-reason*/*38894/*<-int*/;
 
	public GxoFailedType() {
		super("AdaptivePayment::GxoFailedType", TYPE_SIGNATURE);

 
		set("value", null, "String");
 
		set("reason", null, "int");
	}

	// {{{
	public void setValue(String value) { this.set("value", (Object)value); }
 	public String getValue() { return (String)this.get("value"); }
	// }}}
	// {{{
	public void setReason(Integer value) { this.set("reason", (Object)value); }
 	public Integer getReason() { return (Integer)this.get("reason"); }
	// }}}
}