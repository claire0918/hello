/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AdaptivePaymentCommonParams.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.adaptivepayment;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * Common header for all AdaptivePayment APIs
  * 
  * 2008-02-29
   * @author Rohit Sahney
  */

public class APMerchantStoreInfo extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((2189*2189)<<32)/*<-APMerchantStoreInfo*/+
         		62145/*<-account_number*/*18443/*<-String*/+
         		20062/*<-email*/*18443/*<-String*/+
         		51040/*<-store_id*/*18443/*<-String*/+
         		63518/*<-terminal_id*/*18443/*<-String*/+
         		57920/*<-terminal_type*/*18443/*<-String*/+
         		43592/*<-is_inactive*/*15044/*<-bool*/+
         		37567/*<-store_description*/*com.paypal.merchant.StoreDescriptionVO.TYPE_SIGNATURE/*<-Merchant::StoreDescriptionVO*/+
         		39011/*<-address*/*com.paypal.user.AddressVO.TYPE_SIGNATURE/*<-User::AddressVO*/+
         		30153/*<-phones*/*47/*<-repeating*/*com.paypal.user.PhoneVO.TYPE_SIGNATURE/*<-User::PhoneVO*/;
 
	public APMerchantStoreInfo() {
		super("AdaptivePayment::APMerchantStoreInfo", TYPE_SIGNATURE);

 
		set("account_number", null, "String");
 
		set("email", null, "String");
 
		set("store_id", null, "String");
 
		set("terminal_id", null, "String");
 
		set("terminal_type", null, "String");
 
		set("is_inactive", null, "bool");
 
		set("store_description", null, "Merchant::StoreDescriptionVO");
 
		set("address", null, "User::AddressVO");
 
		set("phones", null, "List<User::PhoneVO>");
	}

	// {{{
	public void setAccountNumber(String value) { this.set("account_number", (Object)value); }
 	public String getAccountNumber() { return (String)this.get("account_number"); }
	// }}}
	// {{{
	public void setEmail(String value) { this.set("email", (Object)value); }
 	public String getEmail() { return (String)this.get("email"); }
	// }}}
	// {{{
	public void setStoreId(String value) { this.set("store_id", (Object)value); }
 	public String getStoreId() { return (String)this.get("store_id"); }
	// }}}
	// {{{
	public void setTerminalId(String value) { this.set("terminal_id", (Object)value); }
 	public String getTerminalId() { return (String)this.get("terminal_id"); }
	// }}}
	// {{{
	public void setTerminalType(String value) { this.set("terminal_type", (Object)value); }
 	public String getTerminalType() { return (String)this.get("terminal_type"); }
	// }}}
	// {{{
	public void setIsInactive(Boolean value) { this.set("is_inactive", (Object)value); }
 	public Boolean getIsInactive() { return (Boolean)this.get("is_inactive"); }
	// }}}
	// {{{
	public void setStoreDescription(com.paypal.merchant.StoreDescriptionVO value) { this.set("store_description", (Object)value); }
 	public com.paypal.merchant.StoreDescriptionVO getStoreDescription() { return (com.paypal.merchant.StoreDescriptionVO)this.get("store_description"); }
	// }}}
	// {{{
	public void setAddress(com.paypal.user.AddressVO value) { this.set("address", (Object)value); }
 	public com.paypal.user.AddressVO getAddress() { return (com.paypal.user.AddressVO)this.get("address"); }
	// }}}
	// {{{
	public void setPhones(List<com.paypal.user.PhoneVO> value) { this.set("phones", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<com.paypal.user.PhoneVO> getPhones() { return (List<com.paypal.user.PhoneVO>)this.get("phones"); }
	// }}}
}