/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AdaptivePaymentCommonParams.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.adaptivepayment;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * Common header for all AdaptivePayment APIs
  * 
  * 2008-02-29
   * @author Rohit Sahney
  */

public class APReceiverOption extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((17192*17192)<<32)/*<-APReceiverOption*/+
         		33481/*<-description*/*18443/*<-String*/+
         		25767/*<-custom_id*/*18443/*<-String*/+
         		24243/*<-invoice_data*/*APInvoiceData.TYPE_SIGNATURE/*<-APInvoiceData*/+
         		57057/*<-receiver_identifier*/*APReceiverIdentifier.TYPE_SIGNATURE/*<-APReceiverIdentifier*/;
 
	public APReceiverOption() {
		super("AdaptivePayment::APReceiverOption", TYPE_SIGNATURE);

 
		set("description", null, "String");
 
		set("custom_id", null, "String");
 
		set("invoice_data", null, "AdaptivePayment::APInvoiceData");
 
		set("receiver_identifier", null, "AdaptivePayment::APReceiverIdentifier");
	}

	// {{{
	public void setDescription(String value) { this.set("description", (Object)value); }
 	public String getDescription() { return (String)this.get("description"); }
	// }}}
	// {{{
	public void setCustomId(String value) { this.set("custom_id", (Object)value); }
 	public String getCustomId() { return (String)this.get("custom_id"); }
	// }}}
	// {{{
	public void setInvoiceData(APInvoiceData value) { this.set("invoice_data", (Object)value); }
 	public APInvoiceData getInvoiceData() { return (APInvoiceData)this.get("invoice_data"); }
	// }}}
	// {{{
	public void setReceiverIdentifier(APReceiverIdentifier value) { this.set("receiver_identifier", (Object)value); }
 	public APReceiverIdentifier getReceiverIdentifier() { return (APReceiverIdentifier)this.get("receiver_identifier"); }
	// }}}
}