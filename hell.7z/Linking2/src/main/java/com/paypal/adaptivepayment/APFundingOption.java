/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AdaptivePaymentCommonParams.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.adaptivepayment;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * Common header for all AdaptivePayment APIs
  * 
  * 2008-02-29
   * @author Rohit Sahney
  */

public class APFundingOption extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((28737*28737)<<32)/*<-APFundingOption*/+
         		40017/*<-msb_enabled*/*15044/*<-bool*/+
         		51040/*<-store_id*/*18443/*<-String*/+
         		24223/*<-is_forced_post*/*15044/*<-bool*/+
         		49241/*<-issuer_list*/*47/*<-repeating*/*46168/*<-ullong*/;
 
	public APFundingOption() {
		super("AdaptivePayment::APFundingOption", TYPE_SIGNATURE);

 
		set("msb_enabled", null, "bool");
 
		set("store_id", null, "String");
 
		set("is_forced_post", null, "bool");
 
		set("issuer_list", null, "List<ullong>");
	}

	// {{{
	public void setMsbEnabled(Boolean value) { this.set("msb_enabled", (Object)value); }
 	public Boolean getMsbEnabled() { return (Boolean)this.get("msb_enabled"); }
	// }}}
	// {{{
	public void setStoreId(String value) { this.set("store_id", (Object)value); }
 	public String getStoreId() { return (String)this.get("store_id"); }
	// }}}
	// {{{
	public void setIsForcedPost(Boolean value) { this.set("is_forced_post", (Object)value); }
 	public Boolean getIsForcedPost() { return (Boolean)this.get("is_forced_post"); }
	// }}}
	// {{{
	public void setIssuerList(List<BigInteger> value) { this.set("issuer_list", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<BigInteger> getIssuerList() { return (List<BigInteger>)this.get("issuer_list"); }
	// }}}
}