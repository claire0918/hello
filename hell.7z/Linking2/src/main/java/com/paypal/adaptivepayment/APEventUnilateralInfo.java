/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AdaptivePaymentCommonParams.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.adaptivepayment;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * Common header for all AdaptivePayment APIs
  * 
  * 2008-02-29
   * @author Rohit Sahney
  */

public class APEventUnilateralInfo extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((3177*3177)<<32)/*<-APEventUnilateralInfo*/+
         		32582/*<-alias_id*/*46168/*<-ullong*/+
         		28952/*<-activity_id*/*46168/*<-ullong*/+
         		62145/*<-account_number*/*46168/*<-ullong*/;
 
	public APEventUnilateralInfo() {
		super("AdaptivePayment::APEventUnilateralInfo", TYPE_SIGNATURE);

 
		set("alias_id", null, "ullong");
 
		set("activity_id", null, "ullong");
 
		set("account_number", null, "ullong");
	}

	// {{{
	public void setAliasId(BigInteger value) { this.set("alias_id", (Object)value); }
 	public BigInteger getAliasId() { return (BigInteger)this.get("alias_id"); }
	// }}}
	// {{{
	public void setActivityId(BigInteger value) { this.set("activity_id", (Object)value); }
 	public BigInteger getActivityId() { return (BigInteger)this.get("activity_id"); }
	// }}}
	// {{{
	public void setAccountNumber(BigInteger value) { this.set("account_number", (Object)value); }
 	public BigInteger getAccountNumber() { return (BigInteger)this.get("account_number"); }
	// }}}
}