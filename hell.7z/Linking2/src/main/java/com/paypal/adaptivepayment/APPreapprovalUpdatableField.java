/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AdaptivePaymentCommonParams.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.adaptivepayment;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * Common header for all AdaptivePayment APIs
  * 
  * 2008-02-29
   * @author Rohit Sahney
  */

public class APPreapprovalUpdatableField extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((55368*55368)<<32)/*<-APPreapprovalUpdatableField*/+
         		38832/*<-preferred_funding_source_type*/*37752/*<-char*/+
         		28078/*<-preferred_funding_source_id*/*46168/*<-ullong*/+
         		45460/*<-pin*/*18443/*<-String*/+
         		42403/*<-shipping_address_id*/*46168/*<-ullong*/+
         		4885/*<-apiuser_account_number*/*46168/*<-ullong*/+
         		7278/*<-acceptance_status*/*15044/*<-bool*/+
         		52543/*<-status*/*37752/*<-char*/+
         		16624/*<-cur_payments*/*33490/*<-ulong*/+
         		32934/*<-cur_period_attempts*/*33490/*<-ulong*/+
         		33618/*<-cur_period_ending_date*/*46168/*<-ullong*/+
         		49851/*<-reset_pin_failed_attempts*/*15044/*<-bool*/+
         		57775/*<-increment_pin_failed_attempts*/*15044/*<-bool*/+
         		40359/*<-cur_payments_amount*/*APPayAmount.TYPE_SIGNATURE/*<-APPayAmount*/+
         		35487/*<-sender_email*/*18443/*<-String*/+
         		61980/*<-sender_email_id*/*46168/*<-ullong*/+
         		61799/*<-sender_account_number*/*46168/*<-ullong*/+
         		47658/*<-source_type*/*18443/*<-String*/+
         		18457/*<-paykey*/*18443/*<-String*/;
 
	public APPreapprovalUpdatableField() {
		super("AdaptivePayment::APPreapprovalUpdatableField", TYPE_SIGNATURE);

 
		set("preferred_funding_source_type", null, "char");
 
		set("preferred_funding_source_id", null, "ullong");
 
		set("pin", null, "String");
 
		set("shipping_address_id", null, "ullong");
 
		set("apiuser_account_number", null, "ullong");
 
		set("acceptance_status", null, "bool");
 
		set("status", null, "char");
 
		set("cur_payments", null, "ulong");
 
		set("cur_period_attempts", null, "ulong");
 
		set("cur_period_ending_date", null, "ullong");
 
		set("reset_pin_failed_attempts", null, "bool");
 
		set("increment_pin_failed_attempts", null, "bool");
 
		set("cur_payments_amount", null, "AdaptivePayment::APPayAmount");
 
		set("sender_email", null, "String");
 
		set("sender_email_id", null, "ullong");
 
		set("sender_account_number", null, "ullong");
 
		set("source_type", null, "String");
 
		set("paykey", null, "String");
	}

	// {{{
	public void setPreferredFundingSourceType(Byte value) { this.set("preferred_funding_source_type", (Object)value); }
 	public Byte getPreferredFundingSourceType() { return (Byte)this.get("preferred_funding_source_type"); }
	// }}}
	// {{{
	public void setPreferredFundingSourceId(BigInteger value) { this.set("preferred_funding_source_id", (Object)value); }
 	public BigInteger getPreferredFundingSourceId() { return (BigInteger)this.get("preferred_funding_source_id"); }
	// }}}
	// {{{
	public void setPin(String value) { this.set("pin", (Object)value); }
 	public String getPin() { return (String)this.get("pin"); }
	// }}}
	// {{{
	public void setShippingAddressId(BigInteger value) { this.set("shipping_address_id", (Object)value); }
 	public BigInteger getShippingAddressId() { return (BigInteger)this.get("shipping_address_id"); }
	// }}}
	// {{{
	public void setApiuserAccountNumber(BigInteger value) { this.set("apiuser_account_number", (Object)value); }
 	public BigInteger getApiuserAccountNumber() { return (BigInteger)this.get("apiuser_account_number"); }
	// }}}
	// {{{
	public void setAcceptanceStatus(Boolean value) { this.set("acceptance_status", (Object)value); }
 	public Boolean getAcceptanceStatus() { return (Boolean)this.get("acceptance_status"); }
	// }}}
	// {{{
	public void setStatus(Byte value) { this.set("status", (Object)value); }
 	public Byte getStatus() { return (Byte)this.get("status"); }
	// }}}
	// {{{
	public void setCurPayments(Long value) { this.set("cur_payments", (Object)value); }
 	public Long getCurPayments() { return (Long)this.get("cur_payments"); }
	// }}}
	// {{{
	public void setCurPeriodAttempts(Long value) { this.set("cur_period_attempts", (Object)value); }
 	public Long getCurPeriodAttempts() { return (Long)this.get("cur_period_attempts"); }
	// }}}
	// {{{
	public void setCurPeriodEndingDate(BigInteger value) { this.set("cur_period_ending_date", (Object)value); }
 	public BigInteger getCurPeriodEndingDate() { return (BigInteger)this.get("cur_period_ending_date"); }
	// }}}
	// {{{
	public void setResetPinFailedAttempts(Boolean value) { this.set("reset_pin_failed_attempts", (Object)value); }
 	public Boolean getResetPinFailedAttempts() { return (Boolean)this.get("reset_pin_failed_attempts"); }
	// }}}
	// {{{
	public void setIncrementPinFailedAttempts(Boolean value) { this.set("increment_pin_failed_attempts", (Object)value); }
 	public Boolean getIncrementPinFailedAttempts() { return (Boolean)this.get("increment_pin_failed_attempts"); }
	// }}}
	// {{{
	public void setCurPaymentsAmount(APPayAmount value) { this.set("cur_payments_amount", (Object)value); }
 	public APPayAmount getCurPaymentsAmount() { return (APPayAmount)this.get("cur_payments_amount"); }
	// }}}
	// {{{
	public void setSenderEmail(String value) { this.set("sender_email", (Object)value); }
 	public String getSenderEmail() { return (String)this.get("sender_email"); }
	// }}}
	// {{{
	public void setSenderEmailId(BigInteger value) { this.set("sender_email_id", (Object)value); }
 	public BigInteger getSenderEmailId() { return (BigInteger)this.get("sender_email_id"); }
	// }}}
	// {{{
	public void setSenderAccountNumber(BigInteger value) { this.set("sender_account_number", (Object)value); }
 	public BigInteger getSenderAccountNumber() { return (BigInteger)this.get("sender_account_number"); }
	// }}}
	// {{{
	public void setSourceType(String value) { this.set("source_type", (Object)value); }
 	public String getSourceType() { return (String)this.get("source_type"); }
	// }}}
	// {{{
	public void setPaykey(String value) { this.set("paykey", (Object)value); }
 	public String getPaykey() { return (String)this.get("paykey"); }
	// }}}
}