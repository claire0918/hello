/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/UserIndustryVO.fill
 by ASF Java Code Generator
 at ������ 12 06 10:23:41 2012 */

package com.paypal.merchant;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
  * 
   */

public class UserIndustryVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((56232*56232)<<32)/*<-UserIndustryVO*/+
         		3355/*<-id*/*46168/*<-ullong*/+
         		60232/*<-flags*/*46168/*<-ullong*/+
         		62145/*<-account_number*/*46168/*<-ullong*/+
         		17994/*<-industry*/*46168/*<-ullong*/+
         		49677/*<-subindustry*/*46168/*<-ullong*/+
         		36996/*<-date_reviewed*/*33490/*<-ulong*/+
         		5385/*<-memo*/*18443/*<-String*/+
         		39237/*<-user_industry*/*46168/*<-ullong*/+
         		46270/*<-user_subindustry*/*46168/*<-ullong*/;
 
	public UserIndustryVO() {
		super("Merchant::UserIndustryVO", TYPE_SIGNATURE);

 
		set("id", null, "ullong");
 
		set("flags", null, "ullong");
 
		set("account_number", null, "ullong");
 
		set("industry", null, "ullong");
 
		set("subindustry", null, "ullong");
 
		set("date_reviewed", null, "ulong");
 
		set("memo", null, "String");
 
		set("user_industry", null, "ullong");
 
		set("user_subindustry", null, "ullong");
	}

	// {{{
	public void setId(BigInteger value) { this.set("id", (Object)value); }
 	public BigInteger getId() { return (BigInteger)this.get("id"); }
	// }}}
	// {{{
	public void setFlags(BigInteger value) { this.set("flags", (Object)value); }
 	public BigInteger getFlags() { return (BigInteger)this.get("flags"); }
	// }}}
	// {{{
	public void setAccountNumber(BigInteger value) { this.set("account_number", (Object)value); }
 	public BigInteger getAccountNumber() { return (BigInteger)this.get("account_number"); }
	// }}}
	// {{{
	public void setIndustry(BigInteger value) { this.set("industry", (Object)value); }
 	public BigInteger getIndustry() { return (BigInteger)this.get("industry"); }
	// }}}
	// {{{
	public void setSubindustry(BigInteger value) { this.set("subindustry", (Object)value); }
 	public BigInteger getSubindustry() { return (BigInteger)this.get("subindustry"); }
	// }}}
	// {{{
	public void setDateReviewed(Long value) { this.set("date_reviewed", (Object)value); }
 	public Long getDateReviewed() { return (Long)this.get("date_reviewed"); }
	// }}}
	// {{{
	public void setMemo(String value) { this.set("memo", (Object)value); }
 	public String getMemo() { return (String)this.get("memo"); }
	// }}}
	// {{{
	public void setUserIndustry(BigInteger value) { this.set("user_industry", (Object)value); }
 	public BigInteger getUserIndustry() { return (BigInteger)this.get("user_industry"); }
	// }}}
	// {{{
	public void setUserSubindustry(BigInteger value) { this.set("user_subindustry", (Object)value); }
 	public BigInteger getUserSubindustry() { return (BigInteger)this.get("user_subindustry"); }
	// }}}
}