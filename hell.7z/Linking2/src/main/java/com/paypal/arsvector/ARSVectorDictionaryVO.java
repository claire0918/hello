/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/ARSVector.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.arsvector;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * Project 23532: Foosball Phase II ARS Attribute Integration
  * 
  * 2008-04-14
   * @author Kaining Gu
  */

public class ARSVectorDictionaryVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((33972*33972)<<32)/*<-ARSVectorDictionaryVO*/+
         		6189/*<-version*/*31526/*<-double*/+
         		29235/*<-dictionary*/*18443/*<-String*/;
 
	public ARSVectorDictionaryVO() {
		super("ARSVector::ARSVectorDictionaryVO", TYPE_SIGNATURE);

 
		set("version", null, "double");
 
		set("dictionary", null, "String");
	}

	// {{{
	public void setVersion(Double value) { this.set("version", (Object)value); }
 	public Double getVersion() { return (Double)this.get("version"); }
	// }}}
	// {{{
	public void setDictionary(String value) { this.set("dictionary", (Object)value); }
 	public String getDictionary() { return (String)this.get("dictionary"); }
	// }}}
}