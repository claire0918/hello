/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/ARSVector.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.arsvector;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * Project 23532: Foosball Phase II ARS Attribute Integration
  * 
  * 2008-04-14
   * @author Kaining Gu
  */

public class ARSEventNoticeVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((53414*53414)<<32)/*<-ARSEventNoticeVO*/+
         		62145/*<-account_number*/*46168/*<-ullong*/+
         		49267/*<-event_id*/*18443/*<-String*/+
         		31419/*<-zap_it*/*15044/*<-bool*/;
 
	public ARSEventNoticeVO() {
		super("ARSVector::ARSEventNoticeVO", TYPE_SIGNATURE);

 
		set("account_number", null, "ullong");
 
		set("event_id", null, "String");
 
		set("zap_it", null, "bool");
	}

	// {{{
	public void setAccountNumber(BigInteger value) { this.set("account_number", (Object)value); }
 	public BigInteger getAccountNumber() { return (BigInteger)this.get("account_number"); }
	// }}}
	// {{{
	public void setEventId(String value) { this.set("event_id", (Object)value); }
 	public String getEventId() { return (String)this.get("event_id"); }
	// }}}
	// {{{
	public void setZapIt(Boolean value) { this.set("zap_it", (Object)value); }
 	public Boolean getZapIt() { return (Boolean)this.get("zap_it"); }
	// }}}
}