/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/ARSVector.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.arsvector;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * Project 23532: Foosball Phase II ARS Attribute Integration
  * 
  * 2008-04-14
   * @author Kaining Gu
  */

public class ARSAttrServHealthVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((61046*61046)<<32)/*<-ARSAttrServHealthVO*/+
         		52543/*<-status*/*18443/*<-String*/;
 
	public ARSAttrServHealthVO() {
		super("ARSVector::ARSAttrServHealthVO", TYPE_SIGNATURE);

 
		set("status", null, "String");
	}

	// {{{
	public void setStatus(String value) { this.set("status", (Object)value); }
 	public String getStatus() { return (String)this.get("status"); }
	// }}}
}