/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/ARSVector.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.arsvector;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * Project 23532: Foosball Phase II ARS Attribute Integration
  * 
  * 2008-04-14
   * @author Kaining Gu
  */

public class ARSVectorVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((42070*42070)<<32)/*<-ARSVectorVO*/+
         		62145/*<-account_number*/*46168/*<-ullong*/+
         		49267/*<-event_id*/*18443/*<-String*/+
         		29540/*<-vector_history_id*/*46168/*<-ullong*/+
         		6578/*<-vector_dictionary_version*/*31526/*<-double*/+
         		21733/*<-vector_values*/*18443/*<-String*/+
         		39098/*<-error_code*/*38894/*<-int*/;
 
	public ARSVectorVO() {
		super("ARSVector::ARSVectorVO", TYPE_SIGNATURE);

 
		set("account_number", null, "ullong");
 
		set("event_id", null, "String");
 
		set("vector_history_id", null, "ullong");
 
		set("vector_dictionary_version", null, "double");
 
		set("vector_values", null, "String");
 
		set("error_code", null, "int");
	}

	// {{{
	public void setAccountNumber(BigInteger value) { this.set("account_number", (Object)value); }
 	public BigInteger getAccountNumber() { return (BigInteger)this.get("account_number"); }
	// }}}
	// {{{
	public void setEventId(String value) { this.set("event_id", (Object)value); }
 	public String getEventId() { return (String)this.get("event_id"); }
	// }}}
	// {{{
	public void setVectorHistoryId(BigInteger value) { this.set("vector_history_id", (Object)value); }
 	public BigInteger getVectorHistoryId() { return (BigInteger)this.get("vector_history_id"); }
	// }}}
	// {{{
	public void setVectorDictionaryVersion(Double value) { this.set("vector_dictionary_version", (Object)value); }
 	public Double getVectorDictionaryVersion() { return (Double)this.get("vector_dictionary_version"); }
	// }}}
	// {{{
	public void setVectorValues(String value) { this.set("vector_values", (Object)value); }
 	public String getVectorValues() { return (String)this.get("vector_values"); }
	// }}}
	// {{{
	public void setErrorCode(Integer value) { this.set("error_code", (Object)value); }
 	public Integer getErrorCode() { return (Integer)this.get("error_code"); }
	// }}}
}