/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/RiskDCUpdateStatsRequestVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:40 2012 */

package com.paypal.risk;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
  * 
   */

public class RiskDCUpdateStatsRequestVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((40726*40726)<<32)/*<-RiskDCUpdateStatsRequestVO*/+
         		26660/*<-counters*/*47/*<-repeating*/*DCRiskCountersVO.TYPE_SIGNATURE/*<-DCRiskCountersVO*/+
         		2286/*<-card_detail*/*WTransactionCardDetailVO.TYPE_SIGNATURE/*<-WTransactionCardDetailVO*/+
         		40906/*<-model_result*/*DebitCardModelOutVO.TYPE_SIGNATURE/*<-DebitCardModelOutVO*/+
         		24653/*<-is_model_result_set*/*15044/*<-bool*/+
         		20000/*<-transaction_id*/*46168/*<-ullong*/+
         		62145/*<-account_number*/*46168/*<-ullong*/+
         		52543/*<-status*/*37752/*<-char*/+
         		39098/*<-error_code*/*38894/*<-int*/+
         		40166/*<-pimp_return_code*/*46168/*<-ullong*/+
         		14122/*<-message_type*/*18443/*<-String*/;
 
	public RiskDCUpdateStatsRequestVO() {
		super("Risk::RiskDCUpdateStatsRequestVO", TYPE_SIGNATURE);

 
		set("counters", null, "List<Risk::DCRiskCountersVO>");
 
		set("card_detail", null, "Risk::WTransactionCardDetailVO");
 
		set("model_result", null, "Risk::DebitCardModelOutVO");
 
		set("is_model_result_set", null, "bool");
 
		set("transaction_id", null, "ullong");
 
		set("account_number", null, "ullong");
 
		set("status", null, "char");
 
		set("error_code", null, "int");
 
		set("pimp_return_code", null, "ullong");
 
		set("message_type", null, "String");
	}

	// {{{
	public void setCounters(List<DCRiskCountersVO> value) { this.set("counters", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<DCRiskCountersVO> getCounters() { return (List<DCRiskCountersVO>)this.get("counters"); }
	// }}}
	// {{{
	public void setCardDetail(WTransactionCardDetailVO value) { this.set("card_detail", (Object)value); }
 	public WTransactionCardDetailVO getCardDetail() { return (WTransactionCardDetailVO)this.get("card_detail"); }
	// }}}
	// {{{
	public void setModelResult(DebitCardModelOutVO value) { this.set("model_result", (Object)value); }
 	public DebitCardModelOutVO getModelResult() { return (DebitCardModelOutVO)this.get("model_result"); }
	// }}}
	// {{{
	public void setIsModelResultSet(Boolean value) { this.set("is_model_result_set", (Object)value); }
 	public Boolean getIsModelResultSet() { return (Boolean)this.get("is_model_result_set"); }
	// }}}
	// {{{
	public void setTransactionId(BigInteger value) { this.set("transaction_id", (Object)value); }
 	public BigInteger getTransactionId() { return (BigInteger)this.get("transaction_id"); }
	// }}}
	// {{{
	public void setAccountNumber(BigInteger value) { this.set("account_number", (Object)value); }
 	public BigInteger getAccountNumber() { return (BigInteger)this.get("account_number"); }
	// }}}
	// {{{
	public void setStatus(Byte value) { this.set("status", (Object)value); }
 	public Byte getStatus() { return (Byte)this.get("status"); }
	// }}}
	// {{{
	public void setErrorCode(Integer value) { this.set("error_code", (Object)value); }
 	public Integer getErrorCode() { return (Integer)this.get("error_code"); }
	// }}}
	// {{{
	public void setPimpReturnCode(BigInteger value) { this.set("pimp_return_code", (Object)value); }
 	public BigInteger getPimpReturnCode() { return (BigInteger)this.get("pimp_return_code"); }
	// }}}
	// {{{
	public void setMessageType(String value) { this.set("message_type", (Object)value); }
 	public String getMessageType() { return (String)this.get("message_type"); }
	// }}}
}