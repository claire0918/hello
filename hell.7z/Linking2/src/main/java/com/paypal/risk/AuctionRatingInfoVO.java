/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/AuctionRatingInfoVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:39 2012 */

package com.paypal.risk;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
  * 
   */

public class AuctionRatingInfoVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((56303*56303)<<32)/*<-AuctionRatingInfoVO*/+
         		13958/*<-auction_username*/*18443/*<-String*/+
         		10576/*<-auction_site*/*50766/*<-long*/+
         		4040/*<-time_polled*/*33490/*<-ulong*/+
         		3218/*<-overall_pos*/*33490/*<-ulong*/+
         		1390/*<-overall_neg*/*33490/*<-ulong*/+
         		32581/*<-total_pos*/*33490/*<-ulong*/+
         		30601/*<-total_neg*/*33490/*<-ulong*/+
         		34450/*<-recent_pos*/*33490/*<-ulong*/+
         		32078/*<-recent_neg*/*33490/*<-ulong*/+
         		22142/*<-time_on_file*/*33490/*<-ulong*/;
 
	public AuctionRatingInfoVO() {
		super("Risk::AuctionRatingInfoVO", TYPE_SIGNATURE);

 
		set("auction_username", null, "String");
 
		set("auction_site", null, "long");
 
		set("time_polled", null, "ulong");
 
		set("overall_pos", null, "ulong");
 
		set("overall_neg", null, "ulong");
 
		set("total_pos", null, "ulong");
 
		set("total_neg", null, "ulong");
 
		set("recent_pos", null, "ulong");
 
		set("recent_neg", null, "ulong");
 
		set("time_on_file", null, "ulong");
	}

	// {{{
	public void setAuctionUsername(String value) { this.set("auction_username", (Object)value); }
 	public String getAuctionUsername() { return (String)this.get("auction_username"); }
	// }}}
	// {{{
	public void setAuctionSite(Integer value) { this.set("auction_site", (Object)value); }
 	public Integer getAuctionSite() { return (Integer)this.get("auction_site"); }
	// }}}
	// {{{
	public void setTimePolled(Long value) { this.set("time_polled", (Object)value); }
 	public Long getTimePolled() { return (Long)this.get("time_polled"); }
	// }}}
	// {{{
	public void setOverallPos(Long value) { this.set("overall_pos", (Object)value); }
 	public Long getOverallPos() { return (Long)this.get("overall_pos"); }
	// }}}
	// {{{
	public void setOverallNeg(Long value) { this.set("overall_neg", (Object)value); }
 	public Long getOverallNeg() { return (Long)this.get("overall_neg"); }
	// }}}
	// {{{
	public void setTotalPos(Long value) { this.set("total_pos", (Object)value); }
 	public Long getTotalPos() { return (Long)this.get("total_pos"); }
	// }}}
	// {{{
	public void setTotalNeg(Long value) { this.set("total_neg", (Object)value); }
 	public Long getTotalNeg() { return (Long)this.get("total_neg"); }
	// }}}
	// {{{
	public void setRecentPos(Long value) { this.set("recent_pos", (Object)value); }
 	public Long getRecentPos() { return (Long)this.get("recent_pos"); }
	// }}}
	// {{{
	public void setRecentNeg(Long value) { this.set("recent_neg", (Object)value); }
 	public Long getRecentNeg() { return (Long)this.get("recent_neg"); }
	// }}}
	// {{{
	public void setTimeOnFile(Long value) { this.set("time_on_file", (Object)value); }
 	public Long getTimeOnFile() { return (Long)this.get("time_on_file"); }
	// }}}
}