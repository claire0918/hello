/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/RiskPaymentFlowELVVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:40 2012 */

package com.paypal.risk;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
  * 
   */

public class RiskPaymentFlowELVVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((63232*63232)<<32)/*<-RiskPaymentFlowELVVO*/+
         		12252/*<-payment_flow_id*/*46168/*<-ullong*/+
         		62145/*<-account_number*/*46168/*<-ullong*/+
         		10233/*<-counterparty*/*46168/*<-ullong*/+
         		8727/*<-counterparty_alias*/*18443/*<-String*/+
         		11988/*<-s_ebay_id*/*18443/*<-String*/+
         		14991/*<-c_ebay_id*/*18443/*<-String*/+
         		20000/*<-transaction_id*/*46168/*<-ullong*/+
         		56262/*<-market_segment*/*46168/*<-ullong*/+
         		22809/*<-time_created*/*33490/*<-ulong*/+
         		47726/*<-time_updated*/*33490/*<-ulong*/+
         		60232/*<-flags*/*46796/*<-llong*/+
         		266/*<-trans_amt*/*46796/*<-llong*/+
         		55341/*<-trans_currency_code*/*18443/*<-String*/+
         		44506/*<-trans_usd_amt*/*46796/*<-llong*/+
         		62934/*<-trans_amount_res*/*46796/*<-llong*/+
         		31230/*<-s_tof*/*46796/*<-llong*/+
         		30703/*<-s_tof_max_res*/*46796/*<-llong*/+
         		20215/*<-s_tof_min_res*/*46796/*<-llong*/+
         		22172/*<-s_has_neg_bal*/*46796/*<-llong*/+
         		15693/*<-s_has_neg_bal_res*/*46796/*<-llong*/+
         		64606/*<-s_has_confirmed_email*/*46796/*<-llong*/+
         		16403/*<-s_has_confirmed_email_res*/*46796/*<-llong*/+
         		24907/*<-s_has_confirmed_bank*/*46796/*<-llong*/+
         		13304/*<-s_has_confirmed_bank_res*/*46796/*<-llong*/+
         		38673/*<-s_cc_available*/*46796/*<-llong*/+
         		37403/*<-s_cc_available_res*/*46796/*<-llong*/+
         		38959/*<-s_elv_tnum_rev_res*/*46796/*<-llong*/+
         		12008/*<-s_elv_tusd_amt_rvsd_res*/*46796/*<-llong*/+
         		21646/*<-s_complaint_rate*/*31526/*<-double*/+
         		39279/*<-s_complaint_rate_res*/*46796/*<-llong*/+
         		14768/*<-s_charge_back_rate*/*31526/*<-double*/+
         		38997/*<-s_charge_back_rate_res*/*46796/*<-llong*/+
         		56490/*<-s_usd_amt_cum_pays_sent*/*46796/*<-llong*/+
         		57234/*<-s_usd_amt_cum_pays_sent_res*/*46796/*<-llong*/+
         		58268/*<-s_is_high_risk_subprime*/*46796/*<-llong*/+
         		15917/*<-s_is_high_risk_subprime_res*/*46796/*<-llong*/+
         		44392/*<-c_is_business_or_premier*/*46796/*<-llong*/+
         		19789/*<-c_is_business_or_premier_res*/*46796/*<-llong*/+
         		24428/*<-c_accept_cc*/*46796/*<-llong*/+
         		48031/*<-c_accept_cc_res*/*46796/*<-llong*/+
         		43896/*<-trans_not_in_send_money*/*46796/*<-llong*/+
         		25798/*<-trans_not_in_send_money_res*/*46796/*<-llong*/+
         		49373/*<-trans_is_ebay_trans*/*46796/*<-llong*/+
         		7394/*<-trans_is_ebay_trans_res*/*46796/*<-llong*/+
         		31106/*<-s_elv_tusd_amt_fail_res*/*46796/*<-llong*/+
         		11203/*<-s_elv_tusd_amt_succ*/*46796/*<-llong*/+
         		32542/*<-s_elv_tusd_amt_succ_res*/*46796/*<-llong*/+
         		58743/*<-s_ach_nonfinaltx_usd_amt*/*46796/*<-llong*/+
         		65208/*<-s_ach_nonfinaltx_usd_amt_res*/*46796/*<-llong*/+
         		10237/*<-s_ach_model_score*/*31526/*<-double*/+
         		14908/*<-s_ach_model_score_res*/*46796/*<-llong*/+
         		30688/*<-c_complaint_rate*/*31526/*<-double*/+
         		13568/*<-c_complaint_rate_res*/*46796/*<-llong*/+
         		55088/*<-c_chargeback_rate*/*31526/*<-double*/+
         		57505/*<-c_chargeback_rate_res*/*46796/*<-llong*/+
         		28854/*<-c_is_hi_risk_subprime*/*46796/*<-llong*/+
         		34570/*<-c_is_hi_risk_subprime_res*/*46796/*<-llong*/+
         		23801/*<-c_elv_tusd_amt_rc_p_rvsd_res*/*46796/*<-llong*/+
         		62078/*<-c_elv_tusd_amt_rc_rvsd_res*/*46796/*<-llong*/+
         		65375/*<-c_elv_tusd_amt_rc_p_rvsd_r*/*31526/*<-double*/+
         		29641/*<-c_elv_tusd_amt_rc_p_rvsd_r2*/*46796/*<-llong*/+
         		2706/*<-c_elv_tusd_amt_rc_rvsd_r*/*31526/*<-double*/+
         		38447/*<-c_elv_tusd_amt_rc_rvsd_r_res*/*46796/*<-llong*/+
         		10925/*<-c_elv_tusd_amt_rc_res*/*46796/*<-llong*/+
         		17327/*<-c_cum_usd_amt_rc*/*46796/*<-llong*/+
         		58714/*<-c_cum_usd_amt_rc_res*/*46796/*<-llong*/+
         		9371/*<-s_elv_tusd_amt_rvsd_r*/*31526/*<-double*/+
         		654/*<-s_elv_tusd_amt_rvsd_r_res*/*46796/*<-llong*/+
         		5419/*<-s_elv_tusd_amt_rvsd_l_r*/*31526/*<-double*/+
         		29367/*<-s_elv_tusd_amt_rvsd_l_r_res*/*46796/*<-llong*/+
         		41405/*<-s_elv_tusd_amt_fail_r*/*31526/*<-double*/+
         		46188/*<-s_elv_tusd_amt_fail_r_res*/*46796/*<-llong*/+
         		60871/*<-s_elv_tusd_amt_rexpos_res*/*46796/*<-llong*/+
         		30172/*<-c_ebay_tof*/*46796/*<-llong*/+
         		5396/*<-c_ebay_tof_res*/*46796/*<-llong*/+
         		57269/*<-c_ebay_pos_feed_pts*/*46796/*<-llong*/+
         		32281/*<-c_ebay_pos_feed_pts_res*/*46796/*<-llong*/+
         		18596/*<-c_ebay_neg_feed_pts*/*46796/*<-llong*/+
         		8378/*<-c_ebay_neg_feed_pts_res*/*46796/*<-llong*/+
         		4699/*<-c_ebay_pcnt_pos_feed_pts*/*31526/*<-double*/+
         		3878/*<-c_ebay_pcnt_pos_feed_pts_res*/*46796/*<-llong*/+
         		34645/*<-s_ebay_tof*/*46796/*<-llong*/+
         		43368/*<-s_ebay_tof_res*/*46796/*<-llong*/+
         		61711/*<-s_ebay_pos_feed_pts*/*46796/*<-llong*/+
         		3379/*<-s_ebay_pos_feed_pts_res*/*46796/*<-llong*/+
         		26382/*<-s_ebay_neg_feed_pts*/*46796/*<-llong*/+
         		46035/*<-s_ebay_neg_feed_pts_res*/*46796/*<-llong*/+
         		1122/*<-s_ebay_pcnt_pos_feed_pts*/*31526/*<-double*/+
         		33286/*<-s_ebay_pcnt_pos_feed_pts_res*/*46796/*<-llong*/+
         		34265/*<-s_ebay_num_ppacc_bad*/*46796/*<-llong*/+
         		63120/*<-s_ebay_num_ppacc_bad_res*/*46796/*<-llong*/+
         		50938/*<-s_ebay_num_ppacc_rstr*/*46796/*<-llong*/+
         		38469/*<-s_ebay_num_ppacc_rstr_res*/*46796/*<-llong*/+
         		11331/*<-s_ebay_num_ppacc_neg_bal*/*46796/*<-llong*/+
         		24790/*<-s_ebay_num_ppacc_neg_res*/*46796/*<-llong*/+
         		10588/*<-s_ebay_num_ppacc_out_elv*/*46796/*<-llong*/+
         		39155/*<-s_ebay_num_ppacc_out_elv_res*/*46796/*<-llong*/+
         		9740/*<-c_ebay_num_ppacc_bad*/*46796/*<-llong*/+
         		1224/*<-c_ebay_num_ppacc_bad_res*/*46796/*<-llong*/+
         		26779/*<-c_ebay_num_ppacc_rstr*/*46796/*<-llong*/+
         		50510/*<-c_ebay_num_ppacc_rstr_res*/*46796/*<-llong*/+
         		16296/*<-c_ebay_num_ppacc_neg_bal*/*46796/*<-llong*/+
         		52820/*<-c_ebay_num_ppacc_neg_bal_res*/*46796/*<-llong*/+
         		61608/*<-s_elv_tusd_amt_sent*/*46796/*<-llong*/+
         		43091/*<-s_elv_tnum_sent*/*46796/*<-llong*/+
         		49677/*<-s_elv_tusd_amt_rc*/*46796/*<-llong*/+
         		1639/*<-s_elv_tnum_rc*/*46796/*<-llong*/+
         		63268/*<-s_elv_tusd_amt_fail*/*46796/*<-llong*/+
         		28526/*<-s_elv_tnum_failed*/*46796/*<-llong*/+
         		27181/*<-s_elv_tusd_amt_fail_nsf*/*46796/*<-llong*/+
         		54430/*<-s_elv_tnum_fail_nsf*/*46796/*<-llong*/+
         		22879/*<-s_elv_tusd_amt_fail_admin*/*46796/*<-llong*/+
         		14075/*<-s_elv_tnum_failed_admin*/*46796/*<-llong*/+
         		48277/*<-s_elv_tusd_amt_rvsd*/*46796/*<-llong*/+
         		31836/*<-s_elv_tnum_rvsd*/*46796/*<-llong*/+
         		7100/*<-s_elv_tusd_amt_rvsd_unrez*/*46796/*<-llong*/+
         		44700/*<-s_elv_tnum_rvsd_unrez*/*46796/*<-llong*/+
         		9345/*<-s_elv_tusd_amt_rvsd_l*/*46796/*<-llong*/+
         		60629/*<-s_elv_tnum_rvsd_l*/*46796/*<-llong*/+
         		63548/*<-s_elv_tusd_amt_rc_p_rvsd*/*46796/*<-llong*/+
         		54201/*<-s_elv_tnum_rc_p_rvsd*/*46796/*<-llong*/+
         		16705/*<-s_elv_tusd_amt_rc_rvsd*/*46796/*<-llong*/+
         		34149/*<-s_elv_tnum_rc_rvsd*/*46796/*<-llong*/+
         		43164/*<-s_elv_tusd_amt_rvsl_expo*/*46796/*<-llong*/+
         		36113/*<-s_elv_tnum_rvsl_expo*/*46796/*<-llong*/+
         		46373/*<-s_elv_tusd_amt_rvsl_expo_clr*/*46796/*<-llong*/+
         		7066/*<-s_elv_tnum_rvsl_expo_clr*/*46796/*<-llong*/+
         		53874/*<-c_elv_tusd_amt_sent*/*46796/*<-llong*/+
         		2653/*<-c_elv_tnum_sent*/*46796/*<-llong*/+
         		57535/*<-c_elv_tusd_amt_rc*/*46796/*<-llong*/+
         		40454/*<-c_elv_tnum_rc*/*46796/*<-llong*/+
         		56778/*<-c_elv_tusd_amt_fail*/*46796/*<-llong*/+
         		4833/*<-c_elv_tnum_fail*/*46796/*<-llong*/+
         		55667/*<-c_elv_tusd_amt_fail_nsf*/*46796/*<-llong*/+
         		46696/*<-c_elv_tnum_fail_nsf*/*46796/*<-llong*/+
         		35906/*<-c_elv_tusd_amt_fail_admin*/*46796/*<-llong*/+
         		35740/*<-c_elv_tnum_fail_admin*/*46796/*<-llong*/+
         		42607/*<-c_elv_tusd_amt_rvsd*/*46796/*<-llong*/+
         		54869/*<-c_elv_tnum_rvsd*/*46796/*<-llong*/+
         		20311/*<-c_elv_tusd_amt_rvsd_unrez*/*46796/*<-llong*/+
         		21567/*<-c_elv_tnum_rvsd_unrez*/*46796/*<-llong*/+
         		51969/*<-c_elv_tusd_amt_rvsd_l*/*46796/*<-llong*/+
         		2666/*<-c_elv_tnum_rvsd_l*/*46796/*<-llong*/+
         		2564/*<-c_elv_tusd_amt_rc_p_rvsd*/*46796/*<-llong*/+
         		29578/*<-c_elv_tnum_rc_p_rvsd*/*46796/*<-llong*/+
         		39125/*<-c_elv_tusd_amt_rc_rvsd*/*46796/*<-llong*/+
         		25211/*<-c_elv_tnum_rc_rvsd*/*46796/*<-llong*/+
         		47979/*<-c_elv_tusd_amt_rvsl_expo*/*46796/*<-llong*/+
         		8550/*<-c_elv_tnum_rvsl_expo*/*46796/*<-llong*/+
         		18373/*<-c_elv_tusd_amt_rvsl_expo_clr*/*46796/*<-llong*/+
         		13731/*<-c_elv_tnum_rvsl_expo_clr*/*46796/*<-llong*/;
 
	public RiskPaymentFlowELVVO() {
		super("Risk::RiskPaymentFlowELVVO", TYPE_SIGNATURE);

 
		set("payment_flow_id", null, "ullong");
 
		set("account_number", null, "ullong");
 
		set("counterparty", null, "ullong");
 
		set("counterparty_alias", null, "String");
 
		set("s_ebay_id", null, "String");
 
		set("c_ebay_id", null, "String");
 
		set("transaction_id", null, "ullong");
 
		set("market_segment", null, "ullong");
 
		set("time_created", null, "ulong");
 
		set("time_updated", null, "ulong");
 
		set("flags", null, "llong");
 
		set("trans_amt", null, "llong");
 
		set("trans_currency_code", null, "String");
 
		set("trans_usd_amt", null, "llong");
 
		set("trans_amount_res", null, "llong");
 
		set("s_tof", null, "llong");
 
		set("s_tof_max_res", null, "llong");
 
		set("s_tof_min_res", null, "llong");
 
		set("s_has_neg_bal", null, "llong");
 
		set("s_has_neg_bal_res", null, "llong");
 
		set("s_has_confirmed_email", null, "llong");
 
		set("s_has_confirmed_email_res", null, "llong");
 
		set("s_has_confirmed_bank", null, "llong");
 
		set("s_has_confirmed_bank_res", null, "llong");
 
		set("s_cc_available", null, "llong");
 
		set("s_cc_available_res", null, "llong");
 
		set("s_elv_tnum_rev_res", null, "llong");
 
		set("s_elv_tusd_amt_rvsd_res", null, "llong");
 
		set("s_complaint_rate", null, "double");
 
		set("s_complaint_rate_res", null, "llong");
 
		set("s_charge_back_rate", null, "double");
 
		set("s_charge_back_rate_res", null, "llong");
 
		set("s_usd_amt_cum_pays_sent", null, "llong");
 
		set("s_usd_amt_cum_pays_sent_res", null, "llong");
 
		set("s_is_high_risk_subprime", null, "llong");
 
		set("s_is_high_risk_subprime_res", null, "llong");
 
		set("c_is_business_or_premier", null, "llong");
 
		set("c_is_business_or_premier_res", null, "llong");
 
		set("c_accept_cc", null, "llong");
 
		set("c_accept_cc_res", null, "llong");
 
		set("trans_not_in_send_money", null, "llong");
 
		set("trans_not_in_send_money_res", null, "llong");
 
		set("trans_is_ebay_trans", null, "llong");
 
		set("trans_is_ebay_trans_res", null, "llong");
 
		set("s_elv_tusd_amt_fail_res", null, "llong");
 
		set("s_elv_tusd_amt_succ", null, "llong");
 
		set("s_elv_tusd_amt_succ_res", null, "llong");
 
		set("s_ach_nonfinaltx_usd_amt", null, "llong");
 
		set("s_ach_nonfinaltx_usd_amt_res", null, "llong");
 
		set("s_ach_model_score", null, "double");
 
		set("s_ach_model_score_res", null, "llong");
 
		set("c_complaint_rate", null, "double");
 
		set("c_complaint_rate_res", null, "llong");
 
		set("c_chargeback_rate", null, "double");
 
		set("c_chargeback_rate_res", null, "llong");
 
		set("c_is_hi_risk_subprime", null, "llong");
 
		set("c_is_hi_risk_subprime_res", null, "llong");
 
		set("c_elv_tusd_amt_rc_p_rvsd_res", null, "llong");
 
		set("c_elv_tusd_amt_rc_rvsd_res", null, "llong");
 
		set("c_elv_tusd_amt_rc_p_rvsd_r", null, "double");
 
		set("c_elv_tusd_amt_rc_p_rvsd_r2", null, "llong");
 
		set("c_elv_tusd_amt_rc_rvsd_r", null, "double");
 
		set("c_elv_tusd_amt_rc_rvsd_r_res", null, "llong");
 
		set("c_elv_tusd_amt_rc_res", null, "llong");
 
		set("c_cum_usd_amt_rc", null, "llong");
 
		set("c_cum_usd_amt_rc_res", null, "llong");
 
		set("s_elv_tusd_amt_rvsd_r", null, "double");
 
		set("s_elv_tusd_amt_rvsd_r_res", null, "llong");
 
		set("s_elv_tusd_amt_rvsd_l_r", null, "double");
 
		set("s_elv_tusd_amt_rvsd_l_r_res", null, "llong");
 
		set("s_elv_tusd_amt_fail_r", null, "double");
 
		set("s_elv_tusd_amt_fail_r_res", null, "llong");
 
		set("s_elv_tusd_amt_rexpos_res", null, "llong");
 
		set("c_ebay_tof", null, "llong");
 
		set("c_ebay_tof_res", null, "llong");
 
		set("c_ebay_pos_feed_pts", null, "llong");
 
		set("c_ebay_pos_feed_pts_res", null, "llong");
 
		set("c_ebay_neg_feed_pts", null, "llong");
 
		set("c_ebay_neg_feed_pts_res", null, "llong");
 
		set("c_ebay_pcnt_pos_feed_pts", null, "double");
 
		set("c_ebay_pcnt_pos_feed_pts_res", null, "llong");
 
		set("s_ebay_tof", null, "llong");
 
		set("s_ebay_tof_res", null, "llong");
 
		set("s_ebay_pos_feed_pts", null, "llong");
 
		set("s_ebay_pos_feed_pts_res", null, "llong");
 
		set("s_ebay_neg_feed_pts", null, "llong");
 
		set("s_ebay_neg_feed_pts_res", null, "llong");
 
		set("s_ebay_pcnt_pos_feed_pts", null, "double");
 
		set("s_ebay_pcnt_pos_feed_pts_res", null, "llong");
 
		set("s_ebay_num_ppacc_bad", null, "llong");
 
		set("s_ebay_num_ppacc_bad_res", null, "llong");
 
		set("s_ebay_num_ppacc_rstr", null, "llong");
 
		set("s_ebay_num_ppacc_rstr_res", null, "llong");
 
		set("s_ebay_num_ppacc_neg_bal", null, "llong");
 
		set("s_ebay_num_ppacc_neg_res", null, "llong");
 
		set("s_ebay_num_ppacc_out_elv", null, "llong");
 
		set("s_ebay_num_ppacc_out_elv_res", null, "llong");
 
		set("c_ebay_num_ppacc_bad", null, "llong");
 
		set("c_ebay_num_ppacc_bad_res", null, "llong");
 
		set("c_ebay_num_ppacc_rstr", null, "llong");
 
		set("c_ebay_num_ppacc_rstr_res", null, "llong");
 
		set("c_ebay_num_ppacc_neg_bal", null, "llong");
 
		set("c_ebay_num_ppacc_neg_bal_res", null, "llong");
 
		set("s_elv_tusd_amt_sent", null, "llong");
 
		set("s_elv_tnum_sent", null, "llong");
 
		set("s_elv_tusd_amt_rc", null, "llong");
 
		set("s_elv_tnum_rc", null, "llong");
 
		set("s_elv_tusd_amt_fail", null, "llong");
 
		set("s_elv_tnum_failed", null, "llong");
 
		set("s_elv_tusd_amt_fail_nsf", null, "llong");
 
		set("s_elv_tnum_fail_nsf", null, "llong");
 
		set("s_elv_tusd_amt_fail_admin", null, "llong");
 
		set("s_elv_tnum_failed_admin", null, "llong");
 
		set("s_elv_tusd_amt_rvsd", null, "llong");
 
		set("s_elv_tnum_rvsd", null, "llong");
 
		set("s_elv_tusd_amt_rvsd_unrez", null, "llong");
 
		set("s_elv_tnum_rvsd_unrez", null, "llong");
 
		set("s_elv_tusd_amt_rvsd_l", null, "llong");
 
		set("s_elv_tnum_rvsd_l", null, "llong");
 
		set("s_elv_tusd_amt_rc_p_rvsd", null, "llong");
 
		set("s_elv_tnum_rc_p_rvsd", null, "llong");
 
		set("s_elv_tusd_amt_rc_rvsd", null, "llong");
 
		set("s_elv_tnum_rc_rvsd", null, "llong");
 
		set("s_elv_tusd_amt_rvsl_expo", null, "llong");
 
		set("s_elv_tnum_rvsl_expo", null, "llong");
 
		set("s_elv_tusd_amt_rvsl_expo_clr", null, "llong");
 
		set("s_elv_tnum_rvsl_expo_clr", null, "llong");
 
		set("c_elv_tusd_amt_sent", null, "llong");
 
		set("c_elv_tnum_sent", null, "llong");
 
		set("c_elv_tusd_amt_rc", null, "llong");
 
		set("c_elv_tnum_rc", null, "llong");
 
		set("c_elv_tusd_amt_fail", null, "llong");
 
		set("c_elv_tnum_fail", null, "llong");
 
		set("c_elv_tusd_amt_fail_nsf", null, "llong");
 
		set("c_elv_tnum_fail_nsf", null, "llong");
 
		set("c_elv_tusd_amt_fail_admin", null, "llong");
 
		set("c_elv_tnum_fail_admin", null, "llong");
 
		set("c_elv_tusd_amt_rvsd", null, "llong");
 
		set("c_elv_tnum_rvsd", null, "llong");
 
		set("c_elv_tusd_amt_rvsd_unrez", null, "llong");
 
		set("c_elv_tnum_rvsd_unrez", null, "llong");
 
		set("c_elv_tusd_amt_rvsd_l", null, "llong");
 
		set("c_elv_tnum_rvsd_l", null, "llong");
 
		set("c_elv_tusd_amt_rc_p_rvsd", null, "llong");
 
		set("c_elv_tnum_rc_p_rvsd", null, "llong");
 
		set("c_elv_tusd_amt_rc_rvsd", null, "llong");
 
		set("c_elv_tnum_rc_rvsd", null, "llong");
 
		set("c_elv_tusd_amt_rvsl_expo", null, "llong");
 
		set("c_elv_tnum_rvsl_expo", null, "llong");
 
		set("c_elv_tusd_amt_rvsl_expo_clr", null, "llong");
 
		set("c_elv_tnum_rvsl_expo_clr", null, "llong");
	}

	// {{{
	public void setPaymentFlowId(BigInteger value) { this.set("payment_flow_id", (Object)value); }
 	public BigInteger getPaymentFlowId() { return (BigInteger)this.get("payment_flow_id"); }
	// }}}
	// {{{
	public void setAccountNumber(BigInteger value) { this.set("account_number", (Object)value); }
 	public BigInteger getAccountNumber() { return (BigInteger)this.get("account_number"); }
	// }}}
	// {{{
	public void setCounterparty(BigInteger value) { this.set("counterparty", (Object)value); }
 	public BigInteger getCounterparty() { return (BigInteger)this.get("counterparty"); }
	// }}}
	// {{{
	public void setCounterpartyAlias(String value) { this.set("counterparty_alias", (Object)value); }
 	public String getCounterpartyAlias() { return (String)this.get("counterparty_alias"); }
	// }}}
	// {{{
	public void setSEbayId(String value) { this.set("s_ebay_id", (Object)value); }
 	public String getSEbayId() { return (String)this.get("s_ebay_id"); }
	// }}}
	// {{{
	public void setCEbayId(String value) { this.set("c_ebay_id", (Object)value); }
 	public String getCEbayId() { return (String)this.get("c_ebay_id"); }
	// }}}
	// {{{
	public void setTransactionId(BigInteger value) { this.set("transaction_id", (Object)value); }
 	public BigInteger getTransactionId() { return (BigInteger)this.get("transaction_id"); }
	// }}}
	// {{{
	public void setMarketSegment(BigInteger value) { this.set("market_segment", (Object)value); }
 	public BigInteger getMarketSegment() { return (BigInteger)this.get("market_segment"); }
	// }}}
	// {{{
	public void setTimeCreated(Long value) { this.set("time_created", (Object)value); }
 	public Long getTimeCreated() { return (Long)this.get("time_created"); }
	// }}}
	// {{{
	public void setTimeUpdated(Long value) { this.set("time_updated", (Object)value); }
 	public Long getTimeUpdated() { return (Long)this.get("time_updated"); }
	// }}}
	// {{{
	public void setFlags(Long value) { this.set("flags", (Object)value); }
 	public Long getFlags() { return (Long)this.get("flags"); }
	// }}}
	// {{{
	public void setTransAmt(Long value) { this.set("trans_amt", (Object)value); }
 	public Long getTransAmt() { return (Long)this.get("trans_amt"); }
	// }}}
	// {{{
	public void setTransCurrencyCode(String value) { this.set("trans_currency_code", (Object)value); }
 	public String getTransCurrencyCode() { return (String)this.get("trans_currency_code"); }
	// }}}
	// {{{
	public void setTransUsdAmt(Long value) { this.set("trans_usd_amt", (Object)value); }
 	public Long getTransUsdAmt() { return (Long)this.get("trans_usd_amt"); }
	// }}}
	// {{{
	public void setTransAmountRes(Long value) { this.set("trans_amount_res", (Object)value); }
 	public Long getTransAmountRes() { return (Long)this.get("trans_amount_res"); }
	// }}}
	// {{{
	public void setSTof(Long value) { this.set("s_tof", (Object)value); }
 	public Long getSTof() { return (Long)this.get("s_tof"); }
	// }}}
	// {{{
	public void setSTofMaxRes(Long value) { this.set("s_tof_max_res", (Object)value); }
 	public Long getSTofMaxRes() { return (Long)this.get("s_tof_max_res"); }
	// }}}
	// {{{
	public void setSTofMinRes(Long value) { this.set("s_tof_min_res", (Object)value); }
 	public Long getSTofMinRes() { return (Long)this.get("s_tof_min_res"); }
	// }}}
	// {{{
	public void setSHasNegBal(Long value) { this.set("s_has_neg_bal", (Object)value); }
 	public Long getSHasNegBal() { return (Long)this.get("s_has_neg_bal"); }
	// }}}
	// {{{
	public void setSHasNegBalRes(Long value) { this.set("s_has_neg_bal_res", (Object)value); }
 	public Long getSHasNegBalRes() { return (Long)this.get("s_has_neg_bal_res"); }
	// }}}
	// {{{
	public void setSHasConfirmedEmail(Long value) { this.set("s_has_confirmed_email", (Object)value); }
 	public Long getSHasConfirmedEmail() { return (Long)this.get("s_has_confirmed_email"); }
	// }}}
	// {{{
	public void setSHasConfirmedEmailRes(Long value) { this.set("s_has_confirmed_email_res", (Object)value); }
 	public Long getSHasConfirmedEmailRes() { return (Long)this.get("s_has_confirmed_email_res"); }
	// }}}
	// {{{
	public void setSHasConfirmedBank(Long value) { this.set("s_has_confirmed_bank", (Object)value); }
 	public Long getSHasConfirmedBank() { return (Long)this.get("s_has_confirmed_bank"); }
	// }}}
	// {{{
	public void setSHasConfirmedBankRes(Long value) { this.set("s_has_confirmed_bank_res", (Object)value); }
 	public Long getSHasConfirmedBankRes() { return (Long)this.get("s_has_confirmed_bank_res"); }
	// }}}
	// {{{
	public void setSCcAvailable(Long value) { this.set("s_cc_available", (Object)value); }
 	public Long getSCcAvailable() { return (Long)this.get("s_cc_available"); }
	// }}}
	// {{{
	public void setSCcAvailableRes(Long value) { this.set("s_cc_available_res", (Object)value); }
 	public Long getSCcAvailableRes() { return (Long)this.get("s_cc_available_res"); }
	// }}}
	// {{{
	public void setSElvTnumRevRes(Long value) { this.set("s_elv_tnum_rev_res", (Object)value); }
 	public Long getSElvTnumRevRes() { return (Long)this.get("s_elv_tnum_rev_res"); }
	// }}}
	// {{{
	public void setSElvTusdAmtRvsdRes(Long value) { this.set("s_elv_tusd_amt_rvsd_res", (Object)value); }
 	public Long getSElvTusdAmtRvsdRes() { return (Long)this.get("s_elv_tusd_amt_rvsd_res"); }
	// }}}
	// {{{
	public void setSComplaintRate(Double value) { this.set("s_complaint_rate", (Object)value); }
 	public Double getSComplaintRate() { return (Double)this.get("s_complaint_rate"); }
	// }}}
	// {{{
	public void setSComplaintRateRes(Long value) { this.set("s_complaint_rate_res", (Object)value); }
 	public Long getSComplaintRateRes() { return (Long)this.get("s_complaint_rate_res"); }
	// }}}
	// {{{
	public void setSChargeBackRate(Double value) { this.set("s_charge_back_rate", (Object)value); }
 	public Double getSChargeBackRate() { return (Double)this.get("s_charge_back_rate"); }
	// }}}
	// {{{
	public void setSChargeBackRateRes(Long value) { this.set("s_charge_back_rate_res", (Object)value); }
 	public Long getSChargeBackRateRes() { return (Long)this.get("s_charge_back_rate_res"); }
	// }}}
	// {{{
	public void setSUsdAmtCumPaysSent(Long value) { this.set("s_usd_amt_cum_pays_sent", (Object)value); }
 	public Long getSUsdAmtCumPaysSent() { return (Long)this.get("s_usd_amt_cum_pays_sent"); }
	// }}}
	// {{{
	public void setSUsdAmtCumPaysSentRes(Long value) { this.set("s_usd_amt_cum_pays_sent_res", (Object)value); }
 	public Long getSUsdAmtCumPaysSentRes() { return (Long)this.get("s_usd_amt_cum_pays_sent_res"); }
	// }}}
	// {{{
	public void setSIsHighRiskSubprime(Long value) { this.set("s_is_high_risk_subprime", (Object)value); }
 	public Long getSIsHighRiskSubprime() { return (Long)this.get("s_is_high_risk_subprime"); }
	// }}}
	// {{{
	public void setSIsHighRiskSubprimeRes(Long value) { this.set("s_is_high_risk_subprime_res", (Object)value); }
 	public Long getSIsHighRiskSubprimeRes() { return (Long)this.get("s_is_high_risk_subprime_res"); }
	// }}}
	// {{{
	public void setCIsBusinessOrPremier(Long value) { this.set("c_is_business_or_premier", (Object)value); }
 	public Long getCIsBusinessOrPremier() { return (Long)this.get("c_is_business_or_premier"); }
	// }}}
	// {{{
	public void setCIsBusinessOrPremierRes(Long value) { this.set("c_is_business_or_premier_res", (Object)value); }
 	public Long getCIsBusinessOrPremierRes() { return (Long)this.get("c_is_business_or_premier_res"); }
	// }}}
	// {{{
	public void setCAcceptCc(Long value) { this.set("c_accept_cc", (Object)value); }
 	public Long getCAcceptCc() { return (Long)this.get("c_accept_cc"); }
	// }}}
	// {{{
	public void setCAcceptCcRes(Long value) { this.set("c_accept_cc_res", (Object)value); }
 	public Long getCAcceptCcRes() { return (Long)this.get("c_accept_cc_res"); }
	// }}}
	// {{{
	public void setTransNotInSendMoney(Long value) { this.set("trans_not_in_send_money", (Object)value); }
 	public Long getTransNotInSendMoney() { return (Long)this.get("trans_not_in_send_money"); }
	// }}}
	// {{{
	public void setTransNotInSendMoneyRes(Long value) { this.set("trans_not_in_send_money_res", (Object)value); }
 	public Long getTransNotInSendMoneyRes() { return (Long)this.get("trans_not_in_send_money_res"); }
	// }}}
	// {{{
	public void setTransIsEbayTrans(Long value) { this.set("trans_is_ebay_trans", (Object)value); }
 	public Long getTransIsEbayTrans() { return (Long)this.get("trans_is_ebay_trans"); }
	// }}}
	// {{{
	public void setTransIsEbayTransRes(Long value) { this.set("trans_is_ebay_trans_res", (Object)value); }
 	public Long getTransIsEbayTransRes() { return (Long)this.get("trans_is_ebay_trans_res"); }
	// }}}
	// {{{
	public void setSElvTusdAmtFailRes(Long value) { this.set("s_elv_tusd_amt_fail_res", (Object)value); }
 	public Long getSElvTusdAmtFailRes() { return (Long)this.get("s_elv_tusd_amt_fail_res"); }
	// }}}
	// {{{
	public void setSElvTusdAmtSucc(Long value) { this.set("s_elv_tusd_amt_succ", (Object)value); }
 	public Long getSElvTusdAmtSucc() { return (Long)this.get("s_elv_tusd_amt_succ"); }
	// }}}
	// {{{
	public void setSElvTusdAmtSuccRes(Long value) { this.set("s_elv_tusd_amt_succ_res", (Object)value); }
 	public Long getSElvTusdAmtSuccRes() { return (Long)this.get("s_elv_tusd_amt_succ_res"); }
	// }}}
	// {{{
	public void setSAchNonfinaltxUsdAmt(Long value) { this.set("s_ach_nonfinaltx_usd_amt", (Object)value); }
 	public Long getSAchNonfinaltxUsdAmt() { return (Long)this.get("s_ach_nonfinaltx_usd_amt"); }
	// }}}
	// {{{
	public void setSAchNonfinaltxUsdAmtRes(Long value) { this.set("s_ach_nonfinaltx_usd_amt_res", (Object)value); }
 	public Long getSAchNonfinaltxUsdAmtRes() { return (Long)this.get("s_ach_nonfinaltx_usd_amt_res"); }
	// }}}
	// {{{
	public void setSAchModelScore(Double value) { this.set("s_ach_model_score", (Object)value); }
 	public Double getSAchModelScore() { return (Double)this.get("s_ach_model_score"); }
	// }}}
	// {{{
	public void setSAchModelScoreRes(Long value) { this.set("s_ach_model_score_res", (Object)value); }
 	public Long getSAchModelScoreRes() { return (Long)this.get("s_ach_model_score_res"); }
	// }}}
	// {{{
	public void setCComplaintRate(Double value) { this.set("c_complaint_rate", (Object)value); }
 	public Double getCComplaintRate() { return (Double)this.get("c_complaint_rate"); }
	// }}}
	// {{{
	public void setCComplaintRateRes(Long value) { this.set("c_complaint_rate_res", (Object)value); }
 	public Long getCComplaintRateRes() { return (Long)this.get("c_complaint_rate_res"); }
	// }}}
	// {{{
	public void setCChargebackRate(Double value) { this.set("c_chargeback_rate", (Object)value); }
 	public Double getCChargebackRate() { return (Double)this.get("c_chargeback_rate"); }
	// }}}
	// {{{
	public void setCChargebackRateRes(Long value) { this.set("c_chargeback_rate_res", (Object)value); }
 	public Long getCChargebackRateRes() { return (Long)this.get("c_chargeback_rate_res"); }
	// }}}
	// {{{
	public void setCIsHiRiskSubprime(Long value) { this.set("c_is_hi_risk_subprime", (Object)value); }
 	public Long getCIsHiRiskSubprime() { return (Long)this.get("c_is_hi_risk_subprime"); }
	// }}}
	// {{{
	public void setCIsHiRiskSubprimeRes(Long value) { this.set("c_is_hi_risk_subprime_res", (Object)value); }
 	public Long getCIsHiRiskSubprimeRes() { return (Long)this.get("c_is_hi_risk_subprime_res"); }
	// }}}
	// {{{
	public void setCElvTusdAmtRcPRvsdRes(Long value) { this.set("c_elv_tusd_amt_rc_p_rvsd_res", (Object)value); }
 	public Long getCElvTusdAmtRcPRvsdRes() { return (Long)this.get("c_elv_tusd_amt_rc_p_rvsd_res"); }
	// }}}
	// {{{
	public void setCElvTusdAmtRcRvsdRes(Long value) { this.set("c_elv_tusd_amt_rc_rvsd_res", (Object)value); }
 	public Long getCElvTusdAmtRcRvsdRes() { return (Long)this.get("c_elv_tusd_amt_rc_rvsd_res"); }
	// }}}
	// {{{
	public void setCElvTusdAmtRcPRvsdR(Double value) { this.set("c_elv_tusd_amt_rc_p_rvsd_r", (Object)value); }
 	public Double getCElvTusdAmtRcPRvsdR() { return (Double)this.get("c_elv_tusd_amt_rc_p_rvsd_r"); }
	// }}}
	// {{{
	public void setCElvTusdAmtRcPRvsdR2(Long value) { this.set("c_elv_tusd_amt_rc_p_rvsd_r2", (Object)value); }
 	public Long getCElvTusdAmtRcPRvsdR2() { return (Long)this.get("c_elv_tusd_amt_rc_p_rvsd_r2"); }
	// }}}
	// {{{
	public void setCElvTusdAmtRcRvsdR(Double value) { this.set("c_elv_tusd_amt_rc_rvsd_r", (Object)value); }
 	public Double getCElvTusdAmtRcRvsdR() { return (Double)this.get("c_elv_tusd_amt_rc_rvsd_r"); }
	// }}}
	// {{{
	public void setCElvTusdAmtRcRvsdRRes(Long value) { this.set("c_elv_tusd_amt_rc_rvsd_r_res", (Object)value); }
 	public Long getCElvTusdAmtRcRvsdRRes() { return (Long)this.get("c_elv_tusd_amt_rc_rvsd_r_res"); }
	// }}}
	// {{{
	public void setCElvTusdAmtRcRes(Long value) { this.set("c_elv_tusd_amt_rc_res", (Object)value); }
 	public Long getCElvTusdAmtRcRes() { return (Long)this.get("c_elv_tusd_amt_rc_res"); }
	// }}}
	// {{{
	public void setCCumUsdAmtRc(Long value) { this.set("c_cum_usd_amt_rc", (Object)value); }
 	public Long getCCumUsdAmtRc() { return (Long)this.get("c_cum_usd_amt_rc"); }
	// }}}
	// {{{
	public void setCCumUsdAmtRcRes(Long value) { this.set("c_cum_usd_amt_rc_res", (Object)value); }
 	public Long getCCumUsdAmtRcRes() { return (Long)this.get("c_cum_usd_amt_rc_res"); }
	// }}}
	// {{{
	public void setSElvTusdAmtRvsdR(Double value) { this.set("s_elv_tusd_amt_rvsd_r", (Object)value); }
 	public Double getSElvTusdAmtRvsdR() { return (Double)this.get("s_elv_tusd_amt_rvsd_r"); }
	// }}}
	// {{{
	public void setSElvTusdAmtRvsdRRes(Long value) { this.set("s_elv_tusd_amt_rvsd_r_res", (Object)value); }
 	public Long getSElvTusdAmtRvsdRRes() { return (Long)this.get("s_elv_tusd_amt_rvsd_r_res"); }
	// }}}
	// {{{
	public void setSElvTusdAmtRvsdLR(Double value) { this.set("s_elv_tusd_amt_rvsd_l_r", (Object)value); }
 	public Double getSElvTusdAmtRvsdLR() { return (Double)this.get("s_elv_tusd_amt_rvsd_l_r"); }
	// }}}
	// {{{
	public void setSElvTusdAmtRvsdLRRes(Long value) { this.set("s_elv_tusd_amt_rvsd_l_r_res", (Object)value); }
 	public Long getSElvTusdAmtRvsdLRRes() { return (Long)this.get("s_elv_tusd_amt_rvsd_l_r_res"); }
	// }}}
	// {{{
	public void setSElvTusdAmtFailR(Double value) { this.set("s_elv_tusd_amt_fail_r", (Object)value); }
 	public Double getSElvTusdAmtFailR() { return (Double)this.get("s_elv_tusd_amt_fail_r"); }
	// }}}
	// {{{
	public void setSElvTusdAmtFailRRes(Long value) { this.set("s_elv_tusd_amt_fail_r_res", (Object)value); }
 	public Long getSElvTusdAmtFailRRes() { return (Long)this.get("s_elv_tusd_amt_fail_r_res"); }
	// }}}
	// {{{
	public void setSElvTusdAmtRexposRes(Long value) { this.set("s_elv_tusd_amt_rexpos_res", (Object)value); }
 	public Long getSElvTusdAmtRexposRes() { return (Long)this.get("s_elv_tusd_amt_rexpos_res"); }
	// }}}
	// {{{
	public void setCEbayTof(Long value) { this.set("c_ebay_tof", (Object)value); }
 	public Long getCEbayTof() { return (Long)this.get("c_ebay_tof"); }
	// }}}
	// {{{
	public void setCEbayTofRes(Long value) { this.set("c_ebay_tof_res", (Object)value); }
 	public Long getCEbayTofRes() { return (Long)this.get("c_ebay_tof_res"); }
	// }}}
	// {{{
	public void setCEbayPosFeedPts(Long value) { this.set("c_ebay_pos_feed_pts", (Object)value); }
 	public Long getCEbayPosFeedPts() { return (Long)this.get("c_ebay_pos_feed_pts"); }
	// }}}
	// {{{
	public void setCEbayPosFeedPtsRes(Long value) { this.set("c_ebay_pos_feed_pts_res", (Object)value); }
 	public Long getCEbayPosFeedPtsRes() { return (Long)this.get("c_ebay_pos_feed_pts_res"); }
	// }}}
	// {{{
	public void setCEbayNegFeedPts(Long value) { this.set("c_ebay_neg_feed_pts", (Object)value); }
 	public Long getCEbayNegFeedPts() { return (Long)this.get("c_ebay_neg_feed_pts"); }
	// }}}
	// {{{
	public void setCEbayNegFeedPtsRes(Long value) { this.set("c_ebay_neg_feed_pts_res", (Object)value); }
 	public Long getCEbayNegFeedPtsRes() { return (Long)this.get("c_ebay_neg_feed_pts_res"); }
	// }}}
	// {{{
	public void setCEbayPcntPosFeedPts(Double value) { this.set("c_ebay_pcnt_pos_feed_pts", (Object)value); }
 	public Double getCEbayPcntPosFeedPts() { return (Double)this.get("c_ebay_pcnt_pos_feed_pts"); }
	// }}}
	// {{{
	public void setCEbayPcntPosFeedPtsRes(Long value) { this.set("c_ebay_pcnt_pos_feed_pts_res", (Object)value); }
 	public Long getCEbayPcntPosFeedPtsRes() { return (Long)this.get("c_ebay_pcnt_pos_feed_pts_res"); }
	// }}}
	// {{{
	public void setSEbayTof(Long value) { this.set("s_ebay_tof", (Object)value); }
 	public Long getSEbayTof() { return (Long)this.get("s_ebay_tof"); }
	// }}}
	// {{{
	public void setSEbayTofRes(Long value) { this.set("s_ebay_tof_res", (Object)value); }
 	public Long getSEbayTofRes() { return (Long)this.get("s_ebay_tof_res"); }
	// }}}
	// {{{
	public void setSEbayPosFeedPts(Long value) { this.set("s_ebay_pos_feed_pts", (Object)value); }
 	public Long getSEbayPosFeedPts() { return (Long)this.get("s_ebay_pos_feed_pts"); }
	// }}}
	// {{{
	public void setSEbayPosFeedPtsRes(Long value) { this.set("s_ebay_pos_feed_pts_res", (Object)value); }
 	public Long getSEbayPosFeedPtsRes() { return (Long)this.get("s_ebay_pos_feed_pts_res"); }
	// }}}
	// {{{
	public void setSEbayNegFeedPts(Long value) { this.set("s_ebay_neg_feed_pts", (Object)value); }
 	public Long getSEbayNegFeedPts() { return (Long)this.get("s_ebay_neg_feed_pts"); }
	// }}}
	// {{{
	public void setSEbayNegFeedPtsRes(Long value) { this.set("s_ebay_neg_feed_pts_res", (Object)value); }
 	public Long getSEbayNegFeedPtsRes() { return (Long)this.get("s_ebay_neg_feed_pts_res"); }
	// }}}
	// {{{
	public void setSEbayPcntPosFeedPts(Double value) { this.set("s_ebay_pcnt_pos_feed_pts", (Object)value); }
 	public Double getSEbayPcntPosFeedPts() { return (Double)this.get("s_ebay_pcnt_pos_feed_pts"); }
	// }}}
	// {{{
	public void setSEbayPcntPosFeedPtsRes(Long value) { this.set("s_ebay_pcnt_pos_feed_pts_res", (Object)value); }
 	public Long getSEbayPcntPosFeedPtsRes() { return (Long)this.get("s_ebay_pcnt_pos_feed_pts_res"); }
	// }}}
	// {{{
	public void setSEbayNumPpaccBad(Long value) { this.set("s_ebay_num_ppacc_bad", (Object)value); }
 	public Long getSEbayNumPpaccBad() { return (Long)this.get("s_ebay_num_ppacc_bad"); }
	// }}}
	// {{{
	public void setSEbayNumPpaccBadRes(Long value) { this.set("s_ebay_num_ppacc_bad_res", (Object)value); }
 	public Long getSEbayNumPpaccBadRes() { return (Long)this.get("s_ebay_num_ppacc_bad_res"); }
	// }}}
	// {{{
	public void setSEbayNumPpaccRstr(Long value) { this.set("s_ebay_num_ppacc_rstr", (Object)value); }
 	public Long getSEbayNumPpaccRstr() { return (Long)this.get("s_ebay_num_ppacc_rstr"); }
	// }}}
	// {{{
	public void setSEbayNumPpaccRstrRes(Long value) { this.set("s_ebay_num_ppacc_rstr_res", (Object)value); }
 	public Long getSEbayNumPpaccRstrRes() { return (Long)this.get("s_ebay_num_ppacc_rstr_res"); }
	// }}}
	// {{{
	public void setSEbayNumPpaccNegBal(Long value) { this.set("s_ebay_num_ppacc_neg_bal", (Object)value); }
 	public Long getSEbayNumPpaccNegBal() { return (Long)this.get("s_ebay_num_ppacc_neg_bal"); }
	// }}}
	// {{{
	public void setSEbayNumPpaccNegRes(Long value) { this.set("s_ebay_num_ppacc_neg_res", (Object)value); }
 	public Long getSEbayNumPpaccNegRes() { return (Long)this.get("s_ebay_num_ppacc_neg_res"); }
	// }}}
	// {{{
	public void setSEbayNumPpaccOutElv(Long value) { this.set("s_ebay_num_ppacc_out_elv", (Object)value); }
 	public Long getSEbayNumPpaccOutElv() { return (Long)this.get("s_ebay_num_ppacc_out_elv"); }
	// }}}
	// {{{
	public void setSEbayNumPpaccOutElvRes(Long value) { this.set("s_ebay_num_ppacc_out_elv_res", (Object)value); }
 	public Long getSEbayNumPpaccOutElvRes() { return (Long)this.get("s_ebay_num_ppacc_out_elv_res"); }
	// }}}
	// {{{
	public void setCEbayNumPpaccBad(Long value) { this.set("c_ebay_num_ppacc_bad", (Object)value); }
 	public Long getCEbayNumPpaccBad() { return (Long)this.get("c_ebay_num_ppacc_bad"); }
	// }}}
	// {{{
	public void setCEbayNumPpaccBadRes(Long value) { this.set("c_ebay_num_ppacc_bad_res", (Object)value); }
 	public Long getCEbayNumPpaccBadRes() { return (Long)this.get("c_ebay_num_ppacc_bad_res"); }
	// }}}
	// {{{
	public void setCEbayNumPpaccRstr(Long value) { this.set("c_ebay_num_ppacc_rstr", (Object)value); }
 	public Long getCEbayNumPpaccRstr() { return (Long)this.get("c_ebay_num_ppacc_rstr"); }
	// }}}
	// {{{
	public void setCEbayNumPpaccRstrRes(Long value) { this.set("c_ebay_num_ppacc_rstr_res", (Object)value); }
 	public Long getCEbayNumPpaccRstrRes() { return (Long)this.get("c_ebay_num_ppacc_rstr_res"); }
	// }}}
	// {{{
	public void setCEbayNumPpaccNegBal(Long value) { this.set("c_ebay_num_ppacc_neg_bal", (Object)value); }
 	public Long getCEbayNumPpaccNegBal() { return (Long)this.get("c_ebay_num_ppacc_neg_bal"); }
	// }}}
	// {{{
	public void setCEbayNumPpaccNegBalRes(Long value) { this.set("c_ebay_num_ppacc_neg_bal_res", (Object)value); }
 	public Long getCEbayNumPpaccNegBalRes() { return (Long)this.get("c_ebay_num_ppacc_neg_bal_res"); }
	// }}}
	// {{{
	public void setSElvTusdAmtSent(Long value) { this.set("s_elv_tusd_amt_sent", (Object)value); }
 	public Long getSElvTusdAmtSent() { return (Long)this.get("s_elv_tusd_amt_sent"); }
	// }}}
	// {{{
	public void setSElvTnumSent(Long value) { this.set("s_elv_tnum_sent", (Object)value); }
 	public Long getSElvTnumSent() { return (Long)this.get("s_elv_tnum_sent"); }
	// }}}
	// {{{
	public void setSElvTusdAmtRc(Long value) { this.set("s_elv_tusd_amt_rc", (Object)value); }
 	public Long getSElvTusdAmtRc() { return (Long)this.get("s_elv_tusd_amt_rc"); }
	// }}}
	// {{{
	public void setSElvTnumRc(Long value) { this.set("s_elv_tnum_rc", (Object)value); }
 	public Long getSElvTnumRc() { return (Long)this.get("s_elv_tnum_rc"); }
	// }}}
	// {{{
	public void setSElvTusdAmtFail(Long value) { this.set("s_elv_tusd_amt_fail", (Object)value); }
 	public Long getSElvTusdAmtFail() { return (Long)this.get("s_elv_tusd_amt_fail"); }
	// }}}
	// {{{
	public void setSElvTnumFailed(Long value) { this.set("s_elv_tnum_failed", (Object)value); }
 	public Long getSElvTnumFailed() { return (Long)this.get("s_elv_tnum_failed"); }
	// }}}
	// {{{
	public void setSElvTusdAmtFailNsf(Long value) { this.set("s_elv_tusd_amt_fail_nsf", (Object)value); }
 	public Long getSElvTusdAmtFailNsf() { return (Long)this.get("s_elv_tusd_amt_fail_nsf"); }
	// }}}
	// {{{
	public void setSElvTnumFailNsf(Long value) { this.set("s_elv_tnum_fail_nsf", (Object)value); }
 	public Long getSElvTnumFailNsf() { return (Long)this.get("s_elv_tnum_fail_nsf"); }
	// }}}
	// {{{
	public void setSElvTusdAmtFailAdmin(Long value) { this.set("s_elv_tusd_amt_fail_admin", (Object)value); }
 	public Long getSElvTusdAmtFailAdmin() { return (Long)this.get("s_elv_tusd_amt_fail_admin"); }
	// }}}
	// {{{
	public void setSElvTnumFailedAdmin(Long value) { this.set("s_elv_tnum_failed_admin", (Object)value); }
 	public Long getSElvTnumFailedAdmin() { return (Long)this.get("s_elv_tnum_failed_admin"); }
	// }}}
	// {{{
	public void setSElvTusdAmtRvsd(Long value) { this.set("s_elv_tusd_amt_rvsd", (Object)value); }
 	public Long getSElvTusdAmtRvsd() { return (Long)this.get("s_elv_tusd_amt_rvsd"); }
	// }}}
	// {{{
	public void setSElvTnumRvsd(Long value) { this.set("s_elv_tnum_rvsd", (Object)value); }
 	public Long getSElvTnumRvsd() { return (Long)this.get("s_elv_tnum_rvsd"); }
	// }}}
	// {{{
	public void setSElvTusdAmtRvsdUnrez(Long value) { this.set("s_elv_tusd_amt_rvsd_unrez", (Object)value); }
 	public Long getSElvTusdAmtRvsdUnrez() { return (Long)this.get("s_elv_tusd_amt_rvsd_unrez"); }
	// }}}
	// {{{
	public void setSElvTnumRvsdUnrez(Long value) { this.set("s_elv_tnum_rvsd_unrez", (Object)value); }
 	public Long getSElvTnumRvsdUnrez() { return (Long)this.get("s_elv_tnum_rvsd_unrez"); }
	// }}}
	// {{{
	public void setSElvTusdAmtRvsdL(Long value) { this.set("s_elv_tusd_amt_rvsd_l", (Object)value); }
 	public Long getSElvTusdAmtRvsdL() { return (Long)this.get("s_elv_tusd_amt_rvsd_l"); }
	// }}}
	// {{{
	public void setSElvTnumRvsdL(Long value) { this.set("s_elv_tnum_rvsd_l", (Object)value); }
 	public Long getSElvTnumRvsdL() { return (Long)this.get("s_elv_tnum_rvsd_l"); }
	// }}}
	// {{{
	public void setSElvTusdAmtRcPRvsd(Long value) { this.set("s_elv_tusd_amt_rc_p_rvsd", (Object)value); }
 	public Long getSElvTusdAmtRcPRvsd() { return (Long)this.get("s_elv_tusd_amt_rc_p_rvsd"); }
	// }}}
	// {{{
	public void setSElvTnumRcPRvsd(Long value) { this.set("s_elv_tnum_rc_p_rvsd", (Object)value); }
 	public Long getSElvTnumRcPRvsd() { return (Long)this.get("s_elv_tnum_rc_p_rvsd"); }
	// }}}
	// {{{
	public void setSElvTusdAmtRcRvsd(Long value) { this.set("s_elv_tusd_amt_rc_rvsd", (Object)value); }
 	public Long getSElvTusdAmtRcRvsd() { return (Long)this.get("s_elv_tusd_amt_rc_rvsd"); }
	// }}}
	// {{{
	public void setSElvTnumRcRvsd(Long value) { this.set("s_elv_tnum_rc_rvsd", (Object)value); }
 	public Long getSElvTnumRcRvsd() { return (Long)this.get("s_elv_tnum_rc_rvsd"); }
	// }}}
	// {{{
	public void setSElvTusdAmtRvslExpo(Long value) { this.set("s_elv_tusd_amt_rvsl_expo", (Object)value); }
 	public Long getSElvTusdAmtRvslExpo() { return (Long)this.get("s_elv_tusd_amt_rvsl_expo"); }
	// }}}
	// {{{
	public void setSElvTnumRvslExpo(Long value) { this.set("s_elv_tnum_rvsl_expo", (Object)value); }
 	public Long getSElvTnumRvslExpo() { return (Long)this.get("s_elv_tnum_rvsl_expo"); }
	// }}}
	// {{{
	public void setSElvTusdAmtRvslExpoClr(Long value) { this.set("s_elv_tusd_amt_rvsl_expo_clr", (Object)value); }
 	public Long getSElvTusdAmtRvslExpoClr() { return (Long)this.get("s_elv_tusd_amt_rvsl_expo_clr"); }
	// }}}
	// {{{
	public void setSElvTnumRvslExpoClr(Long value) { this.set("s_elv_tnum_rvsl_expo_clr", (Object)value); }
 	public Long getSElvTnumRvslExpoClr() { return (Long)this.get("s_elv_tnum_rvsl_expo_clr"); }
	// }}}
	// {{{
	public void setCElvTusdAmtSent(Long value) { this.set("c_elv_tusd_amt_sent", (Object)value); }
 	public Long getCElvTusdAmtSent() { return (Long)this.get("c_elv_tusd_amt_sent"); }
	// }}}
	// {{{
	public void setCElvTnumSent(Long value) { this.set("c_elv_tnum_sent", (Object)value); }
 	public Long getCElvTnumSent() { return (Long)this.get("c_elv_tnum_sent"); }
	// }}}
	// {{{
	public void setCElvTusdAmtRc(Long value) { this.set("c_elv_tusd_amt_rc", (Object)value); }
 	public Long getCElvTusdAmtRc() { return (Long)this.get("c_elv_tusd_amt_rc"); }
	// }}}
	// {{{
	public void setCElvTnumRc(Long value) { this.set("c_elv_tnum_rc", (Object)value); }
 	public Long getCElvTnumRc() { return (Long)this.get("c_elv_tnum_rc"); }
	// }}}
	// {{{
	public void setCElvTusdAmtFail(Long value) { this.set("c_elv_tusd_amt_fail", (Object)value); }
 	public Long getCElvTusdAmtFail() { return (Long)this.get("c_elv_tusd_amt_fail"); }
	// }}}
	// {{{
	public void setCElvTnumFail(Long value) { this.set("c_elv_tnum_fail", (Object)value); }
 	public Long getCElvTnumFail() { return (Long)this.get("c_elv_tnum_fail"); }
	// }}}
	// {{{
	public void setCElvTusdAmtFailNsf(Long value) { this.set("c_elv_tusd_amt_fail_nsf", (Object)value); }
 	public Long getCElvTusdAmtFailNsf() { return (Long)this.get("c_elv_tusd_amt_fail_nsf"); }
	// }}}
	// {{{
	public void setCElvTnumFailNsf(Long value) { this.set("c_elv_tnum_fail_nsf", (Object)value); }
 	public Long getCElvTnumFailNsf() { return (Long)this.get("c_elv_tnum_fail_nsf"); }
	// }}}
	// {{{
	public void setCElvTusdAmtFailAdmin(Long value) { this.set("c_elv_tusd_amt_fail_admin", (Object)value); }
 	public Long getCElvTusdAmtFailAdmin() { return (Long)this.get("c_elv_tusd_amt_fail_admin"); }
	// }}}
	// {{{
	public void setCElvTnumFailAdmin(Long value) { this.set("c_elv_tnum_fail_admin", (Object)value); }
 	public Long getCElvTnumFailAdmin() { return (Long)this.get("c_elv_tnum_fail_admin"); }
	// }}}
	// {{{
	public void setCElvTusdAmtRvsd(Long value) { this.set("c_elv_tusd_amt_rvsd", (Object)value); }
 	public Long getCElvTusdAmtRvsd() { return (Long)this.get("c_elv_tusd_amt_rvsd"); }
	// }}}
	// {{{
	public void setCElvTnumRvsd(Long value) { this.set("c_elv_tnum_rvsd", (Object)value); }
 	public Long getCElvTnumRvsd() { return (Long)this.get("c_elv_tnum_rvsd"); }
	// }}}
	// {{{
	public void setCElvTusdAmtRvsdUnrez(Long value) { this.set("c_elv_tusd_amt_rvsd_unrez", (Object)value); }
 	public Long getCElvTusdAmtRvsdUnrez() { return (Long)this.get("c_elv_tusd_amt_rvsd_unrez"); }
	// }}}
	// {{{
	public void setCElvTnumRvsdUnrez(Long value) { this.set("c_elv_tnum_rvsd_unrez", (Object)value); }
 	public Long getCElvTnumRvsdUnrez() { return (Long)this.get("c_elv_tnum_rvsd_unrez"); }
	// }}}
	// {{{
	public void setCElvTusdAmtRvsdL(Long value) { this.set("c_elv_tusd_amt_rvsd_l", (Object)value); }
 	public Long getCElvTusdAmtRvsdL() { return (Long)this.get("c_elv_tusd_amt_rvsd_l"); }
	// }}}
	// {{{
	public void setCElvTnumRvsdL(Long value) { this.set("c_elv_tnum_rvsd_l", (Object)value); }
 	public Long getCElvTnumRvsdL() { return (Long)this.get("c_elv_tnum_rvsd_l"); }
	// }}}
	// {{{
	public void setCElvTusdAmtRcPRvsd(Long value) { this.set("c_elv_tusd_amt_rc_p_rvsd", (Object)value); }
 	public Long getCElvTusdAmtRcPRvsd() { return (Long)this.get("c_elv_tusd_amt_rc_p_rvsd"); }
	// }}}
	// {{{
	public void setCElvTnumRcPRvsd(Long value) { this.set("c_elv_tnum_rc_p_rvsd", (Object)value); }
 	public Long getCElvTnumRcPRvsd() { return (Long)this.get("c_elv_tnum_rc_p_rvsd"); }
	// }}}
	// {{{
	public void setCElvTusdAmtRcRvsd(Long value) { this.set("c_elv_tusd_amt_rc_rvsd", (Object)value); }
 	public Long getCElvTusdAmtRcRvsd() { return (Long)this.get("c_elv_tusd_amt_rc_rvsd"); }
	// }}}
	// {{{
	public void setCElvTnumRcRvsd(Long value) { this.set("c_elv_tnum_rc_rvsd", (Object)value); }
 	public Long getCElvTnumRcRvsd() { return (Long)this.get("c_elv_tnum_rc_rvsd"); }
	// }}}
	// {{{
	public void setCElvTusdAmtRvslExpo(Long value) { this.set("c_elv_tusd_amt_rvsl_expo", (Object)value); }
 	public Long getCElvTusdAmtRvslExpo() { return (Long)this.get("c_elv_tusd_amt_rvsl_expo"); }
	// }}}
	// {{{
	public void setCElvTnumRvslExpo(Long value) { this.set("c_elv_tnum_rvsl_expo", (Object)value); }
 	public Long getCElvTnumRvslExpo() { return (Long)this.get("c_elv_tnum_rvsl_expo"); }
	// }}}
	// {{{
	public void setCElvTusdAmtRvslExpoClr(Long value) { this.set("c_elv_tusd_amt_rvsl_expo_clr", (Object)value); }
 	public Long getCElvTusdAmtRvslExpoClr() { return (Long)this.get("c_elv_tusd_amt_rvsl_expo_clr"); }
	// }}}
	// {{{
	public void setCElvTnumRvslExpoClr(Long value) { this.set("c_elv_tnum_rvsl_expo_clr", (Object)value); }
 	public Long getCElvTnumRvslExpoClr() { return (Long)this.get("c_elv_tnum_rvsl_expo_clr"); }
	// }}}
}