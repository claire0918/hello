/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/RiskInternalELVModelOutVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:40 2012 */

package com.paypal.risk;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
  * 
   */

public class RiskInternalELVModelOutVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((50948*50948)<<32)/*<-RiskInternalELVModelOutVO*/+
         		60852/*<-bank_list*/*47/*<-repeating*/*com.paypal.risk.RiskBankELVResultVO.TYPE_SIGNATURE/*<-Risk::RiskBankELVResultVO*/+
         		28566/*<-internal_elv_decision*/*com.paypal.risk.RiskInternalELVModelDecision.TYPE_SIGNATURE/*<-Risk::RiskInternalELVModelDecision*/+
         		48756/*<-internal_elvecheck_decision*/*com.paypal.risk.RiskInternalELVModelDecision.TYPE_SIGNATURE/*<-Risk::RiskInternalELVModelDecision*/+
         		31846/*<-free_elv_available*/*38894/*<-int*/+
         		54425/*<-has_confirmed_bank*/*15044/*<-bool*/+
         		31008/*<-outstanding_iach_amount_echeck*/*46796/*<-llong*/+
         		16709/*<-outstanding_iach_count_echeck*/*50766/*<-long*/+
         		52372/*<-model_name*/*18443/*<-String*/+
         		33089/*<-model_version*/*18443/*<-String*/+
         		39771/*<-primary_model_name*/*18443/*<-String*/+
         		48529/*<-primary_model_version*/*18443/*<-String*/+
         		65153/*<-secondary_model_name*/*18443/*<-String*/+
         		10591/*<-secondary_model_version*/*18443/*<-String*/;
 
	public RiskInternalELVModelOutVO() {
		super("Risk::RiskInternalELVModelOutVO", TYPE_SIGNATURE);

 
		set("bank_list", null, "List<Risk::RiskBankELVResultVO>");
 
		set("internal_elv_decision", null, "Risk::RiskInternalELVModelDecision");
 
		set("internal_elvecheck_decision", null, "Risk::RiskInternalELVModelDecision");
 
		set("free_elv_available", null, "int");
 
		set("has_confirmed_bank", null, "bool");
 
		set("outstanding_iach_amount_echeck", null, "llong");
 
		set("outstanding_iach_count_echeck", null, "long");
 
		set("model_name", null, "String");
 
		set("model_version", null, "String");
 
		set("primary_model_name", null, "String");
 
		set("primary_model_version", null, "String");
 
		set("secondary_model_name", null, "String");
 
		set("secondary_model_version", null, "String");
	}

	// {{{
	public void setBankList(List<com.paypal.risk.RiskBankELVResultVO> value) { this.set("bank_list", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<com.paypal.risk.RiskBankELVResultVO> getBankList() { return (List<com.paypal.risk.RiskBankELVResultVO>)this.get("bank_list"); }
	// }}}
	// {{{
	public void setInternalElvDecision(com.paypal.risk.RiskInternalELVModelDecision value) { this.set("internal_elv_decision", (Object)value); }
 	public com.paypal.risk.RiskInternalELVModelDecision getInternalElvDecision() { return (com.paypal.risk.RiskInternalELVModelDecision)this.get("internal_elv_decision"); }
	// }}}
	// {{{
	public void setInternalElvecheckDecision(com.paypal.risk.RiskInternalELVModelDecision value) { this.set("internal_elvecheck_decision", (Object)value); }
 	public com.paypal.risk.RiskInternalELVModelDecision getInternalElvecheckDecision() { return (com.paypal.risk.RiskInternalELVModelDecision)this.get("internal_elvecheck_decision"); }
	// }}}
	// {{{
	public void setFreeElvAvailable(Integer value) { this.set("free_elv_available", (Object)value); }
 	public Integer getFreeElvAvailable() { return (Integer)this.get("free_elv_available"); }
	// }}}
	// {{{
	public void setHasConfirmedBank(Boolean value) { this.set("has_confirmed_bank", (Object)value); }
 	public Boolean getHasConfirmedBank() { return (Boolean)this.get("has_confirmed_bank"); }
	// }}}
	// {{{
	public void setOutstandingIachAmountEcheck(Long value) { this.set("outstanding_iach_amount_echeck", (Object)value); }
 	public Long getOutstandingIachAmountEcheck() { return (Long)this.get("outstanding_iach_amount_echeck"); }
	// }}}
	// {{{
	public void setOutstandingIachCountEcheck(Integer value) { this.set("outstanding_iach_count_echeck", (Object)value); }
 	public Integer getOutstandingIachCountEcheck() { return (Integer)this.get("outstanding_iach_count_echeck"); }
	// }}}
	// {{{
	public void setModelName(String value) { this.set("model_name", (Object)value); }
 	public String getModelName() { return (String)this.get("model_name"); }
	// }}}
	// {{{
	public void setModelVersion(String value) { this.set("model_version", (Object)value); }
 	public String getModelVersion() { return (String)this.get("model_version"); }
	// }}}
	// {{{
	public void setPrimaryModelName(String value) { this.set("primary_model_name", (Object)value); }
 	public String getPrimaryModelName() { return (String)this.get("primary_model_name"); }
	// }}}
	// {{{
	public void setPrimaryModelVersion(String value) { this.set("primary_model_version", (Object)value); }
 	public String getPrimaryModelVersion() { return (String)this.get("primary_model_version"); }
	// }}}
	// {{{
	public void setSecondaryModelName(String value) { this.set("secondary_model_name", (Object)value); }
 	public String getSecondaryModelName() { return (String)this.get("secondary_model_name"); }
	// }}}
	// {{{
	public void setSecondaryModelVersion(String value) { this.set("secondary_model_version", (Object)value); }
 	public String getSecondaryModelVersion() { return (String)this.get("secondary_model_version"); }
	// }}}
}