/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/RiskAnalyzeCCResultCacheVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:40 2012 */

package com.paypal.risk;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
  * 
   */

public class RiskAnalyzeCCResultCacheVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((36151*36151)<<32)/*<-RiskAnalyzeCCResultCacheVO*/+
         		56142/*<-currency_code*/*18443/*<-String*/+
         		51280/*<-result*/*RiskAnalyzeCCResultVO.TYPE_SIGNATURE/*<-RiskAnalyzeCCResultVO*/;
 
	public RiskAnalyzeCCResultCacheVO() {
		super("Risk::RiskAnalyzeCCResultCacheVO", TYPE_SIGNATURE);

 
		set("currency_code", null, "String");
 
		set("result", null, "Risk::RiskAnalyzeCCResultVO");
	}

	// {{{
	public void setCurrencyCode(String value) { this.set("currency_code", (Object)value); }
 	public String getCurrencyCode() { return (String)this.get("currency_code"); }
	// }}}
	// {{{
	public void setResult(RiskAnalyzeCCResultVO value) { this.set("result", (Object)value); }
 	public RiskAnalyzeCCResultVO getResult() { return (RiskAnalyzeCCResultVO)this.get("result"); }
	// }}}
}