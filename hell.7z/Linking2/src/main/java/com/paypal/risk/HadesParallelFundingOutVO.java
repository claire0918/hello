/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/HadesParallelFundingOutVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:40 2012 */

package com.paypal.risk;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
  * 
   */

public class HadesParallelFundingOutVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((13174*13174)<<32)/*<-HadesParallelFundingOutVO*/+
         		51280/*<-result*/*com.paypal.risk.EngineResultVO.TYPE_SIGNATURE/*<-Risk::EngineResultVO*/;
 
	public HadesParallelFundingOutVO() {
		super("Risk::HadesParallelFundingOutVO", TYPE_SIGNATURE);

 
		set("result", null, "Risk::EngineResultVO");
	}

	// {{{
	public void setResult(com.paypal.risk.EngineResultVO value) { this.set("result", (Object)value); }
 	public com.paypal.risk.EngineResultVO getResult() { return (com.paypal.risk.EngineResultVO)this.get("result"); }
	// }}}
}