/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/RiskAnalyzeDCResponseVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:40 2012 */

package com.paypal.risk;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
  * 
   */

public class RiskAnalyzeDCResponseVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((47454*47454)<<32)/*<-RiskAnalyzeDCResponseVO*/+
         		3633/*<-rc*/*38894/*<-int*/+
         		236/*<-message*/*18443/*<-String*/+
         		40906/*<-model_result*/*DebitCardModelOutVO.TYPE_SIGNATURE/*<-DebitCardModelOutVO*/;
 
	public RiskAnalyzeDCResponseVO() {
		super("Risk::RiskAnalyzeDCResponseVO", TYPE_SIGNATURE);

 
		set("rc", null, "int");
 
		set("message", null, "String");
 
		set("model_result", null, "Risk::DebitCardModelOutVO");
	}

	// {{{
	public void setRc(Integer value) { this.set("rc", (Object)value); }
 	public Integer getRc() { return (Integer)this.get("rc"); }
	// }}}
	// {{{
	public void setMessage(String value) { this.set("message", (Object)value); }
 	public String getMessage() { return (String)this.get("message"); }
	// }}}
	// {{{
	public void setModelResult(DebitCardModelOutVO value) { this.set("model_result", (Object)value); }
 	public DebitCardModelOutVO getModelResult() { return (DebitCardModelOutVO)this.get("model_result"); }
	// }}}
}