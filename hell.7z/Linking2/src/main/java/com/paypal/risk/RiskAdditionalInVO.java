/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/RiskAdditionalInVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:40 2012 */

package com.paypal.risk;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
  * 
   */

public class RiskAdditionalInVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((49634*49634)<<32)/*<-RiskAdditionalInVO*/+
         		37128/*<-uach_candidate_list*/*47/*<-repeating*/*com.paypal.financialinstrument.UserACHVO.TYPE_SIGNATURE/*<-FinancialInstrument::UserACHVO*/+
         		21751/*<-ach_list*/*47/*<-repeating*/*com.paypal.financialinstrument.UserACHVO.TYPE_SIGNATURE/*<-FinancialInstrument::UserACHVO*/+
         		5035/*<-uach_list*/*47/*<-repeating*/*com.paypal.financialinstrument.UserACHVO.TYPE_SIGNATURE/*<-FinancialInstrument::UserACHVO*/+
         		42413/*<-trans_context*/*RiskFundingInVO.TYPE_SIGNATURE/*<-RiskFundingInVO*/+
         		22649/*<-tlh2_in_vo*/*RiskAnalyzeEbayHoldsVO.TYPE_SIGNATURE/*<-RiskAnalyzeEbayHoldsVO*/+
         		17395/*<-has_tbc_account*/*15044/*<-bool*/+
         		40228/*<-has_active_bc_acct*/*15044/*<-bool*/+
         		58821/*<-uach_candidate_list_loaded*/*15044/*<-bool*/+
         		26872/*<-ach_list_loaded*/*15044/*<-bool*/+
         		55143/*<-uach_list_loaded*/*15044/*<-bool*/+
         		11930/*<-sender_ip*/*18443/*<-String*/+
         		9761/*<-payment_activity_id*/*46168/*<-ullong*/+
         		6992/*<-planning_activity_handle*/*18443/*<-String*/+
         		33990/*<-session*/*com.paypal.risk.SessionVO.TYPE_SIGNATURE/*<-Risk::SessionVO*/+
         		7548/*<-remaining_sla_time*/*46796/*<-llong*/+
         		8576/*<-risk_payment_flow*/*RiskPaymentFlowVO.TYPE_SIGNATURE/*<-RiskPaymentFlowVO*/+
         		60603/*<-iach_nonfinal_amount*/*21015/*<-Currency*/+
         		47309/*<-iach_nonfinal_count*/*46796/*<-llong*/+
         		42502/*<-ach_nonfinal_count*/*46796/*<-llong*/+
         		63683/*<-ach_nonfinal_amount*/*21015/*<-Currency*/+
         		63086/*<-buyer_credit_results*/*47/*<-repeating*/*46168/*<-ullong*/+
         		33610/*<-uach_result_cache*/*RiskAnalyzeUACHResultCacheVO.TYPE_SIGNATURE/*<-RiskAnalyzeUACHResultCacheVO*/+
         		57991/*<-cc_funding_amounts_usd*/*47/*<-repeating*/*RiskAnalyzeFundAmountVO.TYPE_SIGNATURE/*<-RiskAnalyzeFundAmountVO*/+
         		2999/*<-cc_result_cache*/*47/*<-repeating*/*RiskAnalyzeCCResultCacheVO.TYPE_SIGNATURE/*<-RiskAnalyzeCCResultCacheVO*/+
         		2171/*<-ach_result_cache*/*47/*<-repeating*/*RiskAnalyzeACHResultCacheVO.TYPE_SIGNATURE/*<-RiskAnalyzeACHResultCacheVO*/+
         		17105/*<-elv_result_cache*/*47/*<-repeating*/*RiskAnalyzeELVResultCacheVO.TYPE_SIGNATURE/*<-RiskAnalyzeELVResultCacheVO*/+
         		31826/*<-ach5_audit_log_vo*/*RiskModelAuditLogVO.TYPE_SIGNATURE/*<-RiskModelAuditLogVO*/+
         		7008/*<-risk_pi_seller_info_vo*/*RiskPISellerProfileInfoVO.TYPE_SIGNATURE/*<-RiskPISellerProfileInfoVO*/+
         		46149/*<-cc_is_control_group*/*15044/*<-bool*/;
 
	public RiskAdditionalInVO() {
		super("Risk::RiskAdditionalInVO", TYPE_SIGNATURE);

 
		set("uach_candidate_list", null, "List<FinancialInstrument::UserACHVO>");
 
		set("ach_list", null, "List<FinancialInstrument::UserACHVO>");
 
		set("uach_list", null, "List<FinancialInstrument::UserACHVO>");
 
		set("trans_context", null, "Risk::RiskFundingInVO");
 
		set("tlh2_in_vo", null, "Risk::RiskAnalyzeEbayHoldsVO");
 
		set("has_tbc_account", null, "bool");
 
		set("has_active_bc_acct", null, "bool");
 
		set("uach_candidate_list_loaded", null, "bool");
 
		set("ach_list_loaded", null, "bool");
 
		set("uach_list_loaded", null, "bool");
 
		set("sender_ip", null, "String");
 
		set("payment_activity_id", null, "ullong");
 
		set("planning_activity_handle", null, "String");
 
		set("session", null, "Risk::SessionVO");
 		addFieldQualifier("remaining_sla_time","default_value","-1");
 
		set("remaining_sla_time", new Long("-1"), "llong");
 
		set("risk_payment_flow", null, "Risk::RiskPaymentFlowVO");
 
		set("iach_nonfinal_amount", null, "Currency");
 
		set("iach_nonfinal_count", null, "llong");
 
		set("ach_nonfinal_count", null, "llong");
 
		set("ach_nonfinal_amount", null, "Currency");
 
		set("buyer_credit_results", null, "List<ullong>");
 
		set("uach_result_cache", null, "Risk::RiskAnalyzeUACHResultCacheVO");
 
		set("cc_funding_amounts_usd", null, "List<Risk::RiskAnalyzeFundAmountVO>");
 
		set("cc_result_cache", null, "List<Risk::RiskAnalyzeCCResultCacheVO>");
 
		set("ach_result_cache", null, "List<Risk::RiskAnalyzeACHResultCacheVO>");
 
		set("elv_result_cache", null, "List<Risk::RiskAnalyzeELVResultCacheVO>");
 
		set("ach5_audit_log_vo", null, "Risk::RiskModelAuditLogVO");
 
		set("risk_pi_seller_info_vo", null, "Risk::RiskPISellerProfileInfoVO");
 
		set("cc_is_control_group", null, "bool");
	}

	// {{{
	public void setUachCandidateList(List<com.paypal.financialinstrument.UserACHVO> value) { this.set("uach_candidate_list", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<com.paypal.financialinstrument.UserACHVO> getUachCandidateList() { return (List<com.paypal.financialinstrument.UserACHVO>)this.get("uach_candidate_list"); }
	// }}}
	// {{{
	public void setAchList(List<com.paypal.financialinstrument.UserACHVO> value) { this.set("ach_list", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<com.paypal.financialinstrument.UserACHVO> getAchList() { return (List<com.paypal.financialinstrument.UserACHVO>)this.get("ach_list"); }
	// }}}
	// {{{
	public void setUachList(List<com.paypal.financialinstrument.UserACHVO> value) { this.set("uach_list", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<com.paypal.financialinstrument.UserACHVO> getUachList() { return (List<com.paypal.financialinstrument.UserACHVO>)this.get("uach_list"); }
	// }}}
	// {{{
	public void setTransContext(RiskFundingInVO value) { this.set("trans_context", (Object)value); }
 	public RiskFundingInVO getTransContext() { return (RiskFundingInVO)this.get("trans_context"); }
	// }}}
	// {{{
	public void setTlh2InVo(RiskAnalyzeEbayHoldsVO value) { this.set("tlh2_in_vo", (Object)value); }
 	public RiskAnalyzeEbayHoldsVO getTlh2InVo() { return (RiskAnalyzeEbayHoldsVO)this.get("tlh2_in_vo"); }
	// }}}
	// {{{
	public void setHasTbcAccount(Boolean value) { this.set("has_tbc_account", (Object)value); }
 	public Boolean getHasTbcAccount() { return (Boolean)this.get("has_tbc_account"); }
	// }}}
	// {{{
	public void setHasActiveBcAcct(Boolean value) { this.set("has_active_bc_acct", (Object)value); }
 	public Boolean getHasActiveBcAcct() { return (Boolean)this.get("has_active_bc_acct"); }
	// }}}
	// {{{
	public void setUachCandidateListLoaded(Boolean value) { this.set("uach_candidate_list_loaded", (Object)value); }
 	public Boolean getUachCandidateListLoaded() { return (Boolean)this.get("uach_candidate_list_loaded"); }
	// }}}
	// {{{
	public void setAchListLoaded(Boolean value) { this.set("ach_list_loaded", (Object)value); }
 	public Boolean getAchListLoaded() { return (Boolean)this.get("ach_list_loaded"); }
	// }}}
	// {{{
	public void setUachListLoaded(Boolean value) { this.set("uach_list_loaded", (Object)value); }
 	public Boolean getUachListLoaded() { return (Boolean)this.get("uach_list_loaded"); }
	// }}}
	// {{{
	public void setSenderIp(String value) { this.set("sender_ip", (Object)value); }
 	public String getSenderIp() { return (String)this.get("sender_ip"); }
	// }}}
	// {{{
	public void setPaymentActivityId(BigInteger value) { this.set("payment_activity_id", (Object)value); }
 	public BigInteger getPaymentActivityId() { return (BigInteger)this.get("payment_activity_id"); }
	// }}}
	// {{{
	public void setPlanningActivityHandle(String value) { this.set("planning_activity_handle", (Object)value); }
 	public String getPlanningActivityHandle() { return (String)this.get("planning_activity_handle"); }
	// }}}
	// {{{
	public void setSession(com.paypal.risk.SessionVO value) { this.set("session", (Object)value); }
 	public com.paypal.risk.SessionVO getSession() { return (com.paypal.risk.SessionVO)this.get("session"); }
	// }}}
	// {{{
	public void setRemainingSlaTime(Long value) { this.set("remaining_sla_time", (Object)value); }
 	public Long getRemainingSlaTime() { return (Long)this.get("remaining_sla_time"); }
	// }}}
	// {{{
	public void setRiskPaymentFlow(RiskPaymentFlowVO value) { this.set("risk_payment_flow", (Object)value); }
 	public RiskPaymentFlowVO getRiskPaymentFlow() { return (RiskPaymentFlowVO)this.get("risk_payment_flow"); }
	// }}}
	// {{{
	public void setIachNonfinalAmount(Currency value) { this.set("iach_nonfinal_amount", (Object)value); }
 	public Currency getIachNonfinalAmount() { return (Currency)this.get("iach_nonfinal_amount"); }
	// }}}
	// {{{
	public void setIachNonfinalCount(Long value) { this.set("iach_nonfinal_count", (Object)value); }
 	public Long getIachNonfinalCount() { return (Long)this.get("iach_nonfinal_count"); }
	// }}}
	// {{{
	public void setAchNonfinalCount(Long value) { this.set("ach_nonfinal_count", (Object)value); }
 	public Long getAchNonfinalCount() { return (Long)this.get("ach_nonfinal_count"); }
	// }}}
	// {{{
	public void setAchNonfinalAmount(Currency value) { this.set("ach_nonfinal_amount", (Object)value); }
 	public Currency getAchNonfinalAmount() { return (Currency)this.get("ach_nonfinal_amount"); }
	// }}}
	// {{{
	public void setBuyerCreditResults(List<BigInteger> value) { this.set("buyer_credit_results", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<BigInteger> getBuyerCreditResults() { return (List<BigInteger>)this.get("buyer_credit_results"); }
	// }}}
	// {{{
	public void setUachResultCache(RiskAnalyzeUACHResultCacheVO value) { this.set("uach_result_cache", (Object)value); }
 	public RiskAnalyzeUACHResultCacheVO getUachResultCache() { return (RiskAnalyzeUACHResultCacheVO)this.get("uach_result_cache"); }
	// }}}
	// {{{
	public void setCcFundingAmountsUsd(List<RiskAnalyzeFundAmountVO> value) { this.set("cc_funding_amounts_usd", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<RiskAnalyzeFundAmountVO> getCcFundingAmountsUsd() { return (List<RiskAnalyzeFundAmountVO>)this.get("cc_funding_amounts_usd"); }
	// }}}
	// {{{
	public void setCcResultCache(List<RiskAnalyzeCCResultCacheVO> value) { this.set("cc_result_cache", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<RiskAnalyzeCCResultCacheVO> getCcResultCache() { return (List<RiskAnalyzeCCResultCacheVO>)this.get("cc_result_cache"); }
	// }}}
	// {{{
	public void setAchResultCache(List<RiskAnalyzeACHResultCacheVO> value) { this.set("ach_result_cache", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<RiskAnalyzeACHResultCacheVO> getAchResultCache() { return (List<RiskAnalyzeACHResultCacheVO>)this.get("ach_result_cache"); }
	// }}}
	// {{{
	public void setElvResultCache(List<RiskAnalyzeELVResultCacheVO> value) { this.set("elv_result_cache", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<RiskAnalyzeELVResultCacheVO> getElvResultCache() { return (List<RiskAnalyzeELVResultCacheVO>)this.get("elv_result_cache"); }
	// }}}
	// {{{
	public void setAch5AuditLogVo(RiskModelAuditLogVO value) { this.set("ach5_audit_log_vo", (Object)value); }
 	public RiskModelAuditLogVO getAch5AuditLogVo() { return (RiskModelAuditLogVO)this.get("ach5_audit_log_vo"); }
	// }}}
	// {{{
	public void setRiskPiSellerInfoVo(RiskPISellerProfileInfoVO value) { this.set("risk_pi_seller_info_vo", (Object)value); }
 	public RiskPISellerProfileInfoVO getRiskPiSellerInfoVo() { return (RiskPISellerProfileInfoVO)this.get("risk_pi_seller_info_vo"); }
	// }}}
	// {{{
	public void setCcIsControlGroup(Boolean value) { this.set("cc_is_control_group", (Object)value); }
 	public Boolean getCcIsControlGroup() { return (Boolean)this.get("cc_is_control_group"); }
	// }}}
}