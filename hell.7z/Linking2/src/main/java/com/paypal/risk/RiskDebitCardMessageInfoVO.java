/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/RiskDebitCardMessageInfoVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:40 2012 */

package com.paypal.risk;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
  * 
   */

public class RiskDebitCardMessageInfoVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((29632*29632)<<32)/*<-RiskDebitCardMessageInfoVO*/+
         		10882/*<-message_format*/*51052/*<-uint*/+
         		14122/*<-message_type*/*18443/*<-String*/+
         		20296/*<-primary_account_number*/*18443/*<-String*/+
         		43305/*<-processing_code*/*18443/*<-String*/+
         		47541/*<-transaction_amount_foreign_currency*/*18443/*<-String*/+
         		811/*<-transaction_amount_usd*/*18443/*<-String*/+
         		41981/*<-interchange_amount_foreign_currency*/*18443/*<-String*/+
         		55439/*<-interchange_amount_usd*/*18443/*<-String*/+
         		16555/*<-replacement_amount_usd*/*18443/*<-String*/+
         		57250/*<-replacement_amount_foreign_currency*/*18443/*<-String*/+
         		51345/*<-replacement_fee_amount_usd*/*18443/*<-String*/+
         		5212/*<-replacement_fee_amount_foreign_currency*/*18443/*<-String*/+
         		39454/*<-cross_border_fee_amount*/*18443/*<-String*/+
         		50724/*<-cross_currency_fee_amount*/*18443/*<-String*/+
         		31670/*<-cross_currency_replacement_fee_amount*/*18443/*<-String*/+
         		3871/*<-transmission_datetime*/*18443/*<-String*/+
         		41158/*<-system_trace_audit_number*/*18443/*<-String*/+
         		30627/*<-settlement_date*/*18443/*<-String*/+
         		30902/*<-capture_date*/*18443/*<-String*/+
         		22751/*<-merchant_type*/*18443/*<-String*/+
         		57796/*<-acquiring_institution_identification_code*/*18443/*<-String*/+
         		34284/*<-track2_data*/*18443/*<-String*/+
         		18504/*<-retrieval_reference_number*/*18443/*<-String*/+
         		10246/*<-authorization_identification_response*/*18443/*<-String*/+
         		53442/*<-response_code*/*18443/*<-String*/+
         		15192/*<-acceptor_terminal_identification_code*/*18443/*<-String*/+
         		347/*<-acceptor_identification_code*/*18443/*<-String*/+
         		27609/*<-acceptor_name*/*18443/*<-String*/+
         		3084/*<-acceptor_location*/*18443/*<-String*/+
         		62754/*<-retailer_data*/*18443/*<-String*/+
         		56142/*<-currency_code*/*18443/*<-String*/+
         		17115/*<-terminal_data*/*18443/*<-String*/+
         		5062/*<-vendor_data*/*18443/*<-String*/+
         		13932/*<-receiving_institution_identification_code*/*18443/*<-String*/+
         		42029/*<-authorization_indicators*/*18443/*<-String*/+
         		11794/*<-preauth_chargeback_data*/*18443/*<-String*/+
         		33484/*<-acquirer_trace_data*/*18443/*<-String*/+
         		3143/*<-pos_entry_mode*/*18443/*<-String*/+
         		15552/*<-pos_condition_code*/*18443/*<-String*/+
         		40696/*<-encrypted_pin*/*18443/*<-String*/+
         		17910/*<-additional_amounts*/*18443/*<-String*/+
         		52404/*<-national_pos_condition_code*/*18443/*<-String*/+
         		64936/*<-custom_payment_services*/*18443/*<-String*/+
         		37273/*<-address_verification_result*/*18443/*<-String*/+
         		23160/*<-address_verification_data*/*18443/*<-String*/+
         		21077/*<-cvv2_verification_result*/*18443/*<-String*/+
         		37721/*<-cvv2_verification_data*/*18443/*<-String*/+
         		28192/*<-advice_reversal_reason_code*/*18443/*<-String*/+
         		37636/*<-agent_id*/*18443/*<-String*/+
         		52507/*<-terminal_processor_network_id*/*18443/*<-String*/+
         		36100/*<-acquirer_network_id*/*18443/*<-String*/+
         		50763/*<-debug_buffer*/*18443/*<-String*/+
         		15148/*<-local_transaction_time*/*18443/*<-String*/+
         		9241/*<-conversion_date*/*18443/*<-String*/+
         		3574/*<-inst_merchant_name*/*18443/*<-String*/+
         		32143/*<-settlement_currency_code*/*18443/*<-String*/+
         		25913/*<-replacement_amount*/*18443/*<-String*/+
         		59380/*<-private_acq_add_data*/*18443/*<-String*/+
         		13469/*<-sponsor_bank_id*/*18443/*<-String*/+
         		25644/*<-has_cross_border_fee*/*15044/*<-bool*/+
         		55546/*<-has_cross_currency_fee*/*15044/*<-bool*/+
         		25871/*<-has_cross_currency_replacement_fee*/*15044/*<-bool*/;
 
	public RiskDebitCardMessageInfoVO() {
		super("Risk::RiskDebitCardMessageInfoVO", TYPE_SIGNATURE);

 
		set("message_format", null, "uint");
 
		set("message_type", null, "String");
 
		set("primary_account_number", null, "String");
 
		set("processing_code", null, "String");
 
		set("transaction_amount_foreign_currency", null, "String");
 
		set("transaction_amount_usd", null, "String");
 
		set("interchange_amount_foreign_currency", null, "String");
 
		set("interchange_amount_usd", null, "String");
 
		set("replacement_amount_usd", null, "String");
 
		set("replacement_amount_foreign_currency", null, "String");
 
		set("replacement_fee_amount_usd", null, "String");
 
		set("replacement_fee_amount_foreign_currency", null, "String");
 
		set("cross_border_fee_amount", null, "String");
 
		set("cross_currency_fee_amount", null, "String");
 
		set("cross_currency_replacement_fee_amount", null, "String");
 
		set("transmission_datetime", null, "String");
 
		set("system_trace_audit_number", null, "String");
 
		set("settlement_date", null, "String");
 
		set("capture_date", null, "String");
 
		set("merchant_type", null, "String");
 
		set("acquiring_institution_identification_code", null, "String");
 
		set("track2_data", null, "String");
 
		set("retrieval_reference_number", null, "String");
 
		set("authorization_identification_response", null, "String");
 
		set("response_code", null, "String");
 
		set("acceptor_terminal_identification_code", null, "String");
 
		set("acceptor_identification_code", null, "String");
 
		set("acceptor_name", null, "String");
 
		set("acceptor_location", null, "String");
 
		set("retailer_data", null, "String");
 
		set("currency_code", null, "String");
 
		set("terminal_data", null, "String");
 
		set("vendor_data", null, "String");
 
		set("receiving_institution_identification_code", null, "String");
 
		set("authorization_indicators", null, "String");
 
		set("preauth_chargeback_data", null, "String");
 
		set("acquirer_trace_data", null, "String");
 
		set("pos_entry_mode", null, "String");
 
		set("pos_condition_code", null, "String");
 
		set("encrypted_pin", null, "String");
 
		set("additional_amounts", null, "String");
 
		set("national_pos_condition_code", null, "String");
 
		set("custom_payment_services", null, "String");
 
		set("address_verification_result", null, "String");
 
		set("address_verification_data", null, "String");
 
		set("cvv2_verification_result", null, "String");
 
		set("cvv2_verification_data", null, "String");
 
		set("advice_reversal_reason_code", null, "String");
 
		set("agent_id", null, "String");
 
		set("terminal_processor_network_id", null, "String");
 
		set("acquirer_network_id", null, "String");
 
		set("debug_buffer", null, "String");
 
		set("local_transaction_time", null, "String");
 
		set("conversion_date", null, "String");
 
		set("inst_merchant_name", null, "String");
 
		set("settlement_currency_code", null, "String");
 
		set("replacement_amount", null, "String");
 
		set("private_acq_add_data", null, "String");
 
		set("sponsor_bank_id", null, "String");
 
		set("has_cross_border_fee", null, "bool");
 
		set("has_cross_currency_fee", null, "bool");
 
		set("has_cross_currency_replacement_fee", null, "bool");
	}

	// {{{
	public void setMessageFormat(Long value) { this.set("message_format", (Object)value); }
 	public Long getMessageFormat() { return (Long)this.get("message_format"); }
	// }}}
	// {{{
	public void setMessageType(String value) { this.set("message_type", (Object)value); }
 	public String getMessageType() { return (String)this.get("message_type"); }
	// }}}
	// {{{
	public void setPrimaryAccountNumber(String value) { this.set("primary_account_number", (Object)value); }
 	public String getPrimaryAccountNumber() { return (String)this.get("primary_account_number"); }
	// }}}
	// {{{
	public void setProcessingCode(String value) { this.set("processing_code", (Object)value); }
 	public String getProcessingCode() { return (String)this.get("processing_code"); }
	// }}}
	// {{{
	public void setTransactionAmountForeignCurrency(String value) { this.set("transaction_amount_foreign_currency", (Object)value); }
 	public String getTransactionAmountForeignCurrency() { return (String)this.get("transaction_amount_foreign_currency"); }
	// }}}
	// {{{
	public void setTransactionAmountUsd(String value) { this.set("transaction_amount_usd", (Object)value); }
 	public String getTransactionAmountUsd() { return (String)this.get("transaction_amount_usd"); }
	// }}}
	// {{{
	public void setInterchangeAmountForeignCurrency(String value) { this.set("interchange_amount_foreign_currency", (Object)value); }
 	public String getInterchangeAmountForeignCurrency() { return (String)this.get("interchange_amount_foreign_currency"); }
	// }}}
	// {{{
	public void setInterchangeAmountUsd(String value) { this.set("interchange_amount_usd", (Object)value); }
 	public String getInterchangeAmountUsd() { return (String)this.get("interchange_amount_usd"); }
	// }}}
	// {{{
	public void setReplacementAmountUsd(String value) { this.set("replacement_amount_usd", (Object)value); }
 	public String getReplacementAmountUsd() { return (String)this.get("replacement_amount_usd"); }
	// }}}
	// {{{
	public void setReplacementAmountForeignCurrency(String value) { this.set("replacement_amount_foreign_currency", (Object)value); }
 	public String getReplacementAmountForeignCurrency() { return (String)this.get("replacement_amount_foreign_currency"); }
	// }}}
	// {{{
	public void setReplacementFeeAmountUsd(String value) { this.set("replacement_fee_amount_usd", (Object)value); }
 	public String getReplacementFeeAmountUsd() { return (String)this.get("replacement_fee_amount_usd"); }
	// }}}
	// {{{
	public void setReplacementFeeAmountForeignCurrency(String value) { this.set("replacement_fee_amount_foreign_currency", (Object)value); }
 	public String getReplacementFeeAmountForeignCurrency() { return (String)this.get("replacement_fee_amount_foreign_currency"); }
	// }}}
	// {{{
	public void setCrossBorderFeeAmount(String value) { this.set("cross_border_fee_amount", (Object)value); }
 	public String getCrossBorderFeeAmount() { return (String)this.get("cross_border_fee_amount"); }
	// }}}
	// {{{
	public void setCrossCurrencyFeeAmount(String value) { this.set("cross_currency_fee_amount", (Object)value); }
 	public String getCrossCurrencyFeeAmount() { return (String)this.get("cross_currency_fee_amount"); }
	// }}}
	// {{{
	public void setCrossCurrencyReplacementFeeAmount(String value) { this.set("cross_currency_replacement_fee_amount", (Object)value); }
 	public String getCrossCurrencyReplacementFeeAmount() { return (String)this.get("cross_currency_replacement_fee_amount"); }
	// }}}
	// {{{
	public void setTransmissionDatetime(String value) { this.set("transmission_datetime", (Object)value); }
 	public String getTransmissionDatetime() { return (String)this.get("transmission_datetime"); }
	// }}}
	// {{{
	public void setSystemTraceAuditNumber(String value) { this.set("system_trace_audit_number", (Object)value); }
 	public String getSystemTraceAuditNumber() { return (String)this.get("system_trace_audit_number"); }
	// }}}
	// {{{
	public void setSettlementDate(String value) { this.set("settlement_date", (Object)value); }
 	public String getSettlementDate() { return (String)this.get("settlement_date"); }
	// }}}
	// {{{
	public void setCaptureDate(String value) { this.set("capture_date", (Object)value); }
 	public String getCaptureDate() { return (String)this.get("capture_date"); }
	// }}}
	// {{{
	public void setMerchantType(String value) { this.set("merchant_type", (Object)value); }
 	public String getMerchantType() { return (String)this.get("merchant_type"); }
	// }}}
	// {{{
	public void setAcquiringInstitutionIdentificationCode(String value) { this.set("acquiring_institution_identification_code", (Object)value); }
 	public String getAcquiringInstitutionIdentificationCode() { return (String)this.get("acquiring_institution_identification_code"); }
	// }}}
	// {{{
	public void setTrack2Data(String value) { this.set("track2_data", (Object)value); }
 	public String getTrack2Data() { return (String)this.get("track2_data"); }
	// }}}
	// {{{
	public void setRetrievalReferenceNumber(String value) { this.set("retrieval_reference_number", (Object)value); }
 	public String getRetrievalReferenceNumber() { return (String)this.get("retrieval_reference_number"); }
	// }}}
	// {{{
	public void setAuthorizationIdentificationResponse(String value) { this.set("authorization_identification_response", (Object)value); }
 	public String getAuthorizationIdentificationResponse() { return (String)this.get("authorization_identification_response"); }
	// }}}
	// {{{
	public void setResponseCode(String value) { this.set("response_code", (Object)value); }
 	public String getResponseCode() { return (String)this.get("response_code"); }
	// }}}
	// {{{
	public void setAcceptorTerminalIdentificationCode(String value) { this.set("acceptor_terminal_identification_code", (Object)value); }
 	public String getAcceptorTerminalIdentificationCode() { return (String)this.get("acceptor_terminal_identification_code"); }
	// }}}
	// {{{
	public void setAcceptorIdentificationCode(String value) { this.set("acceptor_identification_code", (Object)value); }
 	public String getAcceptorIdentificationCode() { return (String)this.get("acceptor_identification_code"); }
	// }}}
	// {{{
	public void setAcceptorName(String value) { this.set("acceptor_name", (Object)value); }
 	public String getAcceptorName() { return (String)this.get("acceptor_name"); }
	// }}}
	// {{{
	public void setAcceptorLocation(String value) { this.set("acceptor_location", (Object)value); }
 	public String getAcceptorLocation() { return (String)this.get("acceptor_location"); }
	// }}}
	// {{{
	public void setRetailerData(String value) { this.set("retailer_data", (Object)value); }
 	public String getRetailerData() { return (String)this.get("retailer_data"); }
	// }}}
	// {{{
	public void setCurrencyCode(String value) { this.set("currency_code", (Object)value); }
 	public String getCurrencyCode() { return (String)this.get("currency_code"); }
	// }}}
	// {{{
	public void setTerminalData(String value) { this.set("terminal_data", (Object)value); }
 	public String getTerminalData() { return (String)this.get("terminal_data"); }
	// }}}
	// {{{
	public void setVendorData(String value) { this.set("vendor_data", (Object)value); }
 	public String getVendorData() { return (String)this.get("vendor_data"); }
	// }}}
	// {{{
	public void setReceivingInstitutionIdentificationCode(String value) { this.set("receiving_institution_identification_code", (Object)value); }
 	public String getReceivingInstitutionIdentificationCode() { return (String)this.get("receiving_institution_identification_code"); }
	// }}}
	// {{{
	public void setAuthorizationIndicators(String value) { this.set("authorization_indicators", (Object)value); }
 	public String getAuthorizationIndicators() { return (String)this.get("authorization_indicators"); }
	// }}}
	// {{{
	public void setPreauthChargebackData(String value) { this.set("preauth_chargeback_data", (Object)value); }
 	public String getPreauthChargebackData() { return (String)this.get("preauth_chargeback_data"); }
	// }}}
	// {{{
	public void setAcquirerTraceData(String value) { this.set("acquirer_trace_data", (Object)value); }
 	public String getAcquirerTraceData() { return (String)this.get("acquirer_trace_data"); }
	// }}}
	// {{{
	public void setPosEntryMode(String value) { this.set("pos_entry_mode", (Object)value); }
 	public String getPosEntryMode() { return (String)this.get("pos_entry_mode"); }
	// }}}
	// {{{
	public void setPosConditionCode(String value) { this.set("pos_condition_code", (Object)value); }
 	public String getPosConditionCode() { return (String)this.get("pos_condition_code"); }
	// }}}
	// {{{
	public void setEncryptedPin(String value) { this.set("encrypted_pin", (Object)value); }
 	public String getEncryptedPin() { return (String)this.get("encrypted_pin"); }
	// }}}
	// {{{
	public void setAdditionalAmounts(String value) { this.set("additional_amounts", (Object)value); }
 	public String getAdditionalAmounts() { return (String)this.get("additional_amounts"); }
	// }}}
	// {{{
	public void setNationalPosConditionCode(String value) { this.set("national_pos_condition_code", (Object)value); }
 	public String getNationalPosConditionCode() { return (String)this.get("national_pos_condition_code"); }
	// }}}
	// {{{
	public void setCustomPaymentServices(String value) { this.set("custom_payment_services", (Object)value); }
 	public String getCustomPaymentServices() { return (String)this.get("custom_payment_services"); }
	// }}}
	// {{{
	public void setAddressVerificationResult(String value) { this.set("address_verification_result", (Object)value); }
 	public String getAddressVerificationResult() { return (String)this.get("address_verification_result"); }
	// }}}
	// {{{
	public void setAddressVerificationData(String value) { this.set("address_verification_data", (Object)value); }
 	public String getAddressVerificationData() { return (String)this.get("address_verification_data"); }
	// }}}
	// {{{
	public void setCvv2VerificationResult(String value) { this.set("cvv2_verification_result", (Object)value); }
 	public String getCvv2VerificationResult() { return (String)this.get("cvv2_verification_result"); }
	// }}}
	// {{{
	public void setCvv2VerificationData(String value) { this.set("cvv2_verification_data", (Object)value); }
 	public String getCvv2VerificationData() { return (String)this.get("cvv2_verification_data"); }
	// }}}
	// {{{
	public void setAdviceReversalReasonCode(String value) { this.set("advice_reversal_reason_code", (Object)value); }
 	public String getAdviceReversalReasonCode() { return (String)this.get("advice_reversal_reason_code"); }
	// }}}
	// {{{
	public void setAgentId(String value) { this.set("agent_id", (Object)value); }
 	public String getAgentId() { return (String)this.get("agent_id"); }
	// }}}
	// {{{
	public void setTerminalProcessorNetworkId(String value) { this.set("terminal_processor_network_id", (Object)value); }
 	public String getTerminalProcessorNetworkId() { return (String)this.get("terminal_processor_network_id"); }
	// }}}
	// {{{
	public void setAcquirerNetworkId(String value) { this.set("acquirer_network_id", (Object)value); }
 	public String getAcquirerNetworkId() { return (String)this.get("acquirer_network_id"); }
	// }}}
	// {{{
	public void setDebugBuffer(String value) { this.set("debug_buffer", (Object)value); }
 	public String getDebugBuffer() { return (String)this.get("debug_buffer"); }
	// }}}
	// {{{
	public void setLocalTransactionTime(String value) { this.set("local_transaction_time", (Object)value); }
 	public String getLocalTransactionTime() { return (String)this.get("local_transaction_time"); }
	// }}}
	// {{{
	public void setConversionDate(String value) { this.set("conversion_date", (Object)value); }
 	public String getConversionDate() { return (String)this.get("conversion_date"); }
	// }}}
	// {{{
	public void setInstMerchantName(String value) { this.set("inst_merchant_name", (Object)value); }
 	public String getInstMerchantName() { return (String)this.get("inst_merchant_name"); }
	// }}}
	// {{{
	public void setSettlementCurrencyCode(String value) { this.set("settlement_currency_code", (Object)value); }
 	public String getSettlementCurrencyCode() { return (String)this.get("settlement_currency_code"); }
	// }}}
	// {{{
	public void setReplacementAmount(String value) { this.set("replacement_amount", (Object)value); }
 	public String getReplacementAmount() { return (String)this.get("replacement_amount"); }
	// }}}
	// {{{
	public void setPrivateAcqAddData(String value) { this.set("private_acq_add_data", (Object)value); }
 	public String getPrivateAcqAddData() { return (String)this.get("private_acq_add_data"); }
	// }}}
	// {{{
	public void setSponsorBankId(String value) { this.set("sponsor_bank_id", (Object)value); }
 	public String getSponsorBankId() { return (String)this.get("sponsor_bank_id"); }
	// }}}
	// {{{
	public void setHasCrossBorderFee(Boolean value) { this.set("has_cross_border_fee", (Object)value); }
 	public Boolean getHasCrossBorderFee() { return (Boolean)this.get("has_cross_border_fee"); }
	// }}}
	// {{{
	public void setHasCrossCurrencyFee(Boolean value) { this.set("has_cross_currency_fee", (Object)value); }
 	public Boolean getHasCrossCurrencyFee() { return (Boolean)this.get("has_cross_currency_fee"); }
	// }}}
	// {{{
	public void setHasCrossCurrencyReplacementFee(Boolean value) { this.set("has_cross_currency_replacement_fee", (Object)value); }
 	public Boolean getHasCrossCurrencyReplacementFee() { return (Boolean)this.get("has_cross_currency_replacement_fee"); }
	// }}}
}