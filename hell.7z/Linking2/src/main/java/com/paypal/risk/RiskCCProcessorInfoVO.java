/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/RiskCCProcessorInfoVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:40 2012 */

package com.paypal.risk;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
  * 
   */

public class RiskCCProcessorInfoVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((56257*56257)<<32)/*<-RiskCCProcessorInfoVO*/+
         		26304/*<-flag_is_set*/*15044/*<-bool*/+
         		21640/*<-merchant_ce_email*/*18443/*<-String*/+
         		7348/*<-flag_sla_sensitive*/*15044/*<-bool*/+
         		9213/*<-flag_pinless_debit*/*15044/*<-bool*/+
         		19958/*<-flag_competitor_protect*/*15044/*<-bool*/+
         		39986/*<-flag_short_sd*/*15044/*<-bool*/+
         		60538/*<-flag_airline*/*15044/*<-bool*/;
 
	public RiskCCProcessorInfoVO() {
		super("Risk::RiskCCProcessorInfoVO", TYPE_SIGNATURE);

 
		set("flag_is_set", null, "bool");
 
		set("merchant_ce_email", null, "String");
 
		set("flag_sla_sensitive", null, "bool");
 
		set("flag_pinless_debit", null, "bool");
 
		set("flag_competitor_protect", null, "bool");
 
		set("flag_short_sd", null, "bool");
 
		set("flag_airline", null, "bool");
	}

	// {{{
	public void setFlagIsSet(Boolean value) { this.set("flag_is_set", (Object)value); }
 	public Boolean getFlagIsSet() { return (Boolean)this.get("flag_is_set"); }
	// }}}
	// {{{
	public void setMerchantCeEmail(String value) { this.set("merchant_ce_email", (Object)value); }
 	public String getMerchantCeEmail() { return (String)this.get("merchant_ce_email"); }
	// }}}
	// {{{
	public void setFlagSlaSensitive(Boolean value) { this.set("flag_sla_sensitive", (Object)value); }
 	public Boolean getFlagSlaSensitive() { return (Boolean)this.get("flag_sla_sensitive"); }
	// }}}
	// {{{
	public void setFlagPinlessDebit(Boolean value) { this.set("flag_pinless_debit", (Object)value); }
 	public Boolean getFlagPinlessDebit() { return (Boolean)this.get("flag_pinless_debit"); }
	// }}}
	// {{{
	public void setFlagCompetitorProtect(Boolean value) { this.set("flag_competitor_protect", (Object)value); }
 	public Boolean getFlagCompetitorProtect() { return (Boolean)this.get("flag_competitor_protect"); }
	// }}}
	// {{{
	public void setFlagShortSd(Boolean value) { this.set("flag_short_sd", (Object)value); }
 	public Boolean getFlagShortSd() { return (Boolean)this.get("flag_short_sd"); }
	// }}}
	// {{{
	public void setFlagAirline(Boolean value) { this.set("flag_airline", (Object)value); }
 	public Boolean getFlagAirline() { return (Boolean)this.get("flag_airline"); }
	// }}}
}