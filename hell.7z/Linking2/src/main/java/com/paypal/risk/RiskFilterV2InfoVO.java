/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/RiskFilterV2InfoVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:40 2012 */

package com.paypal.risk;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
  * 
   */

public class RiskFilterV2InfoVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((48285*48285)<<32)/*<-RiskFilterV2InfoVO*/+
         		20533/*<-filter_id*/*33490/*<-ulong*/+
         		44494/*<-filter_status*/*33490/*<-ulong*/+
         		24420/*<-filter_action*/*33490/*<-ulong*/+
         		37606/*<-filter_adjudication_result*/*33490/*<-ulong*/;
 
	public RiskFilterV2InfoVO() {
		super("Risk::RiskFilterV2InfoVO", TYPE_SIGNATURE);

 
		set("filter_id", null, "ulong");
 
		set("filter_status", null, "ulong");
 
		set("filter_action", null, "ulong");
 
		set("filter_adjudication_result", null, "ulong");
	}

	// {{{
	public void setFilterId(Long value) { this.set("filter_id", (Object)value); }
 	public Long getFilterId() { return (Long)this.get("filter_id"); }
	// }}}
	// {{{
	public void setFilterStatus(Long value) { this.set("filter_status", (Object)value); }
 	public Long getFilterStatus() { return (Long)this.get("filter_status"); }
	// }}}
	// {{{
	public void setFilterAction(Long value) { this.set("filter_action", (Object)value); }
 	public Long getFilterAction() { return (Long)this.get("filter_action"); }
	// }}}
	// {{{
	public void setFilterAdjudicationResult(Long value) { this.set("filter_adjudication_result", (Object)value); }
 	public Long getFilterAdjudicationResult() { return (Long)this.get("filter_adjudication_result"); }
	// }}}
}