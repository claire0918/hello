/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/BlockReasonEnum.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:40 2012 */

package com.paypal.risk;

import java.math.BigInteger;

  
public enum BlockReasonEnum {
/**This enumeration is for the reasons used for block_with_reason. These enumrations should match with the values in RTS. The block_with_reason action creates an ActionDataVO with name='reason' and data=a BlockReasonEnum value.*/
   	BLOCK_REASON_NOT_SPECIFIED(new Integer("0"), "In some cases, the reason for a block is not specified. This enumeration value indicates that the reason was not specified."),
   	BLOCK_REASON_REACHED_DUPLICATE_ACTIVE_BANK_LIMIT(new Integer("1"), "This reason value is used to indicate that the block was due to reaching the bank duplicate active limit. We limit the number of users that can concurrently use the same bank."),
   	BLOCK_REASON_REACHED_DUPLICATE_TOTAL_BANK_LIMIT(new Integer("2"), "This reason value is used to indicate that the block was due to reaching the bank duplicate total limit. We limit the number of users that can ever use the same bank. For this limit we compare against the total number of customers that ever used the bank"),
   	BLOCK_REASON_BANK_RE_ADDED_IN_CLOSE_PROXIMITY(new Integer("3"), "This reason indicates that the block decision is due to the customer attempting to add a bank account too soon after it was last added. Risk could limit users from adding a bank in close time proximity to another user."),
   	BLOCK_REASON_CC_EXCEEDING_MAX_NUMBER_CC_LIMIT(new Integer("4"), "This reason indicates that block due to reaching total limit of credit card added in PayPal system."),
   	BLOCK_REASON_CC_EXCEEDING_TOTAL_SHARED_CC_LIMIT(new Integer("5"), "This reason indicated that the block due to number of shared user has reached maximum limit."),
   	BLOCK_REASON_CC_RE_ADDED_IN_CLOSE_PROXIMITY(new Integer("6"), "This reason indicates that another credit card is being added in the vicinity.");

	private final Integer value;
	private final String desc;

	private BlockReasonEnum(Integer value, String desc) {
		this.value = value;
		this.desc  = desc;
	}

	public Integer getValue() {
		return value;
	}

	public String getDesc() {
		return desc;
	}
}
