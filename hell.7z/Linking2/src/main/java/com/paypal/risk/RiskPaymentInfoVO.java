/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/RiskPaymentInfoVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:40 2012 */

package com.paypal.risk;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
  * 
   */

public class RiskPaymentInfoVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((20186*20186)<<32)/*<-RiskPaymentInfoVO*/+
         		10339/*<-is_autopay*/*15044/*<-bool*/+
         		10189/*<-is_billpay*/*15044/*<-bool*/+
         		48283/*<-is_masspay*/*15044/*<-bool*/+
         		48325/*<-is_incentive*/*15044/*<-bool*/+
         		25591/*<-is_wax*/*15044/*<-bool*/+
         		6785/*<-is_dcc*/*15044/*<-bool*/+
         		56343/*<-is_gc_purchase*/*15044/*<-bool*/+
         		28472/*<-is_authorization*/*15044/*<-bool*/+
         		35572/*<-is_reauthorization*/*15044/*<-bool*/+
         		26588/*<-is_delayed_settlement*/*15044/*<-bool*/+
         		48902/*<-is_child_auth*/*15044/*<-bool*/+
         		58053/*<-is_as2_delayed_settlement*/*15044/*<-bool*/+
         		29794/*<-is_buyer_credit*/*15044/*<-bool*/+
         		61577/*<-is_cc_funded*/*15044/*<-bool*/+
         		65483/*<-is_cross_currency*/*15044/*<-bool*/+
         		27199/*<-is_currency_funded*/*15044/*<-bool*/+
         		50161/*<-is_elv_echeck*/*15044/*<-bool*/+
         		3550/*<-is_echeck*/*15044/*<-bool*/+
         		63217/*<-is_instant_ach*/*15044/*<-bool*/+
         		21888/*<-is_instant_uach*/*15044/*<-bool*/+
         		8628/*<-is_elv*/*15044/*<-bool*/+
         		36884/*<-is_manual_eft*/*15044/*<-bool*/+
         		18163/*<-is_integrated_eft*/*15044/*<-bool*/+
         		49188/*<-is_chinese_bank*/*15044/*<-bool*/+
         		17348/*<-is_market*/*15044/*<-bool*/+
         		9834/*<-is_xborder*/*15044/*<-bool*/+
         		50429/*<-is_delayed_cc_charge*/*15044/*<-bool*/+
         		21432/*<-is_delayed_bc_charge*/*15044/*<-bool*/+
         		11100/*<-is_mobile_terminated_txn*/*15044/*<-bool*/+
         		46566/*<-is_mobile_initiated_txn*/*15044/*<-bool*/+
         		53464/*<-is_skype_initiated_txn*/*15044/*<-bool*/+
         		4816/*<-achrisk_allows_echeck*/*15044/*<-bool*/+
         		10505/*<-actual_hades_echeck_decision*/*15044/*<-bool*/+
         		14972/*<-achrisk_allows_iach*/*15044/*<-bool*/+
         		57786/*<-actual_hades_iach_decision*/*15044/*<-bool*/+
         		7495/*<-achrisk_allows_meft*/*15044/*<-bool*/+
         		57573/*<-ccrisk_allows_bc*/*15044/*<-bool*/+
         		45585/*<-actual_hades_bc_decision*/*15044/*<-bool*/+
         		57542/*<-ccrisk_allows_cc*/*15044/*<-bool*/+
         		24691/*<-actual_hades_cc_decision*/*15044/*<-bool*/+
         		7845/*<-exempt_non_cc_portion*/*15044/*<-bool*/+
         		54996/*<-funding_transaction_rejected*/*15044/*<-bool*/+
         		12029/*<-gets_ach_reward*/*15044/*<-bool*/+
         		40649/*<-made_pending_cc_risk_payments*/*15044/*<-bool*/+
         		26319/*<-use_acceptserv*/*15044/*<-bool*/+
         		62998/*<-sender_nolock*/*15044/*<-bool*/+
         		15066/*<-restrict_user*/*15044/*<-bool*/+
         		372/*<-to_biz*/*15044/*<-bool*/+
         		37884/*<-to_cat_99*/*15044/*<-bool*/+
         		61970/*<-to_gaming*/*15044/*<-bool*/+
         		47375/*<-to_allowed_gaming*/*15044/*<-bool*/+
         		19857/*<-from_allowed_gaming*/*15044/*<-bool*/+
         		6213/*<-fund_type*/*37752/*<-char*/+
         		26075/*<-amount_p_balance*/*21015/*<-Currency*/+
         		47767/*<-amount_p_fund*/*21015/*<-Currency*/+
         		42561/*<-amount_p_fund_neg_balance*/*21015/*<-Currency*/+
         		13723/*<-usd_amount_p_fund*/*21015/*<-Currency*/+
         		2125/*<-amount_f_balance*/*21015/*<-Currency*/+
         		17305/*<-amount_f_fund*/*21015/*<-Currency*/+
         		53574/*<-amount_f_fund_neg_balance*/*21015/*<-Currency*/+
         		48452/*<-usd_amount_f_fund*/*21015/*<-Currency*/+
         		64866/*<-payer_balance_change*/*21015/*<-Currency*/+
         		43735/*<-amount_applicable_to_limits*/*21015/*<-Currency*/+
         		56709/*<-auth*/*RiskAuthorizationVO.TYPE_SIGNATURE/*<-RiskAuthorizationVO*/+
         		20242/*<-keeping_existing_p_temp_hold*/*15044/*<-bool*/+
         		18643/*<-keeping_existing_f_temp_hold*/*15044/*<-bool*/+
         		33055/*<-order*/*RiskASOrderVO.TYPE_SIGNATURE/*<-RiskASOrderVO*/+
         		10361/*<-shipping_fee_schedule_id*/*46168/*<-ullong*/+
         		61954/*<-warranty_fee_schedule_id*/*46168/*<-ullong*/+
         		19737/*<-payment_flow_counterparty*/*46168/*<-ullong*/+
         		63934/*<-uome_target_alias_id*/*46168/*<-ullong*/+
         		64086/*<-time_now*/*33490/*<-ulong*/+
         		12150/*<-auth_cctrans_id*/*46168/*<-ullong*/+
         		47519/*<-auth_bctrans_id*/*46168/*<-ullong*/+
         		42984/*<-has_ip*/*15044/*<-bool*/+
         		18756/*<-cctrans_id*/*46168/*<-ullong*/+
         		43416/*<-ccrisk_result_model1_score*/*31526/*<-double*/+
         		59445/*<-ccrisk_result_model2_score*/*31526/*<-double*/+
         		8685/*<-ccrisk_result_model3_score*/*31526/*<-double*/+
         		23960/*<-ccrisk_result_model4_score*/*31526/*<-double*/+
         		2190/*<-ccrisk_result_model_buyer1_score*/*31526/*<-double*/+
         		213/*<-ccrisk_result_bc_flags*/*46168/*<-ullong*/+
         		18505/*<-ccrisk_result_model_dcc_score*/*31526/*<-double*/+
         		41557/*<-ebay_hold_decision*/*15044/*<-bool*/+
         		38827/*<-ach_risk_decision*/*ACHRiskDecisionVO.TYPE_SIGNATURE/*<-ACHRiskDecisionVO*/+
         		35791/*<-cc_results*/*com.paypal.risk.RiskAnalyzeCCResultVO.TYPE_SIGNATURE/*<-Risk::RiskAnalyzeCCResultVO*/+
         		16339/*<-elv_elvecheck_results*/*com.paypal.risk.RiskELVModelOutVO.TYPE_SIGNATURE/*<-Risk::RiskELVModelOutVO*/+
         		12730/*<-uach_allow*/*33490/*<-ulong*/+
         		36829/*<-is_refund*/*15044/*<-bool*/;
 
	public RiskPaymentInfoVO() {
		super("Risk::RiskPaymentInfoVO", TYPE_SIGNATURE);

 
		set("is_autopay", null, "bool");
 
		set("is_billpay", null, "bool");
 
		set("is_masspay", null, "bool");
 
		set("is_incentive", null, "bool");
 
		set("is_wax", null, "bool");
 
		set("is_dcc", null, "bool");
 
		set("is_gc_purchase", null, "bool");
 
		set("is_authorization", null, "bool");
 
		set("is_reauthorization", null, "bool");
 
		set("is_delayed_settlement", null, "bool");
 
		set("is_child_auth", null, "bool");
 
		set("is_as2_delayed_settlement", null, "bool");
 
		set("is_buyer_credit", null, "bool");
 
		set("is_cc_funded", null, "bool");
 
		set("is_cross_currency", null, "bool");
 
		set("is_currency_funded", null, "bool");
 
		set("is_elv_echeck", null, "bool");
 
		set("is_echeck", null, "bool");
 
		set("is_instant_ach", null, "bool");
 
		set("is_instant_uach", null, "bool");
 
		set("is_elv", null, "bool");
 
		set("is_manual_eft", null, "bool");
 
		set("is_integrated_eft", null, "bool");
 
		set("is_chinese_bank", null, "bool");
 
		set("is_market", null, "bool");
 
		set("is_xborder", null, "bool");
 
		set("is_delayed_cc_charge", null, "bool");
 
		set("is_delayed_bc_charge", null, "bool");
 
		set("is_mobile_terminated_txn", null, "bool");
 
		set("is_mobile_initiated_txn", null, "bool");
 
		set("is_skype_initiated_txn", null, "bool");
 
		set("achrisk_allows_echeck", null, "bool");
 		addFieldQualifier("actual_hades_echeck_decision","default_value","true");
 
		set("actual_hades_echeck_decision", new Boolean("true"), "bool");
 
		set("achrisk_allows_iach", null, "bool");
 		addFieldQualifier("actual_hades_iach_decision","default_value","true");
 
		set("actual_hades_iach_decision", new Boolean("true"), "bool");
 
		set("achrisk_allows_meft", null, "bool");
 
		set("ccrisk_allows_bc", null, "bool");
 		addFieldQualifier("actual_hades_bc_decision","default_value","true");
 
		set("actual_hades_bc_decision", new Boolean("true"), "bool");
 
		set("ccrisk_allows_cc", null, "bool");
 		addFieldQualifier("actual_hades_cc_decision","default_value","true");
 
		set("actual_hades_cc_decision", new Boolean("true"), "bool");
 
		set("exempt_non_cc_portion", null, "bool");
 
		set("funding_transaction_rejected", null, "bool");
 
		set("gets_ach_reward", null, "bool");
 
		set("made_pending_cc_risk_payments", null, "bool");
 
		set("use_acceptserv", null, "bool");
 
		set("sender_nolock", null, "bool");
 
		set("restrict_user", null, "bool");
 
		set("to_biz", null, "bool");
 
		set("to_cat_99", null, "bool");
 
		set("to_gaming", null, "bool");
 
		set("to_allowed_gaming", null, "bool");
 
		set("from_allowed_gaming", null, "bool");
 
		set("fund_type", null, "char");
 
		set("amount_p_balance", null, "Currency");
 
		set("amount_p_fund", null, "Currency");
 
		set("amount_p_fund_neg_balance", null, "Currency");
 
		set("usd_amount_p_fund", null, "Currency");
 
		set("amount_f_balance", null, "Currency");
 
		set("amount_f_fund", null, "Currency");
 
		set("amount_f_fund_neg_balance", null, "Currency");
 
		set("usd_amount_f_fund", null, "Currency");
 
		set("payer_balance_change", null, "Currency");
 
		set("amount_applicable_to_limits", null, "Currency");
 
		set("auth", null, "Risk::RiskAuthorizationVO");
 
		set("keeping_existing_p_temp_hold", null, "bool");
 
		set("keeping_existing_f_temp_hold", null, "bool");
 
		set("order", null, "Risk::RiskASOrderVO");
 
		set("shipping_fee_schedule_id", null, "ullong");
 
		set("warranty_fee_schedule_id", null, "ullong");
 
		set("payment_flow_counterparty", null, "ullong");
 
		set("uome_target_alias_id", null, "ullong");
 
		set("time_now", null, "ulong");
 
		set("auth_cctrans_id", null, "ullong");
 
		set("auth_bctrans_id", null, "ullong");
 
		set("has_ip", null, "bool");
 
		set("cctrans_id", null, "ullong");
 
		set("ccrisk_result_model1_score", null, "double");
 
		set("ccrisk_result_model2_score", null, "double");
 
		set("ccrisk_result_model3_score", null, "double");
 
		set("ccrisk_result_model4_score", null, "double");
 
		set("ccrisk_result_model_buyer1_score", null, "double");
 
		set("ccrisk_result_bc_flags", null, "ullong");
 
		set("ccrisk_result_model_dcc_score", null, "double");
 
		set("ebay_hold_decision", null, "bool");
 
		set("ach_risk_decision", null, "Risk::ACHRiskDecisionVO");
 
		set("cc_results", null, "Risk::RiskAnalyzeCCResultVO");
 
		set("elv_elvecheck_results", null, "Risk::RiskELVModelOutVO");
 		addFieldQualifier("uach_allow","default_value","0LU");
 
		set("uach_allow", new Long("0LU"), "ulong");
 		addFieldQualifier("is_refund","default_value","false");
 
		set("is_refund", new Boolean("false"), "bool");
	}

	// {{{
	public void setIsAutopay(Boolean value) { this.set("is_autopay", (Object)value); }
 	public Boolean getIsAutopay() { return (Boolean)this.get("is_autopay"); }
	// }}}
	// {{{
	public void setIsBillpay(Boolean value) { this.set("is_billpay", (Object)value); }
 	public Boolean getIsBillpay() { return (Boolean)this.get("is_billpay"); }
	// }}}
	// {{{
	public void setIsMasspay(Boolean value) { this.set("is_masspay", (Object)value); }
 	public Boolean getIsMasspay() { return (Boolean)this.get("is_masspay"); }
	// }}}
	// {{{
	public void setIsIncentive(Boolean value) { this.set("is_incentive", (Object)value); }
 	public Boolean getIsIncentive() { return (Boolean)this.get("is_incentive"); }
	// }}}
	// {{{
	public void setIsWax(Boolean value) { this.set("is_wax", (Object)value); }
 	public Boolean getIsWax() { return (Boolean)this.get("is_wax"); }
	// }}}
	// {{{
	public void setIsDcc(Boolean value) { this.set("is_dcc", (Object)value); }
 	public Boolean getIsDcc() { return (Boolean)this.get("is_dcc"); }
	// }}}
	// {{{
	public void setIsGcPurchase(Boolean value) { this.set("is_gc_purchase", (Object)value); }
 	public Boolean getIsGcPurchase() { return (Boolean)this.get("is_gc_purchase"); }
	// }}}
	// {{{
	public void setIsAuthorization(Boolean value) { this.set("is_authorization", (Object)value); }
 	public Boolean getIsAuthorization() { return (Boolean)this.get("is_authorization"); }
	// }}}
	// {{{
	public void setIsReauthorization(Boolean value) { this.set("is_reauthorization", (Object)value); }
 	public Boolean getIsReauthorization() { return (Boolean)this.get("is_reauthorization"); }
	// }}}
	// {{{
	public void setIsDelayedSettlement(Boolean value) { this.set("is_delayed_settlement", (Object)value); }
 	public Boolean getIsDelayedSettlement() { return (Boolean)this.get("is_delayed_settlement"); }
	// }}}
	// {{{
	public void setIsChildAuth(Boolean value) { this.set("is_child_auth", (Object)value); }
 	public Boolean getIsChildAuth() { return (Boolean)this.get("is_child_auth"); }
	// }}}
	// {{{
	public void setIsAs2DelayedSettlement(Boolean value) { this.set("is_as2_delayed_settlement", (Object)value); }
 	public Boolean getIsAs2DelayedSettlement() { return (Boolean)this.get("is_as2_delayed_settlement"); }
	// }}}
	// {{{
	public void setIsBuyerCredit(Boolean value) { this.set("is_buyer_credit", (Object)value); }
 	public Boolean getIsBuyerCredit() { return (Boolean)this.get("is_buyer_credit"); }
	// }}}
	// {{{
	public void setIsCcFunded(Boolean value) { this.set("is_cc_funded", (Object)value); }
 	public Boolean getIsCcFunded() { return (Boolean)this.get("is_cc_funded"); }
	// }}}
	// {{{
	public void setIsCrossCurrency(Boolean value) { this.set("is_cross_currency", (Object)value); }
 	public Boolean getIsCrossCurrency() { return (Boolean)this.get("is_cross_currency"); }
	// }}}
	// {{{
	public void setIsCurrencyFunded(Boolean value) { this.set("is_currency_funded", (Object)value); }
 	public Boolean getIsCurrencyFunded() { return (Boolean)this.get("is_currency_funded"); }
	// }}}
	// {{{
	public void setIsElvEcheck(Boolean value) { this.set("is_elv_echeck", (Object)value); }
 	public Boolean getIsElvEcheck() { return (Boolean)this.get("is_elv_echeck"); }
	// }}}
	// {{{
	public void setIsEcheck(Boolean value) { this.set("is_echeck", (Object)value); }
 	public Boolean getIsEcheck() { return (Boolean)this.get("is_echeck"); }
	// }}}
	// {{{
	public void setIsInstantAch(Boolean value) { this.set("is_instant_ach", (Object)value); }
 	public Boolean getIsInstantAch() { return (Boolean)this.get("is_instant_ach"); }
	// }}}
	// {{{
	public void setIsInstantUach(Boolean value) { this.set("is_instant_uach", (Object)value); }
 	public Boolean getIsInstantUach() { return (Boolean)this.get("is_instant_uach"); }
	// }}}
	// {{{
	public void setIsElv(Boolean value) { this.set("is_elv", (Object)value); }
 	public Boolean getIsElv() { return (Boolean)this.get("is_elv"); }
	// }}}
	// {{{
	public void setIsManualEft(Boolean value) { this.set("is_manual_eft", (Object)value); }
 	public Boolean getIsManualEft() { return (Boolean)this.get("is_manual_eft"); }
	// }}}
	// {{{
	public void setIsIntegratedEft(Boolean value) { this.set("is_integrated_eft", (Object)value); }
 	public Boolean getIsIntegratedEft() { return (Boolean)this.get("is_integrated_eft"); }
	// }}}
	// {{{
	public void setIsChineseBank(Boolean value) { this.set("is_chinese_bank", (Object)value); }
 	public Boolean getIsChineseBank() { return (Boolean)this.get("is_chinese_bank"); }
	// }}}
	// {{{
	public void setIsMarket(Boolean value) { this.set("is_market", (Object)value); }
 	public Boolean getIsMarket() { return (Boolean)this.get("is_market"); }
	// }}}
	// {{{
	public void setIsXborder(Boolean value) { this.set("is_xborder", (Object)value); }
 	public Boolean getIsXborder() { return (Boolean)this.get("is_xborder"); }
	// }}}
	// {{{
	public void setIsDelayedCcCharge(Boolean value) { this.set("is_delayed_cc_charge", (Object)value); }
 	public Boolean getIsDelayedCcCharge() { return (Boolean)this.get("is_delayed_cc_charge"); }
	// }}}
	// {{{
	public void setIsDelayedBcCharge(Boolean value) { this.set("is_delayed_bc_charge", (Object)value); }
 	public Boolean getIsDelayedBcCharge() { return (Boolean)this.get("is_delayed_bc_charge"); }
	// }}}
	// {{{
	public void setIsMobileTerminatedTxn(Boolean value) { this.set("is_mobile_terminated_txn", (Object)value); }
 	public Boolean getIsMobileTerminatedTxn() { return (Boolean)this.get("is_mobile_terminated_txn"); }
	// }}}
	// {{{
	public void setIsMobileInitiatedTxn(Boolean value) { this.set("is_mobile_initiated_txn", (Object)value); }
 	public Boolean getIsMobileInitiatedTxn() { return (Boolean)this.get("is_mobile_initiated_txn"); }
	// }}}
	// {{{
	public void setIsSkypeInitiatedTxn(Boolean value) { this.set("is_skype_initiated_txn", (Object)value); }
 	public Boolean getIsSkypeInitiatedTxn() { return (Boolean)this.get("is_skype_initiated_txn"); }
	// }}}
	// {{{
	public void setAchriskAllowsEcheck(Boolean value) { this.set("achrisk_allows_echeck", (Object)value); }
 	public Boolean getAchriskAllowsEcheck() { return (Boolean)this.get("achrisk_allows_echeck"); }
	// }}}
	// {{{
	public void setActualHadesEcheckDecision(Boolean value) { this.set("actual_hades_echeck_decision", (Object)value); }
 	public Boolean getActualHadesEcheckDecision() { return (Boolean)this.get("actual_hades_echeck_decision"); }
	// }}}
	// {{{
	public void setAchriskAllowsIach(Boolean value) { this.set("achrisk_allows_iach", (Object)value); }
 	public Boolean getAchriskAllowsIach() { return (Boolean)this.get("achrisk_allows_iach"); }
	// }}}
	// {{{
	public void setActualHadesIachDecision(Boolean value) { this.set("actual_hades_iach_decision", (Object)value); }
 	public Boolean getActualHadesIachDecision() { return (Boolean)this.get("actual_hades_iach_decision"); }
	// }}}
	// {{{
	public void setAchriskAllowsMeft(Boolean value) { this.set("achrisk_allows_meft", (Object)value); }
 	public Boolean getAchriskAllowsMeft() { return (Boolean)this.get("achrisk_allows_meft"); }
	// }}}
	// {{{
	public void setCcriskAllowsBc(Boolean value) { this.set("ccrisk_allows_bc", (Object)value); }
 	public Boolean getCcriskAllowsBc() { return (Boolean)this.get("ccrisk_allows_bc"); }
	// }}}
	// {{{
	public void setActualHadesBcDecision(Boolean value) { this.set("actual_hades_bc_decision", (Object)value); }
 	public Boolean getActualHadesBcDecision() { return (Boolean)this.get("actual_hades_bc_decision"); }
	// }}}
	// {{{
	public void setCcriskAllowsCc(Boolean value) { this.set("ccrisk_allows_cc", (Object)value); }
 	public Boolean getCcriskAllowsCc() { return (Boolean)this.get("ccrisk_allows_cc"); }
	// }}}
	// {{{
	public void setActualHadesCcDecision(Boolean value) { this.set("actual_hades_cc_decision", (Object)value); }
 	public Boolean getActualHadesCcDecision() { return (Boolean)this.get("actual_hades_cc_decision"); }
	// }}}
	// {{{
	public void setExemptNonCcPortion(Boolean value) { this.set("exempt_non_cc_portion", (Object)value); }
 	public Boolean getExemptNonCcPortion() { return (Boolean)this.get("exempt_non_cc_portion"); }
	// }}}
	// {{{
	public void setFundingTransactionRejected(Boolean value) { this.set("funding_transaction_rejected", (Object)value); }
 	public Boolean getFundingTransactionRejected() { return (Boolean)this.get("funding_transaction_rejected"); }
	// }}}
	// {{{
	public void setGetsAchReward(Boolean value) { this.set("gets_ach_reward", (Object)value); }
 	public Boolean getGetsAchReward() { return (Boolean)this.get("gets_ach_reward"); }
	// }}}
	// {{{
	public void setMadePendingCcRiskPayments(Boolean value) { this.set("made_pending_cc_risk_payments", (Object)value); }
 	public Boolean getMadePendingCcRiskPayments() { return (Boolean)this.get("made_pending_cc_risk_payments"); }
	// }}}
	// {{{
	public void setUseAcceptserv(Boolean value) { this.set("use_acceptserv", (Object)value); }
 	public Boolean getUseAcceptserv() { return (Boolean)this.get("use_acceptserv"); }
	// }}}
	// {{{
	public void setSenderNolock(Boolean value) { this.set("sender_nolock", (Object)value); }
 	public Boolean getSenderNolock() { return (Boolean)this.get("sender_nolock"); }
	// }}}
	// {{{
	public void setRestrictUser(Boolean value) { this.set("restrict_user", (Object)value); }
 	public Boolean getRestrictUser() { return (Boolean)this.get("restrict_user"); }
	// }}}
	// {{{
	public void setToBiz(Boolean value) { this.set("to_biz", (Object)value); }
 	public Boolean getToBiz() { return (Boolean)this.get("to_biz"); }
	// }}}
	// {{{
	public void setToCat99(Boolean value) { this.set("to_cat_99", (Object)value); }
 	public Boolean getToCat99() { return (Boolean)this.get("to_cat_99"); }
	// }}}
	// {{{
	public void setToGaming(Boolean value) { this.set("to_gaming", (Object)value); }
 	public Boolean getToGaming() { return (Boolean)this.get("to_gaming"); }
	// }}}
	// {{{
	public void setToAllowedGaming(Boolean value) { this.set("to_allowed_gaming", (Object)value); }
 	public Boolean getToAllowedGaming() { return (Boolean)this.get("to_allowed_gaming"); }
	// }}}
	// {{{
	public void setFromAllowedGaming(Boolean value) { this.set("from_allowed_gaming", (Object)value); }
 	public Boolean getFromAllowedGaming() { return (Boolean)this.get("from_allowed_gaming"); }
	// }}}
	// {{{
	public void setFundType(Byte value) { this.set("fund_type", (Object)value); }
 	public Byte getFundType() { return (Byte)this.get("fund_type"); }
	// }}}
	// {{{
	public void setAmountPBalance(Currency value) { this.set("amount_p_balance", (Object)value); }
 	public Currency getAmountPBalance() { return (Currency)this.get("amount_p_balance"); }
	// }}}
	// {{{
	public void setAmountPFund(Currency value) { this.set("amount_p_fund", (Object)value); }
 	public Currency getAmountPFund() { return (Currency)this.get("amount_p_fund"); }
	// }}}
	// {{{
	public void setAmountPFundNegBalance(Currency value) { this.set("amount_p_fund_neg_balance", (Object)value); }
 	public Currency getAmountPFundNegBalance() { return (Currency)this.get("amount_p_fund_neg_balance"); }
	// }}}
	// {{{
	public void setUsdAmountPFund(Currency value) { this.set("usd_amount_p_fund", (Object)value); }
 	public Currency getUsdAmountPFund() { return (Currency)this.get("usd_amount_p_fund"); }
	// }}}
	// {{{
	public void setAmountFBalance(Currency value) { this.set("amount_f_balance", (Object)value); }
 	public Currency getAmountFBalance() { return (Currency)this.get("amount_f_balance"); }
	// }}}
	// {{{
	public void setAmountFFund(Currency value) { this.set("amount_f_fund", (Object)value); }
 	public Currency getAmountFFund() { return (Currency)this.get("amount_f_fund"); }
	// }}}
	// {{{
	public void setAmountFFundNegBalance(Currency value) { this.set("amount_f_fund_neg_balance", (Object)value); }
 	public Currency getAmountFFundNegBalance() { return (Currency)this.get("amount_f_fund_neg_balance"); }
	// }}}
	// {{{
	public void setUsdAmountFFund(Currency value) { this.set("usd_amount_f_fund", (Object)value); }
 	public Currency getUsdAmountFFund() { return (Currency)this.get("usd_amount_f_fund"); }
	// }}}
	// {{{
	public void setPayerBalanceChange(Currency value) { this.set("payer_balance_change", (Object)value); }
 	public Currency getPayerBalanceChange() { return (Currency)this.get("payer_balance_change"); }
	// }}}
	// {{{
	public void setAmountApplicableToLimits(Currency value) { this.set("amount_applicable_to_limits", (Object)value); }
 	public Currency getAmountApplicableToLimits() { return (Currency)this.get("amount_applicable_to_limits"); }
	// }}}
	// {{{
	public void setAuth(RiskAuthorizationVO value) { this.set("auth", (Object)value); }
 	public RiskAuthorizationVO getAuth() { return (RiskAuthorizationVO)this.get("auth"); }
	// }}}
	// {{{
	public void setKeepingExistingPTempHold(Boolean value) { this.set("keeping_existing_p_temp_hold", (Object)value); }
 	public Boolean getKeepingExistingPTempHold() { return (Boolean)this.get("keeping_existing_p_temp_hold"); }
	// }}}
	// {{{
	public void setKeepingExistingFTempHold(Boolean value) { this.set("keeping_existing_f_temp_hold", (Object)value); }
 	public Boolean getKeepingExistingFTempHold() { return (Boolean)this.get("keeping_existing_f_temp_hold"); }
	// }}}
	// {{{
	public void setOrder(RiskASOrderVO value) { this.set("order", (Object)value); }
 	public RiskASOrderVO getOrder() { return (RiskASOrderVO)this.get("order"); }
	// }}}
	// {{{
	public void setShippingFeeScheduleId(BigInteger value) { this.set("shipping_fee_schedule_id", (Object)value); }
 	public BigInteger getShippingFeeScheduleId() { return (BigInteger)this.get("shipping_fee_schedule_id"); }
	// }}}
	// {{{
	public void setWarrantyFeeScheduleId(BigInteger value) { this.set("warranty_fee_schedule_id", (Object)value); }
 	public BigInteger getWarrantyFeeScheduleId() { return (BigInteger)this.get("warranty_fee_schedule_id"); }
	// }}}
	// {{{
	public void setPaymentFlowCounterparty(BigInteger value) { this.set("payment_flow_counterparty", (Object)value); }
 	public BigInteger getPaymentFlowCounterparty() { return (BigInteger)this.get("payment_flow_counterparty"); }
	// }}}
	// {{{
	public void setUomeTargetAliasId(BigInteger value) { this.set("uome_target_alias_id", (Object)value); }
 	public BigInteger getUomeTargetAliasId() { return (BigInteger)this.get("uome_target_alias_id"); }
	// }}}
	// {{{
	public void setTimeNow(Long value) { this.set("time_now", (Object)value); }
 	public Long getTimeNow() { return (Long)this.get("time_now"); }
	// }}}
	// {{{
	public void setAuthCctransId(BigInteger value) { this.set("auth_cctrans_id", (Object)value); }
 	public BigInteger getAuthCctransId() { return (BigInteger)this.get("auth_cctrans_id"); }
	// }}}
	// {{{
	public void setAuthBctransId(BigInteger value) { this.set("auth_bctrans_id", (Object)value); }
 	public BigInteger getAuthBctransId() { return (BigInteger)this.get("auth_bctrans_id"); }
	// }}}
	// {{{
	public void setHasIp(Boolean value) { this.set("has_ip", (Object)value); }
 	public Boolean getHasIp() { return (Boolean)this.get("has_ip"); }
	// }}}
	// {{{
	public void setCctransId(BigInteger value) { this.set("cctrans_id", (Object)value); }
 	public BigInteger getCctransId() { return (BigInteger)this.get("cctrans_id"); }
	// }}}
	// {{{
	public void setCcriskResultModel1Score(Double value) { this.set("ccrisk_result_model1_score", (Object)value); }
 	public Double getCcriskResultModel1Score() { return (Double)this.get("ccrisk_result_model1_score"); }
	// }}}
	// {{{
	public void setCcriskResultModel2Score(Double value) { this.set("ccrisk_result_model2_score", (Object)value); }
 	public Double getCcriskResultModel2Score() { return (Double)this.get("ccrisk_result_model2_score"); }
	// }}}
	// {{{
	public void setCcriskResultModel3Score(Double value) { this.set("ccrisk_result_model3_score", (Object)value); }
 	public Double getCcriskResultModel3Score() { return (Double)this.get("ccrisk_result_model3_score"); }
	// }}}
	// {{{
	public void setCcriskResultModel4Score(Double value) { this.set("ccrisk_result_model4_score", (Object)value); }
 	public Double getCcriskResultModel4Score() { return (Double)this.get("ccrisk_result_model4_score"); }
	// }}}
	// {{{
	public void setCcriskResultModelBuyer1Score(Double value) { this.set("ccrisk_result_model_buyer1_score", (Object)value); }
 	public Double getCcriskResultModelBuyer1Score() { return (Double)this.get("ccrisk_result_model_buyer1_score"); }
	// }}}
	// {{{
	public void setCcriskResultBcFlags(BigInteger value) { this.set("ccrisk_result_bc_flags", (Object)value); }
 	public BigInteger getCcriskResultBcFlags() { return (BigInteger)this.get("ccrisk_result_bc_flags"); }
	// }}}
	// {{{
	public void setCcriskResultModelDccScore(Double value) { this.set("ccrisk_result_model_dcc_score", (Object)value); }
 	public Double getCcriskResultModelDccScore() { return (Double)this.get("ccrisk_result_model_dcc_score"); }
	// }}}
	// {{{
	public void setEbayHoldDecision(Boolean value) { this.set("ebay_hold_decision", (Object)value); }
 	public Boolean getEbayHoldDecision() { return (Boolean)this.get("ebay_hold_decision"); }
	// }}}
	// {{{
	public void setAchRiskDecision(ACHRiskDecisionVO value) { this.set("ach_risk_decision", (Object)value); }
 	public ACHRiskDecisionVO getAchRiskDecision() { return (ACHRiskDecisionVO)this.get("ach_risk_decision"); }
	// }}}
	// {{{
	public void setCcResults(com.paypal.risk.RiskAnalyzeCCResultVO value) { this.set("cc_results", (Object)value); }
 	public com.paypal.risk.RiskAnalyzeCCResultVO getCcResults() { return (com.paypal.risk.RiskAnalyzeCCResultVO)this.get("cc_results"); }
	// }}}
	// {{{
	public void setElvElvecheckResults(com.paypal.risk.RiskELVModelOutVO value) { this.set("elv_elvecheck_results", (Object)value); }
 	public com.paypal.risk.RiskELVModelOutVO getElvElvecheckResults() { return (com.paypal.risk.RiskELVModelOutVO)this.get("elv_elvecheck_results"); }
	// }}}
	// {{{
	public void setUachAllow(Long value) { this.set("uach_allow", (Object)value); }
 	public Long getUachAllow() { return (Long)this.get("uach_allow"); }
	// }}}
	// {{{
	public void setIsRefund(Boolean value) { this.set("is_refund", (Object)value); }
 	public Boolean getIsRefund() { return (Boolean)this.get("is_refund"); }
	// }}}
}