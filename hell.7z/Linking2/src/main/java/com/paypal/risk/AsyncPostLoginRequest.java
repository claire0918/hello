/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/RiskLoginAsync.sdl
 by ASF Java Code Generator
 at ������ 12 06 10:23:40 2012 */

package com.paypal.risk;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
                        Risk Login Asynchronous Service Definition.
                        This service is having nonconfirm fire and forget APIs related to risk login checks without impacting the sync login flow.
				The plan is to move non UI impacting(challenging auth flows etc) risk related login checks to this async service.
				Another related service owned by Risk is riskloginserv which is containing sync/blocking APIs related to login risk checks.
                
  * 
  * 2010-03-23
   * @author Prabhakaran Chinnathambi
  */

public class AsyncPostLoginRequest extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((15066*15066)<<32)/*<-AsyncPostLoginRequest*/+
         		25763/*<-actor_info*/*com.paypal.common.ActorInfoVO.TYPE_SIGNATURE/*<-Common::ActorInfoVO*/+
         		20798/*<-ars_vector*/*com.paypal.arsvector.ARSVectorVO.TYPE_SIGNATURE/*<-ARSVector::ARSVectorVO*/;
 
	public AsyncPostLoginRequest() {
		super("Risk::AsyncPostLoginRequest", TYPE_SIGNATURE);

 
		set("actor_info", null, "Common::ActorInfoVO");
 
		set("ars_vector", null, "ARSVector::ARSVectorVO");
	}

	// {{{
	public void setActorInfo(com.paypal.common.ActorInfoVO value) { this.set("actor_info", (Object)value); }
 	public com.paypal.common.ActorInfoVO getActorInfo() { return (com.paypal.common.ActorInfoVO)this.get("actor_info"); }
	// }}}
	// {{{
	public void setArsVector(com.paypal.arsvector.ARSVectorVO value) { this.set("ars_vector", (Object)value); }
 	public com.paypal.arsvector.ARSVectorVO getArsVector() { return (com.paypal.arsvector.ARSVectorVO)this.get("ars_vector"); }
	// }}}
}