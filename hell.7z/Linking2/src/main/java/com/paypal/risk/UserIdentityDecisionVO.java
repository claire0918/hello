/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/PaymentStrategyDecisionVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:40 2012 */

package com.paypal.risk;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * RiskPaymentServ 
  * 
  * 2012-01-18
   * @author Vahini Pobbathi, Sagar Loke, Xin Li
  */

public class UserIdentityDecisionVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((49294*49294)<<32)/*<-UserIdentityDecisionVO*/+
         		59701/*<-user_id*/*com.paypal.money.UserIdentifierVO.TYPE_SIGNATURE/*<-Money::UserIdentifierVO*/+
         		1811/*<-user_type*/*38894/*<-int*/+
         		35694/*<-user_level_decision*/*38894/*<-int*/+
         		25147/*<-authflow_decision*/*com.paypal.common.OpaqueDataElementVO.TYPE_SIGNATURE/*<-Common::OpaqueDataElementVO*/+
         		14535/*<-decision_message*/*com.paypal.money.PlanningMessageVO.TYPE_SIGNATURE/*<-Money::PlanningMessageVO*/;
 
	public UserIdentityDecisionVO() {
		super("Risk::UserIdentityDecisionVO", TYPE_SIGNATURE);

 		addFieldQualifier("user_id","required","true");
 
		set("user_id", null, "Money::UserIdentifierVO");
 		addFieldQualifier("user_type","required","true");
 
		set("user_type", null, "int");
 		addFieldQualifier("user_level_decision","required","true");
 
		set("user_level_decision", null, "int");
 
		set("authflow_decision", null, "Common::OpaqueDataElementVO");
 
		set("decision_message", null, "Money::PlanningMessageVO");
	}

	// {{{
	public void setUserId(com.paypal.money.UserIdentifierVO value) { this.set("user_id", (Object)value); }
 	public com.paypal.money.UserIdentifierVO getUserId() { return (com.paypal.money.UserIdentifierVO)this.get("user_id"); }
	// }}}
	// {{{
	public void setUserType(Integer value) { this.set("user_type", (Object)value); }
 	public Integer getUserType() { return (Integer)this.get("user_type"); }
	// }}}
	// {{{
	public void setUserLevelDecision(Integer value) { this.set("user_level_decision", (Object)value); }
 	public Integer getUserLevelDecision() { return (Integer)this.get("user_level_decision"); }
	// }}}
	// {{{
	public void setAuthflowDecision(com.paypal.common.OpaqueDataElementVO value) { this.set("authflow_decision", (Object)value); }
 	public com.paypal.common.OpaqueDataElementVO getAuthflowDecision() { return (com.paypal.common.OpaqueDataElementVO)this.get("authflow_decision"); }
	// }}}
	// {{{
	public void setDecisionMessage(com.paypal.money.PlanningMessageVO value) { this.set("decision_message", (Object)value); }
 	public com.paypal.money.PlanningMessageVO getDecisionMessage() { return (com.paypal.money.PlanningMessageVO)this.get("decision_message"); }
	// }}}
}