/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/RiskFilterInfoVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:40 2012 */

package com.paypal.risk;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
  * 
   */

public class RiskFilterInfoVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((31910*31910)<<32)/*<-RiskFilterInfoVO*/+
         		15446/*<-country_filter_enabled*/*15044/*<-bool*/+
         		10468/*<-country_filter_toggle_level*/*46796/*<-llong*/+
         		2671/*<-country_filter_triggered*/*15044/*<-bool*/+
         		13185/*<-payment_filter_enabled*/*15044/*<-bool*/+
         		26741/*<-payment_filter_toggle_level*/*46796/*<-llong*/+
         		25594/*<-payment_filter_triggered*/*15044/*<-bool*/+
         		14297/*<-fraud_filter_enabled*/*15044/*<-bool*/+
         		3074/*<-fraud_filter_toggle_level*/*46796/*<-llong*/+
         		61671/*<-fraud_filter_triggered*/*15044/*<-bool*/+
         		10477/*<-models_to_run*/*46168/*<-ullong*/+
         		60974/*<-avs_no_address_match_filter_enabled*/*15044/*<-bool*/+
         		42290/*<-avs_no_address_match_filter_toggle_level*/*46796/*<-llong*/+
         		13212/*<-avs_no_address_match_filter_triggered*/*15044/*<-bool*/+
         		32454/*<-avs_no_address_match_filter_touched*/*15044/*<-bool*/+
         		43858/*<-avs_partial_address_match_filter_enabled*/*15044/*<-bool*/+
         		4878/*<-avs_partial_address_match_filter_toggle_level*/*46796/*<-llong*/+
         		57270/*<-avs_partial_address_match_filter_triggered*/*15044/*<-bool*/+
         		12386/*<-avs_partial_address_match_filter_touched*/*15044/*<-bool*/+
         		13498/*<-avs_unsupported_unavailable_filter_enabled*/*15044/*<-bool*/+
         		3388/*<-avs_unsupported_unavailable_filter_toggle_level*/*46796/*<-llong*/+
         		4254/*<-avs_unsupported_unavailable_filter_triggered*/*15044/*<-bool*/+
         		50187/*<-avs_unsupported_unavailable_filter_touched*/*15044/*<-bool*/+
         		19689/*<-cvv_optional_filter_enabled*/*15044/*<-bool*/+
         		14639/*<-cvv_optional_filter_toggle_level*/*46796/*<-llong*/+
         		15797/*<-cvv_optional_filter_triggered*/*15044/*<-bool*/+
         		54330/*<-cvv_optional_filter_touched*/*15044/*<-bool*/+
         		44708/*<-cvv_code_not_passed_in*/*15044/*<-bool*/+
         		44495/*<-optional_billing_address_filter_enabled*/*15044/*<-bool*/+
         		56992/*<-is_rc2_eligible*/*15044/*<-bool*/+
         		23693/*<-preauth_filter_adjudication_result*/*33490/*<-ulong*/+
         		62863/*<-postauth_filter_adjudication_result*/*33490/*<-ulong*/+
         		28678/*<-triggered_filter_list*/*18443/*<-String*/+
         		35459/*<-is_fmf_flagged*/*15044/*<-bool*/+
         		5712/*<-fmf_preference*/*46796/*<-llong*/+
         		27795/*<-risk_filters_v2*/*47/*<-repeating*/*RiskFilterV2InfoVO.TYPE_SIGNATURE/*<-RiskFilterV2InfoVO*/+
         		48065/*<-txn_filter_status*/*18443/*<-String*/+
         		48388/*<-fmf_product_code*/*46168/*<-ullong*/+
         		29491/*<-is_pp_cc_payment_fraud_filter*/*15044/*<-bool*/+
         		48524/*<-is_dcc_payment_fraud_filter*/*15044/*<-bool*/+
         		39289/*<-is_vt_payment_fraud_filter*/*15044/*<-bool*/+
         		35910/*<-override_decline_if_account_restricted*/*15044/*<-bool*/+
         		13824/*<-override_decline_if_cc_disabled*/*15044/*<-bool*/;
 
	public RiskFilterInfoVO() {
		super("Risk::RiskFilterInfoVO", TYPE_SIGNATURE);

 
		set("country_filter_enabled", null, "bool");
 
		set("country_filter_toggle_level", null, "llong");
 
		set("country_filter_triggered", null, "bool");
 
		set("payment_filter_enabled", null, "bool");
 
		set("payment_filter_toggle_level", null, "llong");
 
		set("payment_filter_triggered", null, "bool");
 
		set("fraud_filter_enabled", null, "bool");
 
		set("fraud_filter_toggle_level", null, "llong");
 
		set("fraud_filter_triggered", null, "bool");
 
		set("models_to_run", null, "ullong");
 
		set("avs_no_address_match_filter_enabled", null, "bool");
 
		set("avs_no_address_match_filter_toggle_level", null, "llong");
 
		set("avs_no_address_match_filter_triggered", null, "bool");
 
		set("avs_no_address_match_filter_touched", null, "bool");
 
		set("avs_partial_address_match_filter_enabled", null, "bool");
 
		set("avs_partial_address_match_filter_toggle_level", null, "llong");
 
		set("avs_partial_address_match_filter_triggered", null, "bool");
 
		set("avs_partial_address_match_filter_touched", null, "bool");
 
		set("avs_unsupported_unavailable_filter_enabled", null, "bool");
 
		set("avs_unsupported_unavailable_filter_toggle_level", null, "llong");
 
		set("avs_unsupported_unavailable_filter_triggered", null, "bool");
 
		set("avs_unsupported_unavailable_filter_touched", null, "bool");
 
		set("cvv_optional_filter_enabled", null, "bool");
 
		set("cvv_optional_filter_toggle_level", null, "llong");
 
		set("cvv_optional_filter_triggered", null, "bool");
 
		set("cvv_optional_filter_touched", null, "bool");
 
		set("cvv_code_not_passed_in", null, "bool");
 
		set("optional_billing_address_filter_enabled", null, "bool");
 
		set("is_rc2_eligible", null, "bool");
 
		set("preauth_filter_adjudication_result", null, "ulong");
 
		set("postauth_filter_adjudication_result", null, "ulong");
 
		set("triggered_filter_list", null, "String");
 
		set("is_fmf_flagged", null, "bool");
 
		set("fmf_preference", null, "llong");
 
		set("risk_filters_v2", null, "List<Risk::RiskFilterV2InfoVO>");
 
		set("txn_filter_status", null, "String");
 
		set("fmf_product_code", null, "ullong");
 
		set("is_pp_cc_payment_fraud_filter", null, "bool");
 
		set("is_dcc_payment_fraud_filter", null, "bool");
 
		set("is_vt_payment_fraud_filter", null, "bool");
 		addFieldQualifier("override_decline_if_account_restricted","default_value","false");
 
		set("override_decline_if_account_restricted", new Boolean("false"), "bool");
 		addFieldQualifier("override_decline_if_cc_disabled","default_value","false");
 
		set("override_decline_if_cc_disabled", new Boolean("false"), "bool");
	}

	// {{{
	public void setCountryFilterEnabled(Boolean value) { this.set("country_filter_enabled", (Object)value); }
 	public Boolean getCountryFilterEnabled() { return (Boolean)this.get("country_filter_enabled"); }
	// }}}
	// {{{
	public void setCountryFilterToggleLevel(Long value) { this.set("country_filter_toggle_level", (Object)value); }
 	public Long getCountryFilterToggleLevel() { return (Long)this.get("country_filter_toggle_level"); }
	// }}}
	// {{{
	public void setCountryFilterTriggered(Boolean value) { this.set("country_filter_triggered", (Object)value); }
 	public Boolean getCountryFilterTriggered() { return (Boolean)this.get("country_filter_triggered"); }
	// }}}
	// {{{
	public void setPaymentFilterEnabled(Boolean value) { this.set("payment_filter_enabled", (Object)value); }
 	public Boolean getPaymentFilterEnabled() { return (Boolean)this.get("payment_filter_enabled"); }
	// }}}
	// {{{
	public void setPaymentFilterToggleLevel(Long value) { this.set("payment_filter_toggle_level", (Object)value); }
 	public Long getPaymentFilterToggleLevel() { return (Long)this.get("payment_filter_toggle_level"); }
	// }}}
	// {{{
	public void setPaymentFilterTriggered(Boolean value) { this.set("payment_filter_triggered", (Object)value); }
 	public Boolean getPaymentFilterTriggered() { return (Boolean)this.get("payment_filter_triggered"); }
	// }}}
	// {{{
	public void setFraudFilterEnabled(Boolean value) { this.set("fraud_filter_enabled", (Object)value); }
 	public Boolean getFraudFilterEnabled() { return (Boolean)this.get("fraud_filter_enabled"); }
	// }}}
	// {{{
	public void setFraudFilterToggleLevel(Long value) { this.set("fraud_filter_toggle_level", (Object)value); }
 	public Long getFraudFilterToggleLevel() { return (Long)this.get("fraud_filter_toggle_level"); }
	// }}}
	// {{{
	public void setFraudFilterTriggered(Boolean value) { this.set("fraud_filter_triggered", (Object)value); }
 	public Boolean getFraudFilterTriggered() { return (Boolean)this.get("fraud_filter_triggered"); }
	// }}}
	// {{{
	public void setModelsToRun(BigInteger value) { this.set("models_to_run", (Object)value); }
 	public BigInteger getModelsToRun() { return (BigInteger)this.get("models_to_run"); }
	// }}}
	// {{{
	public void setAvsNoAddressMatchFilterEnabled(Boolean value) { this.set("avs_no_address_match_filter_enabled", (Object)value); }
 	public Boolean getAvsNoAddressMatchFilterEnabled() { return (Boolean)this.get("avs_no_address_match_filter_enabled"); }
	// }}}
	// {{{
	public void setAvsNoAddressMatchFilterToggleLevel(Long value) { this.set("avs_no_address_match_filter_toggle_level", (Object)value); }
 	public Long getAvsNoAddressMatchFilterToggleLevel() { return (Long)this.get("avs_no_address_match_filter_toggle_level"); }
	// }}}
	// {{{
	public void setAvsNoAddressMatchFilterTriggered(Boolean value) { this.set("avs_no_address_match_filter_triggered", (Object)value); }
 	public Boolean getAvsNoAddressMatchFilterTriggered() { return (Boolean)this.get("avs_no_address_match_filter_triggered"); }
	// }}}
	// {{{
	public void setAvsNoAddressMatchFilterTouched(Boolean value) { this.set("avs_no_address_match_filter_touched", (Object)value); }
 	public Boolean getAvsNoAddressMatchFilterTouched() { return (Boolean)this.get("avs_no_address_match_filter_touched"); }
	// }}}
	// {{{
	public void setAvsPartialAddressMatchFilterEnabled(Boolean value) { this.set("avs_partial_address_match_filter_enabled", (Object)value); }
 	public Boolean getAvsPartialAddressMatchFilterEnabled() { return (Boolean)this.get("avs_partial_address_match_filter_enabled"); }
	// }}}
	// {{{
	public void setAvsPartialAddressMatchFilterToggleLevel(Long value) { this.set("avs_partial_address_match_filter_toggle_level", (Object)value); }
 	public Long getAvsPartialAddressMatchFilterToggleLevel() { return (Long)this.get("avs_partial_address_match_filter_toggle_level"); }
	// }}}
	// {{{
	public void setAvsPartialAddressMatchFilterTriggered(Boolean value) { this.set("avs_partial_address_match_filter_triggered", (Object)value); }
 	public Boolean getAvsPartialAddressMatchFilterTriggered() { return (Boolean)this.get("avs_partial_address_match_filter_triggered"); }
	// }}}
	// {{{
	public void setAvsPartialAddressMatchFilterTouched(Boolean value) { this.set("avs_partial_address_match_filter_touched", (Object)value); }
 	public Boolean getAvsPartialAddressMatchFilterTouched() { return (Boolean)this.get("avs_partial_address_match_filter_touched"); }
	// }}}
	// {{{
	public void setAvsUnsupportedUnavailableFilterEnabled(Boolean value) { this.set("avs_unsupported_unavailable_filter_enabled", (Object)value); }
 	public Boolean getAvsUnsupportedUnavailableFilterEnabled() { return (Boolean)this.get("avs_unsupported_unavailable_filter_enabled"); }
	// }}}
	// {{{
	public void setAvsUnsupportedUnavailableFilterToggleLevel(Long value) { this.set("avs_unsupported_unavailable_filter_toggle_level", (Object)value); }
 	public Long getAvsUnsupportedUnavailableFilterToggleLevel() { return (Long)this.get("avs_unsupported_unavailable_filter_toggle_level"); }
	// }}}
	// {{{
	public void setAvsUnsupportedUnavailableFilterTriggered(Boolean value) { this.set("avs_unsupported_unavailable_filter_triggered", (Object)value); }
 	public Boolean getAvsUnsupportedUnavailableFilterTriggered() { return (Boolean)this.get("avs_unsupported_unavailable_filter_triggered"); }
	// }}}
	// {{{
	public void setAvsUnsupportedUnavailableFilterTouched(Boolean value) { this.set("avs_unsupported_unavailable_filter_touched", (Object)value); }
 	public Boolean getAvsUnsupportedUnavailableFilterTouched() { return (Boolean)this.get("avs_unsupported_unavailable_filter_touched"); }
	// }}}
	// {{{
	public void setCvvOptionalFilterEnabled(Boolean value) { this.set("cvv_optional_filter_enabled", (Object)value); }
 	public Boolean getCvvOptionalFilterEnabled() { return (Boolean)this.get("cvv_optional_filter_enabled"); }
	// }}}
	// {{{
	public void setCvvOptionalFilterToggleLevel(Long value) { this.set("cvv_optional_filter_toggle_level", (Object)value); }
 	public Long getCvvOptionalFilterToggleLevel() { return (Long)this.get("cvv_optional_filter_toggle_level"); }
	// }}}
	// {{{
	public void setCvvOptionalFilterTriggered(Boolean value) { this.set("cvv_optional_filter_triggered", (Object)value); }
 	public Boolean getCvvOptionalFilterTriggered() { return (Boolean)this.get("cvv_optional_filter_triggered"); }
	// }}}
	// {{{
	public void setCvvOptionalFilterTouched(Boolean value) { this.set("cvv_optional_filter_touched", (Object)value); }
 	public Boolean getCvvOptionalFilterTouched() { return (Boolean)this.get("cvv_optional_filter_touched"); }
	// }}}
	// {{{
	public void setCvvCodeNotPassedIn(Boolean value) { this.set("cvv_code_not_passed_in", (Object)value); }
 	public Boolean getCvvCodeNotPassedIn() { return (Boolean)this.get("cvv_code_not_passed_in"); }
	// }}}
	// {{{
	public void setOptionalBillingAddressFilterEnabled(Boolean value) { this.set("optional_billing_address_filter_enabled", (Object)value); }
 	public Boolean getOptionalBillingAddressFilterEnabled() { return (Boolean)this.get("optional_billing_address_filter_enabled"); }
	// }}}
	// {{{
	public void setIsRc2Eligible(Boolean value) { this.set("is_rc2_eligible", (Object)value); }
 	public Boolean getIsRc2Eligible() { return (Boolean)this.get("is_rc2_eligible"); }
	// }}}
	// {{{
	public void setPreauthFilterAdjudicationResult(Long value) { this.set("preauth_filter_adjudication_result", (Object)value); }
 	public Long getPreauthFilterAdjudicationResult() { return (Long)this.get("preauth_filter_adjudication_result"); }
	// }}}
	// {{{
	public void setPostauthFilterAdjudicationResult(Long value) { this.set("postauth_filter_adjudication_result", (Object)value); }
 	public Long getPostauthFilterAdjudicationResult() { return (Long)this.get("postauth_filter_adjudication_result"); }
	// }}}
	// {{{
	public void setTriggeredFilterList(String value) { this.set("triggered_filter_list", (Object)value); }
 	public String getTriggeredFilterList() { return (String)this.get("triggered_filter_list"); }
	// }}}
	// {{{
	public void setIsFmfFlagged(Boolean value) { this.set("is_fmf_flagged", (Object)value); }
 	public Boolean getIsFmfFlagged() { return (Boolean)this.get("is_fmf_flagged"); }
	// }}}
	// {{{
	public void setFmfPreference(Long value) { this.set("fmf_preference", (Object)value); }
 	public Long getFmfPreference() { return (Long)this.get("fmf_preference"); }
	// }}}
	// {{{
	public void setRiskFiltersV2(List<RiskFilterV2InfoVO> value) { this.set("risk_filters_v2", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<RiskFilterV2InfoVO> getRiskFiltersV2() { return (List<RiskFilterV2InfoVO>)this.get("risk_filters_v2"); }
	// }}}
	// {{{
	public void setTxnFilterStatus(String value) { this.set("txn_filter_status", (Object)value); }
 	public String getTxnFilterStatus() { return (String)this.get("txn_filter_status"); }
	// }}}
	// {{{
	public void setFmfProductCode(BigInteger value) { this.set("fmf_product_code", (Object)value); }
 	public BigInteger getFmfProductCode() { return (BigInteger)this.get("fmf_product_code"); }
	// }}}
	// {{{
	public void setIsPpCcPaymentFraudFilter(Boolean value) { this.set("is_pp_cc_payment_fraud_filter", (Object)value); }
 	public Boolean getIsPpCcPaymentFraudFilter() { return (Boolean)this.get("is_pp_cc_payment_fraud_filter"); }
	// }}}
	// {{{
	public void setIsDccPaymentFraudFilter(Boolean value) { this.set("is_dcc_payment_fraud_filter", (Object)value); }
 	public Boolean getIsDccPaymentFraudFilter() { return (Boolean)this.get("is_dcc_payment_fraud_filter"); }
	// }}}
	// {{{
	public void setIsVtPaymentFraudFilter(Boolean value) { this.set("is_vt_payment_fraud_filter", (Object)value); }
 	public Boolean getIsVtPaymentFraudFilter() { return (Boolean)this.get("is_vt_payment_fraud_filter"); }
	// }}}
	// {{{
	public void setOverrideDeclineIfAccountRestricted(Boolean value) { this.set("override_decline_if_account_restricted", (Object)value); }
 	public Boolean getOverrideDeclineIfAccountRestricted() { return (Boolean)this.get("override_decline_if_account_restricted"); }
	// }}}
	// {{{
	public void setOverrideDeclineIfCcDisabled(Boolean value) { this.set("override_decline_if_cc_disabled", (Object)value); }
 	public Boolean getOverrideDeclineIfCcDisabled() { return (Boolean)this.get("override_decline_if_cc_disabled"); }
	// }}}
}