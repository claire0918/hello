/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/RiskInternalFundingProposalVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:40 2012 */

package com.paypal.risk;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
  * 
   */

public class RiskInternalFundingProposalVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((20042*20042)<<32)/*<-RiskInternalFundingProposalVO*/+
         		56242/*<-funding_option*/*FundingOptionVO.TYPE_SIGNATURE/*<-FundingOptionVO*/+
         		44429/*<-risk_decision*/*RiskDecisionVO.TYPE_SIGNATURE/*<-RiskDecisionVO*/+
         		34945/*<-risk_decision_additional_1*/*RiskDecisionVO.TYPE_SIGNATURE/*<-RiskDecisionVO*/+
         		34944/*<-risk_decision_additional_2*/*RiskDecisionVO.TYPE_SIGNATURE/*<-RiskDecisionVO*/+
         		34947/*<-risk_decision_additional_3*/*RiskDecisionVO.TYPE_SIGNATURE/*<-RiskDecisionVO*/+
         		62446/*<-internal_ach_risk_decision*/*47/*<-repeating*/*InternalACHRiskDecisionVO.TYPE_SIGNATURE/*<-InternalACHRiskDecisionVO*/+
         		30655/*<-internal_cc_results*/*47/*<-repeating*/*com.paypal.risk.RiskAnalyzeInternalCCResultVO.TYPE_SIGNATURE/*<-Risk::RiskAnalyzeInternalCCResultVO*/+
         		54067/*<-internal_elv_elvecheck_decision*/*47/*<-repeating*/*com.paypal.risk.RiskInternalELVModelOutVO.TYPE_SIGNATURE/*<-Risk::RiskInternalELVModelOutVO*/+
         		65191/*<-internal_idi_risk_results*/*47/*<-repeating*/*com.paypal.risk.RiskAnalyzeIDIResultVO.TYPE_SIGNATURE/*<-Risk::RiskAnalyzeIDIResultVO*/+
         		16324/*<-internal_efl_cc_scores*/*47/*<-repeating*/*com.paypal.risk.WRiskCCTrinityScoreVO.TYPE_SIGNATURE/*<-Risk::WRiskCCTrinityScoreVO*/+
         		36341/*<-hades_action*/*com.paypal.risk.ActionVO.TYPE_SIGNATURE/*<-Risk::ActionVO*/;
 
	public RiskInternalFundingProposalVO() {
		super("Risk::RiskInternalFundingProposalVO", TYPE_SIGNATURE);

 
		set("funding_option", null, "Risk::FundingOptionVO");
 
		set("risk_decision", null, "Risk::RiskDecisionVO");
 
		set("risk_decision_additional_1", null, "Risk::RiskDecisionVO");
 
		set("risk_decision_additional_2", null, "Risk::RiskDecisionVO");
 
		set("risk_decision_additional_3", null, "Risk::RiskDecisionVO");
 
		set("internal_ach_risk_decision", null, "List<Risk::InternalACHRiskDecisionVO>");
 
		set("internal_cc_results", null, "List<Risk::RiskAnalyzeInternalCCResultVO>");
 
		set("internal_elv_elvecheck_decision", null, "List<Risk::RiskInternalELVModelOutVO>");
 
		set("internal_idi_risk_results", null, "List<Risk::RiskAnalyzeIDIResultVO>");
 
		set("internal_efl_cc_scores", null, "List<Risk::WRiskCCTrinityScoreVO>");
 
		set("hades_action", null, "Risk::ActionVO");
	}

	// {{{
	public void setFundingOption(FundingOptionVO value) { this.set("funding_option", (Object)value); }
 	public FundingOptionVO getFundingOption() { return (FundingOptionVO)this.get("funding_option"); }
	// }}}
	// {{{
	public void setRiskDecision(RiskDecisionVO value) { this.set("risk_decision", (Object)value); }
 	public RiskDecisionVO getRiskDecision() { return (RiskDecisionVO)this.get("risk_decision"); }
	// }}}
	// {{{
	public void setRiskDecisionAdditional1(RiskDecisionVO value) { this.set("risk_decision_additional_1", (Object)value); }
 	public RiskDecisionVO getRiskDecisionAdditional1() { return (RiskDecisionVO)this.get("risk_decision_additional_1"); }
	// }}}
	// {{{
	public void setRiskDecisionAdditional2(RiskDecisionVO value) { this.set("risk_decision_additional_2", (Object)value); }
 	public RiskDecisionVO getRiskDecisionAdditional2() { return (RiskDecisionVO)this.get("risk_decision_additional_2"); }
	// }}}
	// {{{
	public void setRiskDecisionAdditional3(RiskDecisionVO value) { this.set("risk_decision_additional_3", (Object)value); }
 	public RiskDecisionVO getRiskDecisionAdditional3() { return (RiskDecisionVO)this.get("risk_decision_additional_3"); }
	// }}}
	// {{{
	public void setInternalAchRiskDecision(List<InternalACHRiskDecisionVO> value) { this.set("internal_ach_risk_decision", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<InternalACHRiskDecisionVO> getInternalAchRiskDecision() { return (List<InternalACHRiskDecisionVO>)this.get("internal_ach_risk_decision"); }
	// }}}
	// {{{
	public void setInternalCcResults(List<com.paypal.risk.RiskAnalyzeInternalCCResultVO> value) { this.set("internal_cc_results", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<com.paypal.risk.RiskAnalyzeInternalCCResultVO> getInternalCcResults() { return (List<com.paypal.risk.RiskAnalyzeInternalCCResultVO>)this.get("internal_cc_results"); }
	// }}}
	// {{{
	public void setInternalElvElvecheckDecision(List<com.paypal.risk.RiskInternalELVModelOutVO> value) { this.set("internal_elv_elvecheck_decision", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<com.paypal.risk.RiskInternalELVModelOutVO> getInternalElvElvecheckDecision() { return (List<com.paypal.risk.RiskInternalELVModelOutVO>)this.get("internal_elv_elvecheck_decision"); }
	// }}}
	// {{{
	public void setInternalIdiRiskResults(List<com.paypal.risk.RiskAnalyzeIDIResultVO> value) { this.set("internal_idi_risk_results", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<com.paypal.risk.RiskAnalyzeIDIResultVO> getInternalIdiRiskResults() { return (List<com.paypal.risk.RiskAnalyzeIDIResultVO>)this.get("internal_idi_risk_results"); }
	// }}}
	// {{{
	public void setInternalEflCcScores(List<com.paypal.risk.WRiskCCTrinityScoreVO> value) { this.set("internal_efl_cc_scores", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<com.paypal.risk.WRiskCCTrinityScoreVO> getInternalEflCcScores() { return (List<com.paypal.risk.WRiskCCTrinityScoreVO>)this.get("internal_efl_cc_scores"); }
	// }}}
	// {{{
	public void setHadesAction(com.paypal.risk.ActionVO value) { this.set("hades_action", (Object)value); }
 	public com.paypal.risk.ActionVO getHadesAction() { return (com.paypal.risk.ActionVO)this.get("hades_action"); }
	// }}}
}