/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/CheckpointInfoVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:40 2012 */

package com.paypal.risk;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
  * 
   */

public class CheckpointInfoVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((15159*15159)<<32)/*<-CheckpointInfoVO*/+
         		62145/*<-account_number*/*46168/*<-ullong*/+
         		48550/*<-checkpoint_number*/*38894/*<-int*/+
         		5764/*<-checkpoint_name*/*18443/*<-String*/;
 
	public CheckpointInfoVO() {
		super("Risk::CheckpointInfoVO", TYPE_SIGNATURE);

 
		set("account_number", null, "ullong");
 
		set("checkpoint_number", null, "int");
 
		set("checkpoint_name", null, "String");
	}

	// {{{
	public void setAccountNumber(BigInteger value) { this.set("account_number", (Object)value); }
 	public BigInteger getAccountNumber() { return (BigInteger)this.get("account_number"); }
	// }}}
	// {{{
	public void setCheckpointNumber(Integer value) { this.set("checkpoint_number", (Object)value); }
 	public Integer getCheckpointNumber() { return (Integer)this.get("checkpoint_number"); }
	// }}}
	// {{{
	public void setCheckpointName(String value) { this.set("checkpoint_name", (Object)value); }
 	public String getCheckpointName() { return (String)this.get("checkpoint_name"); }
	// }}}
}