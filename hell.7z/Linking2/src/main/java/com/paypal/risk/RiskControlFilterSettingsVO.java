/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/RiskControlFilterSettingsVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:40 2012 */

package com.paypal.risk;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
  * 
   */

public class RiskControlFilterSettingsVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((57818*57818)<<32)/*<-RiskControlFilterSettingsVO*/+
         		20533/*<-filter_id*/*33490/*<-ulong*/+
         		32025/*<-action*/*33490/*<-ulong*/+
         		35662/*<-enabled*/*15044/*<-bool*/+
         		49146/*<-filter_info*/*RiskControlFilterInfoVO.TYPE_SIGNATURE/*<-RiskControlFilterInfoVO*/+
         		7893/*<-param*/*RiskControlFilterParamCollectionVO.TYPE_SIGNATURE/*<-RiskControlFilterParamCollectionVO*/;
 
	public RiskControlFilterSettingsVO() {
		super("Risk::RiskControlFilterSettingsVO", TYPE_SIGNATURE);

 
		set("filter_id", null, "ulong");
 
		set("action", null, "ulong");
 
		set("enabled", null, "bool");
 
		set("filter_info", null, "Risk::RiskControlFilterInfoVO");
 
		set("param", null, "Risk::RiskControlFilterParamCollectionVO");
	}

	// {{{
	public void setFilterId(Long value) { this.set("filter_id", (Object)value); }
 	public Long getFilterId() { return (Long)this.get("filter_id"); }
	// }}}
	// {{{
	public void setAction(Long value) { this.set("action", (Object)value); }
 	public Long getAction() { return (Long)this.get("action"); }
	// }}}
	// {{{
	public void setEnabled(Boolean value) { this.set("enabled", (Object)value); }
 	public Boolean getEnabled() { return (Boolean)this.get("enabled"); }
	// }}}
	// {{{
	public void setFilterInfo(RiskControlFilterInfoVO value) { this.set("filter_info", (Object)value); }
 	public RiskControlFilterInfoVO getFilterInfo() { return (RiskControlFilterInfoVO)this.get("filter_info"); }
	// }}}
	// {{{
	public void setParam(RiskControlFilterParamCollectionVO value) { this.set("param", (Object)value); }
 	public RiskControlFilterParamCollectionVO getParam() { return (RiskControlFilterParamCollectionVO)this.get("param"); }
	// }}}
}