/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/RiskAnalyzeUserProfileOptionalVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:40 2012 */

package com.paypal.risk;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
  * 
   */

public class RiskAnalyzeUserProfileOptionalVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((60869*60869)<<32)/*<-RiskAnalyzeUserProfileOptionalVO*/+
         		13575/*<-user_address*/*47/*<-repeating*/*com.paypal.user.AddressVO.TYPE_SIGNATURE/*<-User::AddressVO*/+
         		41613/*<-user_alias*/*47/*<-repeating*/*com.paypal.user.AliasVO.TYPE_SIGNATURE/*<-User::AliasVO*/+
         		8727/*<-counterparty_alias*/*47/*<-repeating*/*com.paypal.user.AliasVO.TYPE_SIGNATURE/*<-User::AliasVO*/+
         		38872/*<-user_publiccredential*/*47/*<-repeating*/*com.paypal.user.PublicCredentialVO.TYPE_SIGNATURE/*<-User::PublicCredentialVO*/+
         		36267/*<-counterparty_publiccredential*/*47/*<-repeating*/*com.paypal.user.PublicCredentialVO.TYPE_SIGNATURE/*<-User::PublicCredentialVO*/+
         		21666/*<-user_email*/*47/*<-repeating*/*com.paypal.user.EmailVO.TYPE_SIGNATURE/*<-User::EmailVO*/+
         		57315/*<-counterparty_email*/*47/*<-repeating*/*com.paypal.user.EmailVO.TYPE_SIGNATURE/*<-User::EmailVO*/+
         		44512/*<-phone_new*/*47/*<-repeating*/*com.paypal.user.PhoneVO.TYPE_SIGNATURE/*<-User::PhoneVO*/+
         		1795/*<-sender_industry*/*com.paypal.merchant.UserIndustryVO.TYPE_SIGNATURE/*<-Merchant::UserIndustryVO*/+
         		27686/*<-counterparty_industry*/*com.paypal.merchant.UserIndustryVO.TYPE_SIGNATURE/*<-Merchant::UserIndustryVO*/+
         		47018/*<-sender_holding*/*com.paypal.risk.RiskHoldingVO.TYPE_SIGNATURE/*<-Risk::RiskHoldingVO*/+
         		2433/*<-user_address_loaded*/*15044/*<-bool*/+
         		7914/*<-user_alias_loaded*/*15044/*<-bool*/+
         		58116/*<-counterparty_alias_loaded*/*15044/*<-bool*/+
         		54651/*<-user_publiccredential_loaded*/*15044/*<-bool*/+
         		56618/*<-counterparty_publiccredential_loaded*/*15044/*<-bool*/+
         		8065/*<-user_email_loaded*/*15044/*<-bool*/+
         		55893/*<-counterparty_email_loaded*/*15044/*<-bool*/+
         		28778/*<-phone_new_loaded*/*15044/*<-bool*/+
         		7439/*<-sender_industry_loaded*/*15044/*<-bool*/+
         		8080/*<-counterparty_industry_loaded*/*15044/*<-bool*/+
         		43573/*<-sender_holding_loaded*/*15044/*<-bool*/+
         		6298/*<-stats_elv_loaded*/*15044/*<-bool*/+
         		4473/*<-stats_elv*/*RiskStatsELVVO.TYPE_SIGNATURE/*<-RiskStatsELVVO*/;
 
	public RiskAnalyzeUserProfileOptionalVO() {
		super("Risk::RiskAnalyzeUserProfileOptionalVO", TYPE_SIGNATURE);

 
		set("user_address", null, "List<User::AddressVO>");
 
		set("user_alias", null, "List<User::AliasVO>");
 
		set("counterparty_alias", null, "List<User::AliasVO>");
 
		set("user_publiccredential", null, "List<User::PublicCredentialVO>");
 
		set("counterparty_publiccredential", null, "List<User::PublicCredentialVO>");
 
		set("user_email", null, "List<User::EmailVO>");
 
		set("counterparty_email", null, "List<User::EmailVO>");
 
		set("phone_new", null, "List<User::PhoneVO>");
 
		set("sender_industry", null, "Merchant::UserIndustryVO");
 
		set("counterparty_industry", null, "Merchant::UserIndustryVO");
 
		set("sender_holding", null, "Risk::RiskHoldingVO");
 
		set("user_address_loaded", null, "bool");
 
		set("user_alias_loaded", null, "bool");
 		addFieldQualifier("counterparty_alias_loaded","default_value","false");
 
		set("counterparty_alias_loaded", new Boolean("false"), "bool");
 
		set("user_publiccredential_loaded", null, "bool");
 		addFieldQualifier("counterparty_publiccredential_loaded","default_value","false");
 
		set("counterparty_publiccredential_loaded", new Boolean("false"), "bool");
 
		set("user_email_loaded", null, "bool");
 		addFieldQualifier("counterparty_email_loaded","default_value","false");
 
		set("counterparty_email_loaded", new Boolean("false"), "bool");
 
		set("phone_new_loaded", null, "bool");
 		addFieldQualifier("sender_industry_loaded","default_value","false");
 
		set("sender_industry_loaded", new Boolean("false"), "bool");
 		addFieldQualifier("counterparty_industry_loaded","default_value","false");
 
		set("counterparty_industry_loaded", new Boolean("false"), "bool");
 
		set("sender_holding_loaded", null, "bool");
 
		set("stats_elv_loaded", null, "bool");
 
		set("stats_elv", null, "Risk::RiskStatsELVVO");
	}

	// {{{
	public void setUserAddress(List<com.paypal.user.AddressVO> value) { this.set("user_address", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<com.paypal.user.AddressVO> getUserAddress() { return (List<com.paypal.user.AddressVO>)this.get("user_address"); }
	// }}}
	// {{{
	public void setUserAlias(List<com.paypal.user.AliasVO> value) { this.set("user_alias", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<com.paypal.user.AliasVO> getUserAlias() { return (List<com.paypal.user.AliasVO>)this.get("user_alias"); }
	// }}}
	// {{{
	public void setCounterpartyAlias(List<com.paypal.user.AliasVO> value) { this.set("counterparty_alias", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<com.paypal.user.AliasVO> getCounterpartyAlias() { return (List<com.paypal.user.AliasVO>)this.get("counterparty_alias"); }
	// }}}
	// {{{
	public void setUserPubliccredential(List<com.paypal.user.PublicCredentialVO> value) { this.set("user_publiccredential", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<com.paypal.user.PublicCredentialVO> getUserPubliccredential() { return (List<com.paypal.user.PublicCredentialVO>)this.get("user_publiccredential"); }
	// }}}
	// {{{
	public void setCounterpartyPubliccredential(List<com.paypal.user.PublicCredentialVO> value) { this.set("counterparty_publiccredential", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<com.paypal.user.PublicCredentialVO> getCounterpartyPubliccredential() { return (List<com.paypal.user.PublicCredentialVO>)this.get("counterparty_publiccredential"); }
	// }}}
	// {{{
	public void setUserEmail(List<com.paypal.user.EmailVO> value) { this.set("user_email", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<com.paypal.user.EmailVO> getUserEmail() { return (List<com.paypal.user.EmailVO>)this.get("user_email"); }
	// }}}
	// {{{
	public void setCounterpartyEmail(List<com.paypal.user.EmailVO> value) { this.set("counterparty_email", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<com.paypal.user.EmailVO> getCounterpartyEmail() { return (List<com.paypal.user.EmailVO>)this.get("counterparty_email"); }
	// }}}
	// {{{
	public void setPhoneNew(List<com.paypal.user.PhoneVO> value) { this.set("phone_new", (Object)value); }
 	@SuppressWarnings("unchecked")
 	public List<com.paypal.user.PhoneVO> getPhoneNew() { return (List<com.paypal.user.PhoneVO>)this.get("phone_new"); }
	// }}}
	// {{{
	public void setSenderIndustry(com.paypal.merchant.UserIndustryVO value) { this.set("sender_industry", (Object)value); }
 	public com.paypal.merchant.UserIndustryVO getSenderIndustry() { return (com.paypal.merchant.UserIndustryVO)this.get("sender_industry"); }
	// }}}
	// {{{
	public void setCounterpartyIndustry(com.paypal.merchant.UserIndustryVO value) { this.set("counterparty_industry", (Object)value); }
 	public com.paypal.merchant.UserIndustryVO getCounterpartyIndustry() { return (com.paypal.merchant.UserIndustryVO)this.get("counterparty_industry"); }
	// }}}
	// {{{
	public void setSenderHolding(com.paypal.risk.RiskHoldingVO value) { this.set("sender_holding", (Object)value); }
 	public com.paypal.risk.RiskHoldingVO getSenderHolding() { return (com.paypal.risk.RiskHoldingVO)this.get("sender_holding"); }
	// }}}
	// {{{
	public void setUserAddressLoaded(Boolean value) { this.set("user_address_loaded", (Object)value); }
 	public Boolean getUserAddressLoaded() { return (Boolean)this.get("user_address_loaded"); }
	// }}}
	// {{{
	public void setUserAliasLoaded(Boolean value) { this.set("user_alias_loaded", (Object)value); }
 	public Boolean getUserAliasLoaded() { return (Boolean)this.get("user_alias_loaded"); }
	// }}}
	// {{{
	public void setCounterpartyAliasLoaded(Boolean value) { this.set("counterparty_alias_loaded", (Object)value); }
 	public Boolean getCounterpartyAliasLoaded() { return (Boolean)this.get("counterparty_alias_loaded"); }
	// }}}
	// {{{
	public void setUserPubliccredentialLoaded(Boolean value) { this.set("user_publiccredential_loaded", (Object)value); }
 	public Boolean getUserPubliccredentialLoaded() { return (Boolean)this.get("user_publiccredential_loaded"); }
	// }}}
	// {{{
	public void setCounterpartyPubliccredentialLoaded(Boolean value) { this.set("counterparty_publiccredential_loaded", (Object)value); }
 	public Boolean getCounterpartyPubliccredentialLoaded() { return (Boolean)this.get("counterparty_publiccredential_loaded"); }
	// }}}
	// {{{
	public void setUserEmailLoaded(Boolean value) { this.set("user_email_loaded", (Object)value); }
 	public Boolean getUserEmailLoaded() { return (Boolean)this.get("user_email_loaded"); }
	// }}}
	// {{{
	public void setCounterpartyEmailLoaded(Boolean value) { this.set("counterparty_email_loaded", (Object)value); }
 	public Boolean getCounterpartyEmailLoaded() { return (Boolean)this.get("counterparty_email_loaded"); }
	// }}}
	// {{{
	public void setPhoneNewLoaded(Boolean value) { this.set("phone_new_loaded", (Object)value); }
 	public Boolean getPhoneNewLoaded() { return (Boolean)this.get("phone_new_loaded"); }
	// }}}
	// {{{
	public void setSenderIndustryLoaded(Boolean value) { this.set("sender_industry_loaded", (Object)value); }
 	public Boolean getSenderIndustryLoaded() { return (Boolean)this.get("sender_industry_loaded"); }
	// }}}
	// {{{
	public void setCounterpartyIndustryLoaded(Boolean value) { this.set("counterparty_industry_loaded", (Object)value); }
 	public Boolean getCounterpartyIndustryLoaded() { return (Boolean)this.get("counterparty_industry_loaded"); }
	// }}}
	// {{{
	public void setSenderHoldingLoaded(Boolean value) { this.set("sender_holding_loaded", (Object)value); }
 	public Boolean getSenderHoldingLoaded() { return (Boolean)this.get("sender_holding_loaded"); }
	// }}}
	// {{{
	public void setStatsElvLoaded(Boolean value) { this.set("stats_elv_loaded", (Object)value); }
 	public Boolean getStatsElvLoaded() { return (Boolean)this.get("stats_elv_loaded"); }
	// }}}
	// {{{
	public void setStatsElv(RiskStatsELVVO value) { this.set("stats_elv", (Object)value); }
 	public RiskStatsELVVO getStatsElv() { return (RiskStatsELVVO)this.get("stats_elv"); }
	// }}}
}