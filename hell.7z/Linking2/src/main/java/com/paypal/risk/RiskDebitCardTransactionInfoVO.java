/* -*- mode: java -*- */ // vim: ft=java
/* Generated from C:/Users/tingzhang/Linking/src/main/resources/omlFiles/RiskDebitCardTransactionInfoVO.oml
 by ASF Java Code Generator
 at ������ 12 06 10:23:40 2012 */

package com.paypal.risk;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import com.paypal.types.Currency;
import com.paypal.vo.ValueObject;

/**
  * 
  * 
   */

public class RiskDebitCardTransactionInfoVO extends ValueObject
{
  	public static final String CODEGEN_VERSION = "1fd708b7479b202ba3de73192002a1ec";
	public static final long TYPE_SIGNATURE = ((49954*49954)<<32)/*<-RiskDebitCardTransactionInfoVO*/+
         		18449/*<-is_pos*/*15044/*<-bool*/+
         		18606/*<-is_pin*/*15044/*<-bool*/+
         		20131/*<-is_hold*/*15044/*<-bool*/+
         		11328/*<-is_denied*/*15044/*<-bool*/+
         		32646/*<-is_forced*/*15044/*<-bool*/+
         		22703/*<-is_reversal*/*15044/*<-bool*/+
         		12106/*<-is_advice*/*15044/*<-bool*/+
         		7472/*<-is_standin*/*15044/*<-bool*/+
         		13322/*<-is_cashadv*/*15044/*<-bool*/+
         		4540/*<-is_adj*/*15044/*<-bool*/+
         		54929/*<-is_settlement*/*15044/*<-bool*/+
         		30318/*<-overdraft_eligible*/*15044/*<-bool*/+
         		20087/*<-overdraft_used*/*15044/*<-bool*/+
         		17172/*<-overdraft_used_at_auth*/*15044/*<-bool*/+
         		64253/*<-is_international*/*15044/*<-bool*/+
         		54014/*<-is_balance_inquiry*/*15044/*<-bool*/+
         		14414/*<-apply_bonus*/*15044/*<-bool*/+
         		2704/*<-apply_fees*/*15044/*<-bool*/+
         		21664/*<-is_credit*/*15044/*<-bool*/+
         		21791/*<-reference_found*/*15044/*<-bool*/+
         		30426/*<-is_preauth*/*15044/*<-bool*/+
         		14217/*<-is_auth*/*15044/*<-bool*/+
         		15692/*<-trace_no*/*18443/*<-String*/+
         		21474/*<-amount*/*21015/*<-Currency*/+
         		4796/*<-interchange_amount*/*21015/*<-Currency*/+
         		25913/*<-replacement_amount*/*21015/*<-Currency*/+
         		5385/*<-memo*/*18443/*<-String*/+
         		13132/*<-merchant_info*/*18443/*<-String*/+
         		39498/*<-trans_id*/*46168/*<-ullong*/+
         		36620/*<-type*/*37752/*<-char*/+
         		34397/*<-xn_date*/*18443/*<-String*/+
         		57050/*<-xn_ref_no*/*18443/*<-String*/+
         		9164/*<-xn_auth_code*/*18443/*<-String*/+
         		58215/*<-xn_time*/*18443/*<-String*/+
         		5507/*<-fee_schedule_id*/*46168/*<-ullong*/+
         		1035/*<-fee_type*/*18443/*<-String*/+
         		62584/*<-retrieval_ref*/*18443/*<-String*/+
         		62145/*<-account_number*/*46168/*<-ullong*/+
         		54037/*<-soft_descriptor*/*18443/*<-String*/+
         		18694/*<-txn_card_ref_id*/*46168/*<-ullong*/+
         		53323/*<-xn_merchant_type*/*18443/*<-String*/+
         		6722/*<-xn_inet_field*/*18443/*<-String*/+
         		13932/*<-card_type*/*33490/*<-ulong*/+
         		40745/*<-bonus_amount*/*21015/*<-Currency*/+
         		6464/*<-fees_amount*/*21015/*<-Currency*/+
         		31289/*<-has_xB_fee*/*15044/*<-bool*/+
         		21509/*<-xB_fee*/*21015/*<-Currency*/+
         		37546/*<-has_xC_fee*/*15044/*<-bool*/+
         		27824/*<-xC_fee*/*21015/*<-Currency*/+
         		34971/*<-has_xC_replacement_fee*/*15044/*<-bool*/+
         		6686/*<-xC_replacement_fee*/*21015/*<-Currency*/+
         		11917/*<-has_sig_international_fee*/*15044/*<-bool*/+
         		42391/*<-sig_international_fee*/*21015/*<-Currency*/+
         		36424/*<-overdraft_amount*/*21015/*<-Currency*/+
         		5030/*<-overdraft_soft_descriptor*/*18443/*<-String*/+
         		42965/*<-overdraft_source*/*51052/*<-uint*/+
         		59881/*<-overdraft_source_id*/*46168/*<-ullong*/+
         		4879/*<-available_overdraft_limit*/*46796/*<-llong*/+
         		40019/*<-reference_transaction_id*/*46168/*<-ullong*/+
         		52796/*<-ref_transaction_amount*/*21015/*<-Currency*/+
         		59821/*<-time_reference_created*/*33490/*<-ulong*/+
         		59524/*<-reference_id*/*46168/*<-ullong*/+
         		23565/*<-auth_match_status*/*51052/*<-uint*/+
         		50454/*<-amount_match_status*/*51052/*<-uint*/+
         		55618/*<-return_amount*/*21015/*<-Currency*/+
         		60232/*<-flags*/*33490/*<-ulong*/+
         		37377/*<-reason*/*37752/*<-char*/+
         		5062/*<-vendor_data*/*18443/*<-String*/;
 
	public RiskDebitCardTransactionInfoVO() {
		super("Risk::RiskDebitCardTransactionInfoVO", TYPE_SIGNATURE);

 
		set("is_pos", null, "bool");
 
		set("is_pin", null, "bool");
 
		set("is_hold", null, "bool");
 
		set("is_denied", null, "bool");
 
		set("is_forced", null, "bool");
 
		set("is_reversal", null, "bool");
 
		set("is_advice", null, "bool");
 
		set("is_standin", null, "bool");
 
		set("is_cashadv", null, "bool");
 
		set("is_adj", null, "bool");
 
		set("is_settlement", null, "bool");
 
		set("overdraft_eligible", null, "bool");
 
		set("overdraft_used", null, "bool");
 
		set("overdraft_used_at_auth", null, "bool");
 
		set("is_international", null, "bool");
 
		set("is_balance_inquiry", null, "bool");
 
		set("apply_bonus", null, "bool");
 
		set("apply_fees", null, "bool");
 
		set("is_credit", null, "bool");
 
		set("reference_found", null, "bool");
 
		set("is_preauth", null, "bool");
 
		set("is_auth", null, "bool");
 
		set("trace_no", null, "String");
 
		set("amount", null, "Currency");
 
		set("interchange_amount", null, "Currency");
 
		set("replacement_amount", null, "Currency");
 
		set("memo", null, "String");
 
		set("merchant_info", null, "String");
 
		set("trans_id", null, "ullong");
 
		set("type", null, "char");
 
		set("xn_date", null, "String");
 
		set("xn_ref_no", null, "String");
 
		set("xn_auth_code", null, "String");
 
		set("xn_time", null, "String");
 
		set("fee_schedule_id", null, "ullong");
 
		set("fee_type", null, "String");
 
		set("retrieval_ref", null, "String");
 
		set("account_number", null, "ullong");
 
		set("soft_descriptor", null, "String");
 
		set("txn_card_ref_id", null, "ullong");
 
		set("xn_merchant_type", null, "String");
 
		set("xn_inet_field", null, "String");
 
		set("card_type", null, "ulong");
 
		set("bonus_amount", null, "Currency");
 
		set("fees_amount", null, "Currency");
 
		set("has_xB_fee", null, "bool");
 
		set("xB_fee", null, "Currency");
 
		set("has_xC_fee", null, "bool");
 
		set("xC_fee", null, "Currency");
 
		set("has_xC_replacement_fee", null, "bool");
 
		set("xC_replacement_fee", null, "Currency");
 
		set("has_sig_international_fee", null, "bool");
 
		set("sig_international_fee", null, "Currency");
 
		set("overdraft_amount", null, "Currency");
 
		set("overdraft_soft_descriptor", null, "String");
 
		set("overdraft_source", null, "uint");
 
		set("overdraft_source_id", null, "ullong");
 
		set("available_overdraft_limit", null, "llong");
 
		set("reference_transaction_id", null, "ullong");
 
		set("ref_transaction_amount", null, "Currency");
 
		set("time_reference_created", null, "ulong");
 
		set("reference_id", null, "ullong");
 
		set("auth_match_status", null, "uint");
 
		set("amount_match_status", null, "uint");
 
		set("return_amount", null, "Currency");
 
		set("flags", null, "ulong");
 
		set("reason", null, "char");
 
		set("vendor_data", null, "String");
	}

	// {{{
	public void setIsPos(Boolean value) { this.set("is_pos", (Object)value); }
 	public Boolean getIsPos() { return (Boolean)this.get("is_pos"); }
	// }}}
	// {{{
	public void setIsPin(Boolean value) { this.set("is_pin", (Object)value); }
 	public Boolean getIsPin() { return (Boolean)this.get("is_pin"); }
	// }}}
	// {{{
	public void setIsHold(Boolean value) { this.set("is_hold", (Object)value); }
 	public Boolean getIsHold() { return (Boolean)this.get("is_hold"); }
	// }}}
	// {{{
	public void setIsDenied(Boolean value) { this.set("is_denied", (Object)value); }
 	public Boolean getIsDenied() { return (Boolean)this.get("is_denied"); }
	// }}}
	// {{{
	public void setIsForced(Boolean value) { this.set("is_forced", (Object)value); }
 	public Boolean getIsForced() { return (Boolean)this.get("is_forced"); }
	// }}}
	// {{{
	public void setIsReversal(Boolean value) { this.set("is_reversal", (Object)value); }
 	public Boolean getIsReversal() { return (Boolean)this.get("is_reversal"); }
	// }}}
	// {{{
	public void setIsAdvice(Boolean value) { this.set("is_advice", (Object)value); }
 	public Boolean getIsAdvice() { return (Boolean)this.get("is_advice"); }
	// }}}
	// {{{
	public void setIsStandin(Boolean value) { this.set("is_standin", (Object)value); }
 	public Boolean getIsStandin() { return (Boolean)this.get("is_standin"); }
	// }}}
	// {{{
	public void setIsCashadv(Boolean value) { this.set("is_cashadv", (Object)value); }
 	public Boolean getIsCashadv() { return (Boolean)this.get("is_cashadv"); }
	// }}}
	// {{{
	public void setIsAdj(Boolean value) { this.set("is_adj", (Object)value); }
 	public Boolean getIsAdj() { return (Boolean)this.get("is_adj"); }
	// }}}
	// {{{
	public void setIsSettlement(Boolean value) { this.set("is_settlement", (Object)value); }
 	public Boolean getIsSettlement() { return (Boolean)this.get("is_settlement"); }
	// }}}
	// {{{
	public void setOverdraftEligible(Boolean value) { this.set("overdraft_eligible", (Object)value); }
 	public Boolean getOverdraftEligible() { return (Boolean)this.get("overdraft_eligible"); }
	// }}}
	// {{{
	public void setOverdraftUsed(Boolean value) { this.set("overdraft_used", (Object)value); }
 	public Boolean getOverdraftUsed() { return (Boolean)this.get("overdraft_used"); }
	// }}}
	// {{{
	public void setOverdraftUsedAtAuth(Boolean value) { this.set("overdraft_used_at_auth", (Object)value); }
 	public Boolean getOverdraftUsedAtAuth() { return (Boolean)this.get("overdraft_used_at_auth"); }
	// }}}
	// {{{
	public void setIsInternational(Boolean value) { this.set("is_international", (Object)value); }
 	public Boolean getIsInternational() { return (Boolean)this.get("is_international"); }
	// }}}
	// {{{
	public void setIsBalanceInquiry(Boolean value) { this.set("is_balance_inquiry", (Object)value); }
 	public Boolean getIsBalanceInquiry() { return (Boolean)this.get("is_balance_inquiry"); }
	// }}}
	// {{{
	public void setApplyBonus(Boolean value) { this.set("apply_bonus", (Object)value); }
 	public Boolean getApplyBonus() { return (Boolean)this.get("apply_bonus"); }
	// }}}
	// {{{
	public void setApplyFees(Boolean value) { this.set("apply_fees", (Object)value); }
 	public Boolean getApplyFees() { return (Boolean)this.get("apply_fees"); }
	// }}}
	// {{{
	public void setIsCredit(Boolean value) { this.set("is_credit", (Object)value); }
 	public Boolean getIsCredit() { return (Boolean)this.get("is_credit"); }
	// }}}
	// {{{
	public void setReferenceFound(Boolean value) { this.set("reference_found", (Object)value); }
 	public Boolean getReferenceFound() { return (Boolean)this.get("reference_found"); }
	// }}}
	// {{{
	public void setIsPreauth(Boolean value) { this.set("is_preauth", (Object)value); }
 	public Boolean getIsPreauth() { return (Boolean)this.get("is_preauth"); }
	// }}}
	// {{{
	public void setIsAuth(Boolean value) { this.set("is_auth", (Object)value); }
 	public Boolean getIsAuth() { return (Boolean)this.get("is_auth"); }
	// }}}
	// {{{
	public void setTraceNo(String value) { this.set("trace_no", (Object)value); }
 	public String getTraceNo() { return (String)this.get("trace_no"); }
	// }}}
	// {{{
	public void setAmount(Currency value) { this.set("amount", (Object)value); }
 	public Currency getAmount() { return (Currency)this.get("amount"); }
	// }}}
	// {{{
	public void setInterchangeAmount(Currency value) { this.set("interchange_amount", (Object)value); }
 	public Currency getInterchangeAmount() { return (Currency)this.get("interchange_amount"); }
	// }}}
	// {{{
	public void setReplacementAmount(Currency value) { this.set("replacement_amount", (Object)value); }
 	public Currency getReplacementAmount() { return (Currency)this.get("replacement_amount"); }
	// }}}
	// {{{
	public void setMemo(String value) { this.set("memo", (Object)value); }
 	public String getMemo() { return (String)this.get("memo"); }
	// }}}
	// {{{
	public void setMerchantInfo(String value) { this.set("merchant_info", (Object)value); }
 	public String getMerchantInfo() { return (String)this.get("merchant_info"); }
	// }}}
	// {{{
	public void setTransId(BigInteger value) { this.set("trans_id", (Object)value); }
 	public BigInteger getTransId() { return (BigInteger)this.get("trans_id"); }
	// }}}
	// {{{
	public void setType(Byte value) { this.set("type", (Object)value); }
 	public Byte getType() { return (Byte)this.get("type"); }
	// }}}
	// {{{
	public void setXnDate(String value) { this.set("xn_date", (Object)value); }
 	public String getXnDate() { return (String)this.get("xn_date"); }
	// }}}
	// {{{
	public void setXnRefNo(String value) { this.set("xn_ref_no", (Object)value); }
 	public String getXnRefNo() { return (String)this.get("xn_ref_no"); }
	// }}}
	// {{{
	public void setXnAuthCode(String value) { this.set("xn_auth_code", (Object)value); }
 	public String getXnAuthCode() { return (String)this.get("xn_auth_code"); }
	// }}}
	// {{{
	public void setXnTime(String value) { this.set("xn_time", (Object)value); }
 	public String getXnTime() { return (String)this.get("xn_time"); }
	// }}}
	// {{{
	public void setFeeScheduleId(BigInteger value) { this.set("fee_schedule_id", (Object)value); }
 	public BigInteger getFeeScheduleId() { return (BigInteger)this.get("fee_schedule_id"); }
	// }}}
	// {{{
	public void setFeeType(String value) { this.set("fee_type", (Object)value); }
 	public String getFeeType() { return (String)this.get("fee_type"); }
	// }}}
	// {{{
	public void setRetrievalRef(String value) { this.set("retrieval_ref", (Object)value); }
 	public String getRetrievalRef() { return (String)this.get("retrieval_ref"); }
	// }}}
	// {{{
	public void setAccountNumber(BigInteger value) { this.set("account_number", (Object)value); }
 	public BigInteger getAccountNumber() { return (BigInteger)this.get("account_number"); }
	// }}}
	// {{{
	public void setSoftDescriptor(String value) { this.set("soft_descriptor", (Object)value); }
 	public String getSoftDescriptor() { return (String)this.get("soft_descriptor"); }
	// }}}
	// {{{
	public void setTxnCardRefId(BigInteger value) { this.set("txn_card_ref_id", (Object)value); }
 	public BigInteger getTxnCardRefId() { return (BigInteger)this.get("txn_card_ref_id"); }
	// }}}
	// {{{
	public void setXnMerchantType(String value) { this.set("xn_merchant_type", (Object)value); }
 	public String getXnMerchantType() { return (String)this.get("xn_merchant_type"); }
	// }}}
	// {{{
	public void setXnInetField(String value) { this.set("xn_inet_field", (Object)value); }
 	public String getXnInetField() { return (String)this.get("xn_inet_field"); }
	// }}}
	// {{{
	public void setCardType(Long value) { this.set("card_type", (Object)value); }
 	public Long getCardType() { return (Long)this.get("card_type"); }
	// }}}
	// {{{
	public void setBonusAmount(Currency value) { this.set("bonus_amount", (Object)value); }
 	public Currency getBonusAmount() { return (Currency)this.get("bonus_amount"); }
	// }}}
	// {{{
	public void setFeesAmount(Currency value) { this.set("fees_amount", (Object)value); }
 	public Currency getFeesAmount() { return (Currency)this.get("fees_amount"); }
	// }}}
	// {{{
	public void setHasXBFee(Boolean value) { this.set("has_xB_fee", (Object)value); }
 	public Boolean getHasXBFee() { return (Boolean)this.get("has_xB_fee"); }
	// }}}
	// {{{
	public void setXBFee(Currency value) { this.set("xB_fee", (Object)value); }
 	public Currency getXBFee() { return (Currency)this.get("xB_fee"); }
	// }}}
	// {{{
	public void setHasXCFee(Boolean value) { this.set("has_xC_fee", (Object)value); }
 	public Boolean getHasXCFee() { return (Boolean)this.get("has_xC_fee"); }
	// }}}
	// {{{
	public void setXCFee(Currency value) { this.set("xC_fee", (Object)value); }
 	public Currency getXCFee() { return (Currency)this.get("xC_fee"); }
	// }}}
	// {{{
	public void setHasXCReplacementFee(Boolean value) { this.set("has_xC_replacement_fee", (Object)value); }
 	public Boolean getHasXCReplacementFee() { return (Boolean)this.get("has_xC_replacement_fee"); }
	// }}}
	// {{{
	public void setXCReplacementFee(Currency value) { this.set("xC_replacement_fee", (Object)value); }
 	public Currency getXCReplacementFee() { return (Currency)this.get("xC_replacement_fee"); }
	// }}}
	// {{{
	public void setHasSigInternationalFee(Boolean value) { this.set("has_sig_international_fee", (Object)value); }
 	public Boolean getHasSigInternationalFee() { return (Boolean)this.get("has_sig_international_fee"); }
	// }}}
	// {{{
	public void setSigInternationalFee(Currency value) { this.set("sig_international_fee", (Object)value); }
 	public Currency getSigInternationalFee() { return (Currency)this.get("sig_international_fee"); }
	// }}}
	// {{{
	public void setOverdraftAmount(Currency value) { this.set("overdraft_amount", (Object)value); }
 	public Currency getOverdraftAmount() { return (Currency)this.get("overdraft_amount"); }
	// }}}
	// {{{
	public void setOverdraftSoftDescriptor(String value) { this.set("overdraft_soft_descriptor", (Object)value); }
 	public String getOverdraftSoftDescriptor() { return (String)this.get("overdraft_soft_descriptor"); }
	// }}}
	// {{{
	public void setOverdraftSource(Long value) { this.set("overdraft_source", (Object)value); }
 	public Long getOverdraftSource() { return (Long)this.get("overdraft_source"); }
	// }}}
	// {{{
	public void setOverdraftSourceId(BigInteger value) { this.set("overdraft_source_id", (Object)value); }
 	public BigInteger getOverdraftSourceId() { return (BigInteger)this.get("overdraft_source_id"); }
	// }}}
	// {{{
	public void setAvailableOverdraftLimit(Long value) { this.set("available_overdraft_limit", (Object)value); }
 	public Long getAvailableOverdraftLimit() { return (Long)this.get("available_overdraft_limit"); }
	// }}}
	// {{{
	public void setReferenceTransactionId(BigInteger value) { this.set("reference_transaction_id", (Object)value); }
 	public BigInteger getReferenceTransactionId() { return (BigInteger)this.get("reference_transaction_id"); }
	// }}}
	// {{{
	public void setRefTransactionAmount(Currency value) { this.set("ref_transaction_amount", (Object)value); }
 	public Currency getRefTransactionAmount() { return (Currency)this.get("ref_transaction_amount"); }
	// }}}
	// {{{
	public void setTimeReferenceCreated(Long value) { this.set("time_reference_created", (Object)value); }
 	public Long getTimeReferenceCreated() { return (Long)this.get("time_reference_created"); }
	// }}}
	// {{{
	public void setReferenceId(BigInteger value) { this.set("reference_id", (Object)value); }
 	public BigInteger getReferenceId() { return (BigInteger)this.get("reference_id"); }
	// }}}
	// {{{
	public void setAuthMatchStatus(Long value) { this.set("auth_match_status", (Object)value); }
 	public Long getAuthMatchStatus() { return (Long)this.get("auth_match_status"); }
	// }}}
	// {{{
	public void setAmountMatchStatus(Long value) { this.set("amount_match_status", (Object)value); }
 	public Long getAmountMatchStatus() { return (Long)this.get("amount_match_status"); }
	// }}}
	// {{{
	public void setReturnAmount(Currency value) { this.set("return_amount", (Object)value); }
 	public Currency getReturnAmount() { return (Currency)this.get("return_amount"); }
	// }}}
	// {{{
	public void setFlags(Long value) { this.set("flags", (Object)value); }
 	public Long getFlags() { return (Long)this.get("flags"); }
	// }}}
	// {{{
	public void setReason(Byte value) { this.set("reason", (Object)value); }
 	public Byte getReason() { return (Byte)this.get("reason"); }
	// }}}
	// {{{
	public void setVendorData(String value) { this.set("vendor_data", (Object)value); }
 	public String getVendorData() { return (String)this.get("vendor_data"); }
	// }}}
}